package com.aia.case360.web.pojo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;

import org.apache.commons.lang.StringUtils;

public class ClaimForDocumentView {

	private String claimNo;
	private String childClaimNo;
	private String oldClaimNo;
	private String compNo;
	private String polNo;
	private String claimReqDate;
	private String admissionDate;
	private String claimType;
	private String childClaimType;
	private String claimStatus;
	private String claimStatusCode;
	private String calculationCode;
	private String incidentDate;
	private String lastUpdateDate;
	private String keyPol;
	private String lastAssessor;
	private String isFinal;

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public String getChildClaimNo() {
		return childClaimNo;
	}

	public void setChildClaimNo(String childClaimNo) {
		this.childClaimNo = childClaimNo;
	}

	public String getOldClaimNo() {
		return oldClaimNo;
	}

	public void setOldClaimNo(String oldClaimNo) {
		this.oldClaimNo = oldClaimNo;
	}

	public String getCompNo() {
		return compNo;
	}

	public void setCompNo(String compNo) {
		this.compNo = compNo;
	}

	public String getPolNo() {
		return polNo;
	}

	public void setPolNo(String polNo) {
		this.polNo = polNo;
	}

	public String getClaimType() {
		return claimType;
	}

	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}

	public String getChildClaimType() {
		return childClaimType;
	}

	public void setChildClaimType(String childClaimType) {
		this.childClaimType = childClaimType;
	}

	public String getClaimStatus() {
		return claimStatus;
	}

	public void setClaimStatus(String claimStatus) {
		this.claimStatus = claimStatus;
	}

	public String getClaimStatusCode() {
		return claimStatusCode;
	}

	public void setClaimStatusCode(String claimStatusCode) {
		this.claimStatusCode = claimStatusCode;
	}

	public String getCalculationCode() {
		return calculationCode;
	}

	public void setCalculationCode(String calculationCode) {
		this.calculationCode = calculationCode;
	}

	public String getKeyPol() {
		return keyPol;
	}

	public void setKeyPol(String keyPol) {
		this.keyPol = keyPol;
	}

	public String getLastAssessor() {
		return lastAssessor;
	}

	public void setLastAssessor(String lastAssessor) {
		this.lastAssessor = lastAssessor;
	}

	public String getIsFinal() {
		return isFinal;
	}

	public void setIsFinal(String isFinal) {
		this.isFinal = isFinal;
	}

	public String getClaimReqDate() {
		return claimReqDate;
	}

	public void setClaimReqDate(String claimReqDate) {
		this.claimReqDate = claimReqDate;
	}

	public String getAdmissionDate() {
		return admissionDate;
	}

	public void setAdmissionDate(String admissionDate) {
		this.admissionDate = admissionDate;
	}

	public String getIncidentDate() {
		return incidentDate;
	}

	public void setIncidentDate(String incidentDate) {
		this.incidentDate = incidentDate;
	}

	public String getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(String lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public void mergeFollowupClaim(ClaimForDocumentView followupClaim) {
		this.setOldClaimNo(followupClaim.getOldClaimNo());
		this.setClaimType(followupClaim.getClaimType());
		this.setChildClaimType("old");
		this.setClaimStatus("Closed");
		this.setClaimStatusCode("CC");
		this.setCalculationCode("0");
		this.setIncidentDate(followupClaim.getIncidentDate());
		this.setLastAssessor(followupClaim.getLastAssessor());
	}

	public void refreshClaimNo() {
		String t = this.oldClaimNo;
		if (StringUtils.isNotEmpty(t) && t.trim().length() == 10) {
			claimNo = oldClaimNo;
		}
	}

	public String getClaimMergeFlag() {
		return this.childClaimNo + "_" + this.claimReqDate;
	}

	public String getClaimNoAndChild() {
		return this.claimNo + "_" + this.childClaimNo;
	}

	// ClaimForDocumentView other,ClaimForDocumentView followupClaim
	public boolean equalsClaimNoAndChild(ClaimForDocumentView other) {
		if (other == null) {
			return false;
		}
		if (StringUtils.isEmpty(claimNo)) {
			return false;
		}
		if (getClass() != other.getClass()) {
			return false;
		}
		if (!StringUtils.equals(keyPol, other.getKeyPol())) {
			return false;
		}
		if (!StringUtils.equals(claimNo.trim(), other.getClaimNoAndChild().trim())) {
			return false;
		}
		return true;
	}

	SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");

	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		ClaimForDocumentView other = (ClaimForDocumentView) obj;
		if (!StringUtils.equals(childClaimNo, other.getChildClaimNo())) {
			return false;
		}
		if (StringUtils.isEmpty(claimReqDate) || StringUtils.isEmpty(other.getClaimReqDate())) {
			return false;
		}

		try {
			Date d1 = sf.parse(claimReqDate.trim());
			Date d2 = sf.parse(other.getClaimReqDate().trim());
			if (d1.compareTo(d2) != 0) {
				return false;
			}
		} catch (ParseException e) {
			 
			return false;
		}

		return true;
	}

	@Override
	public int hashCode() {
		return Objects.hash(claimNo,
				childClaimNo,
				oldClaimNo,
				compNo,
				polNo,
				claimReqDate,
				admissionDate,
				claimType,
				childClaimType,
				claimStatus,
				claimStatusCode,
				calculationCode,
				incidentDate,
				lastUpdateDate,
				keyPol,
				lastAssessor,
				isFinal);
//		int result = claimNo.hashCode() + childClaimNo.hashCode() + oldClaimNo.hashCode() + compNo.hashCode()
//				+ polNo.hashCode() + claimReqDate.hashCode() + admissionDate.hashCode() + claimType.hashCode()
//				+ childClaimType.hashCode() + claimStatus.hashCode() + claimStatusCode.hashCode()
//				+ calculationCode.hashCode() + incidentDate.hashCode() + lastUpdateDate.hashCode() + keyPol.hashCode()
//				+ lastAssessor.hashCode() + isFinal.hashCode();
//		return result;

	}

	@Override
	public String toString() {
		return "ClaimForDocumentView [claimNo=" + claimNo + ", childClaimNo=" + childClaimNo + ", oldClaimNo="
				+ oldClaimNo + ", compNo=" + compNo + ", polNo=" + polNo + ", claimReqDate=" + claimReqDate
				+ ", admissionDate=" + admissionDate + ", claimType=" + claimType + ", childClaimType=" + childClaimType
				+ ", claimStatus=" + claimStatus + ", claimStatusCode=" + claimStatusCode + ", calculationCode="
				+ calculationCode + ", incidentDate=" + incidentDate + ", lastUpdateDate=" + lastUpdateDate
				+ ", keyPol=" + keyPol + ", lastAssessor=" + lastAssessor + ", isFinal=" + isFinal + ", sf=" + sf + "]";
	}

}
