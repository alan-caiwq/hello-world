package com.aia.case360.web.pojo;

import java.util.Date;

public class FdCaseCheckListVO {

	private String acl;
	private int sRowId;
	private String createdBy;
	private Date createdTS;
	private String lastUpdatedBy;
	private Date lastUpsatedTS;
	private int isCompleted;
	private int linkCaseId;
	private String helpText;
	private int isMandatory;
	private int sequenceNum;
	private String checkItemNm;
	private String workStepName;
	private int versionNum;

	public String getAcl() {
		return acl;
	}

	public void setAcl(String acl) {
		this.acl = acl;
	}

	public int getsRowId() {
		return sRowId;
	}

	public void setsRowId(int sRowId) {
		this.sRowId = sRowId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public int getIsCompleted() {
		return isCompleted;
	}

	public void setIsCompleted(int isCompleted) {
		this.isCompleted = isCompleted;
	}

	public int getLinkCaseId() {
		return linkCaseId;
	}

	public void setLinkCaseId(int linkCaseId) {
		this.linkCaseId = linkCaseId;
	}

	public String getHelpText() {
		return helpText;
	}

	public void setHelpText(String helpText) {
		this.helpText = helpText;
	}

	public int getIsMandatory() {
		return isMandatory;
	}

	public void setIsMandatory(int isMandatory) {
		this.isMandatory = isMandatory;
	}

	public int getSequenceNum() {
		return sequenceNum;
	}

	public void setSequenceNum(int sequenceNum) {
		this.sequenceNum = sequenceNum;
	}

	public String getCheckItemNm() {
		return checkItemNm;
	}

	public void setCheckItemNm(String checkItemNm) {
		this.checkItemNm = checkItemNm;
	}

	public String getWorkStepName() {
		return workStepName;
	}

	public void setWorkStepName(String workStepName) {
		this.workStepName = workStepName;
	}

	public int getVersionNum() {
		return versionNum;
	}

	public void setVersionNum(int versionNum) {
		this.versionNum = versionNum;
	}

	public Date getCreatedTS() {
		return createdTS;
	}

	public void setCreatedTS(Date createdTS) {
		this.createdTS = createdTS;
	}

	public Date getLastUpsatedTS() {
		return lastUpsatedTS;
	}

	public void setLastUpsatedTS(Date lastUpsatedTS) {
		this.lastUpsatedTS = lastUpsatedTS;
	}

}
