package com.aia.case360.web.pojo;

import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FdDocAuditTrail{
  
  protected Logger m_Logger = LoggerFactory.getLogger(getClass());
  
  private String createdBy;
  private Date createdTimestamp;
  private String fromBatchNo;
  private String fromBoxNo;
  private String fromComCd;
  private String fromFormId;
  private String fromLinkInd;
  private String fromObjectId;
  private String fromPageNo;
  private String fromPolNum;
  private String fromProcessType;
  private Date fromReceivedDt;
  private String fromReqNo;
  private String fromStatusInd;
  private String fromVerified;
  private String frsReqNo;
  private String other;
  private String sysAct;
  private String toBatchNo;
  private String toBoxNo;
  private String toComCd;
  private String toFormId;
  private String toLinkInd;
  private String toObjectId;
  private String toPageNo;
  private String toPolNum;
  private String toProcessType;
  private Date toReceivedDt;
  private String toReqNo;
  private String toStatusInd;
  private String toVerified;
  private String userAct;
  private String receiveddate;
  private String reqreceiveddate;
  private short isResolved;
	private String logicalLinkId;
  private String activityId;
  private String fromClaimNo;
  private String toClaimNo;
  private String fromNric;
  private String toNric;
  private String sRowid;
  public short getIsResolved() {
    return isResolved;
  }

  public void setIsResolved(short isResolved) {
    this.isResolved = isResolved;
  }

  public String getLogicalLinkId() {
    return logicalLinkId;
  }

  public void setLogicalLinkId(String logicalLinkId) {
    this.logicalLinkId = logicalLinkId;
  }

  public String getActivityId() {
    return activityId;
  }

  public void setActivityId(String activityId) {
    this.activityId = activityId;
  }

  public String getCreatedBy() {
    return createdBy;
  }

  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  public Date getCreatedTimestamp() {
    return createdTimestamp;
  }

  public void setCreatedTimestamp(Date createdTimestamp) {
    this.createdTimestamp = createdTimestamp;
  }

  public String getFromBatchNo() {
    return fromBatchNo;
  }

  public void setFromBatchNo(String fromBatchNo) {
    this.fromBatchNo = fromBatchNo;
  }

  public String getFromBoxNo() {
    return fromBoxNo;
  }

  public void setFromBoxNo(String fromBoxNo) {
    this.fromBoxNo = fromBoxNo;
  }

  public String getFromComCd() {
    return fromComCd;
  }

  public void setFromComCd(String fromComCd) {
    this.fromComCd = fromComCd;
  }

  public String getFromFormId() {
    return fromFormId;
  }

  public void setFromFormId(String fromFormId) {
    this.fromFormId = fromFormId;
  }

  public String getFromLinkInd() {
    return fromLinkInd;
  }

  public void setFromLinkInd(String fromLinkInd) {
    this.fromLinkInd = fromLinkInd;
  }

  public String getFromObjectId() {
    return fromObjectId;
  }

  public void setFromObjectId(String fromObjectId) {
    this.fromObjectId = fromObjectId;
  }

  public String getFromPageNo() {
    return fromPageNo;
  }

  public void setFromPageNo(String fromPageNo) {
    this.fromPageNo = fromPageNo;
  }

  public String getFromPolNum() {
    return fromPolNum;
  }

  public void setFromPolNum(String fromPolNum) {
    this.fromPolNum = fromPolNum;
  }

  public String getFromProcessType() {
    return fromProcessType;
  }

  public void setFromProcessType(String fromProcessType) {
    this.fromProcessType = fromProcessType;
  }

  public String getFromReqNo() {
    return fromReqNo;
  }

  public void setFromReqNo(String fromReqNo) {
    this.fromReqNo = fromReqNo;
  }

  public String getFromStatusInd() {
    return fromStatusInd;
  }

  public void setFromStatusInd(String fromStatusInd) {
    this.fromStatusInd = fromStatusInd;
  }

  public String getFromVerified() {
    return fromVerified;
  }

  public void setFromVerified(String fromVerified) {
    this.fromVerified = fromVerified;
  }

  public String getFrsReqNo() {
    return frsReqNo;
  }

  public void setFrsReqNo(String frsReqNo) {
    this.frsReqNo = frsReqNo;
  }

  public String getOther() {
    return other;
  }

  public void setOther(String other) {
    this.other = other;
  }

  public String getSysAct() {
    return sysAct;
  }

  public void setSysAct(String sysAct) {
    this.sysAct = sysAct;
  }

  public String getToBatchNo() {
    return toBatchNo;
  }

  public void setToBatchNo(String toBatchNo) {
    this.toBatchNo = toBatchNo;
  }

  public String getToBoxNo() {
    return toBoxNo;
  }

  public void setToBoxNo(String toBoxNo) {
    this.toBoxNo = toBoxNo;
  }

  public String getToComCd() {
    return toComCd;
  }

  public void setToComCd(String toComCd) {
    this.toComCd = toComCd;
  }

  public String getToFormId() {
    return toFormId;
  }

  public void setToFormId(String toFormId) {
    this.toFormId = toFormId;
  }

  public String getToLinkInd() {
    return toLinkInd;
  }

  public void setToLinkInd(String toLinkInd) {
    this.toLinkInd = toLinkInd;
  }

  public String getToObjectId() {
    return toObjectId;
  }

  public void setToObjectId(String toObjectId) {
    this.toObjectId = toObjectId;
  }

  public String getToPageNo() {
    return toPageNo;
  }

  public void setToPageNo(String toPageNo) {
    this.toPageNo = toPageNo;
  }

  public String getToPolNum() {
    return toPolNum;
  }

  public void setToPolNum(String toPolNum) {
    this.toPolNum = toPolNum;
  }

  public String getToProcessType() {
    return toProcessType;
  }

  public void setToProcessType(String toProcessType) {
    this.toProcessType = toProcessType;
  }

  public String getToReqNo() {
    return toReqNo;
  }

  public void setToReqNo(String toReqNo) {
    this.toReqNo = toReqNo;
  }

  public String getToStatusInd() {
    return toStatusInd;
  }

  public void setToStatusInd(String toStatusInd) {
    this.toStatusInd = toStatusInd;
  }

  public String getToVerified() {
    return toVerified;
  }

  public void setToVerified(String toVerified) {
    this.toVerified = toVerified;
  }

  public String getUserAct() {
    return userAct;
  }

  public void setUserAct(String userAct) {
    this.userAct = userAct;
  }

  public Date getFromReceivedDt() {
    return fromReceivedDt;
  }

  public void setFromReceivedDt(Date fromReceivedDt) {
    this.fromReceivedDt = fromReceivedDt;
  }

  public Date getToReceivedDt() {
    return toReceivedDt;
  }

  public void setToReceivedDt(Date toReceivedDt) {
    this.toReceivedDt = toReceivedDt;
  }

  public String getReceiveddate() {
	return receiveddate;
	}

	public void setReceiveddate(String receiveddate) {
	this.receiveddate = receiveddate;
	}

	public String getReqreceiveddate() {
	return reqreceiveddate;
	}

	public void setReqreceiveddate(String reqreceiveddate) {
	this.reqreceiveddate = reqreceiveddate;
	}

  public String getsRowid() {
	return sRowid;
	}

	public void setsRowid(String sRowid) {
	this.sRowid = sRowid;
	}

	/**
 * @return the fromClaimNo
 */
	public String getFromClaimNo() {
  return fromClaimNo;
	}

	/**
 * @return the toClaimNo
 */
	public String getToClaimNo() {
  return toClaimNo;
	}

	/**
 * @param fromClaimNo the fromClaimNo to set
 */
	public void setFromClaimNo(String fromClaimNo) {
  this.fromClaimNo = fromClaimNo;
	}

	/**
 * @param toClaimNo the toClaimNo to set
 */
	public void setToClaimNo(String toClaimNo) {
  this.toClaimNo = toClaimNo;
	}

	/**
 * @return the fromNric
 */
	public String getFromNric() {
  return fromNric;
	}

	/**
 * @return the toNric
 */
	public String getToNric() {
  return toNric;
	}

	/**
 * @param fromNric the fromNric to set
 */
	public void setFromNric(String fromNric) {
  this.fromNric = fromNric;
	}

	/**
 * @param toNric the toNric to set
 */
	public void setToNric(String toNric) {
  this.toNric = toNric;
}

public Object getInstance() { 
    FdDocAuditTrail docATrail = new FdDocAuditTrail(); 
      docATrail.setActivityId(activityId);
	  docATrail.setCreatedBy(createdBy);
	  docATrail.setCreatedTimestamp(createdTimestamp);
	  docATrail.setFromBatchNo(fromBatchNo);
	  docATrail.setFromBoxNo(fromBoxNo);
	  docATrail.setFromClaimNo(fromClaimNo);
	  docATrail.setFromComCd(fromComCd);
	  docATrail.setFromFormId(fromFormId);
	  docATrail.setFromLinkInd(fromLinkInd);
	  docATrail.setFromNric(fromNric);
	  docATrail.setFromObjectId(fromObjectId);
	  docATrail.setFromPageNo(fromPageNo);
	  docATrail.setFromPolNum(fromPolNum);
	  docATrail.setFromProcessType(fromProcessType);
	  docATrail.setFromReceivedDt(fromReceivedDt);
	  docATrail.setFromReqNo(fromReqNo);
	  docATrail.setFromStatusInd(fromStatusInd);
	  docATrail.setFromVerified(fromVerified);
	  docATrail.setFrsReqNo(frsReqNo);
	  docATrail.setIsResolved(isResolved);
	  docATrail.setLogicalLinkId(logicalLinkId);
	  docATrail.setOther(other);
	  docATrail.setReceiveddate(receiveddate);
	  docATrail.setReqreceiveddate(reqreceiveddate);
	  docATrail.setsRowid(sRowid);
	  docATrail.setSysAct(sysAct);
	  docATrail.setToBatchNo(toBatchNo);
	  docATrail.setToBoxNo(toBoxNo);
	  docATrail.setToClaimNo(toClaimNo);
	  docATrail.setToComCd(toComCd);
	  docATrail.setToFormId(toFormId);
	  docATrail.setToLinkInd(toLinkInd);
	  docATrail.setToNric(toNric);
	  docATrail.setToObjectId(toObjectId);
	  docATrail.setToPageNo(toPageNo);
	  docATrail.setToPolNum(toPolNum);
	  docATrail.setToProcessType(toProcessType);
	  docATrail.setToReceivedDt(toReceivedDt);
	  docATrail.setToReqNo(toReqNo);
	  docATrail.setToStatusInd(toStatusInd);
	  docATrail.setToVerified(toVerified);	  
	  docATrail.setUserAct(userAct); 
      return docATrail; 
  }

/* (non-Javadoc)
 * @see java.lang.Object#hashCode()
 */
@Override
public int hashCode() {
  final int prime = 31;
  int result = 1;
  result = prime * result + ((StringUtils.isBlank(activityId)) ? 0 : activityId.hashCode());
  result = prime * result + ((StringUtils.isBlank(createdBy)) ? 0 : createdBy.hashCode());
  result = prime * result + ((createdTimestamp == null) ? 0 : createdTimestamp.hashCode());
  result = prime * result + ((StringUtils.isBlank(fromBatchNo)) ? 0 : fromBatchNo.hashCode());
  result = prime * result + ((StringUtils.isBlank(fromBoxNo)) ? 0 : fromBoxNo.hashCode());
  result = prime * result + ((StringUtils.isBlank(fromClaimNo)) ? 0 : fromClaimNo.hashCode());
  result = prime * result + ((StringUtils.isBlank(fromComCd)) ? 0 : fromComCd.hashCode());
  result = prime * result + ((StringUtils.isBlank(fromFormId)) ? 0 : fromFormId.hashCode());
  result = prime * result + ((StringUtils.isBlank(fromLinkInd)) ? 0 : fromLinkInd.hashCode());
  result = prime * result + ((StringUtils.isBlank(fromNric)) ? 0 : fromNric.hashCode());
  result = prime * result + ((StringUtils.isBlank(fromObjectId)) ? 0 : fromObjectId.hashCode());
  result = prime * result + ((StringUtils.isBlank(fromPageNo)) ? 0 : fromPageNo.hashCode());
  result = prime * result + ((StringUtils.isBlank(fromPolNum)) ? 0 : fromPolNum.hashCode());
  result = prime * result + ((StringUtils.isBlank(fromProcessType)) ? 0 : fromProcessType.hashCode());
  result = prime * result + ((fromReceivedDt == null) ? 0 : fromReceivedDt.hashCode());
  result = prime * result + ((StringUtils.isBlank(fromReqNo)) ? 0 : fromReqNo.hashCode());
  result = prime * result + ((StringUtils.isBlank(fromStatusInd)) ? 0 : fromStatusInd.hashCode());
  result = prime * result + ((StringUtils.isBlank(fromVerified)) ? 0 : fromVerified.hashCode());
  result = prime * result + ((StringUtils.isBlank(frsReqNo)) ? 0 : frsReqNo.hashCode());
  result = prime * result + isResolved;
  result = prime * result + ((StringUtils.isBlank(logicalLinkId)) ? 0 : logicalLinkId.hashCode());
  result = prime * result + ((StringUtils.isBlank(other)) ? 0 : other.hashCode());
  result = prime * result + ((StringUtils.isBlank(receiveddate)) ? 0 : receiveddate.hashCode());
  result = prime * result + ((StringUtils.isBlank(reqreceiveddate)) ? 0 : reqreceiveddate.hashCode());
  result = prime * result + ((StringUtils.isBlank(sRowid)) ? 0 : sRowid.hashCode());
  result = prime * result + ((StringUtils.isBlank(sysAct)) ? 0 : sysAct.hashCode());
  result = prime * result + ((StringUtils.isBlank(toBatchNo)) ? 0 : toBatchNo.hashCode());
  result = prime * result + ((StringUtils.isBlank(toBoxNo)) ? 0 : toBoxNo.hashCode());
  result = prime * result + ((StringUtils.isBlank(toClaimNo)) ? 0 : toClaimNo.hashCode());
  result = prime * result + ((StringUtils.isBlank(toComCd)) ? 0 : toComCd.hashCode());
  result = prime * result + ((StringUtils.isBlank(toFormId)) ? 0 : toFormId.hashCode());
  result = prime * result + ((StringUtils.isBlank(toLinkInd)) ? 0 : toLinkInd.hashCode());
  result = prime * result + ((StringUtils.isBlank(toNric)) ? 0 : toNric.hashCode());
  result = prime * result + ((StringUtils.isBlank(toObjectId)) ? 0 : toObjectId.hashCode());
  result = prime * result + ((StringUtils.isBlank(toPageNo)) ? 0 : toPageNo.hashCode());
  result = prime * result + ((StringUtils.isBlank(toPolNum)) ? 0 : toPolNum.hashCode());
  result = prime * result + ((StringUtils.isBlank(toProcessType)) ? 0 : toProcessType.hashCode());
  result = prime * result + ((toReceivedDt == null) ? 0 : toReceivedDt.hashCode());
  result = prime * result + ((StringUtils.isBlank(toReqNo)) ? 0 : toReqNo.hashCode());
  result = prime * result + ((StringUtils.isBlank(toStatusInd)) ? 0 : toStatusInd.hashCode());
  result = prime * result + ((StringUtils.isBlank(toVerified)) ? 0 : toVerified.hashCode());
  result = prime * result + ((StringUtils.isBlank(userAct)) ? 0 : userAct.hashCode());
  return result;
}

/* (non-Javadoc)
 * @see java.lang.Object#equals(java.lang.Object)
 */
@Override
public boolean equals(Object obj) {
  if (this == obj) return true;
  if (obj == null) return false;
  if (getClass() != obj.getClass()) return false;
  FdDocAuditTrail other = (FdDocAuditTrail) obj;
  if (StringUtils.isBlank(activityId)) {
    if (StringUtils.isNotBlank(other.activityId)) return false;
  } else if (!activityId.equals(other.activityId)) return false;
  if (StringUtils.isBlank(createdBy)) {
    if (StringUtils.isNotBlank(other.createdBy)) return false;
  } else if (!createdBy.equals(other.createdBy)) return false;
  if (createdTimestamp == null) {
    if (other.createdTimestamp != null) return false;
  } else if (!createdTimestamp.equals(other.createdTimestamp)) return false;
  if (StringUtils.isBlank(fromBatchNo)) {
    if (StringUtils.isNotBlank(other.fromBatchNo)) return false;
  } else if (!fromBatchNo.equals(other.fromBatchNo)) return false;
  if (StringUtils.isBlank(fromBoxNo)) {
    if (StringUtils.isNotBlank(other.fromBoxNo)) return false;
  } else if (!fromBoxNo.equals(other.fromBoxNo)) return false;
  if (StringUtils.isBlank(fromClaimNo)) {
    if (StringUtils.isNotBlank(other.fromClaimNo)) return false;
  } else if (!fromClaimNo.equals(other.fromClaimNo)) return false;
  if (StringUtils.isBlank(fromComCd)) {
    if (StringUtils.isNotBlank(other.fromComCd)) return false;
  } else if (!fromComCd.equals(other.fromComCd)) return false;
  if (StringUtils.isBlank(fromFormId)) {
    if (StringUtils.isNotBlank(other.fromFormId)) return false;
  } else if (!fromFormId.equals(other.fromFormId)) return false;
  if (StringUtils.isBlank(fromLinkInd)) {
    if (StringUtils.isNotBlank(other.fromLinkInd)) return false;
  } else if (!fromLinkInd.equals(other.fromLinkInd)) return false;
  if (StringUtils.isBlank(fromNric)) {
    if (StringUtils.isNotBlank(other.fromNric)) return false;
  } else if (!fromNric.equals(other.fromNric)) return false;
  if (StringUtils.isBlank(fromObjectId)) {
    if (StringUtils.isNotBlank(other.fromObjectId)) return false;
  } else if (!fromObjectId.equals(other.fromObjectId)) return false;
  if (StringUtils.isBlank(fromPageNo)) {
    if (StringUtils.isNotBlank(other.fromPageNo)) return false;
  } else if (!fromPageNo.equals(other.fromPageNo)) return false;
  if (StringUtils.isBlank(fromPolNum)) {
    if (StringUtils.isNotBlank(other.fromPolNum)) return false;
  } else if (!fromPolNum.equals(other.fromPolNum)) return false;
  if (StringUtils.isBlank(fromProcessType)) {
    if (StringUtils.isNotBlank(other.fromProcessType)) return false;
  } else if (!fromProcessType.equals(other.fromProcessType)) return false;
  if (fromReceivedDt == null) {
    if (other.fromReceivedDt != null) return false;
  } else if (!fromReceivedDt.equals(other.fromReceivedDt)) return false;
  if (StringUtils.isBlank(fromReqNo)) {
    if (StringUtils.isNotBlank(other.fromReqNo)) return false;
  } else if (!fromReqNo.equals(other.fromReqNo)) return false;
  if (StringUtils.isBlank(fromStatusInd)) {
    if (StringUtils.isNotBlank(other.fromStatusInd)) return false;
  } else if (!fromStatusInd.equals(other.fromStatusInd)) return false;
  if (StringUtils.isBlank(fromVerified)) {
    if (StringUtils.isNotBlank(other.fromVerified)) return false;
  } else if (!fromVerified.equals(other.fromVerified)) return false;
  if (StringUtils.isBlank(frsReqNo)) {
    if (StringUtils.isNotBlank(other.frsReqNo)) return false;
  } else if (!frsReqNo.equals(other.frsReqNo)) return false;
  if (isResolved != other.isResolved) return false;
  if (StringUtils.isBlank(logicalLinkId)) {
    if (StringUtils.isNotBlank(other.logicalLinkId)) return false;
  } else if (!logicalLinkId.equals(other.logicalLinkId)) return false;
  if (StringUtils.isBlank(this.other)) {
    if (StringUtils.isNotBlank(other.other)) return false;
  } else if (!this.other.equals(other.other)) return false;
  if (StringUtils.isBlank(receiveddate)) {
    if (StringUtils.isNotBlank(other.receiveddate)) return false;
  } else if (!receiveddate.equals(other.receiveddate)) return false;
  if (StringUtils.isBlank(reqreceiveddate)) {
    if (StringUtils.isNotBlank(other.reqreceiveddate)) return false;
  } else if (!reqreceiveddate.equals(other.reqreceiveddate)) return false;
  if (StringUtils.isBlank(sRowid)) {
    if (StringUtils.isNotBlank(other.sRowid)) return false;
  } else if (!sRowid.equals(other.sRowid)) return false;
  if (StringUtils.isBlank(sysAct)) {
    if (StringUtils.isNotBlank(other.sysAct)) return false;
  } else if (!sysAct.equals(other.sysAct)) return false;
  if (StringUtils.isBlank(toBatchNo)) {
    if (StringUtils.isNotBlank(other.toBatchNo)) return false;
  } else if (!toBatchNo.equals(other.toBatchNo)) return false;
  if (StringUtils.isBlank(toBoxNo)) {
    if (StringUtils.isNotBlank(other.toBoxNo)) return false;
  } else if (!toBoxNo.equals(other.toBoxNo)) return false;
  if (StringUtils.isBlank(toClaimNo)) {
    if (StringUtils.isNotBlank(other.toClaimNo)) return false;
  } else if (!toClaimNo.equals(other.toClaimNo)) return false;
  if (StringUtils.isBlank(toComCd)) {
    if (StringUtils.isNotBlank(other.toComCd)) return false;
  } else if (!toComCd.equals(other.toComCd)) return false;
  if (StringUtils.isBlank(toFormId)) {
    if (StringUtils.isNotBlank(other.toFormId)) return false;
  } else if (!toFormId.equals(other.toFormId)) return false;
  if (StringUtils.isBlank(toLinkInd)) {
    if (StringUtils.isNotBlank(other.toLinkInd)) return false;
  } else if (!toLinkInd.equals(other.toLinkInd)) return false;
  if (StringUtils.isBlank(toNric)) {
    if (StringUtils.isNotBlank(other.toNric)) return false;
  } else if (!toNric.equals(other.toNric)) return false;
  if (StringUtils.isBlank(toObjectId)) {
    if (StringUtils.isNotBlank(other.toObjectId)) return false;
  } else if (!toObjectId.equals(other.toObjectId)) return false;
  if (StringUtils.isBlank(toPageNo)) {
    if (StringUtils.isNotBlank(other.toPageNo)) return false;
  } else if (!toPageNo.equals(other.toPageNo)) return false;
  if (StringUtils.isBlank(toPolNum)) {
    if (StringUtils.isNotBlank(other.toPolNum)) return false;
  } else if (!toPolNum.equals(other.toPolNum)) return false;
  if (StringUtils.isBlank(toProcessType)) {
    if (StringUtils.isNotBlank(other.toProcessType)) return false;
  } else if (!toProcessType.equals(other.toProcessType)) return false;
  if (toReceivedDt == null) {
    if (other.toReceivedDt != null) return false;
  } else if (!toReceivedDt.equals(other.toReceivedDt)) return false;
  if (StringUtils.isBlank(toReqNo)) {
    if (StringUtils.isNotBlank(other.toReqNo)) return false;
  } else if (!toReqNo.equals(other.toReqNo)) return false;
  if (StringUtils.isBlank(toStatusInd)) {
    if (StringUtils.isNotBlank(other.toStatusInd)) return false;
  } else if (!toStatusInd.equals(other.toStatusInd)) return false;
  if (StringUtils.isBlank(toVerified)) {
    if (StringUtils.isNotBlank(other.toVerified)) return false;
  } else if (!toVerified.equals(other.toVerified)) return false;
  if (StringUtils.isBlank(userAct)) {
    if (StringUtils.isNotBlank(other.userAct)) return false;
  } else if (!userAct.equals(other.userAct)) return false;
  return true;
}
}
