package com.aia.case360.web.pojo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class FRMSearchBackfileParam {
  
  @JsonProperty("POLICY_NOS")
  private String polNums;
  
  @JsonProperty("COMPANY_NO")
  private String companyNo;
  
  @JsonProperty("TYPE")
  private Integer type;

  /**
   * @return the polNumS
   */
  public String getPolNums() {
    return polNums;
  }

  /**
   * @return the companyNo
   */
  public String getCompanyNo() {
    return companyNo;
  }

  /**
   * @param polNumS the polNumS to set
   */
  public void setPolNums(String polNums) {
    this.polNums = polNums;
  }

  /**
   * @param companyNo the companyNo to set
   */
  public void setCompanyNo(String companyNo) {
    this.companyNo = companyNo;
  }

  
  /**
   * @return the type
   */
  public Integer getType() {
    return type;
  }

  /**
   * @param type the type to set
   */
  public void setType(Integer type) {
    this.type = type;
  }

  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "FRMSearchBackfileParam [polNums=" + polNums + ", companyNo=" + companyNo + ", type="
        + type + "]";
  }
  
}
