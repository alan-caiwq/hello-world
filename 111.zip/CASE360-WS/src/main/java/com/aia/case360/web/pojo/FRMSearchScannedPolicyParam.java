package com.aia.case360.web.pojo;

import com.aia.case360.web.common.CommonUtil;
import com.fasterxml.jackson.annotation.JsonProperty;

public class FRMSearchScannedPolicyParam {

  @JsonProperty("POLICY_NOS")
  private String polNums;

  @JsonProperty("COMPANY_NO")
  private String companyNo;
  
  private String reqType;

  /**
   * @return the polNums
   */
  public String getPolNums() {
    return polNums;
  }

  /**
   * @return the companyNo
   */
  public String getCompanyNo() {
    return CommonUtil.getString(companyNo, "011");
  }

  /**
   * @param polNums the polNums to set
   */
  public void setPolNums(String polNums) {
    this.polNums = polNums;
  }

  /**
   * @param companyNo the companyNo to set
   */
  public void setCompanyNo(String companyNo) {
    this.companyNo = companyNo;
  }

  /**
   * @return the reqType
   */
  public String getReqType() {
    return reqType;
  }

  /**
   * @param reqType the reqType to set
   */
  public void setReqType(String reqType) {
    this.reqType = reqType;
  }

  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "FRMSearchScannedPolicyParam [polNums=" + polNums + ", companyNo=" + companyNo
        + ", reqType=" + reqType + "]";
  }
}
