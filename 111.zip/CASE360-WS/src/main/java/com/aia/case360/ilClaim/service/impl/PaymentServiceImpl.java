package com.aia.case360.ilClaim.service.impl;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.aia.case360.ilClaim.dao.PaymentBean;
import com.aia.case360.ilClaim.service.PaymentService;

@Service
public class PaymentServiceImpl implements PaymentService {

	private PaymentBean paymentDao = new PaymentBean();

	/**
	 * payment Approval
	 */
	@Override
	public List<Map<String, String>> getPaymentApproval(String paymentIds, Map<String, String> params)
			 throws SQLException {

		List<Map<String, String>> result = null;
		String paymentId = "";
		if (null != paymentIds && paymentIds.length() > 0) {

			paymentId = paymentIds.replaceAll(",", "','");
			params.put("paymentIds", "'" + paymentId + "'");
			return paymentDao.getPaymentApproval(params);
		} else {
			return result;
		}
	}

	/**
	 * payment Authorization
	 */
	@Override
	public List<Map<String, String>> getPaymentAuthorization(String paymentIds, Map<String, String> params)
			 throws SQLException {

		List<Map<String, String>> result = null;
		String paymentId = "";
		if (null != paymentIds && paymentIds.length() > 0) {

			paymentId = paymentIds.replaceAll(",", "','");

			params.put("paymentIds", "'" + paymentId + "'");
			return paymentDao.getPaymentAuthorization(params);
		} else {
			return result;
		}
	}
}
