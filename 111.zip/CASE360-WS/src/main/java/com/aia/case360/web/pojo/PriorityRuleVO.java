package com.aia.case360.web.pojo;

import java.math.BigDecimal;

public class PriorityRuleVO {

	private String sRowId;

	private String ruleCase;

	private Integer isRank;

	private Integer ruleCaseType;

	// 0 asc 1 desc
	private Integer sortDirection;

	private String displayName;

	private Integer isEnabled;

	private Integer sequenceNum;

	private String department;

	private String priorityValues;

	private Integer symbolValue;

	private BigDecimal anp;

	public String getsRowId() {
		return sRowId;
	}

	public void setsRowId(String sRowId) {
		this.sRowId = sRowId;
	}

	public String getRuleCase() {
		return ruleCase;
	}

	public void setRuleCase(String ruleCase) {
		this.ruleCase = ruleCase;
	}

	public Integer getIsRank() {
		return isRank;
	}

	public void setIsRank(Integer isRank) {
		this.isRank = isRank;
	}

	public Integer getRuleCaseType() {
		return ruleCaseType;
	}

	public void setRuleCaseType(Integer ruleCaseType) {
		this.ruleCaseType = ruleCaseType;
	}

	public Integer getSortDirection() {
		return sortDirection;
	}

	public void setSortDirection(Integer sortDirection) {
		this.sortDirection = sortDirection;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public Integer getIsEnabled() {
		return isEnabled;
	}

	public void setIsEnabled(Integer isEnabled) {
		this.isEnabled = isEnabled;
	}

	public Integer getSequenceNum() {
		return sequenceNum;
	}

	public void setSequenceNum(Integer sequenceNum) {
		this.sequenceNum = sequenceNum;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getPriorityValues() {
		return priorityValues;
	}

	public void setPriorityValues(String priorityValues) {
		this.priorityValues = priorityValues;
	}

	public Integer getSymbolValue() {
		return symbolValue;
	}

	public void setSymbolValue(Integer symbolValue) {
		this.symbolValue = symbolValue;
	}

	public BigDecimal getAnp() {
		return anp;
	}

	public void setAnp(BigDecimal anp) {
		this.anp = anp;
	}

	@Override
	public String toString() {
		return "PriorityRuleVO [sRowId=" + sRowId + ", ruleCase=" + ruleCase + ", isRank=" + isRank + ", ruleCaseType="
				+ ruleCaseType + ", sortDirection=" + sortDirection + ", displayName=" + displayName + ", isEnabled="
				+ isEnabled + ", sequenceNum=" + sequenceNum + ", department=" + department + ", priorityValues="
				+ priorityValues + ", symbolValue=" + symbolValue + ", anp=" + anp + "]";
	}

}
