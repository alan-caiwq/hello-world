package com.aia.case360.web.pojo;

import java.math.BigDecimal;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

public class CaseAvailableStep {
	private String acl;
	private String availableStep;
	private String createdBy;
	private String dataValue;
	private String lastUpdatedBy;
	private BigDecimal linkcaseid;
	private BigDecimal sRowid;

	@DateTimeFormat(pattern = "yyyy-MM-ddHH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-ddHH:mm:ss", timezone = "GMT+8")
	private Date createdTimestamp;

	@DateTimeFormat(pattern = "yyyy-MM-ddHH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-ddHH:mm:ss", timezone = "GMT+8")
	private Date lastUpdatedTimestamp;
	private int versionNum;

	public String getAcl() {
		return acl;
	}

	public void setAcl(String acl) {
		this.acl = acl;
	}

	public String getAvailableStep() {
		return availableStep;
	}

	public void setAvailableStep(String availableStep) {
		this.availableStep = availableStep;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getDataValue() {
		return dataValue;
	}

	public void setDataValue(String dataValue) {
		this.dataValue = dataValue;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public BigDecimal getLinkcaseid() {
		return linkcaseid;
	}

	public void setLinkcaseid(BigDecimal linkcaseid) {
		this.linkcaseid = linkcaseid;
	}

	public BigDecimal getsRowid() {
		return sRowid;
	}

	public void setsRowid(BigDecimal sRowid) {
		this.sRowid = sRowid;
	}

	public Date getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public Date getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Date lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public int getVersionNum() {
		return versionNum;
	}

	public void setVersionNum(int versionNum) {
		this.versionNum = versionNum;
	}

}
