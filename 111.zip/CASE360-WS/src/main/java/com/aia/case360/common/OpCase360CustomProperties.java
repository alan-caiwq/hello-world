package com.aia.case360.common;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.FinderException;

import com.aia.case360.platform.system.InitCase360EJB;
import com.eistream.sonora.system.ServerTO;

public class OpCase360CustomProperties {

	private OpCase360CustomProperties() {}
	public static String getCase360CustomProperty(String propertyName) throws RemoteException, FinderException {
		return InitCase360EJB.getSysSEJB().getSystemApplicationProperty(propertyName).getPropValue();
	}

	public static void updateCase360CustomProerty(String name, String value) throws RemoteException {
		InitCase360EJB.getSysSEJB().updateSystemApplicationProperty(name, value);
		InitCase360EJB.getSysSEJB().flushCache("APPPROPCACHE");
	}
	
	/**
	 * Returns all registered servers plus the cluster record
	 * @return
	 * @throws RemoteException
	 */
	public static List<String> getRegisterHostName() throws RemoteException {
		ServerTO[] serverList = InitCase360EJB.getSysSEJB().getServerList();
		ArrayList<String> result = new ArrayList<String>();
		String hostName = "";
		for(ServerTO t: serverList) {
			hostName = t.getHostName();
			if(hostName.contains("!")){
				result.add(hostName.split("!")[0]);
			}
		}
		return result;
		
	}
}
