package com.aia.case360.web.pojo;

import java.io.Serializable;

public class CaseAndPolInfo implements Serializable {

	private String casefolderId;
	private String requestNum;
	private String policyNum;
	private String policyNo;
	private String clmNum;
	private String nric;
	private String polRole;

	private String companyNo;

	public String getCasefolderId() {
		return casefolderId;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
		this.policyNum= policyNo;
	}

	public void setCasefolderId(String casefolderId) {
		this.casefolderId = casefolderId;
	}

	public String getRequestNum() {
		return requestNum;
	}

	public void setRequestNum(String requestNum) {
		this.requestNum = requestNum;
	}

	public String getPolicyNum() {
		return policyNum;
	}

	public void setPolicyNum(String policyNum) {
		this.policyNum = policyNum;
	}

	public String getClmNum() {
		return clmNum;
	}

	public void setClmNum(String clmNum) {
		this.clmNum = clmNum;
	}

	public String getNric() {
		return nric;
	}

	public void setNric(String nric) {
		this.nric = nric;
	}

	public String getPolRole() {
		return polRole;
	}

	public void setPolRole(String polRole) {
		this.polRole = polRole;
	}

	public String getCompanyNo() {
		return companyNo;
	}

	public void setCompanyNo(String companyNo) {
		this.companyNo = companyNo;
	}

	@Override
	public String toString() {
		return "{casefolderId=" + casefolderId + ", requestNum=" + requestNum + ", policyNum=" + policyNum
				+ ", policyNo=" + policyNo + ", clmNum=" + clmNum + ", nric=" + nric + ", polRole=" + polRole
				+ ", companyNo=" + companyNo + "}";
	}

}
