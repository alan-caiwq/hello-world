package com.aia.case360.web.pojo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class FRMCreateBackfileParam {
  
  @JsonProperty("POLICY_NO")
  private String polNum;
  
  @JsonProperty("COMPANY_NO")
  private String companyNo;

  /**
   * @return the polNum
   */
  public String getPolNum() {
    return polNum;
  }

  /**
   * @return the companyNo
   */
  public String getCompanyNo() {
    return companyNo;
  }

  /**
   * @param polNum the polNum to set
   */
  public void setPolNum(String polNum) {
    this.polNum = polNum;
  }

  /**
   * @param companyNo the companyNo to set
   */
  public void setCompanyNo(String companyNo) {
    this.companyNo = companyNo;
  }

  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "FRMCreateBackfileParam [polNum=" + polNum + ", companyNo=" + companyNo + "]";
  }
}
