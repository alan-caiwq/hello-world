package com.aia.case360.web.pojo;

public class FdDocLink {

	private String formId;
	private String objectId;
	private String nric;
	private String caseId;
	private String receivedDate;
	private String policyNo;
	private String requestNo;
	private String processType;
	private String companyNo;
	private String isLogical;
	private String hashStr;
	private String claimNo;

	public FdDocLink getCloneInstance() {

		FdDocLink instance = new FdDocLink();
		instance.setCaseId(caseId);
		instance.setCompanyNo(companyNo);
		instance.setFormId(formId);
		instance.setHashStr(hashStr);
		instance.setIsLogical(isLogical);
		instance.setNric(nric);
		instance.setObjectId(objectId);
		instance.setPolicyNo(policyNo);
		instance.setProcessType(processType);
		instance.setReceivedDate(receivedDate);
		instance.setRequestNo(requestNo);
		return instance;
	}

	public String getHashStr() {
		return hashStr;
	}

	public void setHashStr(String hashStr) {
		this.hashStr = hashStr;
	}

	public String getIsLogical() {
		return isLogical;
	}

	public void setIsLogical(String isLogical) {
		this.isLogical = isLogical;
	}

	public FdDocLink() {
		super();
	}

	public FdDocLink(String formId, String objectId, String nric) {
		super();
		this.formId = formId;
		this.objectId = objectId;
		this.nric = nric;
	}

	public FdDocLink(String formId, String objectId, String nric, String caseId, String receivedDate) {
		super();
		this.formId = formId;
		this.objectId = objectId;
		this.nric = nric;
		this.caseId = caseId;
		this.receivedDate = receivedDate;
	}

	public FdDocLink(String formId, String objectId, String nric, String receivedDate) {
		super();
		this.formId = formId;
		this.objectId = objectId;
		this.nric = nric;
		this.receivedDate = receivedDate;
	}

	public String getFormId() {
		return formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}

	public String getObjectId() {
		return objectId;
	}

	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}

	public String getNric() {
		return nric;
	}

	public void setNric(String nric) {
		this.nric = nric;
	}

	public FdDocLink(String formId, String objectId, String policyNo, String requestNo, String processType,
			String caseId, String receivedDate) {
		super();
		this.formId = formId;
		this.objectId = objectId;
		this.policyNo = policyNo;
		this.requestNo = requestNo;
		this.processType = processType;
		this.caseId = caseId;
		this.receivedDate = receivedDate;
	}

	public String getReceivedDate() {
		return receivedDate;
	}

	public void setReceivedDate(String receivedDate) {
		this.receivedDate = receivedDate;
	}

	public String getCaseId() {
		return caseId;
	}

	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}

	public String getCompanyNo() {
		return companyNo;
	}

	public void setCompanyNo(String companyNo) {
		this.companyNo = companyNo;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getRequestNo() {
		return requestNo;
	}

	public void setRequestNo(String requestNo) {
		this.requestNo = requestNo;
	}

	public String getProcessType() {
		return processType;
	}

	public void setProcessType(String processType) {
		this.processType = processType;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}
	
}
