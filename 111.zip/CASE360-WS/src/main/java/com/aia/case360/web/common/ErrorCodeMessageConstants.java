package com.aia.case360.web.common;
/**
 * used for errorCode 
 * 
 * @author bsnpc37(Leo Li)
 * @date: Dec 6, 2018 5:21:43 PM
 */
public class ErrorCodeMessageConstants {
	private ErrorCodeMessageConstants() {
		
	}
	// success code and success message
	public static final String SC200001="SC200001";
	public static final String SC200002="SC200002";
	public static final String SC200003="SC200003";
	public static final String SC200004="SC200004";
	public static final String SC200005="SC200005";
	public static final String SC200006="SC200006";
	public static final String SC200007="SC200007";
	public static final String SC200008="SC200008";
	public static final String SC200009="SC200009";
	public static final String SC200010="SC200010";
	public static final String SC200011="SC200011";
	public static final String SC200012="SC200012";
	public static final String SC200013="SC200013";
	public static final String SC200014="SC200014";
	public static final String SC200015="SC200015";
	public static final String SC200016="SC200016";
	public static final String SC200017="SC200017";
	public static final String SC200018="SC200018";
	public static final String SC200019="SC200019";
	public static final String SC200020="SC200020";
	public static final String SC200021="SC200021";
	public static final String SC200022="SC200022";
	public static final String SC200023="SC200023";
	public static final String SC200024="SC200024";
	public static final String SC200025="SC200025";
	public static final String SC200026="SC200026";
    // error code and error message
	public static final String ER200001="ER200001";
	public static final String ER200002="ER200002";
	public static final String ER200003="ER200003";
	public static final String ER200004="ER200004";
	public static final String ER200005="ER200005";
	public static final String ER200006="ER200006";
	public static final String ER200007="ER200007";
	public static final String ER200008="ER200008";
	public static final String ER200009="ER200009";
	public static final String ER200010="ER200010";
	public static final String ER200011="ER200011";
	public static final String ER200012="ER200012";
	public static final String ER200013="ER200013";
	public static final String ER200014="ER200014";
	public static final String ER200015="ER200015";
	public static final String ER200016="ER200016";
	public static final String ER200017="ER200017";
	public static final String ER200018="ER200018";
	public static final String ER200019="ER200019";
	public static final String ER200020="ER200020";
	public static final String ER200021="ER200021";
	public static final String ER200022="ER200022";
	public static final String ER200023="ER200023";
	public static final String ER200024="ER200024";
	public static final String ER200025="ER200025";
	public static final String ER200026="ER200026";
	public static final String ER200027="ER200027";
	public static final String ER200028="ER200028";
	public static final String ER200029="ER200029";
	public static final String ER200030="ER200030";
	public static final String ER200031="ER200031";
	public static final String ER200032="ER200032";
	public static final String ER200033="ER200033";
	public static final String ER200034="ER200034";
	public static final String ER200035="ER200035";
	public static final String ER200036="ER200036";
	public static final String ER200037="ER200037";
	public static final String ER200038="ER200038";
	public static final String ER200039="ER200039";
	public static final String ER200040="ER200040";
	public static final String ER200041="ER200041";
	public static final String ER200042="ER200042";
	public static final String ER200043="ER200043";
	public static final String ER200044="ER200044";
	public static final String ER200045="ER200045";
	public static final String ER200046="ER200046";
	public static final String ER200047="ER200047";
	public static final String ER200048="ER200048";
	public static final String ER200049="ER200049";
	public static final String ER200051="ER200051";
	public static final String ER200052="ER200052";
	public static final String ER200053="ER200053";
	public static final String ER200054="ER200054";
	public static final String ER200055="ER200055";
	public static final String ER200056="ER200056";
	public static final String ER200057="ER200057";
	public static final String ER200058="ER200058";
	public static final String ER200059="ER200059";
	public static final String ER200060="ER200060";
	public static final String ER200061="ER200061";
	public static final String ER200062="ER200062";
	public static final String ER200063="ER200063";
	public static final String ER200064="ER200064";
	public static final String ER200065="ER200065";
	public static final String ER200066="ER200066";
	public static final String ER200067="ER200067";
	public static final String ER200068="ER200068";
	public static final String ER200069="ER200069";
	public static final String ER200070="ER200070";
	public static final String ER200071="ER200071";
	public static final String ER200072="ER200072";
	public static final String ER200073="ER200073";
	public static final String ER200074="ER200074";
	public static final String ER200075="ER200075";
	public static final String ER200076="ER200076";
	public static final String ER200077="ER200077";
	public static final String ER200078="ER200078";
	public static final String ER200079="ER200079";
	public static final String ER200080="ER200080";
	
	public static final String ER200100="ER200100";
	public static final String ER200101="ER200101";
	public static final String ER200102="ER200102";
	public static final String ER200103="ER200103";
	public static final String ER200104="ER200104";
	public static final String ER200105="ER200105";
	public static final String ER200106="ER200106";
	public static final String ER200107="ER200107";
	public static final String ER200108="ER200108";
	public static final String ER200109="ER200109";
	public static final String ER200110="ER200110";
}
