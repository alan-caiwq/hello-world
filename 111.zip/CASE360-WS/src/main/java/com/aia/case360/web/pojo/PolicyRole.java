package com.aia.case360.web.pojo;
/**
 * 
 * @author bsnpc37
 *
 */
public class PolicyRole {
    private String policyNo;
    private String policyRoleValue;
    private String policyStatus;
    private String fullName;
    private String source;
    private String nric;
    private String fscCode;

	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getPolicyRole() {
		return policyRoleValue;
	}
	public void setPolicyRole(String policyRole) {
		this.policyRoleValue = policyRole;
	}
	public String getPolicyStatus() {
		return policyStatus;
	}
	public void setPolicyStatus(String policyStatus) {
		this.policyStatus = policyStatus;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getNric() {
		return nric;
	}
	public void setNric(String nric) {
		this.nric = nric;
	}
	public String getFscCode() {
		return fscCode;
	}
	public void setFscCode(String fscCode) {
		this.fscCode = fscCode;
	}
	public String getPolicyRoleValue() {
		return policyRoleValue;
	}
	public void setPolicyRoleValue(String policyRoleValue) {
		this.policyRoleValue = policyRoleValue;
	}
	@Override
	public String toString() {
		return "PolicyRole [policyNo=" + policyNo + ", policyRoleValue=" + policyRoleValue + ", policyStatus="
				+ policyStatus + ", fullName=" + fullName + ", source=" + source + ", nric=" + nric + ", fscCode="
				+ fscCode + "]";
	}
	
}
