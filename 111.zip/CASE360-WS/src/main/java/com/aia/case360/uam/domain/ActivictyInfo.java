package com.aia.case360.uam.domain;

public class ActivictyInfo {

	private String ACT_NAME;

	private String ACT_ID;

	private String USE_FLAG;

	public String getACT_NAME() {
		return ACT_NAME;
	}

	public void setACT_NAME(String aCT_NAME) {
		ACT_NAME = aCT_NAME;
	}

	public String getACT_ID() {
		return ACT_ID;
	}

	public void setACT_ID(String aCT_ID) {
		ACT_ID = aCT_ID;
	}

	public String getUSE_FLAG() {
		return USE_FLAG;
	}

	public void setUSE_FLAG(String uSE_FLAG) {
		USE_FLAG = uSE_FLAG;
	}

}
