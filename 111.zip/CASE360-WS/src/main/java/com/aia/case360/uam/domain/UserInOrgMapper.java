package com.aia.case360.uam.domain;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

public class UserInOrgMapper implements ResultSetExtractor {

	@Override
	public List<UserInOrg> extractData(ResultSet arg0) throws SQLException, DataAccessException {
		List<UserInOrg> allResult = new ArrayList<UserInOrg>();
		while (arg0.next()) {
			UserInOrg result = new UserInOrg();
			result.setComponentId(arg0.getBigDecimal(UserInOrg.fieldNames.UAM_COMPONENT_ID.name()));
			result.setActivityStatus(arg0.getString(UserInOrg.fieldNames.ACTIVESTATUS.name()));
			result.setDisplayName(arg0.getString(UserInOrg.fieldNames.DISPLAYNAME.name()));
			result.setCompany(arg0.getString(UserInOrg.fieldNames.USERCOMPANY.name()));
			result.setDepartment(arg0.getString(UserInOrg.fieldNames.UAM_USER_DEPARTMENT.name()));
			result.setEmail(arg0.getString(UserInOrg.fieldNames.DELIVERYSTRING.name()));
			result.setLoginId(arg0.getString(UserInOrg.fieldNames.LOGINID.name()));
			result.setOfficeNumber(arg0.getString(UserInOrg.fieldNames.UAM_USER_OFFICE_NUMBER.name()));
			result.setPhoneNumber(arg0.getString(UserInOrg.fieldNames.UAM_USER_PHONE_NUMBER.name()));
			result.setUserPosition(arg0.getString(UserInOrg.fieldNames.UAM_USER_POSITION.name()));
			result.setUserTeam(arg0.getString(UserInOrg.fieldNames.UAM_USER_TEAM.name()));
			allResult.add(result);
		}
		return allResult;
	}

}
