package com.aia.case360.platform.document.impl;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;

import javax.ejb.FinderException;
import javax.ejb.RemoveException;
import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriter;
import javax.imageio.plugins.jpeg.JPEGImageWriteParam;

import org.apache.commons.codec.binary.Base64;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.tools.zip.ZipEntry;
import org.apache.tools.zip.ZipOutputStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.StringUtils;

import com.aia.case360.common.PDFUtil;
import com.aia.case360.common.SystemNameEnum;
import com.aia.case360.platform.casefolder.CasefolderHelper;
import com.aia.case360.platform.common.Constants;
import com.aia.case360.platform.common.DataFieldUtil;
import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.common.PropertyUtil;
import com.aia.case360.platform.common.ScriptUtil;
import com.aia.case360.platform.dao.FsDocumentBean;
import com.aia.case360.platform.dao.TableIdBean;
import com.aia.case360.platform.document.DocumentHelper;
import com.aia.case360.platform.process.ProcessHelper;
import com.aia.case360.platform.process.impl.RepositoryKey;
import com.aia.case360.platform.query.QueryHelper;
import com.aia.case360.web.common.PFHConstants;
import com.aia.case360.web.dao.DocOMSDao;
import com.aia.case360.web.dao.WaterMarksDao;
import com.aia.case360.web.exception.CustomException;
import com.aia.case360.web.exception.ObjectNotFoundException;
import com.aia.case360.web.pojo.DocOMSDetailsInfo;
import com.aia.case360.web.service.impl.AbstractFileHelperImpl;
import com.aia.case360.web.vo.ExportDocInfoParam;
import com.aia.case360.web.vo.FileResult;
import com.eistream.sonora.exceptions.SonoraApplicationException;
import com.eistream.sonora.exceptions.SonoraException;
import com.eistream.sonora.fields.FmsField;
import com.eistream.sonora.fields.FmsRow;
import com.eistream.sonora.fields.FmsRowConflict;
import com.eistream.sonora.fields.FmsRowNative;
import com.eistream.sonora.filestore.FSVersionElement;
import com.eistream.sonora.filestore.FileStoreElement;
import com.eistream.sonora.filestore.PoolElement;
import com.eistream.sonora.filestore.StorageElement;
import com.eistream.sonora.util.StringUtil;
import com.eistream.sonora.workflow.Envelope;
import com.eistream.utilities.UtilityException;
import com.eistream.utilities.tiff.Tiff;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfCopy;
import com.itextpdf.text.pdf.PdfGState;
import com.itextpdf.text.pdf.PdfImportedPage;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;
import com.rometools.utils.Lists;

import nochump.util.extend.ZipOutput;
import nochump.util.zip.EncryptZipOutput;

/**
 * 
 * 2018/08/15 CASEPP-6313 Error happens when export multiple documents from
 * policy document list - mod by bsnpc1n 2018/08/22 CASEPP-6579 Export voided
 * page mod by bsnpc1n 2018/08/27 CASEPP-7378 Input page number more than max
 * page number, the message is "Wrong page scope!(wrong page num:5, page num
 * should be in pageScope: (0,2])", please change to "The max page number is
 * {max page number}, please input correct page number." mod by bsnpc1n
 * 2018/08/31 CASEPP-6313 Error happens when export multiple documents from
 * policy document list. mod by bsnpc1n
 */
@Component
public class DocumentHelperImpl extends AbstractFileHelperImpl implements DocumentHelper {
	private static final String DOC_ID_S_FIELDS_S = "docId:=%s  ,fields:=%s ";

	private static final String FILE_UPLOAD_SUCCESS_DOCID_S = "File upload success:docid = %s ";

	private static final String WATERMARK_TEXT = "WATERMARK_TEXT";

	private static final String FILE_BODY = "fileBody";

	private static final String INDEX_VALID_FLAG = "INDEX_VALID_FLAG";

	private static final String INDEXING_REPOSITORY_KEY = "Indexing repositoryKey:";

	private static final String TMP_PATH = "TMP_PATH";

	private static final String IS_CREATED = " is created!";

	private static final String DOCIMPL_PARENT_CASEID = "DOCIMPL_PARENT_CASEID";

	private static final String DOCID = "DOCID";

	private static final String ZIP = ".zip";

	private static final String PDF = ".pdf";

	private static final String IS_LEAVING = " is Leaving";

	private static final String IS_ENTERING = " is Entering";

	private static final String IS_DELETED = "IS_DELETED";
	
	private static final String DOC_POOL_STATE_STR = "&state=";

	@Autowired
	private QueryHelper queryHelper;

	@Autowired
	private CasefolderHelper cfHelper;

	@Autowired
	private ProcessHelper processHelper;

	@Autowired
	private TableIdBean dataTableIds;

	@Autowired
	private FsDocumentBean fsBean;

	@Autowired
	DocOMSDao docOMSDao;
	@Autowired
	WaterMarksDao waterMarksDao;

	private String getMainCaseId(Map<String, Object> workFolderDetail, String wfCaseId) throws RemoteException {
		LogUtil.logInfo(m_Logger, "the function getMainCaseId began with params wfCaseId: " + wfCaseId);
		LogUtil.logInfo(m_Logger, workFolderDetail.toString());
		String mainCaseId = wfCaseId;

		if (workFolderDetail.get(PropertyUtil.getCommonProperty("DOCIMPL_MAIN_CASEID")) != null) {
			mainCaseId = workFolderDetail.get(PropertyUtil.getCommonProperty("DOCIMPL_MAIN_CASEID")).toString();
			Map<String, Object> wfDetail = cfHelper.getCasefolderDetail(new BigDecimal(mainCaseId));
			mainCaseId = getMainCaseId(wfDetail, mainCaseId);
		}

		LogUtil.logInfo(m_Logger, "the function getMainCaseId end with mainCaseId" + mainCaseId);
		return mainCaseId;

	}

	@Override
	public List<BigDecimal> saveDoc(List<String> filePaths) throws RemoteException {
		List<BigDecimal> docIds = new ArrayList<BigDecimal>();
		BigDecimal docId = null;
		if (filePaths != null && filePaths.size() > 0) {
			try {
				for (String path : filePaths) {

					docId = getFsEJB()
							.createInstanceWithFile(
									new BigDecimal(dataTableIds.getTemplateIds()
											.get(PropertyUtil.getTableIDProperty("TABLEID_UPLOADDOCUMENT"))),
									path, null);

					docIds.add(docId);
				}
			} catch (RemoteException e) {
				LogUtil.logException(m_Logger, "", e);

			}
		}
		return docIds;
	}

	@Override
	public List<BigDecimal> saveSigFS(List<String> filePaths) throws RemoteException {
		List<BigDecimal> docIds = new ArrayList<BigDecimal>();
		BigDecimal docId = null;
		File f = null;
		if (filePaths != null && filePaths.size() > 0) {
			try {
				for (String path : filePaths) {
					docId = getFsEJB().createInstanceWithFile(new BigDecimal(
							dataTableIds.getTemplateIds().get(PropertyUtil.getTableIDProperty("TABLEID_SIGNATURE"))),
							path, null);
					docIds.add(docId);
					f = new File(path);
					if (f.exists())
						Files.delete(Paths.get("", path));

				}
			} catch (Exception e) {
				LogUtil.logException(m_Logger, filePaths.toString(), e);
			}
		}
		return docIds;
	}

	@Override
	public List<BigDecimal> saveDocOnOWS(List<String> filePaths) throws RemoteException {
		List<BigDecimal> docIds = new ArrayList<BigDecimal>();
		BigDecimal docId = null;
		File f = null;
		if (filePaths != null && filePaths.size() > 0) {
			try {
				for (String path : filePaths) {
					docId = getFsEJB()
							.createInstanceWithFile(
									new BigDecimal(dataTableIds.getTemplateIds()
											.get(PropertyUtil.getTableIDProperty("TABLEID_FS_OWS_FILESTORE"))),
									path, null);
					docIds.add(docId);
					f = new File(path);
					if (f.exists())
						Files.delete(Paths.get("", path));
				}
			} catch (Exception e) {
				LogUtil.logException(m_Logger, filePaths.toString(), e);
			}
		}
		return docIds;
	}

	public boolean updateFileStoryFields(Map<String, String> fields, BigDecimal docId) throws RemoteException {
		String message = "FunctionName: updateFileStoryFields.docId:" + docId;
		message += fields.toString();
		LogUtil.logInfo(m_Logger, message);
		try {
			String version = getDocLatestVersion(docId.toString());

			FmsRow orgRow = getFsEJB().getFileStoreFields(docId, Integer.parseInt(version));
			FmsRow newRow = getFsEJB().getFileStoreFields(docId, Integer.parseInt(version));

			for (Map.Entry<String, String> e : fields.entrySet()) {

				FmsField ffd = newRow.getField(e.getKey().toString());
				if (ffd != null) {
					ffd.setValue(e.getValue().toString());
				}
			}
			FmsRowConflict conflict = getFsEJB().setFileStoreFields(docId, orgRow, newRow, false);

			if (conflict != null) {
				LogUtil.logError(m_Logger, "conflict size:" + conflict.getConflictFieldNames().length);
				return false;
			}
			return true;
		} catch (Exception e) {

			throw LogUtil.logException(m_Logger, message, e);
		}
	}

	@Override
	public boolean indexDocIdToCaseId(String caseId, BigDecimal docId) throws RemoteException {

		String message = String.format("FunctionName:  indexDocIdToCaseId.caseId:%s .docId:%s", caseId, docId);
		LogUtil.logInfo(m_Logger, message + IS_ENTERING);

		try {
			FmsRowNative frn = getFmsEJB().getNewRow(new BigDecimal(
					dataTableIds.getTableIds().get(PropertyUtil.getTableIDProperty("TABLEID_CFID_DOC_RELATION"))));

			FmsRow fmsRow = (FmsRow) frn.clone();
			fmsRow.setValue("LINKCASEID", new BigDecimal(caseId));
			fmsRow.setValue(PropertyUtil.getCommonProperty(DOCID), docId);
			getFmsEJB().saveChanges(fmsRow, (FmsRowNative) fmsRow, true);

			LogUtil.logInfo(m_Logger, message + IS_LEAVING);
		} catch (Exception e) {

			throw LogUtil.logException(m_Logger, message, e);
		}
		return true;
	}

	@Override
	public boolean indexDocIdToChgId(String chgItemId, BigDecimal docId) throws RemoteException {

		String message = String.format("FunctionName: indexDocIdToCaseId.chgItemId :%s .docId: %s", chgItemId, docId);
		LogUtil.logInfo(m_Logger, message + IS_ENTERING);

		try {
			FmsRowNative frn = getFmsEJB().getNewRow(new BigDecimal(
					dataTableIds.getTableIds().get(PropertyUtil.getTableIDProperty("TABLE_NAME_FD_CHG_DOC_RELATION"))));

			FmsRow fmsRow = (FmsRow) frn.clone();
			fmsRow.setValue(PropertyUtil.getCommonProperty("CHG_ITEM_ID"), new BigDecimal(chgItemId));
			fmsRow.setValue(PropertyUtil.getCommonProperty(DOCID), docId);
			getFmsEJB().saveChanges(fmsRow, (FmsRowNative) fmsRow, true);

			LogUtil.logInfo(m_Logger, message + IS_LEAVING);
		} catch (Exception e) {

			throw LogUtil.logException(m_Logger, message, e);
		}
		return true;
	}

	/**
	 * not implement method
	 */
	@Override
	public String reIndexDoc(String caseId, List<String> formIds) throws RemoteException {
		String message = "FunctionName: reIndexDoc";
		LogUtil.logInfo(m_Logger, message + IS_ENTERING);
		LogUtil.logInfo(m_Logger, "caseId no: " + caseId + "form id list :" + formIds.toString());

		return null;
	}

	@Override
	public String reIndexDoc(String caseId, String docId) throws RemoteException {

		String message = String.format("FunctionName:  reIndexDoc.caseId:%s docId:%s", caseId, docId);
		LogUtil.logInfo(m_Logger, message + IS_ENTERING);
		String key = "";
		Map<String, String> reqMap = new HashMap<String, String>();
		reqMap.put(DOCID, docId);
		Map<String, Object> caseFolderDetail = new HashMap<String, Object>();
		String masterFolderId = "";
		String mainCaseId = "";

		try {
			caseFolderDetail = cfHelper.getCasefolderDetail(new BigDecimal(caseId));
			// check current caseid is master casefolder id
			final boolean isParentCaseId = caseFolderDetail
					.containsKey(PropertyUtil.getCommonProperty(DOCIMPL_PARENT_CASEID));

			if (!isParentCaseId) {
				masterFolderId = caseId;
				boolean flag = doReIndex(masterFolderId, docId);
				if (flag) {
					key = intoIndexing(docId);
					LogUtil.logInfo(m_Logger,
							String.format("masterFolderId:%s and docId:%s reIndex success!", masterFolderId, docId));
					LogUtil.logInfo(m_Logger, message + IS_LEAVING);
					return key;
				} else {
					LogUtil.logError(m_Logger, message);
				}
			} else {
				// if current caseid is workfolder casefolderid
				masterFolderId = caseFolderDetail.get(PropertyUtil.getCommonProperty(DOCIMPL_PARENT_CASEID))
						.toString();

				mainCaseId = getMainCaseId(caseFolderDetail, caseId);

				boolean mfReindexflag = doReIndex(masterFolderId, docId);
				boolean maincaseReindexflag = false;
				if (mfReindexflag && mainCaseId != null && mainCaseId.trim().length() > 0) {
					maincaseReindexflag = doReIndex(mainCaseId, docId);
				}

				if (mfReindexflag && maincaseReindexflag) {
					LogUtil.logInfo(m_Logger, String.format(":masterFolderId:%s and mainCaseId:%s reIndex success!",
							masterFolderId, mainCaseId));
					key = intoIndexing(docId);
					LogUtil.logInfo(m_Logger, key);
				} else {
					throw LogUtil.logException(m_Logger, message, new Exception());
				}
				LogUtil.logInfo(m_Logger, message + IS_LEAVING);
				return key;
			}
		} catch (Exception e) {

			throw LogUtil.logException(m_Logger, message, e);
		}
		return key;
	}

	private boolean doReIndex(String caseId, String docId) throws RemoteException {
		String message = String.format("FunctionName: doReIndex  caseId:%s docId:%s", caseId, docId);
		LogUtil.logInfo(m_Logger, message + IS_ENTERING);

		Map<String, String> reqMap = new HashMap<String, String>();
		reqMap.put(DOCID, docId);

		try {
			ArrayList<Map<String, Object>> resultList = queryHelper.doQuery(reqMap,
					PropertyUtil.getScriptAndQueryProperty("QUERY_DOCRELBYDOCID"));
			if (resultList != null && resultList.size() > 0)
				for (Map<String, Object> l : resultList) {
					for (Map.Entry<String, Object> entry : l.entrySet()) {
						if (entry.getKey().equals("CASEID") && entry.getValue().toString().equals(caseId)) {

							String rowId = l.get("S_ROWID").toString();

							FmsRowNative frn2 = getFmsEJB().fetch(
									new BigDecimal(dataTableIds.getTableIds()
											.get(PropertyUtil.getTableIDProperty("TABLEID_CFID_DOC_RELATION"))),
									new BigDecimal(rowId));
							FmsRow originalRo = (FmsRow) frn2.clone();
							FmsRowNative newRow = (FmsRowNative) frn2.clone();
							newRow.setValue("CASEID", new BigDecimal(0));
							newRow.setValue(DOCID, new BigDecimal(0));
							getFmsEJB().saveChanges(originalRo, newRow, false);
						}
					}
				}
			else {
				LogUtil.logError(m_Logger, "no found data,please check docId or caseId is right!");
				return false;
			}
			return true;
		} catch (Exception e) {

			LogUtil.logException(m_Logger, message, e);
			return false;
		}
	}

	private String intoIndexing(String docId) throws RemoteException {
		String message = "FunctionName: intoIndexing docId:" + docId;
		LogUtil.logInfo(m_Logger, message + IS_ENTERING);
		String key = "";
		try {
			Map<String, Object> cfParams = new HashMap<String, Object>();
			cfParams.put(DOCID, docId);
			key = processHelper.createWorkitem(PropertyUtil.getCommonProperty("Index_WORKFLOWNAME"), cfParams, null);
			LogUtil.logInfo(m_Logger, key);
			LogUtil.logInfo(m_Logger, message + IS_LEAVING);
			return key;
		} catch (RemoteException e) {

			throw LogUtil.logException(m_Logger, message, e);
		}
	}

	@Override
	public String downloadDocs(List<String> docIds) throws RemoteException {
		String message = "FunctionName: downloadDocs docId:" + docIds.toString();
		LogUtil.logInfo(m_Logger, message + IS_ENTERING);
		LogUtil.logInfo(m_Logger, docIds.toString());
		String zipFilePath = PropertyUtil.getCommonProperty("ZIP_SAVE_PATH");
		if (!(new File(zipFilePath)).exists()) {
			new File(zipFilePath).mkdirs();
			LogUtil.logInfo(m_Logger, new File(zipFilePath).getAbsolutePath() + IS_CREATED);
		}
		ArrayList<String> fileList = new ArrayList<String>();
		for (String docId : docIds) {
			fileList.add(getDocPath(docId));
		}
		String zipDocs = fileToZip(zipFilePath, fileList);

		LogUtil.logInfo(m_Logger, message + IS_LEAVING);
		return zipDocs;
	}

	/**
	 * List<ExportDocInfoParam> docIds, boolean isExportPage, boolean isZip, boolean
	 * isEncrypt, String...exportDocParameters
	 * 
	 * @param docIds
	 * @param isExportPage
	 * @param pages
	 * @param isZip
	 * @param isEncrypt
	 * @param password
	 * @param rootPath
	 * @param nric
	 * @return
	 * @throws IOException
	 * @throws DocumentException
	 */
	@Override
	public FileResult exportDocs(List<ExportDocInfoParam> docIds, boolean isExportPage, boolean isZip,
			boolean isEncrypt, String... exportDocParameters) throws IOException, DocumentException {

		String pages = exportDocParameters[0];
		String password = exportDocParameters[1];
		String rootPath = exportDocParameters[2];
		String nric = exportDocParameters[3];

		String message = String.format("FunctionName: downloadDocs docId:%s ,isZip:%s with password", docIds.toString(),
				isZip);
		LogUtil.logInfo(m_Logger, message + IS_ENTERING);
		LogUtil.logInfo(m_Logger, docIds.toString());
		long timeStamp = System.nanoTime();
		String docTmpPath = "docTmpPath" + '\\' + timeStamp + '\\';
		String zipTmpPath = "zipTmpPath" + '\\' + timeStamp + '\\';

		String zipFilePath = rootPath + '\\' + zipTmpPath + '\\';
		if (!(new File(zipFilePath)).exists()) {
			new File(zipFilePath).mkdirs();
			LogUtil.logInfo(m_Logger, new File(zipFilePath).getAbsolutePath() + IS_CREATED);
		}

		String destPath = rootPath + '\\' + docTmpPath + '\\' + System.nanoTime() + '_' + Math.round((Math.random() * 10000)) + '_'
				+ Math.round((Math.random() * 10000)) + '\\';
		if (!(new File(destPath)).exists()) {
			new File(destPath).mkdirs();
			LogUtil.logInfo(m_Logger, new File(destPath).getAbsolutePath() + IS_CREATED);
		}

		ArrayList<File> fileList = new ArrayList<File>();
		List<String> filePathList = new ArrayList<String>();
		getPaths(docIds, isExportPage, pages, destPath, fileList, filePathList);

		LogUtil.logInfo(m_Logger, "filePathList size:" + filePathList.size());
		LogUtil.logInfo(m_Logger, "fileList size:" + fileList.size());

		// create result
		FileResult result = new FileResult();
		result.setTimeNum(timeStamp);

		byte[] fileDataByte = null;

		if (docIds.size() == 1 && !isZip) {
			File file = fileList.get(0);
			fileDataByte = getFileBytes(file);
			result.setFilePath(docTmpPath);
			result.setFileName(file.getName());
			file.deleteOnExit();
		} else if (docIds.size() == 1 && isZip || docIds.size() > 1) {

			fileDataByte = zipFiles(docIds, fileList, filePathList, result, isEncrypt, password, nric, zipTmpPath, zipFilePath);
		}

		result.setBody(fileDataByte);

		delDir(rootPath + '\\' + docTmpPath);
		delDir(rootPath + '\\' + zipTmpPath);

		LogUtil.logInfo(m_Logger, message + IS_LEAVING);
		return result;
	}

	private String getPaths(List<ExportDocInfoParam> docIds, boolean isExportPage, String pages, String destPath,
			ArrayList<File> fileList, List<String> filePathList)
			throws RemoteException, IOException, DocumentException {
		for (ExportDocInfoParam exportDocInfoParam : docIds) {
			String src = getDocPath(exportDocInfoParam.getDocumentID());
			if (StringUtils.isEmpty(src)) {
				throw new CustomException("Can not get file path of docID " + exportDocInfoParam.getDocumentID(),
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
			String dest = destPath + getFileName(exportDocInfoParam);
			if (src.toLowerCase().endsWith(PDF)) {
				// get document attribute(page indicator(N&V))
				// if page indicator has V, do not export this page
				
				// if pdf && isExportPage, check pages format
				// create new pdf
				if (!isExportPage && docIds.size() == 1 || docIds.size() > 1) {
					pages = "";
				}
				
				String isMigrated = exportDocInfoParam.getIsMigrated();
				if (StringUtil.isBlank(isMigrated)) {
					isMigrated = "0";
				}
				
				String pageIndicator = exportDocInfoParam.getPageIndicator();
				// 2018/08/22 CASEPP-6579 Export voided page add by bsnpc1n --Start
				String tmpPath = PropertyUtil.getCommonProperty(TMP_PATH);
				String maskTmpDest = tmpPath + "/" + System.nanoTime() + PDF;
				boolean isNeedPassword = PDFUtil.generateVoidMaskPDFFile(src, new File(maskTmpDest), pageIndicator,
						isMigrated);
				addFileToDesk(pages, fileList, src, dest, maskTmpDest, isNeedPassword);
			} else {
				copyFile(new File(src), new File(dest));
				fileList.add(new File(dest));
			}
			filePathList.add(dest);
		}
		return pages;
	}

	private void addFileToDesk(String pages, ArrayList<File> fileList, String src, String dest,
			String maskTmpDest, boolean isNeedPassword) throws IOException, RemoteException, DocumentException {
		if (isNeedPassword) {
			m_Logger.info(String.format("%s %s", src, " File is copy"));
			m_Logger.info(dest + " target File is copy");
			copyFile(new File(src), new File(dest));
			fileList.add(new File(dest));
			m_Logger.info("password File is copy");
		} else {
			// 2018/08/22 CASEPP-6579 Export voided page add by bsnpc1n
			// --End

			List<Integer> pageList = getPageListFromString(pages, src);

			splitPdf(maskTmpDest, dest, pageList);

			fileList.add(new File(dest));
			deleteFile(maskTmpDest);
		}
	}

	private byte[] zipFiles(List<ExportDocInfoParam> docIds, ArrayList<File> fileList, List<String> filePathList, FileResult result, boolean isEncrypt, 
			String... strParams) throws IOException, RemoteException {
		String password = strParams[0]; 
		String nric = strParams[1]; 
		String zipTmpPath = strParams[2];
		String zipFilePath = strParams[3];
		byte[] fileDataByte;
		String fileName = "";
		if (docIds.size() == 1) {
			fileName = fileList.get(0).getName();
			// 2018/08/31 CASEPP-6313 Error happens when export multiple documents from
			// policy document list. mod by bsnpc1n
			if (fileName.indexOf('_') != -1 && fileName.length() > fileName.indexOf('_') + 2) {
				fileName = fileName.substring(fileName.indexOf('_') + 1);
			}
			fileName = fileName.lastIndexOf('.') == -1 ? fileName + ZIP
					: fileName.substring(0, fileName.lastIndexOf('.') - 1) + ZIP;
		} else {
			ExportDocInfoParam exportDocInfoParam = docIds.get(0);
			String companyCode = exportDocInfoParam.getCompanyCode() == null ? ""
					: exportDocInfoParam.getCompanyCode();
			String policyNum = exportDocInfoParam.getPolicyNum() == null ? "" : exportDocInfoParam.getPolicyNum();
			SimpleDateFormat df = new SimpleDateFormat("dMMMyyyy", Locale.ENGLISH);
			Calendar calendar = Calendar.getInstance();
			String curentTime = df.format(calendar.getTime());
			fileName = speltZipFileName(nric, fileName, companyCode, policyNum, curentTime);
		}

		if (isEncrypt && !StringUtils.isEmpty(password)) {
			removeDuplicateFile(fileList);
			File[] files = new File[fileList.size()];
			files = fileList.toArray(files);
			fileDataByte = ZipOutput.getEncryptZipByte(files, password);
			String zipFileFullPath = zipFilePath + fileName;
			File zipFile = new File(zipFileFullPath);
			writeByteToFile(fileDataByte, zipFile);
			zipFile.deleteOnExit();
		} else {
			removeDuplicateFilePath(filePathList);
			String zipDocs = fileToZip(zipFilePath, filePathList);
			File zipFile = new File(zipDocs);
			fileDataByte = getFileBytes(zipFile);
			zipFile.deleteOnExit();
		}

		result.setFileName(fileName);
		result.setFilePath(zipTmpPath);
		return fileDataByte;
	}

  private String speltZipFileName(String nric, String fileName, String companyCode,
      String policyNum, String curentTime) {
    if (!StringUtils.isEmpty(companyCode)) {
    	fileName += companyCode + '_';
    }
    if (!StringUtils.isEmpty(policyNum)) {
    	fileName += policyNum + '_';
    }
    if (!StringUtils.isEmpty(nric)) {
    	fileName += nric + '_';
    }
    fileName += curentTime + ZIP;
    return fileName;
  }

	public void delDir(String path) {
		File dir = new File(path);
		if (dir.exists()) {
			File[] tmp = dir.listFiles();
			for (int i = 0; i < tmp.length; i++) {
				if (tmp[i].isDirectory()) {
					delDir(path + '/' + tmp[i].getName());
				} else {
					try {
						Files.delete(Paths.get("", tmp[i].getPath()));
					} catch (IOException e) {
						LogUtil.logException(m_Logger, tmp[i].getPath(), e);
					}
				}
			}
			try {
				Files.delete(Paths.get("", path));
			} catch (IOException e) {
				LogUtil.logException(m_Logger, "delete folder failed : " + path, e);
			}
		}
	}

	private void removeDuplicateFile(ArrayList<File> fileList) {
		List<String> checkFilePathList = new ArrayList<String>();
		java.util.Iterator<File> iterator = fileList.iterator();
		String filePath = null;
		while (iterator.hasNext()) {
			filePath = iterator.next().getAbsolutePath();
			if (!checkFilePathList.contains(filePath)) {
				checkFilePathList.add(filePath);
			} else {
				iterator.remove();
			}
		}
	}

	private void removeDuplicateFilePath(List<String> filePathList) {
		List<String> checkFilePathList = new ArrayList<String>();
		java.util.Iterator<String> iterator = filePathList.iterator();
		String filePath = null;
		while (iterator.hasNext()) {
			filePath = iterator.next();
			if (!checkFilePathList.contains(filePath)) {
				checkFilePathList.add(filePath);
			} else {
				iterator.remove();
			}
		}
	}

	public byte[] getEncryptZipByte(java.io.File[] srcfile, String password) throws IOException {
		byte[] tempBytes = (byte[]) null;
		byte[] buf = new byte['?'];
		try (ByteArrayOutputStream tempOStream = new ByteArrayOutputStream(1024)) {
			try (EncryptZipOutput out = new EncryptZipOutput(tempOStream, password)) {
				for (int i = 0; i < srcfile.length; i++) {
					try (FileInputStream in = new FileInputStream(srcfile[i])) {
						out.putNextEntry(new nochump.util.zip.EncryptZipEntry(srcfile[i].getName()));
						int len;
						while ((len = in.read(buf)) > 0) {
							out.write(buf, 0, len);
						}
					}

				}
				tempOStream.flush();
				out.close();
				tempBytes = tempOStream.toByteArray();
				tempOStream.close();
				return tempBytes;

			}
		}

	}

	public String getFileName(ExportDocInfoParam exportDocInfoParam) throws RemoteException {
		String formName = exportDocInfoParam.getFormName();
		String formId = exportDocInfoParam.getFormId();
		List<Map<String, String>> docInfo = getDocumentInfo(exportDocInfoParam.getDocumentID());
		String objectId = docInfo.get(0).get("OBJECT_ID");
		String fileName = docInfo.get(0).get("FILENAME");
		String fileSuffix = fileName.substring(fileName.lastIndexOf('.'));
		if ("Y".equalsIgnoreCase(exportDocInfoParam.getVoidFlag())) {
			// 2018/08/31 CASEPP-6313 Error happens when export multiple documents from
			// policy document list. mod by bsnpc1n
			if (!formName.equals("")) {
				fileName = formId + '_' + formName.replaceAll("[\\|/|:|\\*|\\?|\"|>|<|\\|]", "_") + "_(Void)_" + objectId + fileSuffix;
			} else {
				fileName = formId + "_(Void)_" + objectId + fileSuffix;
			}
		} else {
			// 2018/08/31 CASEPP-6313 Error happens when export multiple documents from
			// policy document list. mod by bsnpc1n
			if (!formName.equals("")) {
				fileName = formId + '_' + formName.replaceAll("[\\|/|:|\\*|\\?|\"|>|<|\\|]", "_") + '_' + objectId + fileSuffix;
			} else {
				fileName = formId + '_' + objectId + fileSuffix;
			}
		}
		return fileName;
	}
	
	public static void main(String[] arg) throws RemoteException, IOException{
//	  String str="test\\1/2:3*4?5\"6>7<8|9'";
//	  System.out.println(str.replaceAll("[\\\\|/|:|\\*|\\?|\"|>|<|\\|]", "_"));
	  
	  String src = "D:\\Case360\\doc1.pdf";
	  String pages = "1-2";
	  System.out.println(getPageListFromString(pages, src));
	  
	}

	private void writeByteToFile(byte[] byteArray, File dest) throws IOException {

		try (ByteArrayInputStream inputStream = new ByteArrayInputStream(byteArray)) {
			try (FileOutputStream outStream = new FileOutputStream(dest);) {

				FileCopyUtils.copy(inputStream, outStream);
			}
		}
	}

	private void copyFile(File src, File dest) throws IOException {

		try (BufferedInputStream inputStream = new BufferedInputStream(new FileInputStream(src));) {
			try (FileOutputStream outStream = new FileOutputStream(dest)) {
				FileCopyUtils.copy(inputStream, outStream);
			}
		}
	}

	private void splitPdf(String src, String dest, List<Integer> pageList)
			throws IOException, DocumentException {
		PDFUtil.splitPdf(src, dest, pageList);
	}

	public static List<Integer> getPageListFromString(String pages, String src) throws IOException, RemoteException {
		int num = PDFUtil.getPageNumber(src);
//		if (StringUtils.isEmpty(pages)) {
//			throw new RemoteException("System can not get available page contents by the specified page numbers.");
//		}
		List<Integer> pageList = new ArrayList<Integer>();
		String[] pageArray = pages.split(",");
		for (String page : pageArray) {
			getPageList(num, pageList, page);
		}

		if (!StringUtils.isEmpty(pages) && pageList.isEmpty()) {
			throw new RemoteException("System can not get available page contents by the specified page numbers.");
		}

		return pageList;
	}

	private static void getPageList(int num, List<Integer> pageList, String page) throws RemoteException {
	  if(StringUtil.isBlank(page)) {
	    return;
	  }
	  
	  if (page.contains("-")) {
			String[] newPages = page.split("-");
			int startNum = 0;
			int endNum = 0;
			try {
				startNum = Integer.valueOf(newPages[0]);
				endNum = Integer.valueOf(newPages[1]);
				if (startNum > endNum) {
					int temp = startNum;
					startNum = endNum;
					endNum = temp;
				}
			} catch (NumberFormatException e) {
				return;
			}

			if (newPages.length == 2 && startNum >= 1 && endNum <= num) {

				getPageList(pageList, startNum, endNum);
			} else if (newPages.length != 2) {
				throw new RemoteException("Wrong page format!(" + page + ")");
			} else if (startNum > num || endNum > num) {
				// 2018/08/27 CASEPP-7378 Input page number more than max page number, the
				// message is "Wrong page scope!(wrong page num:5, page num should be in
				// pageScope: (0,2])", please change to "The max page number is {max page
				// number}, please input correct page number."
				throw new RemoteException("The max page number is " + num + ", please input correct page number.");
			} else {
				return;
			}
		} else {
			getPageListAssist(num, pageList, page);
		}
	}

  private static void getPageListAssist(int num, List<Integer> pageList, String page)
      throws RemoteException {
    int pageNum = 0;
    try {
    	pageNum = Integer.valueOf(page);
    } catch (NumberFormatException e) {
    	throw new RemoteException("Wrong page format!(" + page + ")", e);
    }
    if (pageNum >= 1 && pageNum <= num) {
    	if (!pageList.contains(pageNum)) {
    		pageList.add(pageNum);
    	}
    } else {
    	// 2018/08/27 CASEPP-7378 Input page number more than max page number, the
    	// message is "Wrong page scope!(wrong page num:5, page num should be in
    	// pageScope: (0,2])", please change to "The max page number is {max page
    	// number}, please input correct page number."
    	throw new RemoteException("The max page number is " + num + ", please input correct page number.");
    }
  }

	private static void getPageList(List<Integer> pageList, int startNum, int endNum) {
		for (int i = startNum; i <= endNum; i++) {
			if (!pageList.contains(i)) {
				pageList.add(i);
			}
		}
	}

	private String getDocPath(String docId) throws RemoteException {

		String message = String.format("FunctionName: getDocPath docId:%s" , docId);
		LogUtil.logInfo(m_Logger, message + IS_ENTERING);

		String docPath = "";
		try {

			FSVersionElement fse = getLatestVerFSObj(docId);
			if (null != fse) {

				StorageElement storageElement = fse.getStorageElement();

				docPath = storageElement.getLocation() + storageElement.getDirectoryPrefix()
						+ storageElement.getDiskFileName();

			}
			LogUtil.logInfo(m_Logger, message + IS_LEAVING);
		} catch (Exception e) {
			throw LogUtil.logException(m_Logger, message, e);
		}
		return docPath;
	}

	/**
	 * 
	 * @param zipFilePath
	 * @param fileList
	 * @return
	 */
	private String fileToZip(final String zipFilePath, final List<String> fileList) {

		final String message = String.format("FunctionName: fileToZip zipFilePath:%s fileListLength:%s" ,zipFilePath,fileList.size());
		LogUtil.logInfo(m_Logger, message + IS_ENTERING);
		LogUtil.logInfo(m_Logger, fileList.toString());

		String fileName = new Date().getTime() + "";
		File zipFile = new File(zipFilePath + "/" + fileName + ZIP);

		if (zipFile.exists()) {
			this.m_Logger.error("zipFile Already exist");
		} else {
			try (ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(zipFile)))) {
				zos.setEncoding(PropertyUtil.getCommonProperty("FILETOZIP_ENCODING"));

				// 2018/08/15 CASEPP-6313 Error happens when export multiple documents from
				// policy document list - mod by bsnpc1n
				// move for loop into try catch block.
				genZipFile(fileList, message, zos);
				LogUtil.logInfo(m_Logger, message + IS_LEAVING);
			} catch (FileNotFoundException e) {
				LogUtil.logException(m_Logger, message, e);
			} catch (IOException e) {
				LogUtil.logException(m_Logger, message, e);
			}
		}
		return zipFilePath + "/" + fileName + ZIP;

	}

	private void genZipFile(List<String> fileList, String message, ZipOutputStream zos) {

		for (String f : fileList) {
			File fs = new File(f);
			ZipEntry zipEntry = new ZipEntry(fs.getName());
			try {
				zos.putNextEntry(zipEntry);

				try (FileInputStream fis = new FileInputStream(fs)) {
					byte[] bufs = new byte[1024 * 10];
					try (BufferedInputStream bis = new BufferedInputStream(fis, 1024 * 10)) {

						int read = 0;
						while ((read = bis.read(bufs, 0, 1024 * 10)) != -1) {
							zos.write(bufs, 0, read);
						}
					}
				}
			} catch (IOException e) {
				LogUtil.logException(m_Logger, message, e);
			}
		}

	}

	@Override
	public String getUserIdByDocId(String docId) throws RemoteException {
		String message = String.format("FunctionName: getUserIdByDocId docId:%s", docId);
		LogUtil.logInfo(m_Logger, message + IS_ENTERING);

		String userId = "";
		try {
			FSVersionElement fse = getLatestVerFSObj(docId);
			if (null != fse) {
				userId = fse.getCreatedBy();
			}
			LogUtil.logInfo(m_Logger, message + IS_LEAVING);
		} catch (FinderException e) {

			throw LogUtil.logException(m_Logger, message, e);
		} catch (RemoteException e) {
			throw LogUtil.logException(m_Logger, message, e);
		}

		return userId;
	}

	private FSVersionElement getLatestVerFSObj(String docId) throws FinderException, RemoteException {
		List<FSVersionElement> list = getFsEJB().getDocumentElements(new BigDecimal(docId), true);
		int latestVer = Integer.valueOf(getDocLatestVersion(docId));
		for (FSVersionElement fse : list) {
			StorageElement storageElement = fse.getStorageElement();

			if (storageElement.getVersionNumber() == latestVer) {
				return fse;
			}
		}
		return null;
	}

	@Override
	public Timestamp getDocCreateDate(String docId) throws RemoteException {
		String message = String.format("FunctionName: getDocCreateDate docId:%s" , docId);
		LogUtil.logInfo(m_Logger, message + IS_ENTERING);

		Timestamp creationDate = null;
		try {
			FSVersionElement fse = getLatestVerFSObj(docId);
			if (null != fse) {
				creationDate = fse.getCreatedDateTime();
			}
			LogUtil.logInfo(m_Logger, message + IS_LEAVING);
		} catch (Exception e) {

			throw LogUtil.logException(m_Logger, message, e);
		}

		return creationDate;
	}

	@Override
	public String getDocLatestVersion(String docId) throws RemoteException {
		String message = String.format("FunctionName: getDocCreateLatestVersion docId:%s" , docId);
		LogUtil.logInfo(m_Logger, message + IS_ENTERING);

		List<FSVersionElement> list = new ArrayList<FSVersionElement>();
		int latestVer = 0;
		try {
			list = getFsEJB().getDocumentElements(new BigDecimal(docId), true);

			for (FSVersionElement fse : list) {
				StorageElement storageElement = fse.getStorageElement();
				if (latestVer < storageElement.getVersionNumber()) {
					latestVer = storageElement.getVersionNumber();
				}

			}
			LogUtil.logInfo(m_Logger, message + IS_LEAVING);
		} catch (Exception e) {

			throw LogUtil.logException(m_Logger, message, e);
		}
		return new BigDecimal(latestVer).toString();
	}

	@Override
	public ArrayList<Map<String, Object>> doSearch(Map<String, String> queryParams) throws RemoteException {
		String message = "FunctionName: doSerach";
		LogUtil.logInfo(m_Logger, message + IS_ENTERING);

		ArrayList<Map<String, Object>> resultList = queryHelper.doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_DOCUMENTSEARCH"));

		LogUtil.logInfo(m_Logger, message + IS_LEAVING);
		return resultList;
	}

	@Override
	public List<Map<String, Object>> getDocVersionList(String docId) throws RemoteException {
		String message = String.format("FunctionName:  getDocVersionList docId:%s" , docId);
		LogUtil.logInfo(m_Logger, message + IS_ENTERING);

		List<Map<String, Object>> verList = new ArrayList<Map<String, Object>>();
		try {
			List<FSVersionElement> feList = getFsEJB().getVersions(new BigDecimal(docId));
			for (FSVersionElement fse : feList) {
				Map<String, Object> map = new HashMap<String, Object>();
				map.put("version", fse.getVersionNumber());
				map.put("userId", fse.getCreatedBy());
				map.put("timeStamp", fse.getCreatedDateTime());
				verList.add(map);
			}
			LogUtil.logInfo(m_Logger, verList.toString());
			LogUtil.logInfo(m_Logger, message + IS_LEAVING);
		} catch (RemoteException e) {

			throw LogUtil.logException(m_Logger, message, e);
		}
		return verList;
	}

	private void judgeCaseIdAndDocId(String docId) throws RemoteException {
		String caseId = "";
		List<Map<String, Object>> result = getCaseIdByDocId(docId);

		for (Map<String, Object> map : result) {
			for (Map.Entry<String, Object> m : map.entrySet()) {
				caseId = m.getValue().toString();
				if (caseId == null || caseId.trim().length() < 1) {
					return;
				} else {
					reIndexDoc(caseId, docId);
				}
			}
		}
	}

	@Override
	public boolean deleteDoc(String docId) throws RemoteException {
		try {
			judgeCaseIdAndDocId(docId);
			getFsEJB().deleteElement(new BigDecimal(docId));
		} catch (RemoveException e) {

			LogUtil.logError(m_Logger, e.getMessage());
			return false;
		}
		return true;
	}

	@Override
	public boolean setLogicalDeletionFlag(String docId) throws RemoteException {
		String isDeleted;
		try {
			judgeCaseIdAndDocId(docId);
			FmsRow fms = getFsEJB().getFileStoreFields(new BigDecimal(docId));
			isDeleted = fms.getField(PropertyUtil.getCommonProperty(IS_DELETED)).getValue().toString();
			if (isDeleted == null) {
				return false;
			}
			if (Constants.TRUE.equalsIgnoreCase(isDeleted)) {
				return false;
			}
			if (Constants.FALSE.equalsIgnoreCase(isDeleted)) {
				fms.setValue(PropertyUtil.getCommonProperty(IS_DELETED), Constants.TRUE);
				getFsEJB().setFileStoreFields(new BigDecimal(docId),
						getFsEJB().getFileStoreFields(new BigDecimal(docId)), fms, false);
				return true;
			}
		} catch (FinderException e) {

			LogUtil.logError(m_Logger, e.getMessage());
			return false;
		} catch (SonoraException e) {

			LogUtil.logError(m_Logger, e.getMessage());
			return false;
		}
		return false;
	}

	@Override
	public boolean setFSFields(String docId, Map<String, String> fieldProperties) throws RemoteException {
		String message = "FunctionName: setFSFields(" + docId + "," + fieldProperties.toString() + ")";
		LogUtil.logInfo(m_Logger, message + IS_ENTERING);
		try {
			FmsRow fms = getFsEJB().getFileStoreFields(new BigDecimal(docId));
			for (Entry<String, String> fldName : fieldProperties.entrySet()) {
				LogUtil.logInfo(m_Logger, "fldName =" + fldName.getKey());
				if (fms.getField(fldName.getKey()) == null) {
					continue;
				}
				if (fieldProperties.get(fldName.getKey()) != null || "".equals(fieldProperties.get(fldName.getKey()))) {
					fms.setValue(fldName.getKey(), fieldProperties.get(fldName.getKey()));
				}
			}

			FmsRowConflict result = getFsEJB().setFileStoreFields(new BigDecimal(docId),
					getFsEJB().getFileStoreFields(new BigDecimal(docId)), fms, true);
			boolean fResult = (result == null || result.conflictCount == 0);
			LogUtil.logInfo(m_Logger, message + " result:+" + fResult + IS_LEAVING);
			return fResult;
		} catch (RemoteException e) {

			LogUtil.logError(m_Logger, String.format(DOC_ID_S_FIELDS_S , docId , fieldProperties.toString()));
			LogUtil.logError(m_Logger, e.getMessage());
			throw e;
		} catch (FinderException e) {

			LogUtil.logError(m_Logger, String.format(DOC_ID_S_FIELDS_S , docId , fieldProperties.toString()));
			LogUtil.logError(m_Logger, e.getMessage());
			throw new RemoteException(e.getMessage());
		} catch (SonoraException e) {

			LogUtil.logError(m_Logger, String.format(DOC_ID_S_FIELDS_S , docId , fieldProperties.toString()));
			LogUtil.logError(m_Logger, e.getMessage());
			throw new RemoteException(e.getMessage());
		}
	}

	@Override
	public List<Map<String, Object>> getCaseIdByDocId(String docId) throws RemoteException {
		String message = "get CaseId by DocId:" + docId + ".";
		LogUtil.logInfo(m_Logger, message + IS_ENTERING);

		Map<String, String> queryParam = new HashMap<String, String>();
		queryParam.put(PropertyUtil.getCommonProperty(DOCID), docId);
		ArrayList<Map<String, Object>> queryResult = queryHelper.doQuery(queryParam,
				PropertyUtil.getScriptAndQueryProperty("QUERY_GETCASEIDBYDOCID"));

		return queryResult;
	}

	@Override
	public String getDocIdByIndex(String rpKeyStr) throws RemoteException {
		StringBuilder sb = new StringBuilder();
		String docId;
		RepositoryKey rpKey = RepositoryKey.getInstance(rpKeyStr);
		sb.append(INDEXING_REPOSITORY_KEY + rpKey.toString());
		FmsRow nfr;
		try {
			nfr = getWfEJB().getWorkItemFields(rpKey.getWorkflowId(), rpKey.getEnvelopeId().toString());
			docId = nfr.getField(PropertyUtil.getCommonProperty(DOCID)).getValue().toString();
			sb.append("docId:").append(docId);
			LogUtil.logInfo(m_Logger, sb.toString());
		} catch (FinderException e) {

			throw LogUtil.logException(m_Logger, sb.toString(), e);
		}
		return docId;
	}

	@Override
	public boolean deleteIndexWorkitem(String rpKeyStr) throws RemoteException {
		StringBuilder sb = new StringBuilder();
		RepositoryKey rpKey = RepositoryKey.getInstance(rpKeyStr);
		sb.append(INDEXING_REPOSITORY_KEY + rpKey.toString());
		Envelope wiEvp = getWfEJB().getEnvelope(rpKey.getWorkflowId(), rpKey.getEnvelopeId().toString(), true);
		try {
			getWfEJB().removeFromWorkflow(rpKey.getWorkflowId(), rpKey.getEnvelopeId().toString(),
					wiEvp.getEnvelopeId().toString());
			LogUtil.logInfo(m_Logger, sb.toString());
		} catch (SonoraApplicationException e) {

			throw LogUtil.logException(m_Logger, sb.toString(), e);
		}
		return true;

	}

	@Override
	public boolean deleteIndex(int deleteType, String rpKeyStr) throws RemoteException {
		StringBuilder sb = new StringBuilder();
		String docId;
		boolean flag = false;
		if (deleteType != 0 && deleteType != 1) {
			return flag;
		}
		flag = deleteIndexWorkitem(rpKeyStr);
		if (!flag) {
			sb.append("update Index Delete Sign have error .");
			return flag;
		}
		docId = getDocIdByIndex(rpKeyStr);
		sb.append("delete Indexing docId:").append(docId);
		sb.append(". Delete Type:").append(deleteType).append(".");
		switch (deleteType) {
		case 0:
			flag = deleteDoc(docId);
			break;
		case 1:
			flag = setLogicalDeletionFlag(docId);
			break;
		default:
			flag = false;
			break;
		}
		if (!flag) {
			sb.append("delete document error.");
			LogUtil.logInfo(m_Logger, sb.toString());
			return flag;
		}
		return flag;
	}

	@Override
	public int getIndexItemCount(int queryType) throws RemoteException {
		int queryResultNum = 0;
		String querySQL = null;
		Map<String, String> queryParam = new HashMap<String, String>();
		queryParam.put("ID", "");
		switch (queryType) {
		case 0:
			break;
		case 1:
			querySQL = PropertyUtil.getScriptAndQueryProperty("QUERY_OWNINDEXING");
			break;
		case 2:
			querySQL = PropertyUtil.getScriptAndQueryProperty("QUERY_LOCKINDEXING");
			break;
		case 3:
			querySQL = PropertyUtil.getScriptAndQueryProperty("QUERY_VALIDINDEXING");
			break;
		case 4:
			querySQL = PropertyUtil.getScriptAndQueryProperty("QUERY_INVALIDINDEXING");
			break;
		default:
			querySQL = "";
			break;
		}
		ArrayList<Map<String, Object>> queryResult = queryHelper.doQuery(queryParam, querySQL);
		queryResultNum = queryResult.size();
		return queryResultNum;
	}

	@Override
	public boolean invalidDoc(String rpKeyStr) throws RemoteException {
		StringBuilder sb = new StringBuilder();
		String validFlag;
		RepositoryKey rpKey = RepositoryKey.getInstance(rpKeyStr);
		sb.append(INDEXING_REPOSITORY_KEY + rpKey.toString());
		try {
			FmsRow fms = getWfEJB().getFields(rpKey.getWorkflowId(), rpKey.getEnvelopeId().toString());
			validFlag = fms.getField(PropertyUtil.getCommonProperty(INDEX_VALID_FLAG)).getValue().toString();
			sb.append(fms.getField(PropertyUtil.getCommonProperty(INDEX_VALID_FLAG)));
			if (Constants.TRUE.equalsIgnoreCase(validFlag)) {
				fms.setValue(PropertyUtil.getCommonProperty(INDEX_VALID_FLAG), Constants.FALSE);
				getWfEJB().setWorkItemFields(rpKey.getWorkflowId(), rpKey.getEnvelopeId().toString(), fms);
			}
			LogUtil.logInfo(m_Logger, sb.toString());
			return true;
		} catch (SonoraApplicationException e) {

			throw LogUtil.logException(m_Logger, sb.toString(), e);
		} catch (SonoraException e) {

			throw LogUtil.logException(m_Logger, sb.toString(), e);
		}
	}

	@Override
	public boolean linkDocToWorkFolder(String caseId, String docId, String rpKeyStr) throws RemoteException {
		StringBuilder sb = new StringBuilder();
		boolean flag = false;
		boolean mflag = true;
		RepositoryKey rpKey = RepositoryKey.getInstance(rpKeyStr);
		sb.append(INDEXING_REPOSITORY_KEY + rpKey.toString());
		Map<String, Object> caseFolderDetail = new HashMap<String, Object>();
		String masterFolderId = "";
		String mainCaseId = "";

		try {
			caseFolderDetail = cfHelper.getCasefolderDetail(new BigDecimal(caseId));
			//
			boolean isParentCaseId = caseFolderDetail
					.containsKey(PropertyUtil.getCommonProperty(DOCIMPL_PARENT_CASEID));
			if (!isParentCaseId) {
				masterFolderId = caseId;
			} else {
				masterFolderId = caseFolderDetail.get(PropertyUtil.getCommonProperty(DOCIMPL_PARENT_CASEID))
						.toString();
				mainCaseId = getMainCaseId(caseFolderDetail, caseId);
			}
			flag = indexDocIdToCaseId(masterFolderId, new BigDecimal(docId));
			if (flag && mainCaseId != null && !"".equals(mainCaseId)) {
				mflag = indexDocIdToCaseId(mainCaseId, new BigDecimal(docId));
			}
			if (flag && mflag) {
				deleteIndexWorkitem(rpKeyStr);
			}
			LogUtil.logInfo(m_Logger, sb.toString());
			return flag;
		} catch (Exception e) {

			throw new RemoteException(e.getMessage() + " " + sb.toString());
		}
	}

	@Override
	public boolean linkDocToNewWorkItem(String docId, String displayName, Map<String, String> parameters,
			String rpKeyStr) throws RemoteException {
		BigDecimal caseId = cfHelper.createCaseFolder(displayName, parameters);
		if (caseId != null) {
			linkDocToWorkFolder(caseId.toString(), docId, rpKeyStr);
			return true;
		}
		return false;
	}

	@Override
	public String addDocVersion(String filePath, String docId) throws RemoteException {
		String message = String.format("FunctionName: uploadDoc docId:%s" , docId);
		LogUtil.logInfo(m_Logger, message + IS_ENTERING);

		String version = null;
		try {
			String[] s = filePath.split("/");
			String fileName = s[s.length - 1];
			byte[] data = null;
			File file = new File(filePath);
			data = getFileBytes(file);
			getFsEJB().putFile(new BigDecimal(docId), data, fileName);
			version = getDocLatestVersion(docId);

			LogUtil.logInfo(m_Logger, String.format(FILE_UPLOAD_SUCCESS_DOCID_S , docId));
			LogUtil.logInfo(m_Logger, message + IS_LEAVING);

			return version;

		} catch (Exception e) {
			throw LogUtil.logException(m_Logger, message, e);
		}
	}

	private byte[] getFileBytes(File file) throws RemoteException {
		try (FileInputStream fis = new FileInputStream(file)) {
			try (ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
				byte[] b = new byte[1024];
				int n;
				while ((n = fis.read(b)) != -1) {
					bos.write(b, 0, n);
				}
				bos.flush();

				return bos.toByteArray();
			}
		} catch (Exception e) {

			throw LogUtil.logException(m_Logger, file.toString(), e);
		}
	}

	@Override
	public String splitTIFFDoc(String docId, int[] pageNums) throws RemoteException {

		String path = getDocPath(docId);
		String newTiffPath = getNewTiffFileName(docId);
		String key = "";
		try {
			Tiff tiff = new Tiff(path);
			// get will delete pageFiles
			List<byte[]> pageList = getDeletePages(tiff, pageNums);
			// create new tiff
			Tiff newTiff = new Tiff(newTiffPath, null, true);
			newTiff.insertPages(0, (ArrayList<byte[]>) pageList);
			// copy fileStory
			BigDecimal newDocId = getFsEJB().copyInstance(new BigDecimal(docId));
			// put newTiff to copyFile
			File newFile = new File(newTiffPath);
			byte[] newFileData = getFileBytes(newFile);
			getFsEJB().putFile(newDocId, newFileData, newTiffPath, null, "1", true);
			deleteTiff(tiff, pageNums);

			// newFileStory into indexing
			key = intoIndexing(newDocId.toString());
			return key;

		} catch (UtilityException e) {
			String message = "file is not TIFF ";
			throw LogUtil.logException(m_Logger, message, e);
		}

	}

	private String getNewTiffFileName(String docId) throws RemoteException {
		String message = String.format("FunctionName: getDocPath  docId:%s",docId);
		LogUtil.logInfo(m_Logger, message + IS_ENTERING);

		String docPath = "";
		try {

			FSVersionElement fse = getLatestVerFSObj(docId);
			if (null != fse) {

				StorageElement storageElement = fse.getStorageElement();

				docPath = storageElement.getLocation() + storageElement.getDirectoryPrefix() + "s-"
						+ storageElement.getDiskFileName();

			}
			LogUtil.logInfo(m_Logger, message + IS_LEAVING);
		} catch (Exception e) {

			throw LogUtil.logException(m_Logger, message, e);
		}
		return docPath;
	}

	private List<byte[]> getDeletePages(Tiff tiff, int[] pageNums) {
		ArrayList<byte[]> pageList = new ArrayList<byte[]>();
		try {
			for (int i = 0; i < pageNums.length; i++) {
				pageList.add(tiff.getPage(pageNums[i] - 1, true));
			}
			return pageList;
		} catch (UtilityException e) {
			LogUtil.logException(m_Logger, tiff.toString(), e);

		}
		return new ArrayList<byte[]>();

	}

	private boolean deleteTiff(Tiff tiff, int[] pageNums) {

		try {
			for (int i = 0; i < pageNums.length; i++) {
				tiff.deletePages(pageNums[i] - 1, 1);
				if ((i + 1) < pageNums.length) {
					LogUtil.logInfo(m_Logger, pageNums[i] + ":" + pageNums[i + 1]);
					newPageNum(i, pageNums);
				}

			}
			return true;
		} catch (UtilityException e) {
			LogUtil.logException(m_Logger, tiff.toString(), e);
			return false;
		}
	}

	private int[] newPageNum(int flag, int[] pageNums) {
		for (int i = flag + 1; i < pageNums.length; i++) {
			if (pageNums[i] > pageNums[flag]) {
				pageNums[i] = pageNums[i] - 1;
			}
		}
		return pageNums;

	}

	@Override
	public List<Map<String, String>> getDocumentInfo(String docId) throws RemoteException {

		String message = String.format("FunctionName: getDocumentInfo docId:%s" , docId);
		LogUtil.logInfo(m_Logger, message + "is entering");
		List<Map<String, String>> resultList = new ArrayList<Map<String, String>>();
		Map<String, String> result = new HashMap<String, String>();
		int version = 0;
		try {
			List<Map<String, Object>> versionList = getDocVersionList(docId);

			for (Map<String, Object> m : versionList) {
				version = Integer.parseInt(m.get("version").toString());
				FmsRow row = getFsEJB().getFileStoreFields(new BigDecimal(docId), version);

				FmsField[] fs = row.getFieldList();
				for (int i = 0; i < fs.length; i++) {
					if (fs[i].getValue() == null) {
						result.put(fs[i].getFmsFieldTO().getFieldName(), "");
					} else {
						result.put(fs[i].getFmsFieldTO().getFieldName(), fs[i].getValue().toString());
					}
				}
				String url = "FileStore?op=view&id=" + docId + "&version=" + version;
				result.put("url", url);
				resultList.add(result);
			}
			LogUtil.logInfo(m_Logger, message + "is leaving");
			return resultList;
		} catch (Exception e) {

			throw LogUtil.logException(m_Logger, message, e);
		}
	}

	private Map<String, String> getVoidDocuments() throws RemoteException {
		Map<String, String> result = new HashMap<String, String>();
		try {
			result = fsBean.getVoidDocuments();
		} catch (SQLException e) {

			LogUtil.logError(m_Logger, "Get Void Documents fail.");
			throw new RemoteException(e.getMessage());
		}
		return result;
	}

	@Override
	public void clearVoidPages() throws RemoteException {
		// get void document
		Map<String, String> voidDocs = getVoidDocuments();
		String filePath = null;

		for (Map.Entry<String, String> entry : voidDocs.entrySet()) {
			int deletePages = 0;
			int deleteFlag = 0;
			try {
				// get Tiff physical location
				filePath = getDocPath(entry.getKey());
				// if document is a tiff,get a tiff`s object
				Tiff oldTiff = new Tiff(filePath);

				char[] voidFlag = entry.getValue().toCharArray();
				writeLogAboutVoidTiff("**********************************************************************");
				writeLogAboutVoidTiff("before delete page : DocumentId : " + entry.getKey());
				writeLogAboutVoidTiff("TOTAL_PAGES : " + oldTiff.getPageCount());
				writeLogAboutVoidTiff("PAGEINDICATORS : " + entry.getValue());
				// do delete voidTiffPage
				for (int i = 0; i < voidFlag.length; i++) {
					if (voidFlag[i] == 'V') {
						writeLogAboutVoidTiff("doing.....:");
						deleteFlag = i - deletePages;
						oldTiff.deletePages(deleteFlag, 1);

						writeLogAboutVoidTiff("Delete a Tiff Page: DocumentId is " + entry.getKey()
								+ ",delete pageNum is " + (i + 1));

						deletePages++;
					}
				}
				String pageNums = (voidFlag.length - deletePages) + "";
				String newPageFlag = entry.getValue().replace("V", "");
				Map<String, String> map = new HashMap<String, String>();
				map.put("PAGEINDICATORS", newPageFlag);
				map.put("TOTAL_PAGES", pageNums);
				writeLogAboutVoidTiff("after delete page:");
				writeLogAboutVoidTiff("PAGEINDICATORS : " + newPageFlag);
				writeLogAboutVoidTiff("TOTAL_PAGES : " + pageNums + "\r\n");
				writeLogAboutVoidTiff("**********************************************************************");
				updateFileStoryFields(map, new BigDecimal(entry.getKey()));
			} catch (RemoteException e) {

				writeLogAboutVoidTiff("File Path is not found or error! Document id is " + entry.getKey()
						+ ". Also possible that update PAGEINDICATORS fail." + "\r\n");
				continue;
			} catch (UtilityException e) {
				writeLogAboutVoidTiff("File is not TIFF ! Document id is " + entry.getKey() + "\r\n");
				continue;
			}
		}
	}

	private void writeLogAboutVoidTiff(String info) {
		String dir = PropertyUtil.getCommonProperty("DOC_IMPL_VOIDTIFF_DIR");
		String fileName = PropertyUtil.getCommonProperty("DOC_IMPL_VOIDTIFF_FILENAME");
		File fDir = new File(dir);
		File file = new File(dir + fileName);
		String message = "Function :writeLogAboutVoidTiff ";
		if (!fDir.exists()) {
			try {
				fDir.mkdirs();
				if (!file.exists()) {
					boolean createFile = file.createNewFile();
					if (createFile) {
						LogUtil.logInfo(m_Logger, message + "create file success");
					} else {
						LogUtil.logInfo(m_Logger, message + "create file failed");
					}
				}
			} catch (IOException e) {
				LogUtil.logException(m_Logger, info, e);
			}
		}
		OutputStream fos = null;
		try {
			fos = new FileOutputStream(file, true);
			fos.write((info + "\r\n").getBytes());
		} catch (IOException e) {
			LogUtil.logException(m_Logger, info, e);
		}
		if (fos != null) {
			try {
				fos.close();
			} catch (IOException e) {
				LogUtil.logException(m_Logger, info, e);
			} finally {
				try {
					fos.close();
				} catch (IOException e) {
					LogUtil.logException(m_Logger, info, e);
				}
			}
		}
	}

	/**
	 * return page numbers for document
	 * 
	 * @param docId
	 * @return
	 * @throws RemoteException
	 * @throws UtilityException
	 * @throws FinderException
	 */
	public int getTotalPageNum(String docId) throws RemoteException, FinderException, UtilityException {
		// retrieve real physical path and filename
		FSVersionElement fse = getLatestVerFSObj(docId);
		if (null != fse) {

			StorageElement storageElement = fse.getStorageElement();
			String fileName = storageElement.getDiskFileName();
			StringBuilder sb = new StringBuilder();
			String fullPath = sb.append(storageElement.getLocation()).append(storageElement.getDirectoryPrefix())
					.append(fileName).toString();
			boolean isTiffFile = fileName.matches("^.*?\\.(?i)(tiff|tif)$");// ignore
																			// case
			boolean isPDFFile = fileName.matches("^.*?\\.(?i)(pdf|PDF)$");// ignore
																			// case
			if (isTiffFile) {
				Tiff tiff = new Tiff(fullPath);
				int totalPage = tiff.getPageCount();

				return totalPage;
			} else if (isPDFFile) {
				int totalPage = getPDFPageNum(fullPath);
				return totalPage;
			}

			boolean isImageFile = fileName.matches("^.*?\\.(?i)(jpg|jpeg|png|bmp)$");// ignore case
			if (isImageFile) {
				return 1;
			} else {
				LogUtil.logInfo(m_Logger,
						" DocumentHelperImpl.getTotalPageNum() Currently only support image files including tiff,jpeg,png and bmp, while current file is:"
								+ fileName);
			}
		}
		return 0;
	}

	/**
	 * return JPEG image of specified page for document
	 * 
	 * @throws UtilityException
	 * @throws IOException
	 */
	public byte[] getPageInJpeg(String docId, int page) throws FinderException, UtilityException, IOException {

		return writeJpeg(getPageImage(docId, page), 1.0f);
	}

	private byte[] writeJpeg(byte[] imageBytes, float quality) throws IOException {
		JPEGImageWriteParam jpegEncodeParam = new JPEGImageWriteParam(Locale.getDefault());
		jpegEncodeParam.setCompressionMode(JPEGImageWriteParam.MODE_EXPLICIT);
		jpegEncodeParam.setCompressionQuality(quality);// default to 0.20
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

		final ImageWriter writer = ImageIO.getImageWritersByFormatName("jpeg").next();
		// specifies where the jpg image has to be written
		writer.setOutput(ImageIO.createImageOutputStream(outputStream));
		BufferedImage pageBuff = ImageIO.read(new ByteArrayInputStream(imageBytes));
		// writes the file with given compression level
		// from your JPEGImageWriteParam instance
		writer.write(null, new IIOImage(pageBuff, null, null), jpegEncodeParam);
		byte[] byteArray = outputStream.toByteArray();
		LogUtil.logInfo(m_Logger, "byteArray length:" + String.valueOf(byteArray.length));
		outputStream.flush();
		outputStream.close();
		return byteArray;
	}

	/**
	 * Revised by Henry, accept -1 as last page Revised by Henry, to accept 'Old
	 * style TIFF-JPEG (compression type 6)', but it's not guaranteed since it's out
	 * dated format.
	 * 
	 * @param docId
	 * @param page
	 * @return
	 * @throws FinderException
	 * @throws UtilityException
	 * @throws IOException
	 */
	static int TAG_COMPRESSION = 259;
	static int TAG_JPEG_INTERCHANGE_FORMAT = 513;
	static int COMP_JPEG_OLD = 6;
	static int COMP_JPEG_TTN2 = 7;

	/**
	 * crop signature for customer and save it to filestore
	 * 
	 * @throws IOException
	 */
	public HashMap<String, String> saveSignature(String docId, int page, int x, int y, int width, int height,
			boolean rel_position) throws FinderException, UtilityException, IOException {

		byte[] imageBytes = getPageImage(docId, page);
		if (imageBytes != null) {
			LogUtil.logInfo(m_Logger, "saveSignature start");
			BufferedImage pageBuff = ImageIO.read(new ByteArrayInputStream(imageBytes));
			int imgWidth = pageBuff.getWidth();
			int imgHeight = pageBuff.getHeight();

			StringBuilder sb = new StringBuilder();
			sb.append("Entering saveSignature with parameters docId:").append(docId).append(" page:").append(page);
			sb.append(" x:").append(x).append(" y:").append(y).append(" crop width:").append(width)
					.append(" crop height1:").append(height);
			sb.append("\r\n with image width:").append(width).append(" height:").append(height);
			sb.append("\r\n rel_position:").append(rel_position);
			LogUtil.logInfo(m_Logger, sb.toString());

			// try to calculate absolute position
			// all the relative position are 100 perent based, 9000 means 90.00
			// percent.
			if (rel_position) {
				x = imgWidth * x / 10000;
				y = imgHeight * y / 10000;
				width = imgWidth * width / 10000;
				height = imgHeight * height / 10000;
				StringBuilder sb1 = new StringBuilder();
				sb1.append("Absolute position after adjustment x:").append(x).append(" y:").append(y)
						.append(" crop width:").append(width).append(" crop height2:").append(height);
				sb1.append("\r\n with image width:").append(width).append(" height:").append(height);
				LogUtil.logInfo(m_Logger, sb1.toString());
			}

			if (imgWidth < x || imgHeight < y) {
				LogUtil.logError(m_Logger,
						"DocumentHelperImpl.saveSignature() does not know how to handle illegal x/y( bigger than image width/height), while current document id is:"
								+ docId);
				return null;
			}
			boolean adjusted = false;
			if (imgWidth < x + width) {
				width = imgWidth - x;
				adjusted = true;
			}
			if (imgHeight < y + height) {
				height = imgHeight - y;
				adjusted = true;
			}
			if (adjusted) {
				sb = new StringBuilder();
				sb.append("saveSignature with adjusted crop width:").append(width).append(" crop height3:")
						.append(height);
				LogUtil.logInfo(m_Logger, sb.toString());
			}

			String tmpPath = PropertyUtil.getCommonProperty(TMP_PATH);

			String fileName = "SVS_" + System.nanoTime() + ".jpg";
			String pdfFileName = "SVS_" + System.nanoTime() + PDF;
			String fullPath = tmpPath + "/" + fileName;
			String pdfFullPath = tmpPath + "/" + pdfFileName;

			LogUtil.logInfo(m_Logger, "fullPath:" + fullPath);

			File svsTempFile = new File(fullPath);

			BufferedImage cropImg = pageBuff.getSubimage(x, y, width, height);
			// need to resize cropImg to 320x240 here Henry 2017/03/21
			int imgType = cropImg.getType();
			if (0 == imgType) {// workaround for 0:TYPE_CUSTOM
				imgType = 5;
			}
			// CASEPP-7655 UPDATE BY bsnpc65 2018-9-1
			BufferedImage resizedImg = new BufferedImage(width, height, imgType);
			resizedImg.getGraphics().drawImage(cropImg.getScaledInstance(width, height, java.awt.Image.SCALE_SMOOTH), 0,
					0, null);

			FileOutputStream nImage = new FileOutputStream(svsTempFile);
			ImageIO.write(resizedImg, "jpeg", nImage);

			convertImgToPdf(fullPath, pdfFullPath);

			HashMap<String, String> pm = new HashMap<String, String>();
			pm.put("extension", "pdf");
			pm.put("filename", pdfFileName);
			pm.put("fullpath", pdfFullPath);
			deleteFile(fullPath);
			return pm;

		}
		return null;
	}

	private void convertImgToPdf(String imgFilePath, String pdfFilePath) throws IOException {
		// CASEPP-7655 UPDATE BY BSNPC65 2018-9-1
		Document document = null;
		FileOutputStream fos = null;
		PdfWriter pdfWriter = null;
		try {
		    Image image = Image.getInstance(imgFilePath);
			float imageHeight = image.getScaledHeight();
			float imageWidth = image.getScaledWidth();
			// CASEPP-7655 add by bsnpc65 2018-9-5
			if (imageHeight > 250 || imageWidth > 250) {
				document = new Document(PageSize.A5, 0, 0, 40, 40);
			} else if (imageHeight > 150 || imageWidth > 150) {
				document = new Document(PageSize.A6, 0, 0, 40, 40);
			} else {
				document = new Document(PageSize.A7, 0, 0, 40, 40);
			}
			// CASEPP-7655 add by bsnpc65 2018-9-5
			int i = 0;
			// CASEPP-7655 disabled by bsnpc65 2018-9-5
			while (imageHeight >= 400 || imageWidth >= 400) {
				image.scalePercent((float) (100 - i));
				i++;
				imageHeight = image.getScaledHeight();
				imageWidth = image.getScaledWidth();
				LogUtil.logInfo(m_Logger, "imageHeight->" + imageHeight);
				LogUtil.logInfo(m_Logger, "imageWidth->" + imageWidth);
			}
			fos = new FileOutputStream(pdfFilePath);
			pdfWriter = PdfWriter.getInstance(document, fos);
			// CASEPP-7655 UPDATE BY BSNPC65 2018-9-1
			document.open();
			image.setAlignment(Image.ALIGN_CENTER);
			document.add(image);
		} catch (DocumentException de) {
			LogUtil.logException(m_Logger, de.getMessage(), de);
		} catch (IOException ioe) {
		  LogUtil.logException(m_Logger, ioe.getMessage(), ioe);
		} finally {
		  if (pdfWriter != null) {
            try{
              pdfWriter.close();
            } catch(Exception e) {
              LogUtil.logException(m_Logger, e.getMessage(), e);
            }
          }
		  if (document != null && document.isOpen()) {
		    try{
		      document.close();
		    } catch(Exception e) {
		      LogUtil.logException(m_Logger, e.getMessage(), e);
		    }
          }
		  if (fos != null) {
		    try{
              fos.flush();
              fos.close();
		    } catch(Exception e) {
              LogUtil.logException(m_Logger, e.getMessage(), e);
            }
          }
		}
	}

	@Override
	public List<BigDecimal> uploadDoc(List<String> filePaths, Map<String, String> docFields) throws RemoteException {
		String message = "FunctionName: uploadDoc";
		LogUtil.logInfo(m_Logger, docFields.toString());
		LogUtil.logInfo(m_Logger, message + IS_ENTERING);

		List<BigDecimal> docIds = null;
		try {
			docIds = saveDoc(filePaths);
			// get caseFolder detail
			LogUtil.logInfo(m_Logger, docIds.toString());

			LogUtil.logInfo(m_Logger, docFields.toString());

			for (int i = 0; i < docIds.size(); i++) {
				updateFileStoryFields(docFields, docIds.get(i));
			}
			LogUtil.logInfo(m_Logger, String.format(FILE_UPLOAD_SUCCESS_DOCID_S , docIds.toString()));
			LogUtil.logInfo(m_Logger, message + IS_LEAVING);
		} catch (Exception e) {
			throw LogUtil.logException(m_Logger, message, e);
		}
		return docIds;
	}

	@Override
	public List<BigDecimal> uploadDoc(List<String> filePaths, List<Map<String, String>> docFields)
			throws RemoteException {
		String message = "FunctionName: uploadDoc";
		LogUtil.logInfo(m_Logger, docFields.toString());
		LogUtil.logInfo(m_Logger, message + IS_ENTERING);

		List<BigDecimal> docIds = null;
		try {
			docIds = saveDoc(filePaths);
			// get caseFolder detail
			LogUtil.logInfo(m_Logger, docIds.toString());

			LogUtil.logInfo(m_Logger, docFields.toString());

			if (docIds.size() != docFields.size()) {
				throw new IOException("Wrong parameter size");
			}

			for (int i = 0; i < docIds.size(); i++) {
				updateFileStoryFields(docFields.get(i), docIds.get(i));
			}
			LogUtil.logInfo(m_Logger, String.format(FILE_UPLOAD_SUCCESS_DOCID_S , docIds.toString()));
			LogUtil.logInfo(m_Logger, message + IS_LEAVING);
		} catch (Exception e) {
			throw LogUtil.logException(m_Logger, message, e);
		}
		return docIds;
	}

	@Override
	public List<BigDecimal> uploadDocOnOWS(List<String> filePaths, List<Map<String, String>> docFields)
			throws RemoteException {
		String message = String.format("FunctionName: uploadDocOnOWS filePaths:%s",filePaths.toString());
		LogUtil.logInfo(m_Logger, docFields.toString());
		LogUtil.logInfo(m_Logger, message + IS_ENTERING);

		List<BigDecimal> docIds = null;
		try {
			docIds = saveDocOnOWS(filePaths);
			// get caseFolder detail
			LogUtil.logInfo(m_Logger, docIds.toString());
			if (docIds.size() != docFields.size()) {
				throw LogUtil.logException(m_Logger, "", new IOException("Wrong parameter size"));
			}

			for (int i = 0; i < docIds.size(); i++) {
				updateFileStoryFields(docFields.get(i), docIds.get(i));
			}
			LogUtil.logInfo(m_Logger, String.format(FILE_UPLOAD_SUCCESS_DOCID_S, docIds.toString()));
			LogUtil.logInfo(m_Logger, message + IS_LEAVING);
		} catch (Exception e) {
			throw LogUtil.logException(m_Logger, message, e);
		}
		return docIds;
	}

	/**
	 * not implement method
	 */
	@Override
	public List<BigDecimal> uploadDoc(String caseId, String formId, List<String> filePaths,
			Map<String, String> docFields, List<String> chgIds) throws RemoteException {

		return new ArrayList<BigDecimal>();
	}

	@Override
	public void remove(BigDecimal tableId, BigDecimal S_ROWID)
			throws RemoteException, RemoveException, FinderException {

		getFmsEJB().remove(tableId, S_ROWID);
	}

	private byte[] getPageImage(String docId, int page) throws FinderException, UtilityException, IOException {

	  LogUtil.logInfo(m_Logger, "getPageImage start page:" + page + ",docId:" + docId );
		// retrieve real physical path and filename
		FSVersionElement fse = getLatestVerFSObj(docId);
		byte[] b = null;
		if (null != fse) {

			StorageElement storageElement = fse.getStorageElement();
			String fileName = storageElement.getDiskFileName();
			StringBuilder sb = new StringBuilder();
			String fullPath = sb.append(storageElement.getLocation()).append(storageElement.getDirectoryPrefix())
					.append(fileName).toString();
			boolean isTiffFile = fileName.matches("^.*?\\.(?i)(tiff|tif)$");
			boolean isPDFFile = fileName.matches("^.*?\\.(?i)(pdf|PDF)$");
			boolean isOtherImageFile = fileName.matches("^.*?\\.(?i)(jpg|jpeg|png|bmp|gif)$");
			if (isTiffFile) {
				Tiff tiff = new Tiff(fullPath);
				b = tiff.getPage(page, true);// Don't include
												// thumb nail or
												// extras
			} else if (isPDFFile) {
				b = getPDFByte(page, fullPath);
			} else if (isOtherImageFile) {
				File file = new File(fullPath);
				b = Files.readAllBytes(file.toPath());
			} else {
				return new byte[0];
			}
			LogUtil.logInfo(m_Logger, " b length" + b.length);
			return b;
		}
		return new byte[0];
	}

	private int getPDFPageNum(String fullPath) {
		File pdfFile = new File(fullPath);
		PDDocument pdf;
		int pageNum = 0;
		try {
			pdf = PDDocument.load(pdfFile);
			pageNum = pdf.getNumberOfPages();
		} catch (InvalidPasswordException e) {
			LogUtil.logException(m_Logger, fullPath, e);

		} catch (IOException e) {
			LogUtil.logException(m_Logger, fullPath, e);

		}
		return pageNum;
	}

	private byte[] getPDFByte(int page, String fullPath) {
		byte[] b = null;
		File pdfFile = new File(fullPath);
		try {
			PDDocument doc = PDDocument.load(pdfFile);
			PDFRenderer renderer = new PDFRenderer(doc);
			BufferedImage image = renderer.renderImageWithDPI(page, 96);
			ByteArrayOutputStream swapStream = new ByteArrayOutputStream();
			ImageIO.write(image, "PNG", swapStream);
			b = swapStream.toByteArray();

		} catch (IOException e) {
			LogUtil.logException(m_Logger, fullPath, e);
		}
		return b;
	}

	/**
	 * Get PDF fullPath
	 * 
	 * @param objId
	 * @return String
	 * @author bsnpc1w 2017.9.25
	 * @throws FinderException
	 * @throws RemoteException
	 */
	public String getFullPath(String docId) throws RemoteException, FinderException {
		// retrieve real physical path and filename
		String fullPath = null;
		FSVersionElement fse = getLatestVerFSObj(docId);
		if (null != fse) {

			StorageElement storageElement = fse.getStorageElement();
			String fileName = storageElement.getDiskFileName();
			StringBuilder sb = new StringBuilder();
			fullPath = sb.append(storageElement.getLocation()).append(storageElement.getDirectoryPrefix())
					.append(fileName).toString();

		}
		return fullPath;
	}

	@Override
	public FileStoreElement getElement(BigDecimal documentId, Boolean flag) throws RemoteException, FinderException {
		return getFsEJB().getElement(documentId, true);
	}

	@Override
	public List<FSVersionElement> getDocumentElements(BigDecimal documentId, Boolean flag)
			throws RemoteException, FinderException {
		return getFsEJB().getDocumentElements(documentId, true);
	}

	@Override
	public void getFile(BigDecimal documentId, Integer currentVersion, String targetFileName)
			throws RemoteException, FinderException {
		getFsEJB().getFile(documentId, currentVersion, targetFileName);
	}

	@Override
	public String generateObjectId(BigDecimal id, Integer digits) throws RemoteException {

		HashMap<String, String> params = new HashMap<String, String>();
		params.put("id", id.toString());
		params.put("digits", digits + "");
		params.put("java", "test");
		Map<String, Object> result = ScriptUtil.doScript("PSO.Util.generateObjectId", params, Locale.CHINA,
				getSysSEJB());

		return result == null ? "" : result.get("StrBack").toString();
	}

	// added by Leo Li
	/**
	 * @param tableId
	 * @param templateId
	 * @param contents
	 * @param doucumentName
	 * @param params
	 * @return
	 * @throws RemoteException
	 * @author bsnpc37
	 * @date: 2018-3-29 5:41:33 PM
	 */
	@Override
	public BigDecimal creatFileStoreFromByte(BigDecimal tableId, BigDecimal templateId, byte[] contents,
			String doucumentName, Map<String, String> params) throws RemoteException {
		BigDecimal documentID = null;
		try {
			FmsRowNative frn = getFmsEJB().getNewRow(tableId);
			FmsRow fmsRow = (FmsRow) frn.clone();
			DataFieldUtil.updateTableRow(params, fmsRow);
			documentID = getFsEJB().createInstance(templateId, fmsRow);
			getFsEJB().putFile(documentID, contents, doucumentName);
		} catch (Exception e) {
			throw LogUtil.logException(m_Logger, doucumentName, e);
		}
		return documentID;
	}

	/**
	 * @param documentID
	 * @param contents
	 * @param doucumentName
	 * @throws RemoteException
	 * @author bsnpc37
	 * @date: 2018-3-29 5:41:41 PM
	 */
	@Override
	public void creatFileStoreFromByte(BigDecimal documentID, byte[] contents, String doucumentName)
			throws RemoteException {
		try {
			getFsEJB().putFile(documentID, contents, doucumentName);
		} catch (Exception e) {
			throw LogUtil.logException(m_Logger, doucumentName, e);
		}
	}

	/**
	 * @param documentId
	 * @return
	 * @ throws RemoteException
	 * @author bsnpc37
	 * @date: 2018-3-30 14:16:25
	 */
	@Override
	public String getFile(BigDecimal documentId) throws RemoteException {
		int version = 1;
		String fileBody = null;
		if (documentId != null) {
			version = Integer.valueOf(getDocLatestVersion(documentId.toString()));
		}
		byte[] file = getFsEJB().getFile(documentId, version);
		if (file != null) {
			fileBody = Base64.encodeBase64String(file);
		}
		return fileBody;
	}

	// end

	@Override
	public Map<String, String> getFile(final BigDecimal documentId, String systemNm) throws IOException, DocumentException, FinderException {
		String fileBody = null;
		Map<String, String> returnDataMap = new HashMap<String, String>();
		if (documentId == null) {
			LogUtil.logError(m_Logger, " docOMSDetailsList is empty,not found db rocord");
			throw new ObjectNotFoundException("documentId");
		}
		String docId = documentId.toString();
		String filePath = getFileByDocumentId(docId);
		List<DocOMSDetailsInfo> docOMSDetailsList = docOMSDao.getDocumentsByID(docId);

		List<Map<String, String>> waterMarksList = waterMarksDao
				.queryWaterMarksBySystemNm(SystemNameEnum.getSystemName(systemNm));

		String tmpPath = PropertyUtil.getCommonProperty(TMP_PATH);
		if (docOMSDetailsList != null && docOMSDetailsList.size() > 0) {
			DocOMSDetailsInfo docOMSDetails = docOMSDetailsList.get(0);
			String pageIndicator = docOMSDetails.getPageIndicator();

			String outFileName = tmpPath + "/" + System.nanoTime() + PDF;
			String outFileName2 = tmpPath + "/" + System.nanoTime() + PDF;
			PdfReader reader = new PdfReader(filePath);
			int n = reader.getNumberOfPages();

			LogUtil.logInfo(m_Logger, " pageIndicator page size,NumberOfPages: " + n);
			ignoreVoidPages(returnDataMap, pageIndicator, outFileName, reader, n);

			// add water mark
			String watermarkText = "";
			if (waterMarksList != null && waterMarksList.size() > 0) {
				Map<String, String> map = waterMarksList.get(0);
				watermarkText = map.get(WATERMARK_TEXT);
			}
			if (!StringUtils.isEmpty(watermarkText)) {
				doWaterMark(documentId, outFileName, outFileName2, watermarkText);
			} else {
				LogUtil.logError(m_Logger, " wate mark is empty ");
			}
			try (InputStream inputStream = new FileInputStream(outFileName2)){
				byte[] data = new byte[inputStream.available()];
				int count = 0;
				count = inputStream.read(data);
				if (count == data.length) {
					inputStream.close();
				}
				fileBody = Base64.encodeBase64String(data);
				returnDataMap.put(FILE_BODY, fileBody);
			} catch (IOException e) {
				LogUtil.logException(m_Logger, " wate mark error:", e);
			}

			deleteFile(outFileName);
			deleteFile(outFileName2);

		}
		return returnDataMap;
	}

	private void doWaterMark(final BigDecimal documentId, String outFileName, String outFileName2, String watermarkText)
			throws RemoteException, DocumentException, IOException {
		PdfReader reader;
		int n;
		PdfStamper stamper = null;
		try (BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(outFileName2))) {
			Font f = new Font(FontFamily.COURIER, 100);
			Phrase p = new Phrase(watermarkText, f);
			PdfGState gs = new PdfGState();
			gs.setFillOpacity(0.5f);
			// properties
			PdfContentByte over;
			Rectangle pagesize;
			reader = new PdfReader(outFileName);
			stamper = new PdfStamper(reader, bos);
			n = reader.getNumberOfPages();

			LogUtil.logInfo(m_Logger, " loop over every page,NumberOfPages: " + n);

			double x, y;
			// loop over every page
			for (int i = 0; i < n; i++) {
				pagesize = reader.getPageSizeWithRotation(i + 1);
				x = (float) (((double) pagesize.getLeft() + (double) pagesize.getRight()) / 2);
				y = (float) (((double) pagesize.getTop() + (double) pagesize.getBottom()) / 2);
				over = stamper.getOverContent(i + 1);
				over.saveState();
				over.setGState(gs);
				ColumnText.showTextAligned(over, Element.ALIGN_CENTER, p, (float) x, (float) y, 45);
			}

			bos.flush();
		} catch (Exception e) {

			throw LogUtil.logException(m_Logger, documentId.toString(), e);
		} finally {
			if (stamper != null) {
				stamper.close();
			}

		}
	}

	private void ignoreVoidPages(Map<String, String> returnDataMap, String pageIndicator, String outFileName,
			PdfReader reader, int n) throws RemoteException {
		Document document = null;
		PdfCopy writer = null;
		try (FileOutputStream fileOutputStream = new FileOutputStream(outFileName)) {
			
			document = new Document(reader.getPageSizeWithRotation(1));
			writer = new PdfCopy(document, fileOutputStream);
			document.open();
			int pageIndicatorCount = 0;
			for (int i = 0; i < n; i++) {
				if (i < pageIndicator.length() && pageIndicator.charAt(i) == 'N') {
					pageIndicatorCount++;
					PdfImportedPage page = writer.getImportedPage(reader, pageIndicatorCount);
					writer.addPage(page);
				}
			}

			returnDataMap.put("pageIndicator", pageIndicatorCount + "");
			writer.flush();
		} catch (Exception e) {

			throw LogUtil.logException(m_Logger, " Split PDF VOID page error:", e);
		} finally {
			if (document != null) {
				document.close();
			}
			if (writer != null) {
				writer.close();
			}
		}
	}

	@Override
	public byte[] getFileByte(BigDecimal documentId) throws RemoteException {
		int version = 1;
		if (documentId != null) {
			version = Integer.valueOf(getDocLatestVersion(documentId.toString()));
		}
		byte[] file = getFsEJB().getFile(documentId, version);
		return file;
	}

	/**
	 * 
	 * @param documentId
	 * @param callingSystem
	 * @return
	 * @ throws RemoteException
	 * @author bsnpc37(Leo Li)
	 * @throws FinderException 
	 * @throws IOException 
	 * @throws InvalidPasswordException 
	 * @date Aug 8, 2018 4:29:37 PM
	 */
	@Override
	public Map<String, String> getFilePdf(BigDecimal documentId, Boolean isWaterFlag, String callingSystem)
			throws FinderException, InvalidPasswordException, IOException {
		LogUtil.logInfo(m_Logger, "DocumentHelperImpl function getFilePdf start with params : " + "documentId = "
				+ documentId + " , callingSystem = " + callingSystem);
		String fileBody = null;
		Map<String, String> returnDataMap = new HashMap<String, String>();

		if (documentId == null) {
			return returnDataMap;
		}
		String docId = documentId.toString();
		LogUtil.logInfo(m_Logger, "call docOMSDao.getDocumentsByID start with params : " + docId);
		List<DocOMSDetailsInfo> docOMSDetailsList = docOMSDao.getDocumentsByID(docId);
		LogUtil.logInfo(m_Logger, "call docOMSDao.getDocumentsByID end with result : " + docOMSDetailsList);
		LogUtil.logInfo(m_Logger, "call waterMarksDao.queryWaterMarksBySystemNm start with params : "
				+ SystemNameEnum.getSystemName(callingSystem));
		List<Map<String, String>> waterMarksList = waterMarksDao
				.queryWaterMarksBySystemNm(SystemNameEnum.getSystemName(callingSystem));
		LogUtil.logInfo(m_Logger, "call waterMarksDao.queryWaterMarksBySystemNm end with result : " + waterMarksList);
		if (Lists.isEmpty(docOMSDetailsList)) {
			return returnDataMap;
		}
		DocOMSDetailsInfo docOMSDetails = docOMSDetailsList.get(0);
		String pageIndicator = docOMSDetails.getPageIndicator();
		LogUtil.logInfo(m_Logger, "pageIndicator = " + pageIndicator);
		String fileName = docOMSDetails.getFileName();
		LogUtil.logInfo(m_Logger, "fileName = " + fileName);

		if (!StringUtils.endsWithIgnoreCase(fileName, PFHConstants.SUFFIX_PDF)) {
			return returnDataMap;
		}
		String fullPath = getFullPath(docId);

		if (!isWaterFlag) {
			try (ByteArrayOutputStream memPDFN = new ByteArrayOutputStream()) {

				try (PDDocument doc = PDDocument.load(new File(fullPath))) {

					returnDataMap.put("pageIndicator", doc.getNumberOfPages() + "");
					doc.save(memPDFN);
				}

				byte[] byteArray = memPDFN.toByteArray();
				fileBody = Base64.encodeBase64String(byteArray);
				returnDataMap.put(FILE_BODY, fileBody);
			}
		} else {
			// ADD WATERMARK
			String watermarkText = "";
			if (waterMarksList != null && waterMarksList.size() > 0) {
				Map<String, String> map = waterMarksList.get(0);
				watermarkText = map.get(WATERMARK_TEXT);
				LogUtil.logInfo(m_Logger, "watermarkText = " + watermarkText);
			}
			try (ByteArrayOutputStream memPDFW = PDFUtil.watermarkPDFFilterVoid(new File(fullPath), watermarkText,
					PropertyUtil.getCommonProperty("PDF_WATERMARK_TEXT_FONT_TYPE"),pageIndicator)) {
				byte[] byteArray = memPDFW.toByteArray();
				fileBody = Base64.encodeBase64String(byteArray);
				returnDataMap.put(FILE_BODY, fileBody);
			} catch (Exception e) {
				throw LogUtil.logException(m_Logger, documentId.toString(), e);
			}
		}
		return returnDataMap;
	}

	@Override
	public Map<String, String> getDocPool(String stats, boolean isUpdate) throws Exception {
		Map<String, String> result = new HashMap<>();
		ArrayList<PoolElement> pe = getFsEJB().getPools();
		boolean flag = false;
		String oldConfig = "";
		String updateConfig = "";
		for (PoolElement poolElement : pe) {
			LogUtil.logInfo(m_Logger, "pe :" + poolElement.getPoolId() + ":" + poolElement.getConfiguration());
			if (poolElement.getPoolId() == 4) {
				String config = poolElement.getConfiguration();
				String[] configList = config.split(DOC_POOL_STATE_STR);
				String state = configList[1];
				oldConfig = config;
				if (!state.equals(stats)) {
					config = configList[0] + DOC_POOL_STATE_STR + stats;
					LogUtil.logInfo(m_Logger, "update config :" + config);
					poolElement.setConfiguration(config);
					if (isUpdate) {
						updateConfig = config;
						getFsEJB().updatePool(poolElement);
					}
					flag = true;
				}
				break;
			}
		}
		result.put("SelectConfig", oldConfig);
		result.put("UpdateConfig", updateConfig);
		result.put("isNeedUpdate", flag+"");
		return result;
	}
}