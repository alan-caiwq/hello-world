/**
 * 
 */
package com.aia.case360.web.pojo;

/**
 * @author bsnpc55
 *
 */
public class CitiBankIndicatorMultiInfo {

	private String citiBank;
	private String longDesc;
	private String policyNo;

	public String getCitiBank() {
		return citiBank;
	}

	public void setCitiBank(String citiBank) {
		this.citiBank = citiBank;
	}

	public String getLongDesc() {
		return longDesc;
	}

	public void setLongDesc(String longDesc) {
		this.longDesc = longDesc;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
}
