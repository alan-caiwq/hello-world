package com.aia.case360.JalDocsInterfacesEx.manager;

import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.rmi.RemoteException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.aia.case360.JalDocsInterfacesEx.util.DateUtil;
import com.aia.case360.JalDocsInterfacesEx.util.ImportXmlUtil;
import com.aia.case360.JalDocsInterfacesEx.util.StrUtil;
import com.aia.case360.JalDocsInterfacesEx.util.XmlUtil;
import com.aia.case360.JalDocsInterfacesEx.vo.InputParamVo;
import com.aia.case360.JalDocsInterfacesEx.vo.ObjectDefVo;
import com.aia.case360.JalDocsInterfacesEx.vo.ObjectFieldDefVo;
import com.aia.case360.JalDocsInterfacesEx.vo.ObjectNameDefVo;
import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.common.PropertyUtil;

@Service
public class JalObjectDefManager {

	private Logger m_Logger = LoggerFactory.getLogger(getClass());
	
	private static final String DATEFORMATSTRING = "yyyy-MM-dd";

	private Map objectDefMap = new HashMap();
	private static JalObjectDefManager jalObjectDefManager = null;
	private String xmlDateTimeFormat = PropertyUtil.getCommonProperty("XML_DATETIME_FORMAT");

	public Map getObjectDefMap() {
		return objectDefMap;
	}

	public void setObjectDefMap(Map objectDefMap) {
		 this.objectDefMap = objectDefMap;
	}

	@Autowired
	private JalDocManager jalDocManager;

	/**
	 * Singleton for the releaseObjectDefManager
	 * 
	 * @return
	 * @ throws RemoteException
	 */
	// 001
	public synchronized static JalObjectDefManager getInstance() throws RemoteException {
		if (jalObjectDefManager == null) {
			jalObjectDefManager = new JalObjectDefManager();
		}
		return jalObjectDefManager;
	}

	public JalObjectDefManager() {
		try {
			process();
		} catch (Exception e) {

			 LogUtil.logException(m_Logger, "", e);
		}
	}

	/**
	 * Load the object name map in the buffer
	 * 
	 * @ throws RemoteException
	 */
	public void process() throws RemoteException {
		LogUtil.logInfo(m_Logger,"[" + getClass().getSimpleName() + "] : enter process");

		Document doc = loadObjectXML();
		loadObjectDefMap(doc);

		LogUtil.logInfo(m_Logger,"[" +  getClass().getSimpleName() + "] : exit process");
	}

	/**
	 * Load the object xml in the buffer
	 * 
	 * @return
	 * @ throws RemoteException
	 */
	protected Document loadObjectXML() throws RemoteException {
		Document doc = null;

		LogUtil.logInfo(m_Logger,"[" +  getClass().getSimpleName() + "] : loading Object.xml");

		// Load the object xml file
		InputStream is = XmlUtil.getInputStreamFromResource("Object.xml");

		doc = ImportXmlUtil.loadXML(is);

		return doc;
	}

	/**
	 * Load the object definition from the xml into the buffer map
	 * 
	 * @param doc
	 * @ throws RemoteException
	 */
	protected void loadObjectDefMap(Document doc) throws RemoteException {

		// Check the present of XML node
		NodeList objectList = ImportXmlUtil.getNodeListByXpath(doc, "//Object");

		for (int i = 0; i < objectList.getLength(); i++) {

			Node objectNode = objectList.item(i);

			if (objectNode instanceof Element) {
				ObjectDefVo objectDefVo = loadObjectDef(objectNode);

				objectDefMap.put(objectDefVo.getObjectType(), objectDefVo);
			}
		}

		LogUtil.logInfo(m_Logger, getClass().getSimpleName() + " : exit loadObjectDefMap" + objectDefMap);
	}

	/**
	 * Load the object name detail properties into the buffer map
	 * 
	 * @param objNameNode
	 * @return
	 * @ throws RemoteException
	 */
	protected ObjectDefVo loadObjectDef(Node objectDefNode) throws RemoteException {

		ObjectDefVo objectDefVo = new ObjectDefVo();

		Element objectDefElement = (Element) objectDefNode;
		String objectType = objectDefElement.getAttribute("type");

		if (objectType != null) {
			objectDefVo.setObjectType(objectType);
		}

		List objectNameDefList = loadObjectNameDef(objectDefNode);
		objectDefVo.setObjectNameDefList(objectNameDefList);

		Map objectFieldDefMap = loadObjectFieldDefs(objectDefNode);
		objectDefVo.setObjectFieldDefMap(objectFieldDefMap);

		LogUtil.logInfo(m_Logger, getClass().getSimpleName() + " : loadObjectDef [" + objectType + "] loaded");

		return objectDefVo;
	}

	/**
	 * Load the object name definition into the buffer map
	 * 
	 * @param objectNameDefNode
	 * @return
	 * @ throws RemoteException
	 */
	protected List loadObjectNameDef(Node objectDefNode) throws RemoteException {

		List objectNameDefList = new ArrayList();

		// Check the present of XML node
		NodeList objectNameDefNodeList = ImportXmlUtil.getNodeListByXpath(objectDefNode, "Definition");

		for (int i = 0; i < objectNameDefNodeList.getLength(); i++) {
			Node objectNameDefNode = objectNameDefNodeList.item(i);

			if (objectNameDefNode instanceof Element) {
				Element objectNameDefElement = (Element) objectNameDefNode;

				String conversionMethodName = objectNameDefElement.getAttribute("conversion");
				String length = objectNameDefElement.getAttribute("length");

				String objectNameDef = ImportXmlUtil.getNodeTextVal(objectNameDefNode);

				ObjectNameDefVo objectNameDefVo = new ObjectNameDefVo();
				objectNameDefVo.setObjectNameDef(objectNameDef);
				objectNameDefVo.setConversion(conversionMethodName);
				objectNameDefVo.setLength(length);
				objectNameDefList.add(objectNameDefVo);
			}
		}

		return objectNameDefList;
	}

	/**
	 * Load the object fields with conversion into the buffer map
	 * 
	 * @param objectDefNode
	 * @return
	 * @ throws RemoteException
	 */
	protected Map loadObjectFieldDefs(Node objectDefNode) throws RemoteException {

		LogUtil.logInfo(m_Logger,"[" +  getClass().getSimpleName() + "] : enter loadObjectFieldDefs ");

		Map objectFieldDefMap = new HashMap();

		// Check the present of XML node
		NodeList objectFieldDefList = ImportXmlUtil.getNodeListByXpath(objectDefNode, "Field");

		for (int i = 0; i < objectFieldDefList.getLength(); i++) {
			Node objectFieldDefNode = objectFieldDefList.item(i);

			if (objectFieldDefNode instanceof Element) {
				Element objectFieldDefElement = (Element) objectFieldDefNode;

				String objectFieldName = objectFieldDefElement.getAttribute("name");
				String isObjectFieldRequired = objectFieldDefElement.getAttribute("required");
				String conversionMethodName = objectFieldDefElement.getAttribute("conversion");

				String objectXmlFieldName = ImportXmlUtil.getNodeTextVal(objectFieldDefNode);

				ObjectFieldDefVo objectFieldDefVo = new ObjectFieldDefVo();

				objectFieldDefVo.setRequired(isObjectFieldRequired);
				objectFieldDefVo.setConversion(conversionMethodName);
				objectFieldDefVo.setObjectXmlFieldName(objectXmlFieldName);
				objectFieldDefVo.setObjectFieldName(objectFieldName);

				objectFieldDefMap.put(objectFieldName, objectFieldDefVo);
			}
		}

		return objectFieldDefMap;
	}

	/**
	 * Construct the object name into buffer according to the definition in the
	 * objectName.xml
	 * 
	 * @param objectType
	 * @param params
	 * @return
	 * @ throws RemoteException
	 */
	public String constructDynamicObjName(String objectType, InputParamVo params) throws RemoteException {

		String dynObjName = "";
		String temp;
		ObjectDefVo objectDefVo = (ObjectDefVo) objectDefMap.get(objectType);

		if (objectDefVo != null) {
			List objectNameDefList = objectDefVo.getObjectNameDefList();

			Iterator it = objectNameDefList.iterator();
			while (it.hasNext()) {
				ObjectNameDefVo objectNameDefVo = (ObjectNameDefVo) it.next();

				String conversionMethodName = objectNameDefVo.getConversion();

				String objectNameDef = objectNameDefVo.getObjectNameDef();

				// get length 001
				String length = objectNameDefVo.getLength();

				String objectNameDefXmlVal = getObjectNameDefXmlVal(objectNameDef, params);
				temp = getXmlValAfterConversion(conversionMethodName, objectNameDef, objectNameDefXmlVal);
				dynObjName += temp;

				// check whether the field length is correct. 001
				if (!StringUtils.isBlank(length) && (temp == null || Integer.parseInt(length) != temp.length())) {
					LogUtil.logError(m_Logger, "Object name filed length is incorrect, Object filed:" + objectNameDef
							+ ", Expected field length:" + length);
					throw new RemoteException("Object name filed length is incorrect, Object filed:" + objectNameDef
							+ ", Expected field length:" + length);
				}
			}
		}
		return dynObjName;
	}

	/**
	 * Get the object name according to the object name definition in the object.xml
	 * with the values from the workitem properties map
	 * 
	 * @param objNameDef
	 * @param params
	 * @return
	 * @ throws RemoteException
	 */
	public String getObjectNameDefXmlVal(String objectNameDef, InputParamVo params) throws RemoteException {

		LogUtil.logInfo(m_Logger, getClass().getSimpleName() + " : objectNameDef=" + objectNameDef);

		String objectNameDefXmlVal = "";
		Map parFormFieldsMap = jalDocManager.getParFormFieldsMap();

		if (parFormFieldsMap == null || parFormFieldsMap.isEmpty()) {
			parFormFieldsMap = jalDocManager.getParentInfo(params);
			jalDocManager.setParFormFieldsMap(parFormFieldsMap);
		}

		String companyNo = (String) parFormFieldsMap.get("companyNo");
		String processType = (String) parFormFieldsMap.get("processType");
		String receivedDate = (String) parFormFieldsMap.get("receivedDate");
		String formId = (String) parFormFieldsMap.get("formId");
		String statusIndicator = (String) parFormFieldsMap.get("statusIndicator");
		String polNum = (String) parFormFieldsMap.get("policyNo");
		String requestNo = (String) parFormFieldsMap.get("requestNo");

		if ("company_no".equals(objectNameDef)) {
			objectNameDefXmlVal = StrUtil.nullToEmpty(companyNo);
		} else if ("process_type".equals(objectNameDef)) {
			objectNameDefXmlVal = StrUtil.nullToEmpty(processType);
		} else if ("dteReceive".equals(objectNameDef)) {
			objectNameDefXmlVal = StrUtil.nullToEmpty(receivedDate);
		} else if ("form_type".equals(objectNameDef)) {
			objectNameDefXmlVal = StrUtil.nullToEmpty(formId);
		} else if ("qc_flag".equals(objectNameDef)) {
			objectNameDefXmlVal = StrUtil.nullToEmpty(statusIndicator);
		}

		if (processType.startsWith("POS") || processType.startsWith("CLM")) {
			if ("policy_no".equals(objectNameDef)) {
				objectNameDefXmlVal = StrUtil.nullToEmpty(polNum);
			} else if ("folder_key1".equals(objectNameDef)) {
				// should be requestNo
				objectNameDefXmlVal = StrUtil.nullToEmpty(requestNo);
			}
		} else if (processType.startsWith("UNI") && ("folder_key1".equals(objectNameDef))) {
			// should be requestNo
			objectNameDefXmlVal = StrUtil.nullToEmpty(polNum);
		}

		return objectNameDefXmlVal;
	}

	/**
	 * Get the object field value after converting the input xml field
	 * 
	 * @param conversionMethodName
	 * @param xmlFieldName
	 * @param xmlFieldVal
	 * @return
	 * @ throws RemoteException
	 */
	public String getXmlValAfterConversion(String conversionMethodName, String xmlFieldName, String xmlFieldVal)
			throws RemoteException {

		LogUtil.logInfo(m_Logger, getClass().getSimpleName() + " : getXmlValAfterConversion conversionMethodName="
				+ conversionMethodName + ", xmlFieldName=" + xmlFieldName + ", xmlfieldVal=" + xmlFieldVal);

		String xmlValAfterConversion = "";

		if (conversionMethodName == null || conversionMethodName.isEmpty()) {
			xmlValAfterConversion = xmlFieldVal;
		} else if (conversionMethodName.equals("toStr")) {
			xmlValAfterConversion = xmlFieldName;
		} else {
			xmlValAfterConversion = invokeConversion(conversionMethodName, xmlFieldVal);
		}

		LogUtil.logInfo(m_Logger, getClass().getSimpleName() + " : getXmlValAfterConversion xmlValAfterConversion="
				+ xmlValAfterConversion);

		return xmlValAfterConversion;
	}

	/**
	 * Invoke the conversion method for the input object name properties
	 * 
	 * @param conversionMethodName
	 * @param iStr
	 * @return
	 * @throws FwException
	 */
	protected String invokeConversion(String conversionMethodName, String iStr) throws RemoteException {

		String modifiedStr = "";

		try {
			Class cls =  getClass();
			Class types[] = new Class[1];
			types[0] = String.class;
			Method meth = cls.getMethod(conversionMethodName, types);
			Object arglist[] = new Object[1];
			arglist[0] = iStr;
			modifiedStr = (String) meth.invoke(this, arglist);

		} catch (SecurityException e) {
			LogUtil.logException(m_Logger, iStr, e);
		} catch (NoSuchMethodException e) {
			LogUtil.logException(m_Logger, iStr, e);
		} catch (IllegalArgumentException e) {
			LogUtil.logException(m_Logger, iStr, e);
		} catch (IllegalAccessException e) {
			LogUtil.logException(m_Logger, iStr, e);
		} catch (InvocationTargetException e) {
			LogUtil.logException(m_Logger, iStr, e);
		}
		return modifiedStr;
	}

	/**
	 * Format the xml date into MMDDYYYY format
	 * 
	 * @param iStrDate
	 * @return
	 * @throws FwException
	 */
	public String formatMMDDYYYY(String iStrDate) throws RemoteException {
		String oStrDate = "";
		SimpleDateFormat xmlDateSdf = new SimpleDateFormat(DATEFORMATSTRING);
		if (iStrDate != null) {
			final SimpleDateFormat oSdf = new SimpleDateFormat("MMddyyyy");

			try {
				if (iStrDate.length() == 8) {
					oStrDate = iStrDate;
				} else if (iStrDate.length() == 10) {
					Date iDate = xmlDateSdf.parse(iStrDate);

					oStrDate = oSdf.format(iDate);
				} else {
					SimpleDateFormat xmlDateTimeSdf = new SimpleDateFormat(xmlDateTimeFormat);

					Date iDate = xmlDateTimeSdf.parse(iStrDate);

					oStrDate = oSdf.format(iDate);
				}

			} catch (ParseException e) {
				LogUtil.logException(m_Logger, iStrDate, e);
			}
		}
		return oStrDate;
	}

	/**
	 * Format the xml date into YYYY-MM-DD format
	 * 
	 * @param iStrDate
	 * @return
	 * @throws FwException
	 */
	public String formatYYYY_MM_DD(String iStrDate) throws RemoteException {
		String oStrDate = "";

		if (iStrDate != null) {
			final SimpleDateFormat oSdf = new SimpleDateFormat(DATEFORMATSTRING);

			try {
				SimpleDateFormat xmlDateTimeSdf = new SimpleDateFormat(xmlDateTimeFormat);

				Date iDate = xmlDateTimeSdf.parse(iStrDate);

				oStrDate = oSdf.format(iDate);

			} catch (ParseException e) {
				LogUtil.logException(m_Logger, iStrDate, e);
			}
		}
		return oStrDate;
	}

	/**
	 * Format the xml date into YYYYMMDD format
	 * 
	 * @param iStrDate
	 * @return
	 * @throws FwException
	 */
	public String formatYYYYMMDD(String iStrDate) throws RemoteException {
		String oStrDate = "";
		SimpleDateFormat xmlDateSdf = new SimpleDateFormat(DATEFORMATSTRING);
		if (iStrDate != null) {
			final SimpleDateFormat oSdf = new SimpleDateFormat("yyyyMMdd");

			try {
				if (iStrDate.length() == 10) {
					Date iDate = xmlDateSdf.parse(iStrDate);

					oStrDate = oSdf.format(iDate);
				} else {
					SimpleDateFormat xmlDateTimeSdf = new SimpleDateFormat(xmlDateTimeFormat);

					Date iDate = xmlDateTimeSdf.parse(iStrDate);

					oStrDate = oSdf.format(iDate);
				}

			} catch (ParseException e) {
				 LogUtil.logException(m_Logger, iStrDate, e);
			}
		}
		return oStrDate;
	}

	/**
	 * Duplicate the char 'N' with specific number of times
	 * 
	 * @param strNoOfTime
	 * @return
	 * @throws FwException
	 */
	public String dupN(String strNoOfTime) throws RemoteException {

		LogUtil.logInfo(m_Logger, getClass().getSimpleName() + " : dupN strNoOfTime=" + strNoOfTime);

		String oStr = "";

		try {
			int noOfTime = Integer.parseInt(strNoOfTime);

			LogUtil.logInfo(m_Logger, getClass().getSimpleName() + " : dupN noOfTime=" + noOfTime);

			for (int i = 0; i < noOfTime; i++) {
				LogUtil.logInfo(m_Logger, getClass().getSimpleName() + " : dupN append N");
				oStr = oStr.concat("N");
			}

		} catch (Exception e) {
			LogUtil.logException(m_Logger, getClass().getSimpleName() + " : dupN oStr=" + oStr,e);
		}
		LogUtil.logInfo(m_Logger, getClass().getSimpleName() + " : dupN oStr=" + oStr);

		return oStr;
	}

	/**
	 * Retrieve the document status
	 * 
	 * @param docStatus
	 * @return
	 * @throws FwException
	 */
	public String docStatus(String docStatus) throws RemoteException {

		String modifiedDocStatus = "V";

		if (!docStatus.equals("V")) {
			modifiedDocStatus = "N";
		}

		return modifiedDocStatus;
	}

	/**
	 * Return only the left three char of the input process type
	 * 
	 * @param processType
	 * @return
	 * @throws FwException
	 */
	public String leftThree(String processType) throws RemoteException {

		LogUtil.logInfo(m_Logger, getClass().getSimpleName() + " : leftThree processType=" + processType);

		return processType.substring(0, 3);
	}

	/**
	 * Convert date to three digit string
	 * 
	 * @param date
	 * @return
	 * @ throws RemoteException
	 */
	public String toCompressedJulianDate(String iStrDate)  {
		String compressedJulianDate = "";

		if (iStrDate != null && !iStrDate.isEmpty()) {
			String julianDate;
			try {
				julianDate = DateUtil.releaseXmlDate2Julian(iStrDate, xmlDateTimeFormat);
				return DateUtil.julian2ThreeDigitsDate(julianDate);
			} catch (Exception e) {
				LogUtil.logException(m_Logger, iStrDate, e);
			}
		}

		return compressedJulianDate;
	}

	/**
	 * Convert policy to 10 digital if it is 9
	 * 
	 * @param policyNo
	 * @author bsnpbf0
	 * @date 20090609
	 * @return
	 */
	public String policyNoStartWithSpace(String policyNo) {
		String temp;
		temp = "          " + policyNo;
		return temp.substring(temp.length() - 10);
	}


	/**
	 * Check Length
	 * 
	 * @param fieldValue
	 * @return
	 * @ throws RemoteException
	 */
	public String validateLength(String fieldValue) throws RemoteException {
		if (!StringUtils.isBlank(fieldValue) && (fieldValue.length() > 7)) {
			throw new RemoteException("Object name filed length is incorrect, Object failed:" + fieldValue + " fieldLength: "
					+ fieldValue.length() + ", Expected field length <= 7");
		}
		return fieldValue;
	}

}
