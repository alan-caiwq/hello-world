package com.aia.case360.web.jdbcDao;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

public interface DocDao {

	void addDocNotes()  throws RemoteException;

	public boolean reindexToClient(Map<String, Object> param)  throws RemoteException ;

	public boolean deleteById(String s_rowid);

	public boolean insertDocLink(Map<String, Object> docLink);
	
	public boolean insertDocLinkNoAspect(Map<String, Object> docLink);
	
	public boolean IsDocLinkExist(Map<String,Object> params);
	
	public boolean IsDocLinkExist(Map<String,Object> params, Boolean withLogicalLinkId);
	
	public boolean updateDocLinkFormId(Map<String, Object> docLink);
	
	public boolean updateDocClient(Map<String, Object> doc_client,String splitSql);
	
	public boolean insertDocClient(Map<String, Object> doc_client);

	public boolean verifyDocClient(Map<String, Object> doc_client);

	public boolean updatePageIndicator(String docId, String pageInd);
	
	public List<Map<String,String>> viewDocPrpt(String objectId);
	
	
	public boolean insertDocAttr(String objectId);
	
	
	public boolean updateIsMoved(String objectId);
	
	public List<Map<String,String>> searchDocNotes(String objectID, String formId);
	
	public boolean addDocNotes(Map<String, String> inputParams);
	
	
	public List<Map<String,Object>> getCObjectIdListDocCtrl();
	
	public List<Map<String,Object>> getExObjNameInfoDocLink(String cObjectId);
	
	public Map<String,Object> getDocIdDOCUEMNTS(String cObjectId);
	
	public boolean updateDocAttrObjectId(String eObjectId, String cObjectId);
 
	public boolean updateDocLinkObjectId(String sLogicalLinkId, int linkStatus, String lastUpdateBy, BigDecimal sRowId,String lastUpdateTime);
	
	public boolean updateDocLinkObjectIdEx(String eObjectId, String cObjectId);
	
	public boolean updateDocLinkStatusObjectIdEx(int linkStatus, String lastUpdateBy, BigDecimal sRowId,String lastUpdateTime);
	public boolean updateFailedDocLinkStatusObjectIdEx(int linkStatus, String objectId);
	public boolean updateDocumentsObjectId(String eObjectId, String cObjectId);
	
	public boolean updateAuditTrailFromObjectId(String eObjectId, String cObjectId);
	
	public boolean updateAuditTrailToObjectId(String eObjectId, String cObjectId);
	
	public boolean updateDocCtrlObjectIdStatus(String eObjectId, String eObjectName, String migStatus, String cObjectId);
	
	public List<Map<String, Object>> getCase360ObjectIdVoidPageFromAuditTrail(BigDecimal rowId);
	public Map<String,Object> getCase360InfoPageIndFromFSDocument(String ObjectId);
	public Map<String, Object> getLatestRowIdFromConfig(String configName);	
	public boolean updateLatestRowIdInConfig(String configName, BigDecimal rowId);
	public Map<String, Object> getMaxRowIdForVoidPageFromAuditTrail(BigDecimal rowId);	
	public List<Map<String, Object>> getDocObjectIDListFromDocLink();
	
	public List<Map<String, Object>> getDocInfoFromDocLink(String ObjectId) ;

}
