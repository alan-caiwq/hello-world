package com.aia.case360.web.auditTrail;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.web.auditTrail.annotation.AuditEntity;
import com.aia.case360.web.auditTrail.annotation.AuditField;
import com.aia.case360.web.common.CommonUtil;

/**
 * 
 * @author bsnpbjd
 * @version AuditTrailEngine it is the basic engine to generate audit trail. it
 *          is abstract class.
 *
 */
public abstract class AuditTrailEngine {
	private Map<String, AuditFieldSpecialAction> fieldSpecialActionMap = new HashMap<String, AuditFieldSpecialAction>();
	protected Logger m_Logger = LoggerFactory.getLogger(getClass());
	String tableKeyString = null;

	/**
	 * 
	 * @param rowID
	 * @param o
	 * @param n
	 * @throws RemoteException
	 * @throws IllegalAccessException
	 * @throws IllegalArgumentException
	 */
	public void generateAuditTrail(AuditTrail o, AuditTrail n, String prefixStr,
			Class<? extends AuditTrail> entityClass)
			throws RemoteException, IllegalArgumentException, IllegalAccessException {

		LogUtil.logInfo(m_Logger,"add audit trail begin");
		if (!entityClass.isAnnotationPresent(AuditEntity.class)) {
			LogUtil.logInfo(m_Logger,"add audit trail scenario 1");
			return;
		}

		Boolean isNew = false;
		Field[] fields = entityClass.getDeclaredFields();
		List<AuditEntityIgnoreCondition> registIgnoreEntityList = (n != null ? n : o).registIgnoreEntitylist();
		if (registIgnoreEntityList != null) {
			Map<String, AuditTrail> auditScenario2 = addAuditScenario2(registIgnoreEntityList,o,n,fields);
			o =  auditScenario2.get("o");
			n =  auditScenario2.get("n");
		}	
		judgeTableKey(o, n);
		if (n == null && o == null) {
			return;
		} else if (n == null && o != null) {
			saveAudit(false, CommonUtil.getString(prefixStr) + "" + o.getKeyDisplayName() + " removed.", o);
			return;
		} else if (n != null && o == null) {
			isNew = true;
			// new audit.
			String entityName = n.getKeyDisplayName();
			String auditStr = CommonUtil.getString(prefixStr) + entityName + " created.";
			saveAudit(isNew, auditStr, n);
		} else {
			isNew = false;
		}

		initRegist(n);

		for (Field field : fields) {
			judgeFiledType(o, n, prefixStr, isNew, field);

		}

	}


	private Map<String,AuditTrail> addAuditScenario2(
			List<AuditEntityIgnoreCondition> registIgnoreEntityList,
			AuditTrail o, AuditTrail n, Field[] fields) throws IllegalArgumentException, IllegalAccessException {
		LogUtil.logInfo(m_Logger,"add audit trail scenario 2");
		Map<String,AuditTrail> map = new HashMap<String,AuditTrail>();
		for (AuditEntityIgnoreCondition entityIgnoreCondition : registIgnoreEntityList) {

			Object ignoreValue = entityIgnoreCondition.getFieldValue();
			Object oFileValue = getFileValue(o, fields, entityIgnoreCondition.getFieldName());
			Object nFileValue = getFileValue(n, fields, entityIgnoreCondition.getFieldName());
			if (equalsAcceptNull(oFileValue, ignoreValue)) {
				o = null;
			}

			if (equalsAcceptNull(nFileValue, ignoreValue)) {
				
				n = null;
			}
		}
		map.put("o", o);
		map.put("n", n);
		return  map;
	}



	private void judgeTableKey(AuditTrail o, AuditTrail n) {
		if (n != null) {
			tableKeyString = (String) n.getKey();
		} else if (o != null) {
			tableKeyString = (String) o.getKey();
		}
	}

	private void judgeFiledType(AuditTrail o, AuditTrail n, String prefixStr,
			Boolean isNew, Field field) throws RemoteException {
		LogUtil.logInfo(m_Logger,"add audit trail fields");
		if (field.isAnnotationPresent(AuditField.class)) {
			AuditField fieldAnnotation = field.getAnnotation(AuditField.class);
			String fieldName = fieldAnnotation.fieldName();
			AuditFileTypeEnum type = fieldAnnotation.fieldType();
			switch (type) {
			case FIELD:
				generateFiledAudit(field, isNew, o, n, fieldName, prefixStr);
				break;
			case KEY_FIELD:
				generateFiledAudit(field, isNew, o, n, fieldName, prefixStr);
				break;
			case RELATION:
				generateRelationAudit(field, isNew, o, n,  prefixStr);
				break;

			}

		}
	}

	private Object getFileValue(AuditTrail obj, Field[] fields, String fieldName)
			throws IllegalArgumentException, IllegalAccessException {

		try {
			for (Field field : fields) {
				field.setAccessible(true);
				AuditField fieldAnnotation = field.getAnnotation(AuditField.class);
				String fieldNameDefination = null;
				if (fieldAnnotation != null) {
					fieldNameDefination = fieldAnnotation.fieldName();
				} else {
					fieldNameDefination = field.getName();
				}

				if (fieldNameDefination != null && fieldNameDefination.equals(fieldName)) {
					return obj == null ? null : field.get(obj);
				}
			}
		} catch (Exception e) {
			LogUtil.logInfo(m_Logger,e.getMessage());
		}
		return null;
	}

	private void initRegist(AuditTrail n) {
		fieldSpecialActionMap.clear();
		List<AuditFieldSpecialAction> fieldSpecialActionlist = n.registFieldSpecialActionlist();

		if (fieldSpecialActionlist != null) {
			for (AuditFieldSpecialAction fieldSpecialAction : fieldSpecialActionlist) {
				fieldSpecialActionMap.put(fieldSpecialAction.getFieldName(), fieldSpecialAction);
			}
		}
	}

	/**
	 * 
	 * @param rowID
	 * @param field
	 * @param isNew
	 * @param o
	 * @param n
	 * @param fieldName
	 * @param prefixStr
	 * @throws RemoteException
	 */
	private void generateRelationAudit(Field field, Boolean isNew, AuditTrail o, AuditTrail n, 
			String prefixStr) throws RemoteException {

		field.setAccessible(true);
		String classType = field.getType().getName();
		try {
			if ("java.util.List".equals(classType)) {
				List newList = (List) field.get(n);
				List originalList = null;
				if (!isNew && o != null) {
					originalList = (List) field.get(o);
				}
				if (newList != null) {

					doNewListNotNull(prefixStr, newList, originalList);
				} 
			}
		} catch (IllegalArgumentException e) {

			LogUtil.logException(m_Logger, "",e);
		} catch (IllegalAccessException e) {

			LogUtil.logException(m_Logger, "",e);
		}
	}


	private void doNewListNotNull(String prefixStr, List newList,
			List originalList) throws RemoteException, IllegalAccessException {
		for (Object newItem : newList) {
			if (newItem instanceof AuditTrail) {
				doGenerateAuditTrail(prefixStr, originalList, newItem);

			} 
		}
		if (originalList != null) {
			generateAuditTrail2(prefixStr, originalList);
		}
	}


	private void generateAuditTrail2(String prefixStr, List originalList)
			throws RemoteException, IllegalAccessException {
		for (Object oitem : originalList) {
			if (oitem instanceof AuditTrail) {

				AuditEntity classAnnotation = oitem.getClass().getAnnotation(AuditEntity.class);
				String entityName = (prefixStr == null ? "" : prefixStr) + "["
						+ classAnnotation.entityName() + ":" + ((AuditTrail) oitem).getKeyDisplayName()
						+ "]";
				LogUtil.logInfo(m_Logger,((AuditTrail) oitem).getKeyDisplayName());
				generateAuditTrail((AuditTrail) oitem, null, entityName,
						((AuditTrail) oitem).getClass());
			}
		}
	}


	private void doGenerateAuditTrail(String prefixStr, List originalList,
			Object newItem) throws RemoteException, IllegalAccessException {
		AuditEntity classAnnotation = newItem.getClass().getAnnotation(AuditEntity.class);
		String entityName = (prefixStr == null ? "" : prefixStr) + "["
				+ classAnnotation.entityName() + ":" + ((AuditTrail) newItem).getKeyDisplayName()
				+ "]";

		BigDecimal newItemRowID = ((AuditTrail) newItem).getRowID();
		AuditTrail originalItem = null;
		// is new record?
		if (originalList != null && newItemRowID != null) {
			Iterator it = originalList.iterator();
			while (it.hasNext()) {
				AuditTrail oItem = (AuditTrail) (it.next());
				if (oItem.getRowID() != null && oItem.getRowID().equals(newItemRowID)) {
					originalItem = oItem;
					it.remove();
				}

			}
			// originalList.g
			generateAuditTrail(originalItem, (AuditTrail) newItem, entityName,
					((AuditTrail) newItem).getClass());
		} else {
			generateAuditTrail(null, (AuditTrail) newItem, entityName,
					((AuditTrail) newItem).getClass());
		}
	}

	/**
	 * 
	 * @param rowID
	 * @param field
	 * @param isNew
	 * @param o
	 * @param n
	 * @param fieldName
	 * @param prefixStr
	 * @throws RemoteException
	 */
	private void generateFiledAudit(Field field, Boolean isNew, AuditTrail o, AuditTrail n, String fieldName,
			String prefixStr) throws RemoteException {
		try {
			field.setAccessible(true);

			String classType = field.getType().getName();
			String originalValue = null;
			if (!isNew) {
				originalValue = toStringValue(field.get(o), classType);
			}

			String newValue = toStringValue(field.get(n), classType);

			String action = buildActionString(field, isNew, fieldName, originalValue, newValue, prefixStr);
			saveAudit(isNew, action, n);
		} catch (IllegalArgumentException e) {

			LogUtil.logException(m_Logger, "",e);
		} catch (IllegalAccessException e) {

			LogUtil.logException(m_Logger, "",e);
		}
	}

	/**
	 * 
	 * @param field
	 * @param isNew
	 * @param fieldName
	 * @param originalValue
	 * @param newValue
	 * @return
	 */
	private String buildActionString(Field field, Boolean isNew, String fieldName, String originalValue,
			String newValue, String prefixStr) {
		if (originalValue == null && newValue == null) {
			return null;
		}
		if ((!isNew) && optional(originalValue).equals(optional(newValue))) {
			return null;
		}

		if (isNew && (optional(newValue).equals("") || optional(newValue).equals("0"))) {
			return null;
		}
		String action = "";

		if (fieldSpecialActionMap.containsKey(field.getName())) {
			AuditFieldSpecialAction fieldAction = fieldSpecialActionMap.get(fieldName);
			action = this.getAction(isNew, fieldAction, originalValue, newValue);

			return StringUtils.stripToEmpty(prefixStr) + action;
		} else {
			return StringUtils.stripToEmpty(prefixStr)
					+ (isNew ? ("set " + fieldName + " ") : fieldName + " changed from " + originalValue) + " to "
					+ (newValue);
		}

	}

	private String getAction(Boolean isNew,AuditFieldSpecialAction fieldAction,
			String originalValue,String newValue) {
		String action = "";
		if (isNew) {
			action = fieldAction.getCreationACTION_DESC();
			action = action.replaceAll("\\{\\{newValue\\}\\}", newValue);
		} else {
			action = fieldAction.getUpdateACTION_DESC();
			if (originalValue != null) {
				action = action.replaceAll("\\{\\{originalValue\\}\\}", originalValue);
			} else {
				action = action.replaceAll("\\{\\{originalValue\\}\\}", "");
			}
			action = action.replaceAll("\\{\\{newValue\\}\\}", newValue);
		}
		return action;
	}
	/**
	 * 
	 * @param obj
	 * @param classType
	 * @return
	 */
	private String toStringValue(Object obj, String classType) {
		if (obj == null) {
			return null;
		}
		if (classType.equals("java.math.BigDecimal")) {
			return ((BigDecimal) obj).toString();
		} else if (classType.equals("java.lang.String")) {
			return (String) obj;
		} else if (classType.equals("java.util.Date")) {
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			return format.format(obj);
		} else if (classType.equals("java.lang.Boolean")) {
			return String.valueOf(obj);
		} else if (classType.equals("java.lang.Integer")) {
			return String.valueOf(obj);
		} else if (classType.equals("short")) {
			return ((short) obj) + "";
		} else if (classType.equals("int")) {
			return ((int) obj) + "";
		} else {
			return "";
		}
	}

	/**
	 * 
	 * @param in
	 * @return
	 */
	private String optional(String in) {
		if (in == null)
			return "";
		else
			return in;
	}

	private boolean equalsAcceptNull(Object obj, Object obj2) {
		if (obj == obj2 ) {
			return true;
		}
		if(obj == null) {
			return false;
		}
		return obj.equals(obj2);
	}

	abstract void saveAudit(Boolean isNew, String action, AuditTrail n) throws RemoteException;
}
