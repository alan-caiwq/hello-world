package com.aia.case360.platform.system.impl;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.ejb.FinderException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.system.WorkCalendarHelper;
import com.aia.case360.web.service.impl.AbstractHelperImpl;
import com.eistream.sonora.exceptions.WorkCalendarDefinitionException;
import com.eistream.sonora.nbd.WorkCalendar;
import com.eistream.sonora.nbd.WorkCalendarDefElement;
import com.eistream.sonora.nbd.WorkCalendarElement;

@Component
public class WorkCalendarHelperImpl extends AbstractHelperImpl implements WorkCalendarHelper {
	private Logger m_Logger_second = LoggerFactory.getLogger(getClass());

	@Override
	public List<String> getCustomCalendarCompanyList() {

		List<String> res = null;
		try {
			res = new ArrayList<String>();
			ArrayList<WorkCalendarElement> resElement = getNBDEJB().getWorkCalendarElements();
			LogUtil.logInfo(m_Logger_second,"resElement:" + resElement.size());
			for (WorkCalendarElement workCalendarElement : resElement) {

				res.add(workCalendarElement.getName());
			}
		} catch (RemoteException e) {
			LogUtil.logException(m_Logger_second, "", e);
			 
		}
		return res;
	}

	@Override
	public List<WorkCalendar> getCustomCalendarList(String name) {

		List<WorkCalendar> res = new ArrayList<WorkCalendar>();
		try {
			LogUtil.logInfo(m_Logger_second,"name:" + name);
			if (name == null) {
				ArrayList<WorkCalendarElement> resElement = getNBDEJB().getWorkCalendarElements();
				LogUtil.logInfo(m_Logger_second,"resElement:" + resElement.size());
				for (WorkCalendarElement workCalendarElement : resElement) {

					res.add(getNBDEJB().getWorkCalendar(workCalendarElement.getName()));
				}
			} else {

				res.add(getNBDEJB().getWorkCalendar(name));
			}
		} catch (RemoteException e) {
			LogUtil.logException(m_Logger_second, name, e);
			 
		} catch (FinderException e) {

			LogUtil.logException(m_Logger_second, name, e);
		}

		return res;
	}

	@Override
	public boolean addWorkCalendarDEF(WorkCalendarDefElement tWorkCalendarDefElement) {

		WorkCalendar wc = null;

		try {
			wc = getNBDEJB().getWorkCalendar(tWorkCalendarDefElement.getName());
			ArrayList list = wc.getDefElements();

			list.add(tWorkCalendarDefElement);
			WorkCalendar newWc = new WorkCalendar(wc.getWorkCalendarElement(), list, null, null);
			getNBDEJB().setWorkCalendar(newWc);
			return true;
		} catch (WorkCalendarDefinitionException e) {

			LogUtil.logException(m_Logger_second, "", e);
			return false;
		} catch (RemoteException e) {

			LogUtil.logException(m_Logger_second, "", e);
			return false;
		} catch (FinderException e) {

			 
			return false;
		}

	}

	@Override
	public boolean updateWorkCalendarDEF(ArrayList tWorkCalendarDefElementlist, String name) {

		WorkCalendar wc = null;
		try {
			LogUtil.logInfo(m_Logger_second,"tWorkCalendarDefElementlist:" + tWorkCalendarDefElementlist);
			wc = getNBDEJB().getWorkCalendar(name);
			LogUtil.logInfo(m_Logger_second,"wc:" + wc.getDefElements());
			WorkCalendar newWc = new WorkCalendar(wc.getWcElement(), tWorkCalendarDefElementlist, null, null);
			getNBDEJB().setWorkCalendar(newWc);
			return true;
		} catch (WorkCalendarDefinitionException e) {

			LogUtil.logException(m_Logger_second, name, e);
			return false;
		} catch (RemoteException e) {

			LogUtil.logException(m_Logger_second, name, e);
			return false;
		} catch (FinderException e) {

			 
			return false;
		}
	}

	@Override
	public boolean removeWorkCalendarDEF(WorkCalendarDefElement tWorkCalendarDefElement) {

		WorkCalendar wc = null;
		try {
			wc = getNBDEJB().getWorkCalendar(tWorkCalendarDefElement.getName());
			ArrayList<WorkCalendarDefElement> list = wc.getDefElements();

			Iterator<WorkCalendarDefElement> it = list.iterator();
			while (it.hasNext()) {
				WorkCalendarDefElement WorkCalendarDefElement = it.next();
				if (tWorkCalendarDefElement.getId().intValue() == WorkCalendarDefElement.getId().intValue()) {
					list.remove(WorkCalendarDefElement);
				}
			}
			getNBDEJB().setWorkCalendar(wc);
			return true;
		} catch (WorkCalendarDefinitionException e) {

			LogUtil.logException(m_Logger_second, "", e);
			return false;
		} catch (RemoteException e) {

			LogUtil.logException(m_Logger_second, "", e);
			return false;
		} catch (FinderException e) {

			LogUtil.logException(m_Logger_second, "", e);
			return false;
		}
	}

	@Override
	public Map<String, Object> toMap(Object obj) {
		Map<String, Object> map = new HashMap<String, Object>();
		if (obj instanceof WorkCalendarDefElement) {

			map.put("DESCRIPTION", ((WorkCalendarDefElement) obj).getDescription());
			map.put("S_CALINFO", ((WorkCalendarDefElement) obj).getInfo());
			map.put("S_CALNAME", ((WorkCalendarDefElement) obj).getName());
			map.put("S_CALTYPE", ((WorkCalendarDefElement) obj).getType());
			map.put("S_CALVALUE", ((WorkCalendarDefElement) obj).getValue());
			map.put("S_CALFLAG", ((WorkCalendarDefElement) obj).getFlag());
			map.put("ID", ((WorkCalendarDefElement) obj).getId());
			LogUtil.logInfo(m_Logger_second,"toMap:" + map);
			return map;

		}
		return null;
	}

}
