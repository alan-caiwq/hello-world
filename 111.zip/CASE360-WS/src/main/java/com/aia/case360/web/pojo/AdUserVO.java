package com.aia.case360.web.pojo;

public class AdUserVO extends OutputVO {
	private String userLOGINID;
	private String userDISPLAYNAME;
	private String userFIRSTNAME;
	private String userLASTNAME;
	private int userDELIVERYFLAG;
	private String userDELIVERYSTRING;
	private String userTIMEZONE;
	private String userPREFERREDLOCALE;
	private String userACTIVESTATUS;

	public String getUserLOGINID() {
		return userLOGINID;
	}

	public void setUserLOGINID(String userLOGINID) {
		this.userLOGINID = userLOGINID;
	}

	public String getUserDISPLAYNAME() {
		return userDISPLAYNAME;
	}

	public void setUserDISPLAYNAME(String userDISPLAYNAME) {
		this.userDISPLAYNAME = userDISPLAYNAME;
	}

	public String getUserFIRSTNAME() {
		return userFIRSTNAME;
	}

	public void setUserFIRSTNAME(String userFIRSTNAME) {
		this.userFIRSTNAME = userFIRSTNAME;
	}

	public String getUserLASTNAME() {
		return userLASTNAME;
	}

	public void setUserLASTNAME(String userLASTNAME) {
		this.userLASTNAME = userLASTNAME;
	}

	public Integer getUserDELIVERYFLAG() {
		return userDELIVERYFLAG;
	}

	public void setUserDELIVERYFLAG(Integer userDELIVERYFLAG) {
		this.userDELIVERYFLAG = userDELIVERYFLAG;
	}

	public String getUserDELIVERYSTRING() {
		return userDELIVERYSTRING;
	}

	public void setUserDELIVERYSTRING(String userDELIVERYSTRING) {
		this.userDELIVERYSTRING = userDELIVERYSTRING;
	}

	public String getUserTIMEZONE() {
		return userTIMEZONE;
	}

	public void setUserTIMEZONE(String userTIMEZONE) {
		this.userTIMEZONE = userTIMEZONE;
	}

	public String getUserPREFERREDLOCALE() {
		return userPREFERREDLOCALE;
	}

	public void setUserPREFERREDLOCALE(String userPREFERREDLOCALE) {
		this.userPREFERREDLOCALE = userPREFERREDLOCALE;
	}

	public String getUserACTIVESTATUS() {
		return userACTIVESTATUS;
	}

	public void setUserACTIVESTATUS(String userACTIVESTATUS) {
		this.userACTIVESTATUS = userACTIVESTATUS;
	}

	public AdUserVO() {
		super();
	}

	@Override
	public String toString() {
		return "AdUserPOJO [userLOGINID=" + userLOGINID + ", userDISPLAYNAME=" + userDISPLAYNAME + ", userFIRSTNAME="
				+ userFIRSTNAME + ", userLASTNAME=" + userLASTNAME + ", userDELIVERYFLAG=" + userDELIVERYFLAG
				+ ", userDELIVERYSTRING=" + userDELIVERYSTRING + ", userTIMEZONE=" + userTIMEZONE
				+ ", userPREFERREDLOCALE=" + userPREFERREDLOCALE + ", userACTIVESTATUS=" + userACTIVESTATUS
				+ ", getUserLOGINID()=" + getUserLOGINID() + ", getUserDISPLAYNAME()=" + getUserDISPLAYNAME()
				+ ", getUserFIRSTNAME()=" + getUserFIRSTNAME() + ", getUserLASTNAME()=" + getUserLASTNAME()
				+ ", getUserDELIVERYFLAG()=" + getUserDELIVERYFLAG() + ", getUserDELIVERYSTRING()="
				+ getUserDELIVERYSTRING() + ", getUserTIMEZONE()=" + getUserTIMEZONE() + ", getUserPREFERREDLOCALE()="
				+ getUserPREFERREDLOCALE() + ", getUserACTIVESTATUS()=" + getUserACTIVESTATUS() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

}
