package com.aia.case360.web.dao;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.aia.case360.uam.domain.EditUamTeamSettingAuditTrail;
import com.aia.case360.uam.domain.UAMAuditTrail;
import com.aia.case360.uam.domain.UAMGetAuditTrailParam;
import com.aia.case360.uam.domain.UAMGetOrganizationAuditTrailParam;
import com.aia.case360.uam.domain.UAMOrganizationAuditTrail;
import com.aia.case360.uam.domain.UAMRoleAuditTrail;
import com.aia.case360.uam.domain.UAMUserEditAuditTrail;
import com.aia.case360.uam.domain.UAMUserSyncAuditTrail;
import com.aia.case360.uam.domain.UpdateComponentAuditTrail;

public interface UAMAuditTrailDao {

	public boolean addUAMAuditTrail(@Param("param") UAMAuditTrail param) throws RemoteException;

	public List<UAMAuditTrail> getUAMAuditTrail(@Param("param") UAMGetAuditTrailParam param) throws RemoteException;

	public List<UAMOrganizationAuditTrail> getUAMOrganizationAuditTrail(
			@Param("param") UAMGetOrganizationAuditTrailParam param) throws RemoteException;

	public void syncUAMUserAuditTrail(@Param("param") UAMUserSyncAuditTrail param) throws RemoteException;

	public void editUAMUserAuditTrail(@Param("param") UAMUserEditAuditTrail param) throws RemoteException;

	public void editUAMRoleAuditTrail(@Param("param") UAMRoleAuditTrail param) throws RemoteException;

	public void deleteComponentAuditTrail(@Param("componentId") BigDecimal componentId,
			@Param("loginUser") String loginUser) throws RemoteException;

	public void editUAMTeamSettingAuditTrail(@Param("param") EditUamTeamSettingAuditTrail param) throws RemoteException;

	public void updateComponentAuditTrail(@Param("param") UpdateComponentAuditTrail param) throws RemoteException;
}
