package com.aia.case360.JalDocsInterfacesEx.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import com.rometools.utils.Strings;

public class XmlUtil {
	private XmlUtil() {
	}

	public static InputStream getInputStreamFromResource(String path) throws RemoteException {
		ClassLoader cl = Thread.currentThread().getContextClassLoader();
		InputStream stream = cl.getResourceAsStream(path);
		return stream;
	}

	public static String getNodeValue(Node node) {
		String returnString = "";
		Node child = node.getFirstChild();
		if (child != null && child.getNodeValue() != null)
			return child.getNodeValue();
		else
			return returnString;
	}

	public static String getSubTagAttribute(Element root, String tagName, String subTagName, String attribute) {
		String returnString = "";
		NodeList list = root.getElementsByTagName(tagName);
		for (int loop = 0; loop < list.getLength(); loop++) {
			Node node = list.item(loop);
			if (node != null) {
				NodeList children = node.getChildNodes();
				returnString = findNode(subTagName, attribute, returnString, children);

			}
			if (!returnString.equals("")) {
				return returnString;
			}

		}

		return returnString;
	}

	private static String findNode(String subTagName, String attribute, String returnString, NodeList children) {
		for (int innerLoop = 0; innerLoop < children.getLength(); innerLoop++) {
			Node child = children.item(innerLoop);
			if (returnString.equals("") && child != null && subTagName.equals(child.getNodeName())
					&& (child instanceof Element))
				returnString = ((Element) child).getAttribute(attribute);
		}
		return returnString;
	}

	public static String getSubTagValue(Element root, String tagName, String subTagName) {
		String returnString = "";
		NodeList list = root.getElementsByTagName(tagName);
		for (int loop = 0; loop < list.getLength(); loop++) {
			Node node = list.item(loop);
			if (node != null) {
				NodeList children = node.getChildNodes();
				for (int innerLoop = 0; innerLoop < children.getLength(); innerLoop++) {
					Node child = children.item(innerLoop);
					returnString = getNoteValue(subTagName, child);
					if(!returnString.isEmpty()){
						return returnString;
					}
				}

			}
		}

		return returnString;
	}

	private static String getNoteValue(String subTagName, Node child) {
		String retStr = "";
		if (child != null && subTagName.equals(child.getNodeName())) {
			Node grandChild = child.getFirstChild();
			if (grandChild.getNodeValue() != null)
				return grandChild.getNodeValue();
		}
		
		return retStr;
	}

	public static String getSubTagValue(Node node, String subTagName) {
		String returnString = "";
		if (node != null) {
			NodeList children = node.getChildNodes();
			for (int innerLoop = 0; innerLoop < children.getLength(); innerLoop++) {
				Node child = children.item(innerLoop);
				if (child != null && subTagName.equals(child.getNodeName())) {
					Node grandChild = child.getFirstChild();
					if (grandChild.getNodeValue() != null)
						return grandChild.getNodeValue();
				}
			}

		}
		return returnString;
	}

	public static String getTagAttributeValue(Element root, String tagName, String attribute) {
		String returnString = "";
		NodeList list = root.getElementsByTagName(tagName);
		for (int loop = 0; loop < list.getLength(); loop++) {
			Node node = list.item(loop);
			if (node != null && (node instanceof Element))
				return ((Element) node).getAttribute(attribute);
		}

		return returnString;
	}

	public static String getTagValue(Element root, String tagName) {
		String returnString = "";
		NodeList list = root.getElementsByTagName(tagName);
		for (int loop = 0; loop < list.getLength(); loop++) {
			Node node = list.item(loop);
			if (node != null) {
				Node child = node.getFirstChild();
				if (child != null && child.getNodeValue() != null)
					return child.getNodeValue();
			}
		}

		return returnString;
	}

	public static Element loadDocument(InputStream inputStream) throws RemoteException {
		try {
			InputSource xmlInp = new InputSource(inputStream);
			Element root = loadDocument(xmlInp);
			inputStream.close();
			return root;
		} catch (MalformedURLException mfx) {
			throw new RemoteException("Xml file name mfxerror:" + mfx.getMessage());
		} catch (IOException ioe) {
			throw new RemoteException("Load Xml file IOerror:" + ioe.getMessage());
		} catch (Exception e) {
			throw new RemoteException("Load Xml file error:" + e.getMessage());
		}
	}

	public static Element loadDocument(String urlString) throws RemoteException {
		Element element = null;
		try {
			element = loadDocument(new URL(urlString).openStream());
		} catch (Exception e) {
			throw new RemoteException(e.getMessage());
		}
		return element;
	}

	public static Element loadDocument(String xmlString, boolean url) throws RemoteException {
		if (url) {
			return loadDocument(xmlString);
		} else {
			StringReader reader = new StringReader(xmlString);
			InputSource xmlInp = new InputSource(reader);
			return loadDocument(xmlInp);
		}
	}

	public static Element loadDocument(InputSource xmlInp) throws RemoteException {

		// Check for input stream if null return to caller.
		if (xmlInp == null) {
			return null;
		}
		try {

			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document doc = builder.parse(xmlInp);
			Element root = doc.getDocumentElement();
			return root;
		} catch (SAXParseException saxpe) {
			throw new RemoteException(
					"Parse XML error: line " + saxpe.getLineNumber() + ", uri " + saxpe.getSystemId());
		} catch (SAXException saxe) {
			throw new RemoteException("Parse XML error:" + saxe.getMessage());
		} catch (Exception pce) {
			throw new RemoteException("Load Xml file error:" + pce.getMessage());
		}
	}
}
