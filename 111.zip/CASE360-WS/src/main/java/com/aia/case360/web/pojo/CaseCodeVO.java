package com.aia.case360.web.pojo;

/**
 * case's code
 * 
 * @author bsnpbys
 *
 */
public class CaseCodeVO {

	private Integer linkCaseId;

	private String department;

	private String code;

	public Integer getLinkCaseId() {
		return linkCaseId;
	}

	public void setLinkCaseId(Integer linkCaseId) {
		this.linkCaseId = linkCaseId;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

}
