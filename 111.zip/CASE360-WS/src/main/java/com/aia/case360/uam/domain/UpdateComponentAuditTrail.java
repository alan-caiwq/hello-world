package com.aia.case360.uam.domain;

import java.math.BigDecimal;

public class UpdateComponentAuditTrail {

	private String loginUser;
	private String tmUserIds;
	private String tmPositions;
	private String companyName;
	private String companyType;
	private BigDecimal parentId;
	private BigDecimal componentId;

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "UpdateComponentAuditTrail [loginUser=" + loginUser + ", tmUserIds=" + tmUserIds + ", tmPositions="
				+ tmPositions + ", companyName=" + companyName + ", companyType=" + companyType + ", parentId="
				+ parentId + ", componentId=" + componentId + "]";
	}

	/**
	 * @return the loginUser
	 */
	public String getLoginUser() {
		return loginUser;
	}

	/**
	 * @return the tmUserIds
	 */
	public String getTmUserIds() {
		return tmUserIds;
	}

	/**
	 * @return the tmPositions
	 */
	public String getTmPositions() {
		return tmPositions;
	}

	/**
	 * @return the companyName
	 */
	public String getCompanyName() {
		return companyName;
	}

	/**
	 * @return the companyType
	 */
	public String getCompanyType() {
		return companyType;
	}

	/**
	 * @return the parentId
	 */
	public BigDecimal getParentId() {
		return parentId;
	}

	/**
	 * @return the componentId
	 */
	public BigDecimal getComponentId() {
		return componentId;
	}

	/**
	 * @param loginUser the loginUser to set
	 */
	public void setLoginUser(String loginUser) {
		this.loginUser = loginUser;
	}

	/**
	 * @param tmUserIds the tmUserIds to set
	 */
	public void setTmUserIds(String tmUserIds) {
		this.tmUserIds = tmUserIds;
	}

	/**
	 * @param tmPositions the tmPositions to set
	 */
	public void setTmPositions(String tmPositions) {
		this.tmPositions = tmPositions;
	}

	/**
	 * @param companyName the companyName to set
	 */
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	/**
	 * @param companyType the companyType to set
	 */
	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}

	/**
	 * @param parentId the parentId to set
	 */
	public void setParentId(BigDecimal parentId) {
		this.parentId = parentId;
	}

	/**
	 * @param componentId the componentId to set
	 */
	public void setComponentId(BigDecimal componentId) {
		this.componentId = componentId;
	}
}
