package com.aia.case360.web.pojo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class FRMGetFRMCaseDetailInfoParam {

  @JsonProperty("LINKCASEID")
  private Long caseId;

  /**
   * @return the caseId
   */
  public Long getCaseId() {
    return caseId;
  }

  /**
   * @param caseId the caseId to set
   */
  public void setCaseId(Long caseId) {
    this.caseId = caseId;
  }

  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "FRMGetFRMCaseDetailInfoParam [caseId=" + caseId + "]";
  }
}
