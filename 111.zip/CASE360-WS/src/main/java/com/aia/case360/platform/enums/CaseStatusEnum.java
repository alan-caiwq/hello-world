package com.aia.case360.platform.enums;

public enum CaseStatusEnum {
	WIP, COMPLETED,NORMAL;
}
