package com.aia.case360.web.pojo;

import java.math.BigDecimal;

public class CaseCloseReason {
	private String acl;
	private BigDecimal sRowid;
	private String closeReason;
	private String department;
	private short isSystem;// smallint

	public String getAcl() {
		return acl;
	}

	public void setAcl(String acl) {
		this.acl = acl;
	}

	public BigDecimal getsRowid() {
		return sRowid;
	}

	public void setsRowid(BigDecimal sRowid) {
		this.sRowid = sRowid;
	}

	public String getCloseReason() {
		return closeReason;
	}

	public void setCloseReason(String closeReason) {
		this.closeReason = closeReason;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public short getIsSystem() {
		return isSystem;
	}

	public void setIsSystem(short isSystem) {
		this.isSystem = isSystem;
	}

}
