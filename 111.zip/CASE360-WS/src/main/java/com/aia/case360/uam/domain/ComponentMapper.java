package com.aia.case360.uam.domain;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

@SuppressWarnings("rawtypes")
public class ComponentMapper implements ResultSetExtractor {

	@Override
	public List<CompoenentDTO> extractData(ResultSet rs) throws SQLException, DataAccessException {

		List<CompoenentDTO> allUserInOrgs = new ArrayList<CompoenentDTO>();
		while (rs.next()) {
			CompoenentDTO co = new CompoenentDTO();
			co.setComponentId(rs.getBigDecimal(CompoenentDTO.fieldNames.UAM_COMPONENT_ID.name()));
			co.setComponentName(rs.getString(CompoenentDTO.fieldNames.UAM_COMPONENT_NAME.name()));
			co.setComponentParentId(rs.getBigDecimal(CompoenentDTO.fieldNames.UAM_COMPONENT_PARENTID.name()));
			co.setComponentType(rs.getString(CompoenentDTO.fieldNames.UAM_COMPONENT_TYPE.name()));
			allUserInOrgs.add(co);
		}
		return allUserInOrgs;
	}

}
