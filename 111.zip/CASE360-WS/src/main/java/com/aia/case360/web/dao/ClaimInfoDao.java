package com.aia.case360.web.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.aia.case360.web.pojo.FdClaimInfo;
import com.aia.case360.web.pojo.FdWcfLink;

@Repository
public interface ClaimInfoDao {

	/**
	 * @param linkCaseId
	 * @return
	 */
	public List<FdClaimInfo> queryCaseClaimInfo(String linkCaseId);

	public int insertOneFdClaimInfo(FdClaimInfo fdClaimInfo);

	public int isFdClaimInfoExist(FdClaimInfo fdClaimInfo);

	public int deleteFdClaimInfo(FdClaimInfo fdClaimInfo);

	public int updateClaimDC(FdClaimInfo fdClaimInfo);

	public List<String> getClaimDecisionCategory(String linkcaseid);

	public List<String> getPreDecisionCategory(String linkcaseid);

	public int updateCaseDC(Map<String, String> paramsMap);

	public int isNricLocalExist(Map<String, String> map);

	public List<FdClaimInfo> queryLocalClaimNo(Map<String, Object> paramMap);

	public List<String> queryClaimNoByNric(Map<String, String> paramMap);

	public List<FdClaimInfo> queryClaimInfoByDecision(Map<String, String> claimInfoParam);

	public List<FdClaimInfo> queryNonILLocalClaimNo(Map<String, Object> paramsMap);

	public int delOriginalClaimNum(@Param("linkCaseId") String linkCaseId);

	public List<String> queryCasePols(String linkcaseid);

	public int delWcfLink(FdWcfLink fdWcfLink);

	public List<FdWcfLink> queryFdWcfLink(FdWcfLink fdWcfLink);

	public int updateFdClaimInfo(FdClaimInfo fdClaimInfo);

}
