package com.aia.case360.web.constant;

import org.apache.commons.lang.StringUtils;

/***
 * 
 * @author ASNPHEC
 *
 */
public enum SignatureRoleEnum {
	INSURED("A", "Insured"), INSURED_OWNER("B", "Insured/Owner"), OWNER("C", "Owner"), ASSIGNEE("D", "Assignee"),
	TRUSTEE_1("E", "Trustee 1"), TRUSTEE_2("F", "Trustee 2"), TRUSTEE_3("G", "Trustee 3"), TRUSTEE_4("H", "Trustee 4"),
	PAYOR("X", "Payor"), INSURED_PAYOR("Y", "Insured/Payor");

	private String code, name;

	public static String getSigName(String code) {
		if (StringUtils.isNotBlank(code)) {
			for (SignatureRoleEnum c : SignatureRoleEnum.values()) {
				if (c.getCode().equals(code)) {
					return c.getName();
				}
			}

		}
		return "";
	}

	SignatureRoleEnum(String code, String name) {
		 this.code = code;
		 this.name = name;
	}

	public String getCode() {
		return code;
	}

	public String getName() {
		return name;
	}

}
