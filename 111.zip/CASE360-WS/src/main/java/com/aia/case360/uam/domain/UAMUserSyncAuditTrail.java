package com.aia.case360.uam.domain;

public class UAMUserSyncAuditTrail {

	private String uamUserPhoneNumber;
	private String uamUserDepartment;
	private String uamUserOfficeNumber;
	private String userCompany;
	private String uamUserId;
	private String fromAD;
	private String displayName;
	private String activeStatus;
	private String deliveryString;
	private String curUser;
	private int opFlag;

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "UAMUserSyncAuditTrail [uamUserPhoneNumber=" + uamUserPhoneNumber + ", uamUserDepartment="
				+ uamUserDepartment + ", uamUserOfficeNumber=" + uamUserOfficeNumber + ", userCompany=" + userCompany
				+ ", uamUserId=" + uamUserId + ", fromAD=" + fromAD + ", displayName=" + displayName + ", activeStatus="
				+ activeStatus + ", deliveryString=" + deliveryString + ", curUser=" + curUser + ", opFlag=" + opFlag
				+ "]";
	}

	/**
	 * @return the uamUserPhoneNumber
	 */
	public String getUamUserPhoneNumber() {
		return uamUserPhoneNumber;
	}

	/**
	 * @return the uamUserDepartment
	 */
	public String getUamUserDepartment() {
		return uamUserDepartment;
	}

	/**
	 * @return the uamUserOfficeNumber
	 */
	public String getUamUserOfficeNumber() {
		return uamUserOfficeNumber;
	}

	/**
	 * @return the userCompany
	 */
	public String getUserCompany() {
		return userCompany;
	}

	/**
	 * @return the uamUserId
	 */
	public String getUamUserId() {
		return uamUserId;
	}

	/**
	 * @return the fromAD
	 */
	public String getFromAD() {
		return fromAD;
	}

	/**
	 * @return the displayName
	 */
	public String getDisplayName() {
		return displayName;
	}

	/**
	 * @return the activeStatus
	 */
	public String getActiveStatus() {
		return activeStatus;
	}

	/**
	 * @return the deliveryString
	 */
	public String getDeliveryString() {
		return deliveryString;
	}

	/**
	 * @return the curUser
	 */
	public String getCurUser() {
		return curUser;
	}

	/**
	 * @return the opFlag
	 */
	public int getOpFlag() {
		return opFlag;
	}

	/**
	 * @param uamUserPhoneNumber the uamUserPhoneNumber to set
	 */
	public void setUamUserPhoneNumber(String uamUserPhoneNumber) {
		this.uamUserPhoneNumber = uamUserPhoneNumber;
	}

	/**
	 * @param uamUserDepartment the uamUserDepartment to set
	 */
	public void setUamUserDepartment(String uamUserDepartment) {
		this.uamUserDepartment = uamUserDepartment;
	}

	/**
	 * @param uamUserOfficeNumber the uamUserOfficeNumber to set
	 */
	public void setUamUserOfficeNumber(String uamUserOfficeNumber) {
		this.uamUserOfficeNumber = uamUserOfficeNumber;
	}

	/**
	 * @param userCompany the userCompany to set
	 */
	public void setUserCompany(String userCompany) {
		this.userCompany = userCompany;
	}

	/**
	 * @param uamUserId the uamUserId to set
	 */
	public void setUamUserId(String uamUserId) {
		this.uamUserId = uamUserId;
	}

	/**
	 * @param fromAD the fromAD to set
	 */
	public void setFromAD(String fromAD) {
		this.fromAD = fromAD;
	}

	/**
	 * @param displayName the displayName to set
	 */
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	/**
	 * @param activeStatus the activeStatus to set
	 */
	public void setActiveStatus(String activeStatus) {
		this.activeStatus = activeStatus;
	}

	/**
	 * @param deliveryString the deliveryString to set
	 */
	public void setDeliveryString(String deliveryString) {
		this.deliveryString = deliveryString;
	}

	/**
	 * @param curUser the curUser to set
	 */
	public void setCurUser(String curUser) {
		this.curUser = curUser;
	}

	/**
	 * @param opFlag the opFlag to set
	 */
	public void setOpFlag(int opFlag) {
		this.opFlag = opFlag;
	}
}
