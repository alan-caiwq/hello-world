package com.aia.case360.web.pojo;

public class PanelDoctorInfo {

	private String policyNo;
	private String claimNo;
	private String panelDoctorIndicator;

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public String getPanelDoctorIndicator() {
		return panelDoctorIndicator;
	}

	public void setPanelDoctorIndicator(String panelDoctorIndicator) {
		this.panelDoctorIndicator = panelDoctorIndicator;
	}

}
