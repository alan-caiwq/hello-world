/**
 * ------------------------------------------------- Copyright (c) 2017-2019 AIA . All Rights
 * Reserved. ------------------------------------------------- Project Name: Pulse
 * 
 * @author:
 * @version: 1.0 Description: Revised Records:
 */
package com.aia.case360.uam.service.impl;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aia.case360.common.Constants;
import com.aia.case360.platform.common.DataFieldUtil;
import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.uam.domain.Menu;
import com.aia.case360.uam.service.UAMMenuService;
import com.aia.case360.web.dao.MenuDao;
import com.aia.case360.web.pojo.OutputVO;
import com.aia.case360.web.service.impl.AbstractServiceImpl;

import net.sf.json.JSONArray;

/**
 * @author bsnpbdu
 *
 */
@Service
public class UAMMenuServiceImpl extends AbstractServiceImpl implements UAMMenuService {

	@Autowired
	private MenuDao menuDao;

	@Override
	public String getAllMenus(int menuType) {
		List<Menu> allMenus = menuDao.findAllMenus(menuType);
		return genMenuList(menuType, allMenus);
	}

	private String genMenuList(int menuType, List<Menu> allMenus) {
		switch (Menu.MenuTypeEnum.getByValue(menuType)) {
		case MENU:
			return getMenuList(allMenus);
		case BUTTON:
			return getAllButtons(allMenus);
		case FORMCATEGORY:
			return null;
		default:
			break;
		}
		return null;
	}

	private String getAllButtons(List<Menu> allButtons) {
		JSONArray json = JSONArray.fromObject(allButtons);

		return json.toString();
	}

	@Override
	public String getMenusByUserId(String userId, int menuType) {

		if (userId == null || userId.trim().length() == 0) {
			return "";
		}

		if (userId.equalsIgnoreCase(Constants.SONORA)) {
			return this.getAllMenus(menuType);
		}

		Map<String, Object> queryMap = new HashMap<String, Object>();
		queryMap.put("userId", userId);
		queryMap.put("menuType", menuType);
		List<Menu> allMenus = menuDao.findMenuByUserId(queryMap);
		return genMenuList(menuType, allMenus);
	}

	private String getMenuList(List<Menu> menuList) {
		List<Menu> topMenu = new ArrayList<Menu>();

		for (Menu m : menuList) {
			if (m.getParentMenuId() == null || Integer.parseInt(m.getParentMenuId()) < 1) {
				topMenu.add(m);

			} else {

				Menu parentMenu = getParentMenuItem(m, topMenu);
				if (parentMenu == null) {
					continue;
				}
				parentMenu.getItems().add(m);
			}
		}

		JSONArray json = JSONArray.fromObject(topMenu);

		return json.toString();
	}

	private Menu getParentMenuItem(Menu menu, List<Menu> topMenus) {

		int level = menu.getMenuId().length() / 2 - 1;

		String[] menuHierachy = new String[level];

		for (int i = 0; i < level; i++) {
			menuHierachy[i] = menu.getMenuId().substring(0, i * 2 + 2);

		}
		Menu currentParent = null;
		for (Menu tm : topMenus) {
			if (tm.getMenuId().equals(menuHierachy[0])) {
				currentParent = tm;
			}
		}
		if (currentParent == null) {
			return null;
		}
		List<Menu> items = currentParent.getItems();
		for (int i = 1; i < level; i++) {
			for (Menu sm : items) {
				if (sm.getMenuId().equals(menuHierachy[i])) {
					items = sm.getItems();
					currentParent = sm;
					break;
				}
			}

		}
		return currentParent;
	}

	/**
	 * get all buttons & union a status(known by user's role authority). eg:
	 * name:buttonA, status: available
	 */
	@Override
	public OutputVO getUserButtons()  throws RemoteException {
		OutputVO result = new OutputVO();
		// addErrorInfo
		String userId = userHelper.getCurrentUser();
		LogUtil.logInfo(m_Logger,"userId:" + userId);
		if (DataFieldUtil.isNull(userId)) {
			LogUtil.logInfo(m_Logger,"userId is null");
			result.addErrorInfo("userId is null");
			return result;
		}
		List<Map<String, Object>> userButtons;
		if ("SONORA".equalsIgnoreCase(userId)) {
			userButtons = menuDao.querySONORAButtons();
		} else {
			userButtons = menuDao.queryUserButtons(userId);
		}
		LogUtil.logInfo(m_Logger,"userButtons:" + userButtons);
		result.setDatas(userButtons);
		return result;
	}

	@Override
	public OutputVO getFormCategory(Map<String, Object> request)  throws RemoteException {
		OutputVO outputVO = new OutputVO();
		// get configure user id
		String roleId = request.get("ROLEID") == null ? "" : request.get("ROLEID").toString();
		// get role's configured form category
		List<Map<String, Object>> roleFormCategory = new ArrayList<Map<String, Object>>();
		if (!StringUtils.isBlank(roleId)) {
			roleFormCategory = menuDao.queryRoleFormCategory(Integer.parseInt(roleId));
		}

		// get role's not configured form category
		List<Map<String, Object>> allFormCategory = menuDao.queryAllFormCategory();
		// remove role owned form category from all category
		if (roleFormCategory != null && roleFormCategory.size() > 0 && allFormCategory != null
				&& allFormCategory.size() > 0) {
			for (Map<String, Object> mRole : roleFormCategory) {
				if (allFormCategory.contains(mRole)) {
					allFormCategory.remove(mRole);
				}
			}
		}
		// construct data to outputVO
		Map<String, Object> datas = new ConcurrentHashMap<String, Object>();
		datas.put("ALLFORMCATEGORY", allFormCategory);
		datas.put("ROLEFORMCATEGORY", roleFormCategory);
		outputVO.setDatas(datas);
		return outputVO;
	}

}
