package com.aia.case360.uam.domain;

import java.util.List;

public class LogBean {

	private String action;

	private List<String> context;

	private String date;

	private String LanId;

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public List<String> getContext() {
		return context;
	}

	public void setContext(List<String> context) {
		this.context = context;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getLanId() {
		return LanId;
	}

	public void setLanId(String lanId) {
		LanId = lanId;
	}

}
