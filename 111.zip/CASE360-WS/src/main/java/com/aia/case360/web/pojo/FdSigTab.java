package com.aia.case360.web.pojo;

public class FdSigTab {

	private int sRowId;
	private int commentsRowId;
	private int docuemntId;
	private String polNum;
	private String polRole;
	private String objectId;
	private String companyNo;
	private String comments;
	private int isVoid;
	private int isDeleted;
	private String nric;
	private String name;

	public int getsRowId() {
		return sRowId;
	}

	public void setsRowId(int sRowId) {
		this.sRowId = sRowId;
	}

	public int getCommentsRowId() {
		return commentsRowId;
	}

	public void setCommentsRowId(int commentsRowId) {
		this.commentsRowId = commentsRowId;
	}

	public int getDocuemntId() {
		return docuemntId;
	}

	public void setDocuemntId(int docuemntId) {
		this.docuemntId = docuemntId;
	}

	public String getPolNum() {
		return polNum;
	}

	public void setPolNum(String polNum) {
		this.polNum = polNum;
	}

	public String getPolRole() {
		return polRole;
	}

	public void setPolRole(String polRole) {
		this.polRole = polRole;
	}

	public String getObjectId() {
		return objectId;
	}

	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}

	public String getCompanyNo() {
		return companyNo;
	}

	public void setCompanyNo(String companyNo) {
		this.companyNo = companyNo;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public int getIsVoid() {
		return isVoid;
	}

	public void setIsVoid(int isVoid) {
		this.isVoid = isVoid;
	}

	public int getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(int isDeleted) {
		this.isDeleted = isDeleted;
	}

	public String getNric() {
		return nric;
	}

	public void setNric(String nric) {
		this.nric = nric;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
