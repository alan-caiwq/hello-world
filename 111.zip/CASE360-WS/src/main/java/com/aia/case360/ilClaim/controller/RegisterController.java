package com.aia.case360.ilClaim.controller;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.aia.case360.ilClaim.service.RegisterService;
import com.aia.case360.web.webservice.AbstractController;

@RestController
public class RegisterController extends AbstractController {

	@Autowired
	RegisterService registerService;

	@RequestMapping(value = "/case/ows/searchClaimNo", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Map<String, String>>> searchClaimNo(@RequestBody Map<String, String> params)
			 throws RemoteException {
		List<Map<String, String>> result = new ArrayList<Map<String, String>>();
		String serviceName = "webservice : searchClaimNo";
		try {
			result = registerService.getClaimNo(params);
			return new ResponseEntity<List<Map<String, String>>>(result, HttpStatus.OK);
		} catch (Exception e) {
			 
			Map<String, String> errMapping = new HashMap<String, String>();
			errMapping.put("errMesage", "call " + serviceName + " failed.error message:" + e.getMessage());
			result.add(errMapping);
			return new ResponseEntity<List<Map<String, String>>>(result, HttpStatus.OK);
		}
	}

}
