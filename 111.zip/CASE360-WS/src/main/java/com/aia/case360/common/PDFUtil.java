package com.aia.case360.common;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.PDPageContentStream.AppendMode;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.graphics.state.PDExtendedGraphicsState;
import org.apache.pdfbox.pdmodel.interactive.digitalsignature.PDSignature;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.pdfbox.pdmodel.interactive.form.PDField;
import org.apache.pdfbox.pdmodel.interactive.form.PDSignatureField;
import org.apache.pdfbox.util.Matrix;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aia.case360.platform.common.LogUtil;
import com.eistream.sonora.util.StringUtil;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.AcroFields;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;


public class PDFUtil {
  
    private static Logger m_Logger = LoggerFactory.getLogger(PDFUtil.class);
  
	private  PDFUtil(){
	}
	public static int getPageNumber(final String fileName) throws InvalidPasswordException, IOException {
		int result = 0;
		try (PDDocument doc = PDDocument.load(new File(fileName))) {
			tryRemoveSecurity(doc);
			result = doc.getNumberOfPages();
		}
		return result;
	}

	public static int getPageNumber(final byte[] content) throws InvalidPasswordException, IOException {
		int result = 0;
		try (PDDocument doc = PDDocument.load(content)) {
			tryRemoveSecurity(doc);
			result = doc.getNumberOfPages();
		}
		return result;
	}

	public static byte[] flattenPdf(byte[] input) throws IOException, DocumentException {
		PdfReader reader = new PdfReader(input);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		PdfStamper stamper = new PdfStamper(reader, baos);
		AcroFields fields = stamper.getAcroFields();
		try {
			fields.setGenerateAppearances(true);
		}catch(Exception e) {
		  LogUtil.logException(m_Logger, e.getMessage(),e);
		}
		stamper.setFormFlattening(true);
		stamper.close();
		reader.close();

		return baos.toByteArray();
	}

	public static ByteArrayOutputStream watermarkPDF(File fileStored, String ts, String fontName) throws InvalidPasswordException, IOException {
		PDDocument doc;
		ByteArrayOutputStream bos = new ByteArrayOutputStream();

		doc = PDDocument.load(fileStored);
		tryRemoveSecurity(doc);	
		PDFont font = getConfigFont(fontName);

		PDExtendedGraphicsState r0 = new PDExtendedGraphicsState();
		r0.setNonStrokingAlphaConstant(0.3f);
		for (int i=0;i<doc.getNumberOfPages();i++) {
			genWaterMark(doc, font, ts, r0, i);
		}
		doc.save(bos);
		return bos;
	}
	public static ByteArrayOutputStream watermarkPDFFilterVoid(File fileStored, String ts, String fontName,String pageInd) throws InvalidPasswordException, IOException {
		PDDocument doc;
		ByteArrayOutputStream bos = new ByteArrayOutputStream();

		doc = PDDocument.load(fileStored);
		tryRemoveSecurity(doc);	
		PDFont font = getConfigFont(fontName);

		PDExtendedGraphicsState r0 = new PDExtendedGraphicsState();
		r0.setNonStrokingAlphaConstant(0.3f);
		for (int i=doc.getNumberOfPages()-1;i>=0;i--) {
			if (i < pageInd.length() && pageInd.charAt(i) != 'N') {
				doc.removePage(i);
			}
		}
		for (int i=0;i<doc.getNumberOfPages();i++) {
			genWaterMark(doc, font, ts, r0, i);
		}
		doc.save(bos);
		return bos;
	}
	public static boolean generateVoidMaskPDFFile(byte[] orgPDFbytes, File targetFile, String pageInd, String isMig)
			throws IOException {
		return generateVoidMaskPDFFile(orgPDFbytes, new BufferedOutputStream(new FileOutputStream(targetFile)),  pageInd,  isMig);
	}
	// Overload ui show void watermark
	public static boolean generateVoidMaskPDFFile(byte[] orgPDFbytes, OutputStream out, String pageInd, String isMig)
			throws IOException {
		String ts = "VOID";
		return generateWaterMaskPDFFile(orgPDFbytes,out,  pageInd,  isMig,ts);
	}
	
	public static boolean generateWaterMaskPDFFile(byte[] orgPDFbytes, OutputStream out, String pageInd, String isMig,String ts) throws IOException{
		PDPageContentStream cs = null;
		try (PDDocument reader = PDDocument.load(orgPDFbytes)) {
			tryRemoveSecurity(reader);
			int n = reader.getNumberOfPages();
			float fontSize = 0;
			PDFont font = PDType1Font.COURIER;
			// add watermark in the void page
			if (org.apache.commons.lang.StringUtils.isNotEmpty(isMig)
					&& org.apache.commons.lang.StringUtils.equals("1", isMig)) {
				fontSize = 200;
			} else {
				fontSize = 100;
			}
		
			double fw = (double)font.getStringWidth(ts) / 1000 * fontSize;
			double fh = (double)font.getFontDescriptor().getFontBoundingBox().getHeight() / 1000 * fontSize;
			PDExtendedGraphicsState r0 = new PDExtendedGraphicsState();
			r0.setNonStrokingAlphaConstant(0.3f);
			if (!StringUtil.isBlank(pageInd) && pageInd.indexOf('V') >= 0) {
				for (int i = 0; i < n; i++) {
					if (i < pageInd.length() && pageInd.charAt(i) == 'V') {
						genWaterMark(reader, font, ts, r0, i);
					}
				}
			}
			reader.save(out);
	
		} catch (InvalidPasswordException e) {
			out.write(orgPDFbytes);
			return true;
		}
		out.flush();
		return false;
	}
	
	private static void genWaterMark(PDDocument reader,  PDFont font, String ts,
			PDExtendedGraphicsState r0, int i) throws IOException {
		PDPageContentStream cs;
		PDPage page = reader.getPage(i);
		cs = new PDPageContentStream(reader, page, AppendMode.APPEND, true, true);
		double x = (double)(page.getMediaBox().getWidth())/2;
		double y = (double)(page.getMediaBox().getHeight())/2;
		double fontSize = (double)x/5;
		
		double fwR = (double)font.getStringWidth(ts) / 1000 * fontSize;
		fwR=(double) Math.sqrt(fwR*fwR/2);
		
		cs.setGraphicsStateParameters(r0);
		cs.beginText();
		cs.setFont(font, (float) fontSize);

		cs.transform(Matrix.getRotateInstance(Math.toRadians(45),
				(float)(x - ((fwR)/2)) ,(float)(y-((fwR)/2))));

		cs.showText(ts);
		cs.endText();
		cs.close();
	}

	
	public static boolean generateVoidMaskPDFFile(String sourceFile, File targetFile, String pageInd, String isMig)
			throws IOException {
		Path fileLocation = Paths.get(sourceFile);
		byte[] data = Files.readAllBytes(fileLocation);
		return generateVoidMaskPDFFile(data, targetFile, pageInd, isMig);
	}
	
	public static PDFInstance getPDFNormalPages(String pdfFileNamePath, String pageIndicator)
			throws InvalidPasswordException, IOException {
		ByteArrayOutputStream memPDFN = new ByteArrayOutputStream();
		int pdfPageNumber = 0;
		try (PDDocument doc = PDDocument.load(new File(pdfFileNamePath));
				PDDocument nDoc = new PDDocument();) {// fix sonoraqube bugs by charley 20180924
			tryRemoveSecurity(doc);
			for (int i = 0; i < doc.getNumberOfPages(); i++) {
				if (i < pageIndicator.length() && pageIndicator.charAt(i) != 'N') {
					continue;
				}
				PDPage page = doc.getPage(i);
				nDoc.addPage(page);
			}
			pdfPageNumber = nDoc.getNumberOfPages();
			nDoc.save(memPDFN);
		}

		PDFInstance result = new PDFInstance();
		result.setContent(memPDFN.toByteArray());
		result.setPageNumbers(pdfPageNumber);

		return result;
	}

	public static PDFont getConfigFont(String fontName) {
		if (fontName.equalsIgnoreCase(PDType1Font.COURIER.getName())) {
			return PDType1Font.COURIER;
		}
		if (fontName.equalsIgnoreCase(PDType1Font.COURIER_BOLD.getName())) {
			return PDType1Font.COURIER_BOLD;
		}
		if (fontName.equalsIgnoreCase(PDType1Font.COURIER_BOLD_OBLIQUE.getName())) {
			return PDType1Font.COURIER_BOLD_OBLIQUE;
		}
		if (fontName.equalsIgnoreCase(PDType1Font.COURIER_OBLIQUE.getName())) {
			return PDType1Font.COURIER_OBLIQUE;
		}

		if (fontName.equalsIgnoreCase(PDType1Font.HELVETICA.getName())) {
			return PDType1Font.HELVETICA;
		}
		if (fontName.equalsIgnoreCase(PDType1Font.HELVETICA_BOLD.getName())) {
			return PDType1Font.HELVETICA_BOLD;
		}
		if (fontName.equalsIgnoreCase(PDType1Font.HELVETICA_BOLD_OBLIQUE.getName())) {
			return PDType1Font.HELVETICA_BOLD_OBLIQUE;
		}
		if (fontName.equalsIgnoreCase(PDType1Font.HELVETICA_OBLIQUE.getName())) {
			return PDType1Font.HELVETICA_OBLIQUE;
		}
		if (fontName.equalsIgnoreCase(PDType1Font.SYMBOL.getName())) {
			return PDType1Font.SYMBOL;
		}
		if (fontName.equalsIgnoreCase(PDType1Font.TIMES_BOLD.getName())) {
			return PDType1Font.TIMES_BOLD;
		}
		if (fontName.equalsIgnoreCase(PDType1Font.TIMES_BOLD_ITALIC.getName())) {
			return PDType1Font.TIMES_BOLD_ITALIC;
		}

		if (fontName.equalsIgnoreCase(PDType1Font.TIMES_ITALIC.getName())) {
			return PDType1Font.TIMES_ITALIC;
		}
		if (fontName.equalsIgnoreCase(PDType1Font.TIMES_ROMAN.getName())) {
			return PDType1Font.TIMES_ROMAN;
		}
		if (fontName.equalsIgnoreCase(PDType1Font.ZAPF_DINGBATS.getName())) {
			return PDType1Font.ZAPF_DINGBATS;
		}
		return PDType1Font.COURIER;
	}

	
	public static void splitPdf(String src, String dest, List<Integer> pageList)
			throws IOException, DocumentException {

		try (PDDocument doc = PDDocument.load(new File(src)); PDDocument writer = new PDDocument();) {
			//Paul 
			tryRemoveSecurity(doc);
			int num = doc.getNumberOfPages();

			int resultPage = 0;

			for (int page = 0; page < num; page++) {
				if (pageList.size() != 0 && !pageList.contains(page+1)) {
					continue;
				}
				writer.importPage(doc.getPage(page));
				resultPage++;
			}
			if (resultPage == 0) {
			    
				writer.importPage(new PDPage());
			}
			writer.save(new File(dest));
		}

	}

	public static PDSignature findExistingSignature(PDAcroForm acroForm) {
		PDSignature signature = null;
		PDSignatureField signatureField = null;
		if (acroForm != null) {
			for (PDField f : acroForm.getFields()) {
				if (f instanceof PDSignatureField) {
					signatureField = (PDSignatureField) f;
					break;
				}
			}

			if (signatureField != null) {
				
				signature = signatureField.getSignature();

			}
		}
		return signature;
	}
	private static void tryRemoveSecurity (PDDocument doc) throws IOException {
		if (doc.isEncrypted()) {
			try {
				doc.setAllSecurityToBeRemoved(true);
			} catch (Exception e) {
				throw new IOException(e.getMessage());
			}
		}
	}
}
