package com.aia.case360.uam.domain;

public class RoleReqPara {

	private String uamRoleId;

	private String reqId;

	private String activityName;

	public String getUamRoleId() {
		return uamRoleId;
	}

	public void setUamRoleId(String uamRoleId) {
		this.uamRoleId = uamRoleId;
	}

	public String getReqId() {
		return reqId;
	}

	public void setReqId(String reqId) {
		this.reqId = reqId;
	}

	public String getActivityName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

}
