package com.aia.case360.platform.common;

import java.io.FileNotFoundException;
import java.io.InputStream;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamSource;

/**
 * Load an XSL from a file resource
 * 
 * @author hophvwk
 *
 */
public class XSLTLoader {
	
	private XSLTLoader() {}
	private static final TransformerFactory tf = TransformerFactory.newInstance();
	private static final String RESOURCE_BASE = "/META-INF/xsl/";

	/**
	 * Load an XSL from a resource and initalise a Transformer from it
	 * 
	 * @param resourceName
	 * @return
	 * @throws TransformerConfigurationException
	 * @throws FileNotFoundException
	 */
	public static Transformer load(String resourceName)
			throws TransformerConfigurationException, FileNotFoundException {
		String loc = RESOURCE_BASE + resourceName;
		InputStream in = XSLTLoader.class.getResourceAsStream(loc);
		if (null == in)
			throw new FileNotFoundException("XSL " + loc + "not found");

		Transformer t = null;
		StreamSource src = new StreamSource(in);
		t = tf.newTransformer(src);

		// Any extra config
		return t;
	}

}
