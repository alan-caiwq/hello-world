package com.aia.case360.ilClaim.dao;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

/**
 * claim approval
 * 
 * @author bsnpc0y
 *
 */
public class DecisionBean {


	private JdbcTemplate jdbcTemplate = ILDataSource.getILjdbcTemplate();

	/**
	 * Claim Decision Approval
	 * 
	 * @param params
	 * @return
	 * @throws SQLException
	 */
	public List<Map<String, String>> getClaimDecision(Map<String, String> params) throws SQLException {

		String childClaimNo = "";
		String policyNo = "";
		String matherClaimNo = "";

		if (null != params && params.size() > 0) {
			childClaimNo = params.get("childClaimNo");
			policyNo = params.get("policyNo");
			matherClaimNo = params.get("motherClaimNo");

		}

		StringBuilder str = new StringBuilder();

		str.append("Select CHDRNUM,ZACLMMT,ZACLMCD,ZAMCLSTS from ZPMDPF where VALIDFLAG = '1' ");

		if (null != policyNo && policyNo.length() > 0) {
			str.append(" and CHDRNUM ='");
			str.append(policyNo + "'");
		}
		if (null != matherClaimNo && matherClaimNo.length() > 0) {
			str.append(" and ZACLMMT ='");
			str.append(matherClaimNo + "'");
		}
		if (null != childClaimNo && childClaimNo.length() > 0) {
			str.append(" and ZACLMCD in (");
			str.append(childClaimNo + ")");
		}

		List<Map<String, String>> result = jdbcTemplate.query(str.toString(), new RowMapper<Map<String, String>>() {

			@Override
			public Map<String, String> mapRow(ResultSet rs, int index) throws SQLException {
				Map<String, String> map = new HashMap<String, String>();
				ResultSetMetaData meta = rs.getMetaData();
				int count = meta.getColumnCount();
				for (int i = 1; i <= count; i++) {
					map.put(meta.getColumnName(i), rs.getString(i) == null ? "" : rs.getString(i));
				}
				return map;
			}
		});

		return result;

	}
}
