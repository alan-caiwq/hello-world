package com.aia.case360.web.pojo;

public class AMLInfo {

	private String policyNo;

	private String claimNo;

	private String amlIndicator;

	private String amlTable;

	private int number;

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public String getAmlIndicator() {
		return amlIndicator;
	}

	public void setAmlIndicator(String amlIndicator) {
		this.amlIndicator = amlIndicator;
	}

	public String getAmlTable() {
		return amlTable;
	}

	public void setAmlTable(String amlTable) {
		this.amlTable = amlTable;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

}
