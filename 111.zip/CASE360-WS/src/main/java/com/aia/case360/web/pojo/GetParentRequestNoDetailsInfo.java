package com.aia.case360.web.pojo;

public class GetParentRequestNoDetailsInfo {
	// requestNo
	private String requestNo;

	public String getRequestNo() {
		return requestNo;
	}

	public void setRequestNo(String requestNo) {
		this.requestNo = requestNo;
	}

}
