package com.aia.case360.uam.domain;

import javax.validation.constraints.Pattern;

public class UAMGetOrganizationAuditTrailParam {

	private String userId;

	private String uamComponentName;

	@Pattern(regexp = "^([1-9]\\d{3}\\-(0?[1-9]|1[0-2])\\-(0?[1-9]|[12]\\d|3[01]))?$", message = "Invalid from date")
	private String fromDate;

	@Pattern(regexp = "^([1-9]\\d{3}\\-(0?[1-9]|1[0-2])\\-(0?[1-9]|[12]\\d|3[01]))?$", message = "Invalid to date")
	private String toDate;

	private String category;

	private String withChild;

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "UAMGetOrganizationAuditTrailParam [userId=" + userId + ", uamComponentName=" + uamComponentName
				+ ", fromDate=" + fromDate + ", toDate=" + toDate + ", category=" + category + ", withChild="
				+ withChild + "]";
	}

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @return the uamComponentName
	 */
	public String getUamComponentName() {
		return uamComponentName;
	}

	/**
	 * @return the fromDate
	 */
	public String getFromDate() {
		return fromDate;
	}

	/**
	 * @return the toDate
	 */
	public String getToDate() {
		return toDate;
	}

	/**
	 * @return the category
	 */
	public String getCategory() {
		return category;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @param uamComponentName the uamComponentName to set
	 */
	public void setUamComponentName(String uamComponentName) {
		this.uamComponentName = uamComponentName;
	}

	/**
	 * @param fromDate the fromDate to set
	 */
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	/**
	 * @param toDate the toDate to set
	 */
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	/**
	 * @param category the category to set
	 */
	public void setCategory(String category) {
		this.category = category;
	}

	/**
	 * @return the withChild
	 */
	public String getWithChild() {
		return withChild;
	}

	/**
	 * @param withChild the withChild to set
	 */
	public void setWithChild(String withChild) {
		this.withChild = withChild;
	}
}
