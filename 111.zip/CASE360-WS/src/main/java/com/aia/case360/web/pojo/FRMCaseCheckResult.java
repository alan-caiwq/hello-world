package com.aia.case360.web.pojo;

public class FRMCaseCheckResult {

  /**
   *  0:normal
   *  1:case duplicate with create user.
   *  2:exceed user case number
   */
  private Integer flag;
  
  /**
   *  Only available when flag=1;
   *  case duplicate with create user.
   */
  private String createUser;
  
  /**
   * @return the flag
   */
  public Integer getFlag() {
    return flag;
  }

  /**
   * @return the createUser
   */
  public String getCreateUser() {
    return createUser;
  }

  /**
   * @param flag the flag to set
   */
  public void setFlag(Integer flag) {
    this.flag = flag;
  }

  /**
   * @param createUser the createUser to set
   */
  public void setCreateUser(String createUser) {
    this.createUser = createUser;
  }

  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "FRMCaseCheckResult [flag=" + flag + ", createUser=" + createUser + "]";
  }
  
  
}
