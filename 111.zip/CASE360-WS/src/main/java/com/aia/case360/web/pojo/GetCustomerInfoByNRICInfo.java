package com.aia.case360.web.pojo;

public class GetCustomerInfoByNRICInfo {
	private String policyno;
	private String p_role;
	private String client_id;
	private String source;

	private String fullName;
	private String companyCode;
	private String contractNo;
	private String DOB;
	private String gender;
	private String customerNRIC;
	private String isValid;

	public String getPolicyno() {
		return policyno;
	}

	public void setPolicyno(String policyno) {
		this.policyno = policyno;
	}

	public String getP_role() {
		return p_role;
	}

	public void setP_role(String p_role) {
		this.p_role = p_role;
	}

	public String getClient_id() {
		return client_id;
	}

	public void setClient_id(String client_id) {
		this.client_id = client_id;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getContractNo() {
		return contractNo;
	}

	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	public String getDOB() {
		return DOB;
	}

	public void setDOB(String dOB) {
		if (dOB == null || (dOB.contains("99/99/9999") || dOB.contains("/  /0"))) {
			this.DOB = null;
		} else {
			this.DOB = dOB;
		}
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getCustomerNRIC() {
		return customerNRIC;
	}

	public void setCustomerNRIC(String customerNRIC) {
		this.customerNRIC = customerNRIC;
	}

	public String getIsValid() {
		return isValid;
	}

	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}

	@Override
	public String toString() {
		return "GetCustomerInfoByNRICInfo [policyno=" + policyno + ", p_role=" + p_role + ", client_id=" + client_id
				+ ", source=" + source + ", fullName=" + fullName + ", companyCode=" + companyCode + ", contractNo="
				+ contractNo + ", DOB=" + DOB + ", gender=" + gender + ", customerNRIC=" + customerNRIC + ", isValid="
				+ isValid + "]";
	}

}
