package com.aia.case360.web.advice;

import java.rmi.RemoteException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.aia.case360.platform.common.JsonUtil;
import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.web.dao.DocSigDao;
import com.aia.case360.web.pojo.FdPolRoleSig;
import com.aia.case360.web.pojo.FdSigAuditTrail;
import com.aia.case360.web.service.impl.AbstractServiceImpl;

import net.sf.json.JSONObject;

/**
 * 2018/09/07 CASEPP-8711 Delete signature comment, the comment should be empty
 * on UI. mod by bsnpc1n
 */
@Component
@Aspect
public class AuditTrailSigAspect extends AbstractServiceImpl {

	private static final String LOCALS_ROW_ID = "sRowId";
	@Autowired
	private DocSigDao docSigDao;
   @Pointcut("execution( * com.aia.case360.web.service.DocSigService.*(..))")
   public void pointCut(){
	// NOSONAR
   }

   @After("pointCut()")
	public void after(JoinPoint jp) {

		String methodName = jp.getSignature().getName();
     FdSigAuditTrail fdSigAuditTrail = new FdSigAuditTrail();
     fdSigAuditTrail.setCreatedTimestamp(new Date());
     try {
			String userId = userHelper.getCurrentUser();
       fdSigAuditTrail.setCreatedBy(userId);
     } catch (RemoteException e) {
       // TODO Auto-generated catch block
			 
			LogUtil.logError(m_Logger, "AuditTrailSigAspect getCurrentUser " + e.toString());
     }

		if (methodName.equalsIgnoreCase("reindexSig") || methodName.equalsIgnoreCase("copySig")) {
       JSONObject params = (JSONObject) jp.getArgs()[0];
       List<Map<String, String>> reindexFromList = JsonUtil.getRequestParamsList(params, "FROM");
       List<Map<String, String>> reindexToList = JsonUtil.getRequestParamsList(params, "TO");

			if (methodName.equalsIgnoreCase("reindexSig")) {
         fdSigAuditTrail.setCategory("Reindex Signature");
       } else {
         fdSigAuditTrail.setCategory("Copy Signature");
       }
       fdSigAuditTrail.setObjectId(reindexFromList.get(0).get("OBJECT_ID"));
       fdSigAuditTrail.setFromPolNum(reindexFromList.get(0).get("POL_NUM"));
       fdSigAuditTrail.setFromPolRole(reindexFromList.get(0).get("POL_ROLE"));
			for (Map<String, String> reindexTo : reindexToList) {
         fdSigAuditTrail.setToPolNum(reindexTo.get("POL_NUM"));
         fdSigAuditTrail.setToPolRole(reindexTo.get("POL_ROLE"));
         docSigDao.insertOneFdSigAuditTrail(fdSigAuditTrail);
       }
     }

		if (methodName.equalsIgnoreCase("saveFdSigComments")) {
       JSONObject params = (JSONObject) jp.getArgs()[0];
       String comments = params.getString("COMMENTS");
       String parentId = params.getString("PARENT_ID");
       Map<String, String> param = new HashMap<String, String>();
       param.put(LOCALS_ROW_ID, parentId);

       FdPolRoleSig fdPolRoleSig = docSigDao.findPolRoleSig(param);
       fdSigAuditTrail.setCategory("Update Comment");
       fdSigAuditTrail.setComments(comments);
       fdSigAuditTrail.setObjectId(fdPolRoleSig.getObjectId());
       fdSigAuditTrail.setFromPolNum(fdPolRoleSig.getPolNum());
       fdSigAuditTrail.setFromPolRole(fdPolRoleSig.getPolRole());
       fdSigAuditTrail.setToPolNum(fdPolRoleSig.getPolNum());
       fdSigAuditTrail.setToPolRole(fdPolRoleSig.getPolRole());
       docSigDao.insertOneFdSigAuditTrail(fdSigAuditTrail);
     }

		if (methodName.equalsIgnoreCase("deleteSigComments")) {
       JSONObject params = (JSONObject) jp.getArgs()[0];
			// 2018/09/07 CASEPP-8711 Delete signature comment, the comment should be empty
			// on UI. mod by bsnpc1n
       String parentId = params.getString("PARENT_ID");
       Map<String, String> param = new HashMap<String, String>();
       param.put(LOCALS_ROW_ID, parentId);
			FdPolRoleSig fdPolRoleSig = docSigDao.findPolRoleSig(param);
       fdSigAuditTrail.setCategory("Delete comment");
       fdSigAuditTrail.setObjectId(fdPolRoleSig.getObjectId());
       fdSigAuditTrail.setFromPolNum(fdPolRoleSig.getPolNum());
       fdSigAuditTrail.setFromPolRole(fdPolRoleSig.getPolRole());
       fdSigAuditTrail.setToPolNum(fdPolRoleSig.getPolNum());
       fdSigAuditTrail.setToPolRole(fdPolRoleSig.getPolRole());
       docSigDao.insertOneFdSigAuditTrail(fdSigAuditTrail);
     }

		if (methodName.equalsIgnoreCase("voidSig")) {
       String sRowId = (String) jp.getArgs()[0];
       Map<String, String> param = new HashMap<String, String>();
       param.put(LOCALS_ROW_ID, sRowId);
			FdPolRoleSig fdPolRoleSig = docSigDao.findPolRoleSig(param);
       fdSigAuditTrail.setCategory("Void Signature");
       fdSigAuditTrail.setObjectId(fdPolRoleSig.getObjectId());
       fdSigAuditTrail.setFromPolNum(fdPolRoleSig.getPolNum());
       fdSigAuditTrail.setFromPolRole(fdPolRoleSig.getPolRole());
       fdSigAuditTrail.setToPolNum(fdPolRoleSig.getPolNum());
       fdSigAuditTrail.setToPolRole(fdPolRoleSig.getPolRole());
       docSigDao.insertOneFdSigAuditTrail(fdSigAuditTrail);
     }

		if (methodName.equalsIgnoreCase("printSig")) {
       JSONObject params = (JSONObject) jp.getArgs()[0];
       List<Map<String, String>> prints = JsonUtil.getRequestParamsList(params, "PRINT");
			for (Map<String, String> print : prints) {
         insertSigAuditTrail(methodName, fdSigAuditTrail, print);
     }
   }
	}

  private void insertSigAuditTrail(String methodName, FdSigAuditTrail fdSigAuditTrail,
      Map<String, String> print) {
    String sRowId = print.get("S_ROWID");
    if (!sRowId.isEmpty() && !sRowId.equals("0")) {
       Map<String, String> param = new HashMap<String, String>();
       param.put(LOCALS_ROW_ID, sRowId);
    	FdPolRoleSig fdPolRoleSig = docSigDao.findPolRoleSig(param);
    	if (fdPolRoleSig != null) {
    		LogUtil.logInfo(m_Logger,fdPolRoleSig.toString());
    	   fdSigAuditTrail.setCategory("Print Signature");
    	   fdSigAuditTrail.setObjectId(fdPolRoleSig.getObjectId());
    	   fdSigAuditTrail.setFromPolNum(fdPolRoleSig.getPolNum());
    	   fdSigAuditTrail.setFromPolRole(fdPolRoleSig.getPolRole());
    	   fdSigAuditTrail.setToPolNum(fdPolRoleSig.getPolNum());
    	   fdSigAuditTrail.setToPolRole(fdPolRoleSig.getPolRole());
    		fdSigAuditTrail.setComments(print.get("COMMENT") == null ? "" : print.get("COMMENT"));
    	   docSigDao.insertOneFdSigAuditTrail(fdSigAuditTrail);
    	} else {
    		LogUtil.logError(m_Logger, "AuditTrailSigAspect methodName : " + methodName
    				+ " : cannot find FdPolRoleSig by sRowId " + sRowId);
       }
     }
  }

}
