package com.aia.case360.platform.common;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;

public final class Constants {
	public static final String ZERO = "0";
	public static final String ONE = "1";
	public static final String TWO = "2";
	public static final String THREE = "3";
	public static final String FALSE = "false";
	public static final String TRUE = "true";

	// define string
	public static final String DEPARTMENT = "DEPARTMENT";
	public static final String CATEGORY = "CATEGORY";
	public static final String PRIORITY_VALUES = "PRIORITY_VALUES";
	public static final String GET_PRIORITY_RULE = "GET_PRIORITY_RULE";
	// (1string2 int 3 money 4 date 5 datetime)
	public static final Integer RULE_CASE_TYPE_STRING = 1;
	public static final Integer RULE_CASE_TYPE_INT = 2;
	public static final Integer RULE_CASE_TYPE_MONEY = 3;
	public static final Integer RULE_CASE_TYPE_DATE = 4;
	public static final Integer RULE_CASE_TYPE_DATETIME = 5;

	// concurrent case default rule
	public static final String CONCURRENT_DEFAULT_RULE_SAME_INSURED = "1";
	public static final String CONCURRENT_DEFAULT_RULE_SAME_OWNER = "2";
	public static final String CONCURRENT_DEFAULT_RULE_SAME_POLICY = "3";
	public static final String CONCURRENT_DEFAULT_RULE_SAME_INSURED_OR_OWNER = "4";

	public static final Integer DEFAULT_PAGE_INDEX = 1;
	public static final Integer DEFAULT_PAGE_NUM = 10;
	public static final String DEFAULT_ORDER_BY = "LINKCASEID ASC";
	public static final String DEFAULT_FILTER = " 1=1 ";

	// operation type 1 add 2 delete 3 update 4 query
	public static final String OPERATION_ADD = "1";
	public static final String OPERATION_DELETE = "2";
	public static final String OPERATION_UPDATE = "3";
	public static final String OPERATION_QUERY = "4";
	// priority fields define
	public static final BigDecimal MAX_MONEY = new BigDecimal("10000000000.00");
	public static final Integer MAX_DATE = 99991231;
	public static final String MIN_DATE_STR = "00000000";
	public static final Integer MONEY_SCALE = 2;
	public static final Integer SORT_DIRECTION_ASC = 0;
	public static final Integer SORT_DIRECTION_DESC = 1;
	public static final String FILL_FIELD = "0";
	public static final Long MAX_DATETIME = 99991231235959l;
	public static final String MIN_DATETIME_STR = "00000000000000";


	// POS
	// submission chanel
	public static final String SUB_CHANEL = "SUB_CHANEL";
	// source of business
	public static final String BUS_SOURCE = "BUS_SOURCE";

	public static final String STR_POINT = ".";
	// UNI
	// CLM
	// SOS
	// HNW
	// CS
	// CMP

	// department define
	public static final String DEPARTMENT_POS = "POS";
	public static final String DEPARTMENT_CLM = "CLM";
	public static final String DEPARTMENT_UNI = "UNI";
	// stop clock status stop
	public static final String CASE_STATUS_STOP = "1";
	// default rule flag
	public static final String DEFAULT_RULE = "0";

	public static final Integer AUTO_ASSIN_CASE_COUNT = 10;

	public static final String BUTTON_STATUS_ACTIVE = "1";

	// user Status
	public static final String USER_STATUS_ACTIVE = "Active";
	public static final String USER_STATUS_INACTIVE = "Inactive";
	public static final String USER_STATUS_TERMINATE = "Terminated";

	public static final String FSCCODE = "FSC_CODE";

	public static final String COMPANYCODE = "COMPANYCODE";

	public static final String SGPCODE = "011";

	public static final String POLNUM = "POLNUM";

	public static final String CASEFOLDERID = "CASEFOLDERID";

	public static final String LINKCASEID = "LINKCASEID";

	public static final String BLANK_STR = "";

	public static final String POM = "POM";

	public static final String ANP = "ANP";

	public static final String CWA = "CWA";

	public static final String PANEL_DOCTOR = "PANEL_DOCTOR";

	public static final String CITI = "CITI";

	public static final String MDRT = "MDRT";

	public static final String MDRT_CITI = "MDRT_CITI";

	public static final String OPERATION_TYPE_COPY = "1";

	public static final String OPERATION_TYPE_SPLIT = "2";
	// user active max time is 30 minutes
	public static final long USER_ACTIVE_MAX_TIME = 3000l;

	public static final String REQUEST_TYPE_MASTER = "1";

	public static final String REQUEST_TYPE_SLAVE = "2";
	
	private Constants() {}

	private static final ThreadLocal<SimpleDateFormat> yyyyMMddThreadLocal = new ThreadLocal<SimpleDateFormat>() {
		@Override
		protected SimpleDateFormat initialValue() {
			return new SimpleDateFormat("yyyyMMdd");
		}
	};

	public static SimpleDateFormat getDateFormat() {
		return yyyyMMddThreadLocal.get();
	}

	private static final ThreadLocal<SimpleDateFormat> yyyyMMddHHmmssThreadLocal = new ThreadLocal<SimpleDateFormat>() {
		@Override
		protected SimpleDateFormat initialValue() {
			return new SimpleDateFormat("yyyyMMddHHmmss");
		}
	};

	public static SimpleDateFormat getDateTimeFormat() {
		return yyyyMMddHHmmssThreadLocal.get();
	}

	private static final ThreadLocal<SimpleDateFormat> yyyyMMddHHmmssSSSThreadLocal = new ThreadLocal<SimpleDateFormat>() {
		@Override
		protected SimpleDateFormat initialValue() {
			return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		}
	};

	public static SimpleDateFormat getDBDateTimeFormat() {
		return yyyyMMddHHmmssSSSThreadLocal.get();
	}
}
