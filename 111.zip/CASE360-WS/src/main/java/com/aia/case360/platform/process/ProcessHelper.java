package com.aia.case360.platform.process;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import com.eistream.sonora.workflow.workflows.WFElement;

public interface ProcessHelper {

	/**
	 * get the definition of the process which name is processName. The version is
	 * enabled published setting.
	 * 
	 * @param processName process name is case-sensitive
	 * @param wfVersion   wfversion number
	 * @return WFElement includes workflowId,wfVersion (current)
	 * @throws RemoteException
	 */
	public WFElement getProcessDefinition(String processName) throws RemoteException;

	public List<String> getTableColumnName(String processName) throws RemoteException;

	/**
	 * Create one workitem based on workFlowName, casefolder field values, after
	 * creating, the workitem will auto routeOn next step
	 * 
	 * @param workFlowName workFlow name
	 * @param cfParams     casefolder's field values
	 * @throws RemoteException
	 */
	public String createWorkitem(String workFlowName, Map<String, Object> cfParams, String startWorkStep)
			throws RemoteException;

	List<Map<String, String>> getDispatchButtons(String workstep, int flowId) throws RemoteException;

	public Map<String, String> closeWorkItems(String skey) throws RemoteException;

}
