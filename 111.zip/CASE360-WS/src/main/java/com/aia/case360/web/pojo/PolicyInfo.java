package com.aia.case360.web.pojo;

public class PolicyInfo {

	private String companyNo;
	private String policyNo;
	private String applicationDate;
	private String applicationReceiptDate;
	private String documentReceiptDate;
	private String planName;
	private String sumAssured;
	private String currency;
	private String status;
	private String campaignCode;
	private String campaignDescription;
	private String uwid;
	private String medCode;
	private String billingChannel;
	private String billMode;
	private String paymentMode;
	private String modalPremium;
	private String cwa;
	private String cwaDate;
	private String cwaModalPremium;// CWA>Modal Premium
	private String pendingReason;
	private String pendingType;
	private String fscCode;
	private String fscName;
	private String location;
	private String agencyCode;
	private String agencyName;
	private String fscCode2;
	private String fscName2;
	private String location2;
	private String agencyCode2;
	private String agencyName2;
	private String agencyLeaderEndorsement;
	private String agencyLeaderEndorsementDate;
	private String submissionChannel;
	private String physicalFileReceiptDate;
	private String maturityPolicyNo;
	private String maturityDate;
	private String maturityRelationship;
	private String concurrentCaseIndicator;
	private String mdrtIndicator;
	private String TSAR;
	private String ANP;
	private String followUpCode;
	private String contractNo;
	private String contractCode;
	private String componentCode;
	private String inceptionDate;
	public String getBillMode() {
		return billMode;
	}

	public void setBillMode(String billMode) {
		this.billMode = billMode;
	}

	public String getContractNo() {
		return contractNo;
	}

	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	public String getCompanyNo() {
		return companyNo;
	}

	public void setCompanyNo(String companyNo) {
		this.companyNo = companyNo;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getApplicationDate() {
		return applicationDate;
	}

	public void setApplicationDate(String applicationDate) {
		this.applicationDate = applicationDate;
	}

	public String getApplicationReceiptDate() {
		return applicationReceiptDate;
	}

	public void setApplicationReceiptDate(String applicationReceiptDate) {
		this.applicationReceiptDate = applicationReceiptDate;
	}

	public String getDocumentReceiptDate() {
		return documentReceiptDate;
	}

	public void setDocumentReceiptDate(String documentReceiptDate) {
		this.documentReceiptDate = documentReceiptDate;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public String getSumAssured() {
		return sumAssured;
	}

	public void setSumAssured(String sumAssured) {
		this.sumAssured = sumAssured;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCampaignCode() {
		return campaignCode;
	}

	public void setCampaignCode(String campaignCode) {
		this.campaignCode = campaignCode;
	}

	public String getCampaignDescription() {
		return campaignDescription;
	}

	public void setCampaignDescription(String campaignDescription) {
		this.campaignDescription = campaignDescription;
	}

	public String getUwid() {
		return uwid;
	}

	public void setUwid(String uwid) {
		this.uwid = uwid;
	}

	public String getMedCode() {
		return medCode;
	}

	public void setMedCode(String medCode) {
		this.medCode = medCode;
	}

	public String getBillingChannel() {
		return billingChannel;
	}

	public void setBillingChannel(String billingChannel) {
		this.billingChannel = billingChannel;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public String getModalPremium() {
		return modalPremium;
	}

	public void setModalPremium(String modalPremium) {
		this.modalPremium = modalPremium;
	}

	public String getCwa() {
		return cwa;
	}

	public void setCwa(String cwa) {
		this.cwa = cwa;
	}

	public String getCwaDate() {
		return cwaDate;
	}

	public void setCwaDate(String cwaDate) {
		if (cwaDate == null || (cwaDate.contains("99/99/9999") || cwaDate.contains("/  /0"))) {
			this.cwaDate = null;
		} else {
			this.cwaDate = cwaDate;
		}
	}

	public String getCwaModalPremium() {
		return cwaModalPremium;
	}

	public void setCwaModalPremium(String cwaModalPremium) {
		this.cwaModalPremium = cwaModalPremium;
	}

	public String getPendingReason() {
		return pendingReason;
	}

	public void setPendingReason(String pendingReason) {
		this.pendingReason = pendingReason;
	}

	public String getPendingType() {
		return pendingType;
	}

	public void setPendingType(String pendingType) {
		this.pendingType = pendingType;
	}

	public String getFscCode() {
		return fscCode;
	}

	public void setFscCode(String fscCode) {
		this.fscCode = fscCode;
	}

	public String getFscName() {
		return fscName;
	}

	public void setFscName(String fscName) {
		this.fscName = fscName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getAgencyCode() {
		return agencyCode;
	}

	public void setAgencyCode(String agencyCode) {
		this.agencyCode = agencyCode;
	}

	public String getAgencyName() {
		return agencyName;
	}

	public void setAgencyName(String agencyName) {
		this.agencyName = agencyName;
	}

	public String getFscCode2() {
		return fscCode2;
	}

	public void setFscCode2(String fscCode2) {
		this.fscCode2 = fscCode2;
	}

	public String getFscName2() {
		return fscName2;
	}

	public void setFscName2(String fscName2) {
		this.fscName2 = fscName2;
	}

	public String getLocation2() {
		return location2;
	}

	public void setLocation2(String location2) {
		this.location2 = location2;
	}

	public String getAgencyCode2() {
		return agencyCode2;
	}

	public void setAgencyCode2(String agencyCode2) {
		this.agencyCode2 = agencyCode2;
	}

	public String getAgencyName2() {
		return agencyName2;
	}

	public void setAgencyName2(String agencyName2) {
		this.agencyName2 = agencyName2;
	}

	public String getAgencyLeaderEndorsement() {
		return agencyLeaderEndorsement;
	}

	public void setAgencyLeaderEndorsement(String agencyLeaderEndorsement) {
		this.agencyLeaderEndorsement = agencyLeaderEndorsement;
	}

	public String getAgencyLeaderEndorsementDate() {
		return agencyLeaderEndorsementDate;
	}

	public void setAgencyLeaderEndorsementDate(String agencyLeaderEndorsementDate) {
		this.agencyLeaderEndorsementDate = agencyLeaderEndorsementDate;
	}

	public String getSubmissionChannel() {
		return submissionChannel;
	}

	public void setSubmissionChannel(String submissionChannel) {
		this.submissionChannel = submissionChannel;
	}

	public String getPhysicalFileReceiptDate() {
		return physicalFileReceiptDate;
	}

	public void setPhysicalFileReceiptDate(String physicalFileReceiptDate) {
		this.physicalFileReceiptDate = physicalFileReceiptDate;
	}

	public String getMaturityPolicyNo() {
		return maturityPolicyNo;
	}

	public void setMaturityPolicyNo(String maturityPolicyNo) {
		this.maturityPolicyNo = maturityPolicyNo;
	}

	public String getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(String maturityDate) {
		if (maturityDate == null || (maturityDate.contains("99/99/9999") || maturityDate.contains("/  /0"))) {
			this.maturityDate = null;
		} else {
			this.maturityDate = maturityDate;
		}
	}

	public String getMaturityRelationship() {
		return maturityRelationship;
	}

	public void setMaturityRelationship(String maturityRelationship) {
		this.maturityRelationship = maturityRelationship;
	}

	public String getConcurrentCaseIndicator() {
		return concurrentCaseIndicator;
	}

	public void setConcurrentCaseIndicator(String concurrentCaseIndicator) {
		this.concurrentCaseIndicator = concurrentCaseIndicator;
	}

	public String getMdrtIndicator() {
		return mdrtIndicator;
	}

	public void setMdrtIndicator(String mdrtIndicator) {
		this.mdrtIndicator = mdrtIndicator;
	}

	public String getTSAR() {
		return TSAR;
	}

	public void setTSAR(String tSAR) {
		TSAR = tSAR;
	}

	public String getANP() {
		return ANP;
	}

	public void setANP(String aNP) {
		ANP = aNP;
	}

	public String getFollowUpCode() {
		return followUpCode;
	}

	public void setFollowUpCode(String followUpCode) {
		this.followUpCode = followUpCode;
	}

	public String getComponentCode() {
		return componentCode;
	}

	public void setComponentCode(String componentCode) {
		this.componentCode = componentCode;
	}

	public String getContractCode() {
		return contractCode;
	}

	public void setContractCode(String contractCode) {
		this.contractCode = contractCode;
	}

	public String getInceptionDate() {
		return inceptionDate;
	}

	public void setInceptionDate(String inceptionDate) {
		this.inceptionDate = inceptionDate;
	}

	@Override
	public String toString() {
		return "PolicyInfo [companyNo=" + companyNo + ", policyNo=" + policyNo + ", applicationDate=" + applicationDate
				+ ", applicationReceiptDate=" + applicationReceiptDate + ", documentReceiptDate=" + documentReceiptDate
				+ ", planName=" + planName + ", sumAssured=" + sumAssured + ", currency=" + currency + ", status="
				+ status + ", campaignCode=" + campaignCode + ", campaignDescription=" + campaignDescription + ", uwid="
				+ uwid + ", medCode=" + medCode + ", billingChannel=" + billingChannel + ", billMode=" + billMode
				+ ", paymentMode=" + paymentMode + ", modalPremium=" + modalPremium + ", cwa=" + cwa + ", cwaDate="
				+ cwaDate + ", cwaModalPremium=" + cwaModalPremium + ", pendingReason=" + pendingReason
				+ ", pendingType=" + pendingType + ", fscCode=" + fscCode + ", fscName=" + fscName + ", location="
				+ location + ", agencyCode=" + agencyCode + ", agencyName=" + agencyName + ", fscCode2=" + fscCode2
				+ ", fscName2=" + fscName2 + ", location2=" + location2 + ", agencyCode2=" + agencyCode2
				+ ", agencyName2=" + agencyName2 + ", agencyLeaderEndorsement=" + agencyLeaderEndorsement
				+ ", agencyLeaderEndorsementDate=" + agencyLeaderEndorsementDate + ", submissionChannel="
				+ submissionChannel + ", physicalFileReceiptDate=" + physicalFileReceiptDate + ", maturityPolicyNo="
				+ maturityPolicyNo + ", maturityDate=" + maturityDate + ", maturityRelationship=" + maturityRelationship
				+ ", concurrentCaseIndicator=" + concurrentCaseIndicator + ", mdrtIndicator=" + mdrtIndicator
				+ ", TSAR=" + TSAR + ", ANP=" + ANP + ", followUpCode=" + followUpCode + ", contractNo=" + contractNo
				+ ", contractCode=" + contractCode + ", componentCode=" + componentCode + ", inceptionDate="
				+ inceptionDate + "]";
	}

}
