package com.aia.case360.task;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.web.service.GetJobRuleService;

//@Component
public class JobTask {

	@Autowired
	private GetJobRuleService priorityService;
	private Logger m_Logger = LoggerFactory.getLogger(getClass());

	/**
	 * do case encode job
	 */
	public void doTask() {
		try {
			priorityService.scoreCase("");
		} catch (Exception e) {
			 LogUtil.logException(m_Logger , "", e);
		}
	}
}
