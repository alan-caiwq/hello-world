package com.aia.case360.web.auditTrail;

public enum AuditFileTypeEnum {
	KEY_FIELD, FIELD, RELATION
}
