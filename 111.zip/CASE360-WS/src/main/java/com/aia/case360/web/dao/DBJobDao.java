package com.aia.case360.web.dao;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.aia.case360.web.pojo.Address;
import com.aia.case360.web.pojo.AgentData;
import com.aia.case360.web.pojo.CWADeatilInfo;
import com.aia.case360.web.pojo.CaseAndPolInfo;
import com.aia.case360.web.pojo.CaseDetailsInfo;
import com.aia.case360.web.pojo.DBJobParameter;
import com.aia.case360.web.pojo.DBJobSyncInfo;
import com.aia.case360.web.pojo.ExtractDeductionFilePolicyInfo;
import com.aia.case360.web.pojo.FSCDistrict;
import com.aia.case360.web.pojo.FollowUpCodeInfo;
import com.aia.case360.web.pojo.LapsePolicyInfo;
import com.aia.case360.web.pojo.PendingPaymentInfo;
import com.aia.case360.web.pojo.PolicyInfoFromOMS;
import com.aia.case360.web.pojo.PolicyInfoParameter;
import com.aia.case360.web.pojo.ReportDetail;
import com.aia.case360.web.pojo.RequestTypeRule;
import com.aia.case360.web.pojo.SVSCustPolicyData;
import com.aia.case360.web.pojo.SVSCustPolicyDataPLAS;
import com.aia.case360.web.pojo.SearchCaseDetailsInfo;
import com.aia.case360.web.pojo.SyncCPFADVFlag;
import com.aia.case360.web.pojo.TPDCaseInfo;
import com.aia.case360.web.pojo.TsarInfo;
import com.aia.case360.web.pojo.UNIPolicyInfo;
import com.aia.case360.web.pojo.UWDecision;

/**
 * @Author: huiyun ma
 * @Create Date: 03/02/2018 
*/ 

@Repository
public interface DBJobDao {
	
	
	//delete TempLapsePolicy table
	public void deleteTempLapsePolicy() throws SQLException;
	
	//sync Lapse Policy info from IL
	public List<LapsePolicyInfo> syncLapsePolicyIL(DBJobParameter paramMap) throws SQLException;
	//add by bsnpc65 2019-1-24 begin 
	//sync Lapse Policy info from ODS
	public List<LapsePolicyInfo> syncLapsePolicyODS(Map<String, Object> paraMap) throws SQLException;
	//add by bsnpc65 2019-1-24 end
	
	//insert TempLapsePolicy table
	public void insertLapsePolicyList(List<LapsePolicyInfo> lapsePolicyList) throws SQLException;
	
	//update case status as closed in CF_WORK table for lapse policy
	public List<String> updateLapseCaseStatus(Map<String, String> params) throws SQLException;
	
	//delete TempTPDCaseinfo table
	public void deleteTempTPDCaseInfo() throws SQLException;
	
	//sync TPD Case info from IL
	public List<TPDCaseInfo> syncTPDCaseInfoIL() throws SQLException;
	
	//sync TPD Case info from IL
	public List<TPDCaseInfo> syncTPDCaseInfoIL(DBJobParameter paramMap) throws SQLException;
	
	//insert the data list into TempTPDCaseinfo table
	public void insertTPDCaseInfoList(List<TPDCaseInfo> tpdCaseInfoList ) throws SQLException;
	
	
	//sync DeductionFilePolicy from IL
	public List<ExtractDeductionFilePolicyInfo> syncExtractDeductionFilePolicyIL(DBJobParameter dbJobParameter) throws SQLException;
		
	//delete TempExtractDeductionFilePolicy table
	public void deleteTempExtractDeductionFilePolicy() throws SQLException;
			
	//insert the data list into TempExtractDeductionFilePolicy table
	public void insertExtractDeductionFilePolicyList(List<ExtractDeductionFilePolicyInfo> insertExtractDeductionFilePolicyList) throws SQLException;
	
	
	
	/**
	 * get data from IL to sync FD_WCF_REQ_TYPE_RULES
	 * @return
	 * @throws SQLException
	 * @author bsnpc37(Leo Li)
	 * @date: May 3, 2018 5:04:38 PM
	 */
	List<RequestTypeRule>getDataForRequestTypeIL(Map<String, Object> parameters) throws SQLException;
	/**
	 * 
	 * @param parameters
	 * @return
	 * @throws SQLException
	 * @author bsnpc55(Paul Kong)
	 * @date: Jan 24, 2019 5:04:38 PM
	 */
	void getDataForRequestTypeODS(Map<String, Object> parameters) throws SQLException;
	/**
	 * get PolicyNo For RequestType from sonora to  get data from IL
	 * @return
	 * @throws SQLException
	 * @author bsnpc37(Leo Li)
	 * @date: May 3, 2018 5:36:36 PM
	 */
	List<CaseAndPolInfo>getPolicyInfoForRequestTypeAndPriority(String maxNum)throws SQLException;
	/**
	 * 
	 * @param procedureParam
	 * @return
	 * @throws SQLException
	 * @author bsnpc37(Leo Li)
	 * @date: May 4, 2018 11:46:37 AM
	 */
	int updateRequestTypeAndPriority(String procedureParam) throws SQLException;
	/**
	 * call stored procedure to count requestType and update CF_WORK requestType
	 * @return
	 * @throws SQLException
	 * @author bsnpc37(Leo Li)
	 * @date: May 4, 2018 3:10:34 PM
	 */
	List<CaseDetailsInfo> jobFindRequestType() throws SQLException;
	/**
	 *  
	 * @param params
	 * @return
	 * @throws SQLException
	 * @author bsnpc37(Leo Li)
	 * @date: May 11, 2018 6:06:47 PM
	 */
	int updateRequestTypeStatus(Map<String, String> params)throws SQLException;
	
	//check IL online status	
	public List<String> syncOnlineStatusIL(DBJobParameter param) throws SQLException;
	
	//get policyNo from FD_SYNC_POLICY_CACHE table (SYNCSTATUS = 0)
	public List<PolicyInfoParameter> getCachePolicyNoList() throws SQLException;
	
	//call oms procedure to get PolicyInfo for capture
	public List<PolicyInfoFromOMS> getPolicyInfoFromSybase(Map<String,String> paramMap) throws SQLException;
	
	//get policy No List
	public List<SVSCustPolicyData> getSVSListOfPolicies(String source) throws SQLException;
	//get client Info
    public List<SVSCustPolicyData> getClientInfoIL(Map<String,Object> param) throws SQLException;
    
    //confirm UD case or not
    public String confirmUDTypeIL(String clientNum ) throws SQLException;
    //get UD case address Info
    public List<Address> getUDaddressForClientNumIL(String clientNum ) throws SQLException;
    //get address Info
    public List<Address> getAddressForClientNumIL(String clientNum ) throws SQLException;
    //get address Info
    public List<Address> getAddressForClientNumHias(String clientNum ) throws SQLException;
    //get SG agentData Info
    public AgentData getSGAgentDetailsAMS(Map<String,String> param) throws SQLException;
    //get SG agentData Info
    public AgentData getBRUAgentDetailsAMS(Map<String,String> param) throws SQLException;
    //get policy No List in HIAS
   	public List<SVSCustPolicyData> getHiasListOfPolicies() throws SQLException;
    //get policy No List in PLAS
   	public List<SVSCustPolicyData> getPlasListOfPolicies() throws SQLException;
   	
    //get client Info in HIAS
    public List<SVSCustPolicyData> getClientInfoHias(Map<String,Object> param) throws SQLException;
    //getUserDeskHias
    public String getUserDeskHias(String userId) throws SQLException;
    //update notification status
    public Integer updateNotificationStatus(Map<String,Object> param) throws SQLException;
    
    
    //get xml Info in PLAS
    public List<SVSCustPolicyDataPLAS> getCustPolicyDataForPlas(Map<String,Object> param) throws SQLException;
    
    
    //select UNI policy Info 
    public List<String> getUNIPolicy() throws SQLException;
    //sync Inforce Policy info from IL
  	public List<UNIPolicyInfo> syncPolicyStatusIL(List<String> policyNoList) throws SQLException;
  	//delete TempUNIPolicyStatus table
  	public void deleteTempUNIPolicyStatusTable() throws SQLException;
    //insert TempUNIPolicyStatus table
  	public void insertTempUNIPolicyStatusTable(List<UNIPolicyInfo> policyStatusList) throws SQLException;
  	//get auto close case from Case360
    public List<UNIPolicyInfo> getAutoCloseCase() throws SQLException;
      
      
    //select UNI pending/closed case policy 
    public List<String> getUNICasePolicy(String caseStatus) throws SQLException;
    //sync Inforce Policy info from IL
  	public List<UNIPolicyInfo> syncCWAdetailsIL(Map<String,Object> param) throws SQLException;
  	
  	public List<UNIPolicyInfo> syncCWAdetailsODS(Map<String,Object> param) throws SQLException;
    //delete TempUNIPolicyCWAInfo table
  	public void deleteTempUNIPolicyCWAInfo() throws SQLException;
    //insert TempInforcePolicy table
  	public void insertTempUNIPolicyCWAInfo(List<UNIPolicyInfo> policyCWAList) throws SQLException;
    //get auto reopen case from Case360
    public List<UNIPolicyInfo> getReopenCase(String policyNo) throws SQLException;
    
    //get repositoryKey
    public String getRepositoryKey(String caseId) throws SQLException;
    
   	List<String> syncPolicyExpireIL(int noOfDays)throws SQLException;
   	//add by bsnpc65 2019-1-24 begin 
	List<String> syncPolicyExpireODS(Map<String, Object> paraMap)throws SQLException;
	//add by bsnpc65 2019-1-24 end 
	List<String> getFollowUpExpireCaseList(List<String> policyNos)throws SQLException;
	
    void addFollowUpCodeNote(Map<String, Object> params)throws SQLException;
    
    List<SyncCPFADVFlag> syncCPFADVFlagIL(List<String> params)throws SQLException;
    
    List<SyncCPFADVFlag> GetClaimNo4CPFADVFlag()throws SQLException;

    //get pending case policy from case360 by LOB and pendingID
    public List<String> getPendingCasePolicy(Map<String, String> params) throws SQLException;
    //delete TempPendingPaymentPolicy table
    public void deleteTempPendingPaymentInfo() throws SQLException;
    //sync pending payment Info from IL
  	public List<PendingPaymentInfo> syncPendingPaymentInfoIL(Map<String,Object> param) throws SQLException;
  	//get pending payment case Info
  	public List<PendingPaymentInfo> getUnpendPaymentCase(String policyNo) throws SQLException;
   //insert TempPendingPaymentInfo table
  	public void insertTempPendingPaymentInfo(List<PendingPaymentInfo> PendingPaymentInfoList) throws SQLException;

   //get  case Info
  	public List<SearchCaseDetailsInfo> getCaseByCaseParams(Map map) throws SQLException;
  	
  	
    
	

    /**
     * 
     * @param map
     * @return
     * @author bsnpc37(Leo Li)
     * @date: May 23, 2018 11:17:21 AM
     */
  	List<Map<String,Object>> getPendingCaseInfo(Map<String, String> map);

  	
  	List<PolicyInfoParameter> syncEDocNotification(Map<String,Date>map);

  	//get UNI pending IL status case in case360
  	List<UNIPolicyInfo> getUNIPendingILPolicy() throws SQLException;
    /**
     * 
     * @param getPendingLinkParams
     * @return
     * @author bsnpc37(Leo Li)
     * @date: May 25, 2018 3:14:47 PM
     */
	public List<Map<String, Object>> getPendingLink(Map<String, String> getPendingLinkParams);
	
	//get clientID from FD_WCF_REQ_TYPE_RULES for get TSAR
	public List<TsarInfo> getClientIDList() throws SQLException;
	
	public int insertTsarValues(List<TsarInfo> tasrInfoList) throws SQLException;
    /**
     * get job run info from FD_JOB_TIMESTAMP
     * @param queryJobRunInfoParams
     * @return
     * @author bsnpc37(Leo Li)
     * @date: Jun 15, 2018 1:47:52 PM
     */
	public Map<String, Object> getJobRunInfo(
			Map<String, String> queryJobRunInfoParams);
    /**
     * 
     * @param getPolicyNoParams
     * @return
     * @author bsnpc37(Leo Li)
     * @date: Jun 15, 2018 2:09:31 PM
     */
	public List<Map<String, String>> getCaseInfoForCitiBankReport(
			Map<String, String> getPolicyNoParams);
    /**
     * 
     * @param updateJobRunInfoParams
     * @author bsnpc37(Leo Li)
     * @date: Jun 15, 2018 2:16:16 PM
     */
	public void updateJobRunInfo(Map<String, String> updateJobRunInfoParams) throws SQLException;;

	public void createJobTimeStampBaseRecord(Map<String, String> updateJobRunInfoParams) throws SQLException;;
	
	public void syncBatchUploadFileDetails(Map<String, String> queryBatchUploadFileDetailsParams) throws SQLException;;

	/**
	 * 
	 * @param params
	 * @return
	 * @author: bsnpc55
	 * @date:6:56:17 PM Jul 24, 2018
	 */
	public List<CWADeatilInfo> getCWAdetailsMultiIL(Map<String, Object> params);
	/**
	 * 
	 * @param params
	 * @return
	 * @author: bsnpc65
	 * @date:15:33:17 PM Jan 24, 2019
	 */
	public List<CWADeatilInfo> getCWAdetailsMultiODS(Map<String, Object> params);
	/**
	 * 
	 * @param updateData   require companyNo|policyNo|source|fullName|role!!companyNo2|policyNo2|source2|fullName2|role2...
	 * @return
	 * @throws SQLException
	 * @author bsnpc37(Leo Li)
	 * @date: Aug 13, 2018 5:21:17 PM
	 */
    int updateTempEDocNotification (String updateData) throws SQLException;
    /**
     * 
     * @return
     * @throws SQLException
     * @author bsnpc37(Leo Li)
     * @date: Aug 13, 2018 5:21:43 PM
     */
    int insertEDocNotification ()throws SQLException;
    /**
     * 
     * @return
     * @throws SQLException
     * @author bsnpc37(Leo Li)
     * @date: Sep 3, 2018 5:46:32 PM
     */
    List<Map<String, Object>> getCloseCaseCache()throws SQLException;
   /**
    * 
    * @param params
    * @throws SQLException
    * @author bsnpc37(Leo Li)
    * @date: Sep 3, 2018 7:34:36 PM
    */
    int updateCloseCaseCache(Map<String, Object> params)throws SQLException;
    /**
     * 
     * @return
     * @throws SQLException
     * @author bsnpc37(Leo Li)
     * @date: Oct 18, 2018 10:59:32 AM
     */
    List<FSCDistrict> syncFSCcodeDistrictCodeAMS () throws SQLException;
    /**
     * 
     * @param dataBuffer
     * @throws SQLException
     * @author bsnpc37(Leo Li)
     * @date: Oct 18, 2018 11:56:28 AM
     */
    void insertFSCcodeDistrictCode (String dataBuffer) throws SQLException;

	void updateTEMPFLAG(List<String> caseIds) throws SQLException;

	List<Map<String, String>> getUNIPendingSTPPolicy() throws SQLException;
	
    List<DBJobSyncInfo> syncUWIDIL(List<String> policyNoList) throws SQLException;
    
    List<DBJobSyncInfo> syncUWIDODS(Map<String,Object> policyNoList) throws SQLException;
    
    public void deleteTempUWIDInfo() throws SQLException;
    
    public void insertTempUWIDInfo(List<DBJobSyncInfo> uwidInfoList) throws SQLException;
	
	List<DBJobSyncInfo> getUWIDUnpendCaseList() throws SQLException;
	
	List<String> getUNIPendingPLASPolicy() throws SQLException;
	
	public void deleteTempPlasStatusInfo() throws SQLException;	
	
	List<DBJobSyncInfo> syncPolicyStatusPlas(List<String> policyNoList) throws SQLException;
	
	public void insertTempPlasStatusInfo(List<DBJobSyncInfo> plasStatusList) throws SQLException;
	
	List<String> getPlasCloseCaseList() throws SQLException;
	
	List<Map<String, String>> getUNIPendingUWDecisionPolicy() throws SQLException;
	
	public void deleteTempUWDecisionInfo() throws SQLException;
	    
	List<DBJobSyncInfo> syncUWdecisionIL(List<String> policyNoList) throws SQLException;
	
    public void insertTempUWDecisionInfo(List<UWDecision> uwidInfoList) throws SQLException;
	
    List<BigDecimal> getUWdecisionUnpendCaseList() throws SQLException;
    

	public void updateTsarValues(@Param("hashStr")String policyNo) throws SQLException;

	public void updateOrInsertILStatus(@Param("onLineFlag")String onLineFlag, @Param("dateString")String dateString);

	public void syncILOnlineStatus4ODS(Map<String, Object> map) throws SQLException;

	public String getILOnlineStatusTimeFlag() throws SQLException;
	/**
	 * @description get special request type case to reclassify
	 * @param requestType
	 * @return
	 * @author bsnpc37(Leo Li)
	 * @date Jan 25, 2019 7:05:49 PM
	 */
	List<CaseAndPolInfo> getPolicyInfoForReclassify(String requestType);
	/**
	 * 
	 * @description 
	 * @param linkCaseId
	 * @return
	 * @author bsnpc37(Leo Li)
	 * @date Jan 26, 2019 11:45:31 AM
	 */
	Map<String, BigDecimal> reclassifyCommonProcess (String linkCaseId);
	/**
	 * @description 
	 * @param requestType
	 * @return
	 * @author bsnpc37(Leo Li)
	 * @date Jan 28, 2019 1:53:29 PM
	 */
	List<String> getReadyReclassifyCaseId(String requestType);
	/**
	 * @description 
	 * @param requestType
	 * @return
	 * @author bsnpc55(Paul Kong)
	 * @date Jan 28, 2019 18:53:29 PM
	 */
	public List<PendingPaymentInfo> syncPendingPaymentInfoODS(Map<String, Object> params);

	public void syncPolicyStatus4ODS(Map<String, Object> map);
	/**
	 * sync GIO and contract code exclusion for request type from ODS
	 * @description 
	 * @return
	 * @author bsnpc37(Leo Li)
	 * @date Feb 14, 2019 2:32:30 PM
	 */
	List<Map<String, String>> getItempfIL();
	/**
	 * TRUNCATE TABLE FD_ITEMPF,INSERT FD_ITEMPF
	 * @description 
	 * @param itempfList
	 * @author bsnpc37(Leo Li)
	 * @date Feb 14, 2019 3:03:47 PM
	 */
	void updateItempf(List<Map<String, String>> itempfList);
	public void syncExtractDeductionFilePolicyODS(Map<String, Object> map);

	public List<ReportDetail> getCitibankReport() throws SQLException;
	
	public void syncUWdecisionODS(Map<String, Object> para);
	/**
	 * used for shortPayMent notice
	 * @description 
	 * @param params
	 * @author bsnpc37(Leo Li)
	 * @date Feb 18, 2019 3:53:53 PM
	 */
	void updateAmountOfIlRequest(Map<String, String> params);
	void insertIlRequestForUni (Map<String, String> params);

	List<Map<String, Object>> getFailedDataForRetry();
	String getAvailableStep(Map<String, String> params);
	/**
	 * get last case activity processor
	 * @param map
	 * @return
	 * @author bsnpc0y(Weini Wei)
	 */
	public String getLastActProcessor(Map<String, String> map);

	public List<PendingPaymentInfo> getUnpendPaymentCaseForJob();
	String getIlStatus();
	void updateOrInsertILDBStatus(@Param("onLineFlag")String onLineFlag, @Param("dateString")String dateString);

	public void syncEDocNotificationToTEMP();
	public List<UNIPolicyInfo> getAutoCloseCase4CLM();

	public void insertTempCLMPolicyStatusTable(List<UNIPolicyInfo> list);

	public List<UNIPolicyInfo> getCLMPending4EFLPolicy();
	
	void syncCLMPolicyStatus4ODS(Map<String, Object> map);
	
	void syncFollowUpCodeInfoODS(Map<String, Object> map) throws SQLException;
	/**
	 * val exist batchNo in FD_XML_BATCH
	 * @description 
	 * @param batchNo
	 * @return
	 * @author bsnpc37(Leo Li)
	 * @date May 3, 2019 2:09:59 PM
	 */
	int valBatchNo(String batchNo);


	public List<SVSCustPolicyData> getPolTrTypeIl(Map<String, Object> params);

	public List<Map<String,String>> getPolIndicatorIL(Map<String, Object> params);

	public void getPolTrTypeODS(Map<String, Object> params);

	public void getClientInfoODS(Map<String, Object> param);

	public void getPolIndicatorODS(Map<String, Object> params);

	public List<String> getPolTrType();

	public void getMobileAndEMailODS(Map<String, Object> map);

	public void getAddressForClientNumODS(Map<String, Object> map);

	public List<Map<String, String>> getMobileAndEMailIL(Map<String, Object> map);

	public int countCYOCase(@Param("policyNo")String policyNo, @Param("companyCode")String companyCode,
			@Param("requestType")String requestType);
	
}
