package com.aia.case360.web.dao;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.aia.case360.web.pojo.ActInfo;
import com.aia.case360.web.pojo.FdReqType;
import com.aia.case360.web.pojo.FdReqTypeAuditTrail;
import com.aia.case360.web.pojo.FdReqTypeCategory;
import com.aia.case360.web.pojo.FdReqTypeCategoryAuditTrail;
import com.aia.case360.web.pojo.MandatoryDoc;
import com.aia.case360.web.pojo.ReqTypeCheckItem;
import com.aia.case360.web.pojo.ReqTypeVersion;

@Repository
public interface ReqtypeDao {

	public List<Map<String, String>> queryActiveReqtype(String Reqtype)  throws RemoteException;

	public List<Map<String, String>> queryAllActiveReqtype();

	public List<Map<String, String>> queryAllActivityByReqtype(String reqtype);

	public List<Map<String, String>> queryPreActivityByThisReqtype(ActInfo actInfo);

	public List<Map<String, String>> queryPreActivitySlaveByThisReqtype(ActInfo actInfo);

	List<FdReqType> queryActiveReqtypeList(FdReqType reqType);

	List<FdReqType> queryActiveReqtypeListFromSlave(FdReqType reqType);

	int queryActiveReqtypeCount(FdReqType reqType);

	FdReqType getReqtypeDetail(FdReqType reqType);

	FdReqType querySubReqtypeList(FdReqType reqType);

	List<ReqTypeCheckItem> getChecklist(ReqTypeCheckItem checkItem);

	List<ActInfo> getActList(ActInfo actInfo);

	List<MandatoryDoc> getMandatoryDocList(MandatoryDoc mandatoryDoc);

	FdReqType getReqtypeDetailFromSlave(FdReqType reqType);

	List<ReqTypeCheckItem> getChecklistFromSlave(ReqTypeCheckItem checkItem);

	List<ActInfo> getActListFromSlave(ActInfo actInfo);

	List<MandatoryDoc> getMandatoryDocListFromSlave(MandatoryDoc mandatoryDoc);

	void addReqType(FdReqType reqType);

	void updateReqType(FdReqType reqType);

	void batchAddActInfo(List<ActInfo> actInfos);

	void batchUpdateActInfo(List<ActInfo> actInfos);

	void batchAddMandatoryDoc(List<MandatoryDoc> mandatoryDocs);

	void batchAddReqTypeCheckItem(List<ReqTypeCheckItem> checklist);

	void deleteMandatoryDoc(MandatoryDoc mandatoryDoc);

	void deleteCheckItem(ReqTypeCheckItem checkItem);

	void addAuditTrail(FdReqTypeAuditTrail reqTypeAuditTrail);

	public List<Map<String, String>> queryAuditTrail(Map<String, String> params);

	public List<Map<String, String>> queryClosedAuditTrail(Map<String, String> params);

	void addReqTypeSlave(FdReqType reqType);

	void batchAddActInfoSlave(List<ActInfo> actInfos);

	void batchAddMandatoryDocSlave(List<MandatoryDoc> mandatoryDocs);

	void batchAddReqTypeCheckItemSlave(List<ReqTypeCheckItem> checklist);

	List<String> getBuddyReqTypeList()  throws RemoteException;

	String getMaxVersionNum(FdReqType reqType)  throws RemoteException;

	String getMaxVersionNumSlave(FdReqType reqType)  throws RemoteException;

	List<ReqTypeVersion> getVersionList(FdReqType reqType)  throws RemoteException;

	List<ReqTypeVersion> getVersionListFromSlave(FdReqType reqType)  throws RemoteException;

	int batchUpdateMandatoryDoc(List<MandatoryDoc> mandatoryDocList);

	int batchUpdateReqTypeCheckItem(List<ReqTypeCheckItem> ReqTypeCheckItemList);

	int deleteReqType(FdReqType reqType);

	void batchUpdateActInfoSlave(List<ActInfo> actInfos);

	int batchUpdateMandatoryDocSlave(List<MandatoryDoc> mandatoryDocList);

	int batchUpdateReqTypeCheckItemSlave(List<ReqTypeCheckItem> ReqTypeCheckItemList);

	int deleteReqTypeSlave(FdReqType reqType);

	int updateReqTypeSlave(FdReqType reqType);

	int closeVersion(FdReqType reqType);

	int addReqtypeAuditTrail(FdReqTypeAuditTrail fdReqTypeAuditTrail);

	int addReqtypeCategoryAuditTrail(FdReqTypeCategoryAuditTrail fdReqTypeCategoryAuditTrail);

	int validateVersionExist(FdReqType reqType);

	int getReqtypeCountByCategory(String rowid);

	int getReqtypeVersionCountByCategory(String rowid);

	FdReqTypeCategory getReqtypeCategoryDetail(String rowid);

	public List<Map<String, String>> queryCategoryAuditTrail(Map<String, String> params);

	public FdReqType copyReqType(Map<String, String> params)  throws RemoteException;

	public void batchUpdateReqTypeCheckItemSequence(List<ReqTypeCheckItem> checkListUpdate);

	public void batchUpdateReqTypeCheckItemSequenceSlave(List<ReqTypeCheckItem> checkListUpdate);

	public void batchCopyReqtypeAvailableSteps(@Param("reqType") String reqType, @Param("subTemplate") String subTemplate, @Param("userid") String userid);

}
