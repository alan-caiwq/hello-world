package com.aia.case360.drools.model;

public class RuleResult {

	private String rulename;
	private String destination;
	private String extraAct;

	public String getRulename() {
		return rulename;
	}

	public void setRulename(String rulename) {
		this.rulename = rulename;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getExtraAct() {
		return extraAct;
	}

	public void setExtraAct(String extraAct) {
		this.extraAct = extraAct;
	}

	@Override
	public String toString() {
		return "RuleResult [rulename=" + rulename + ", destination=" + destination + ", extraAct=" + extraAct + "]";
	}

	public String toTxt() {
		return "		RuleResult result = new RuleResult();result.setDestination(\""
				+ getDestination().replaceAll("\"", "") + "\");insert(result)" + "\n";
	}

}
