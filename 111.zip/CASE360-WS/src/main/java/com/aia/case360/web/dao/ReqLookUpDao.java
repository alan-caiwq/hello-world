package com.aia.case360.web.dao;

import java.util.List;
import java.util.Map;

import com.aia.case360.web.pojo.ReqLookUp;

public interface ReqLookUpDao {

	public List<ReqLookUp> getLookUpByCategAndGroup(Map<String, Object> params);

	public List<String> getLookUpCodesByCategAndGroup(Map<String, Object> params);

}
