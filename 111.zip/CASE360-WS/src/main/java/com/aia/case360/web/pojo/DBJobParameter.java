package com.aia.case360.web.pojo;

import java.math.BigDecimal;
import java.util.Date;

public class DBJobParameter {

    private BigDecimal currentDate;

	private String date;
   
	private Date runDate;

	public BigDecimal getCurrentDate() {
		return currentDate;
	}

	public void setCurrentDate(BigDecimal currentDate) {
		this.currentDate = currentDate;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public Date getRunDate() {
		return runDate;
	}

	public void setRunDate(Date runDate) {
		this.runDate = runDate;
	}
	
}
