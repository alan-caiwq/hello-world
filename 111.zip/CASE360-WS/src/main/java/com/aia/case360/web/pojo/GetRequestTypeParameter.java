package com.aia.case360.web.pojo;

import java.io.Serializable;

public class GetRequestTypeParameter implements Serializable {
	// processName
	private String processName;
	private String callingSystem;

	public String getProcessName() {
		return processName;
	}

	public void setProcessName(String processName) {
		this.processName = processName;
	}

	public String getCallingSystem() {
		return callingSystem;
	}

	public void setCallingSystem(String callingSystem) {
		this.callingSystem = callingSystem;
	}

}
