package com.aia.case360.web.pojo;

public class CaseCreateInfo {

	private String requestNo;

	private String batchNo;

	private String submitChannel;

	private String custNameScreened;

	private String casefolderId;

	private String createDate;

	private String requestType;

	private String parentCaseId;

	private String companyNo;

	private String policyNo;

	private String signatureVerifyFlag;

	public String getRequestNo() {
		return requestNo;
	}

	public void setRequestNo(String requestNo) {
		this.requestNo = requestNo;
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public String getSubmitChannel() {
		return submitChannel;
	}

	public void setSubmitChannel(String submitChannel) {
		this.submitChannel = submitChannel;
	}

	public String getCustNameScreened() {
		return custNameScreened;
	}

	public void setCustNameScreened(String custNameScreened) {
		this.custNameScreened = custNameScreened;
	}

	public String getCasefolderId() {
		return casefolderId;
	}

	public void setCasefolderId(String casefolderId) {
		this.casefolderId = casefolderId;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getParentCaseId() {
		return parentCaseId;
	}

	public void setParentCaseId(String parentCaseId) {
		this.parentCaseId = parentCaseId;
	}

	public String getCompanyNo() {
		return companyNo;
	}

	public void setCompanyNo(String companyNo) {
		this.companyNo = companyNo;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getSignatureVerifyFlag() {
		return signatureVerifyFlag;
	}

	public void setSignatureVerifyFlag(String signatureVerifyFlag) {
		this.signatureVerifyFlag = signatureVerifyFlag;
	}

}
