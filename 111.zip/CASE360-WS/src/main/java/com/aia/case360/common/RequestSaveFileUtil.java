package com.aia.case360.common;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.multipart.MultipartFile;

import com.aia.case360.platform.common.PropertyUtil;

public class RequestSaveFileUtil {
	
	private static final String UPLOAD_FILE_PATH = "UPLOAD_FILE_PATH";
	
	private  RequestSaveFileUtil(){
	}
	
	/**
	 * save file to local
	 * 
	 * @param multipartFiles
	 * @param request
	 * @return
	 * @throws IOException
	 */
	public static File[] saveFile(MultipartFile[] multipartFiles, HttpServletRequest request) throws IOException {
		File[] files = new File[multipartFiles.length];
		for (int i = 0; i < multipartFiles.length; i++) {
			files[i] =  saveFile(multipartFiles[i], request);
		}

		return files;
	}

	/**
	 * save file to local
	 * 
	 * @param multipartFile
	 * @param request
	 * @return
	 * @throws IOException
	 */
	public static File saveFile(MultipartFile multipartFile, HttpServletRequest request) throws IOException {
		InputStream inputStream = multipartFile.getInputStream();
		String fileName = multipartFile.getOriginalFilename();
		String rootPath = request.getServletContext().getRealPath("/");
		String uploadPath = rootPath + "\\" + PropertyUtil.getCommonProperty(UPLOAD_FILE_PATH);
		File uploadPathDir = new File(uploadPath);
		if (!uploadPathDir.exists()) {
			uploadPathDir.mkdirs();
		}
		File uploadFile = new File(uploadPath + "\\" + fileName);
		OutputStream outputStream = new FileOutputStream(uploadFile);
		try {
			byte[] bytes = new byte[1024];
			int len = 0;
			while ((len = inputStream.read(bytes)) != -1) {
				outputStream.write(bytes, 0, len);
			}
		} catch (IOException e) {
			throw e;
		} finally {
			outputStream.close();
			inputStream.close();
		}

		return uploadFile;
	}
}
