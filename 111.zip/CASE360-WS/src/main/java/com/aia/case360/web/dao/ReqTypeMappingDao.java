package com.aia.case360.web.dao;

import java.rmi.RemoteException;
import java.util.List;

import com.aia.case360.web.vo.ReqTypeMapping;

public interface ReqTypeMappingDao {
	public void updateReqTypeMapping(ReqTypeMapping reqTypeMapping)throws RemoteException;
	public void insertReqTypeMapping(ReqTypeMapping reqTypeMapping) throws RemoteException;
	public void deleteReqTypeMapping(long rowId)throws RemoteException;
	public List<ReqTypeMapping> searchReqTypeMapping(ReqTypeMapping reqTypeMapping) throws RemoteException;
	public ReqTypeMapping  searchReqTypeMappingByID(long sRowid);
}
