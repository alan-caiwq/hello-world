package com.aia.case360.web.pojo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import com.aia.case360.web.auditTrail.AuditEntityIgnoreCondition;
import com.aia.case360.web.auditTrail.AuditFieldSpecialAction;
import com.aia.case360.web.auditTrail.AuditFileTypeEnum;
import com.aia.case360.web.auditTrail.AuditTrail;
import com.aia.case360.web.auditTrail.annotation.AuditEntity;
import com.aia.case360.web.auditTrail.annotation.AuditField;
import com.fasterxml.jackson.annotation.JsonFormat;

@AuditEntity(entityName = "Non AIA Customer Information", formDataName = "Non AIA Customer", tableName = "FD_NON_AIA_CUSTOMER")
public class NonAIACustomerAuditTrail implements AuditTrail {

	private String acl;
	private BigDecimal sRowid;
	private BigDecimal id;
	
	@AuditField(fieldName = "ACTION_DESC", fieldType = AuditFileTypeEnum.FIELD)
	private String actDesc;

	@AuditField(fieldName = "CATEGORY", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private String category;
	
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	private Date createdTimestamp;
	
	@AuditField(fieldName = "Created By", fieldType = AuditFileTypeEnum.FIELD)
	private String createdBy;

	public String getAcl() {
		return acl;
	}

	public void setAcl(String acl) {
		this.acl = acl;
	}

	public BigDecimal getsRowid() {
		return sRowid;
	}

	public void setsRowid(BigDecimal sRowid) {
		this.sRowid = sRowid;
	}

	public BigDecimal getId() {
		return id;
	}

	public void setId(BigDecimal id) {
		this.id = id;
	}

	public String getActDesc() {
		return actDesc;
	}

	public void setActDesc(String actDesc) {
		this.actDesc = actDesc;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Date getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	@Override
	public List<AuditFieldSpecialAction> registFieldSpecialActionlist() {
		return new ArrayList<AuditFieldSpecialAction>();
	}

	@Override
	public List<AuditEntityIgnoreCondition> registIgnoreEntitylist() {
		return new ArrayList<AuditEntityIgnoreCondition>();
	}

	@Override
	public BigDecimal getRowID() {
		return null;
	}

	@Override
	public String getKeyDisplayName() {
		return "S_ROWID";
	}

	@Override
	public Object getKey() {
		return null;
	}

	@Override
	public String toString() {
		return "NonAIACustomerAuditTrail [actDesc=" + actDesc + ", category="
				+ category +  "]";
	}

}
