package com.aia.case360.web.pojo;

import java.math.BigDecimal;
import java.util.Date;

public class FdReqTypeCategory {

	private String acl;

	private BigDecimal sRowid;

	private String createdBy;

	private Date createdTimestamp;

	private String department;

	private String description;

	private short isDisable;

	private String reqTypeCategory;

	public String getAcl() {
		return acl;
	}

	public void setAcl(String acl) {
		this.acl = acl;
	}

	public BigDecimal getsRowid() {
		return sRowid;
	}

	public void setsRowid(BigDecimal sRowid) {
		this.sRowid = sRowid;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public short getIsDisable() {
		return isDisable;
	}

	public void setIsDisable(short isDisable) {
		this.isDisable = isDisable;
	}

	public String getReqTypeCategory() {
		return reqTypeCategory;
	}

	public void setReqTypeCategory(String reqTypeCategory) {
		this.reqTypeCategory = reqTypeCategory;
	}

}
