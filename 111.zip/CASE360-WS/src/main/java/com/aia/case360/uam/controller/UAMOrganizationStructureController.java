package com.aia.case360.uam.controller;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletRequest;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.aia.case360.common.Constants;
import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.uam.service.UAMOrganizationStructureService;
import com.aia.case360.uam.service.UAMUserAccountService;
import com.aia.case360.web.common.ParamsUtil;
import com.aia.case360.web.pojo.OutputVO;
import com.aia.case360.web.webservice.AbstractController;

@RestController
public class UAMOrganizationStructureController extends AbstractController {

	private static final String LOCALGET_TEAM_SETTING_ERROR = "getTeamSetting error";

	private static final String LOCALPARENTID = "PARENTID";

	private static final String LOCALUAM_COMPONENT_ID = "UAM_COMPONENT_ID";

	private static final String LOCALCOMPANYTYPE = "COMPANYTYPE";

	private static final String LOCALCOMPANYNAME = "COMPANYNAME";

	private static final String LOCALPARAMID = "PARAMID";

	@Autowired
	public UAMOrganizationStructureService uamOrgStrService;

	@Autowired
	public UAMUserAccountService uamUserAccountService;

	@RequestMapping(value = "/case/uam/addComponent", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Object>> addComponent(@RequestBody Map<String, Object> params,
			HttpServletRequest request)  throws RemoteException {
		List<String> validateStrs = new ArrayList<String>();
		validateStrs.add(LOCALPARAMID);
		validateStrs.add(LOCALCOMPANYNAME);
		validateStrs.add(LOCALCOMPANYTYPE);
		Map<String, String> validateMap = new ConcurrentHashMap<String, String>();
		validateMap.put(LOCALPARAMID, params.get(LOCALPARAMID) == null ? "" : params.get(LOCALPARAMID).toString());
		validateMap.put(LOCALCOMPANYNAME, params.get(LOCALCOMPANYNAME) == null ? "" : params.get(LOCALCOMPANYNAME).toString());
		validateMap.put(LOCALCOMPANYTYPE, params.get(LOCALCOMPANYTYPE) == null ? "" : params.get(LOCALCOMPANYTYPE).toString());
		ParamsUtil.validateParamsThrowException(validateMap, validateStrs);
		this.logStart(validateMap, "UAMOrganizationStructureController:addComponent", request);
		uamOrgStrService.addComponent(params);
		this.logEnd(request);
		return new ResponseEntity<Map<String, Object>>(new HashMap<String, Object>(), HttpStatus.OK);
	}

	@RequestMapping(value = "/case/uam/organizationlist", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Object>> organizationlist()  throws RemoteException {
		OutputVO output = new OutputVO();
		try {
			m_Logger.info("organizationlist start");
			output = uamOrgStrService.organizationlist(Constants.ALLORGS);
			return new ResponseEntity<Map<String, Object>>(output.toMap(), HttpStatus.OK);
		} catch (Exception e) {

			m_Logger.error("organizationlist error", e);
			output.addErrorInfo("organizationlist error:" + e.getMessage());
			return new ResponseEntity<Map<String, Object>>(output.toMap(), HttpStatus.OK);
		}
	}

	@RequestMapping(value = "/case/uam/deleteOrg/{componentId}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Object>> deleteComponent(@PathVariable("componentId") String componentId)
			 throws RemoteException {
		m_Logger.info("deleteComponent start");
		OutputVO outputVO = new OutputVO();
		boolean deleteComponent = uamOrgStrService.deleteComponent(componentId);
		if (deleteComponent) {
			return new ResponseEntity<Map<String, Object>>(outputVO.toMap(), HttpStatus.OK);
		}
		outputVO.addErrorInfo("delete failed");
		return new ResponseEntity<Map<String, Object>>(outputVO.toMap(), HttpStatus.OK);
	}

	@RequestMapping(value = "/case/uam/updateComponent", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Object>> updateComponent(@RequestBody Map<String, Object> params)
			 throws RemoteException {
		OutputVO output = new OutputVO();
		try {
			m_Logger.info("updateComponent start");
			List<String> validateStrs = new ArrayList<String>();
			validateStrs.add(LOCALUAM_COMPONENT_ID);
			validateStrs.add(LOCALCOMPANYNAME);
			validateStrs.add(LOCALCOMPANYTYPE);
			validateStrs.add(LOCALPARENTID);
			Map<String, String> validateMap = new ConcurrentHashMap<String, String>();
			validateMap.put(LOCALUAM_COMPONENT_ID,
					params.get(LOCALUAM_COMPONENT_ID) == null ? "" : params.get(LOCALUAM_COMPONENT_ID).toString());
			validateMap.put(LOCALCOMPANYNAME,
					params.get(LOCALCOMPANYNAME) == null ? "" : params.get(LOCALCOMPANYNAME).toString());
			validateMap.put(LOCALCOMPANYTYPE,
					params.get(LOCALCOMPANYTYPE) == null ? "" : params.get(LOCALCOMPANYTYPE).toString());
			validateMap.put(LOCALPARENTID, params.get(LOCALPARENTID) == null ? "" : params.get(LOCALPARENTID).toString());
			ParamsUtil.validateParamsThrowException(validateMap, validateStrs);
			m_Logger.info("updateComponent start");
			String componentId = uamOrgStrService.updateComponent(params);
			params.remove(LOCALUAM_COMPONENT_ID);
			params.put(LOCALUAM_COMPONENT_ID, componentId);
			output.setInputParameters(params);
			return new ResponseEntity<Map<String, Object>>(output.toMap(), HttpStatus.OK);
		} catch (Exception e) {
			 
			m_Logger.info("updateComponent error", e);
			output.addErrorInfo("updateComponent error:" + e);
			return new ResponseEntity<Map<String, Object>>(output.toMap(), HttpStatus.OK);
		}
	}

	/**
	 * get organization users & leaders
	 * 
	 * @param request
	 * @return
	 * @ throws RemoteException
	 */
	@RequestMapping(value = "/case/uam/getOrganizationUsers", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Object>> getOrganizationUsers(@RequestBody Map<String, Object> request)
			 throws RemoteException {
		OutputVO output = new OutputVO();
		try {
			m_Logger.info("getOrganizationUsers start");
			output = uamOrgStrService.getUserList(request);
			return new ResponseEntity<Map<String, Object>>(output.toMap(), HttpStatus.OK);
		} catch (Exception e) {
			 
			m_Logger.info("getOrganizationUsers error", e);
			output.addErrorInfo("getOrganizationUsers error");
			return new ResponseEntity<Map<String, Object>>(output.toMap(), HttpStatus.OK);
		}
	}

	// add by bsnpc65 2018-9-19
	@RequestMapping(value = "/case/uam/getOrganizationAllUsers", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Object>> getOrganizationAllUsers(@RequestBody Map<String, Object> request)
			 throws RemoteException {
		OutputVO output = new OutputVO();
		try {
			m_Logger.info("getOrganizationAllUsers start");
			output = uamOrgStrService.getAllUserList(request);
			return new ResponseEntity<Map<String, Object>>(output.toMap(), HttpStatus.OK);
		} catch (Exception e) {
			 
			m_Logger.info("getOrganizationAllUsers error", e);
			output.addErrorInfo("getOrganizationAllUsers error:" + e.toString());
			return new ResponseEntity<Map<String, Object>>(output.toMap(), HttpStatus.OK);
		}
	}

	@RequestMapping(value = "/case/uam/getTrineeByAct", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public Map<String, Object> getTrineeByAct(@RequestBody Map<String, String> params)  throws RemoteException {
		Map<String, Object> trainneInfo = uamUserAccountService.getTraineeByUserAct(params);
		OutputVO result = new OutputVO();
		result.setDatas(trainneInfo);
		return result.toMap();
	}

	@RequestMapping(value = "/case/uam/findAllLeader", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Object>> findAllLeader()  throws RemoteException {
		List<Map<String, Object>> list = uamOrgStrService.findAllLeader();
		return new ResponseEntity(list, HttpStatus.OK);
	}

	/**
	 * get team setting
	 * 
	 * @return
	 */
	@RequestMapping(value = "/case/uam/getTeamSetting", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Object>> getTeamSetting(@RequestBody Map<String, Object> request) {
		OutputVO output = new OutputVO();
		try {
			m_Logger.info("getTeamSetting start");
			output = uamOrgStrService.getTeamSetting(request);
			m_Logger.info("getTeamSetting end");
			return new ResponseEntity<Map<String, Object>>(output.toMap(), HttpStatus.OK);
		} catch (Exception e) {
			 
			m_Logger.info(LOCALGET_TEAM_SETTING_ERROR, e);
			m_Logger.error(LOCALGET_TEAM_SETTING_ERROR + e);
			output.addErrorInfo(LOCALGET_TEAM_SETTING_ERROR + e);
			return new ResponseEntity<Map<String, Object>>(output.toMap(), HttpStatus.OK);
		}
	}

	/**
	 * update team setting
	 * 
	 * @return
	 */
	@RequestMapping(value = "/case/uam/updateTeamSetting", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Object>> updateTeamSetting(@RequestBody Map<String, Object> request) {
		OutputVO output = new OutputVO();
		try {
			m_Logger.info("updateTeamSetting start");
			output = uamOrgStrService.updateTeamSetting(request);
			m_Logger.info("updateTeamSetting end");
			return new ResponseEntity<Map<String, Object>>(output.toMap(), HttpStatus.OK);
		} catch (Exception e) {
			 
			m_Logger.error("updateTeamSetting error", e);
			output.addErrorInfo("updateTeamSetting error" + e);
			return new ResponseEntity<Map<String, Object>>(output.toMap(), HttpStatus.OK);
		}
	}

	/**
	 * get Team Member
	 * 
	 * @return
	 */
	@RequestMapping(value = "/case/uam/getTeamMember", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Object>> getTeamMember(@RequestBody Map<String, Object> request) {
		OutputVO output = new OutputVO();
		m_Logger.info("getTeamMember start");
		try {
			output = uamOrgStrService.getTeamMember(request);
			m_Logger.info("getTeamMember end");
			return new ResponseEntity<Map<String, Object>>(output.toMap(), HttpStatus.OK);
		} catch (Exception e) {
			LogUtil.logError(m_Logger, "getTeamMember error" + e);
			output.addErrorInfo("getTeamMember error" + e);
			return new ResponseEntity<Map<String, Object>>(output.toMap(), HttpStatus.OK);
		}
	}
}
