package com.aia.case360.mybatis;

import static java.lang.reflect.Proxy.newProxyInstance;
import static org.mybatis.spring.SqlSessionUtils.closeSqlSession;
import static org.mybatis.spring.SqlSessionUtils.getSqlSession;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.executor.BatchResult;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.ResultHandler;
import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.MyBatisExceptionTranslator;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.dao.support.PersistenceExceptionTranslator;
import org.springframework.util.Assert;

import com.aia.case360.web.exception.CustomException;
import com.itextpdf.text.pdf.PdfStructTreeController.returnType;

/**
 * @Author: huiyun ma
 * @Create Date: 03/02/2018
 */

public class DynamicSqlSessionTemplate extends SqlSessionTemplate {

	private final SqlSessionFactory sqlSessionFactory;
	private final ExecutorType executorType;
	private final SqlSession sqlSessionProxy;
	private final PersistenceExceptionTranslator exceptionTranslator;

	private Map<Object, SqlSessionFactory> targetSqlSessionFactorys;
	private SqlSessionFactory defaultTargetSqlSessionFactory;

	public void setTargetSqlSessionFactorys(Map<Object, SqlSessionFactory> targetSqlSessionFactorys) {
		 this.targetSqlSessionFactorys = targetSqlSessionFactorys;
	}

	public Map<Object, SqlSessionFactory> getTargetSqlSessionFactorys() {
		return targetSqlSessionFactorys;
	}

	public void setDefaultTargetSqlSessionFactory(SqlSessionFactory defaultTargetSqlSessionFactory) {
		 this.defaultTargetSqlSessionFactory = defaultTargetSqlSessionFactory;
	}

	public DynamicSqlSessionTemplate(SqlSessionFactory sqlSessionFactory) {
		this(sqlSessionFactory, sqlSessionFactory.getConfiguration().getDefaultExecutorType());
	}

	public DynamicSqlSessionTemplate(SqlSessionFactory sqlSessionFactory, ExecutorType executorType) {
		this(sqlSessionFactory, executorType, new MyBatisExceptionTranslator(
				sqlSessionFactory.getConfiguration().getEnvironment().getDataSource(), true));
	}

	public DynamicSqlSessionTemplate(SqlSessionFactory sqlSessionFactory, ExecutorType executorType,
			PersistenceExceptionTranslator exceptionTranslator) {

		super(sqlSessionFactory, executorType, exceptionTranslator);

		 this.sqlSessionFactory = sqlSessionFactory;
		 this.executorType = executorType;
		 this.exceptionTranslator = exceptionTranslator;

		 sqlSessionProxy = (SqlSession) newProxyInstance(SqlSessionFactory.class.getClassLoader(),
				new Class[] { SqlSession.class }, new SqlSessionInterceptor());

		 defaultTargetSqlSessionFactory = sqlSessionFactory;
	}

	@Override
	public SqlSessionFactory getSqlSessionFactory() {

		SqlSessionFactory targetSqlSessionFactory = targetSqlSessionFactorys
				.get(SqlSessionContentHolder.getContextType());
		if (targetSqlSessionFactory != null) {
			return targetSqlSessionFactory;
		} else if (defaultTargetSqlSessionFactory != null) {
			return defaultTargetSqlSessionFactory;
		} else {
			Assert.notNull(targetSqlSessionFactorys,
					"Property 'targetSqlSessionFactorys' or 'defaultTargetSqlSessionFactory' are required");
			Assert.notNull(defaultTargetSqlSessionFactory,
					"Property 'defaultTargetSqlSessionFactory' or 'targetSqlSessionFactorys' are required");
		}
		return  sqlSessionFactory;
	}

	@Override
	public Configuration getConfiguration() {
		return  getSqlSessionFactory().getConfiguration();
	}

	@Override
	public ExecutorType getExecutorType() {
		return  executorType;
	}

	@Override
	public PersistenceExceptionTranslator getPersistenceExceptionTranslator() {
		return  exceptionTranslator;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public <T> T selectOne(String statement) {
		return  sqlSessionProxy.<T>selectOne(statement);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public <T> T selectOne(String statement, Object parameter) {
		return  sqlSessionProxy.<T>selectOne(statement, parameter);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public <K, V> Map<K, V> selectMap(String statement, String mapKey) {
		return  sqlSessionProxy.<K, V>selectMap(statement, mapKey);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public <K, V> Map<K, V> selectMap(String statement, Object parameter, String mapKey) {
		return  sqlSessionProxy.<K, V>selectMap(statement, parameter, mapKey);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public <K, V> Map<K, V> selectMap(String statement, Object parameter, String mapKey, RowBounds rowBounds) {
		return  sqlSessionProxy.<K, V>selectMap(statement, parameter, mapKey, rowBounds);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public <E> List<E> selectList(String statement) {
		return  sqlSessionProxy.<E>selectList(statement);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public <E> List<E> selectList(String statement, Object parameter) {
		return  sqlSessionProxy.<E>selectList(statement, parameter);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public <E> List<E> selectList(String statement, Object parameter, RowBounds rowBounds) {
		return  sqlSessionProxy.<E>selectList(statement, parameter, rowBounds);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void select(String statement, ResultHandler handler) {
		 sqlSessionProxy.select(statement, handler);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void select(String statement, Object parameter, ResultHandler handler) {
		 sqlSessionProxy.select(statement, parameter, handler);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void select(String statement, Object parameter, RowBounds rowBounds, ResultHandler handler) {
		 sqlSessionProxy.select(statement, parameter, rowBounds, handler);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int insert(String statement) {
		return  sqlSessionProxy.insert(statement);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int insert(String statement, Object parameter) {
		return  sqlSessionProxy.insert(statement, parameter);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int update(String statement) {
		return  sqlSessionProxy.update(statement);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int update(String statement, Object parameter) {
		return  sqlSessionProxy.update(statement, parameter);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int delete(String statement) {
		return  sqlSessionProxy.delete(statement);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int delete(String statement, Object parameter) {
		return  sqlSessionProxy.delete(statement, parameter);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public <T> T getMapper(Class<T> type) {
		return getConfiguration().getMapper(type, this);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void commit() {
		throw new UnsupportedOperationException("Manual commit is not allowed over a Spring managed SqlSession");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void commit(boolean force) {
		throw new UnsupportedOperationException("Manual commit is not allowed over a Spring managed SqlSession");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void rollback() {
		throw new UnsupportedOperationException("Manual rollback is not allowed over a Spring managed SqlSession");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void rollback(boolean force) {
		throw new UnsupportedOperationException("Manual rollback is not allowed over a Spring managed SqlSession");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void close() {
		throw new UnsupportedOperationException("Manual close is not allowed over a Spring managed SqlSession");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void clearCache() {
		 sqlSessionProxy.clearCache();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Connection getConnection() {
		return  sqlSessionProxy.getConnection();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @since ..
	 */
	@Override
	public List<BatchResult> flushStatements() {
		return  sqlSessionProxy.flushStatements();
	}

	/**
	 * Proxy needed to route MyBatis method calls to the proper SqlSession got from
	 * Spring's Transaction Manager It also unwraps exceptions thrown by
	 * {@code Method#invoke(Object, Object...)} to pass a
	 * {@code PersistenceException} to the {@code PersistenceExceptionTranslator}.
	 */
	private class SqlSessionInterceptor implements InvocationHandler {
		public Object invoke(Object proxy, Method method, Object[] args) throws CustomException {
			final SqlSession sqlSession = getSqlSession(DynamicSqlSessionTemplate.this.getSqlSessionFactory(),
					DynamicSqlSessionTemplate.this.executorType, DynamicSqlSessionTemplate.this.exceptionTranslator);
			try {
					return invokeMd(sqlSession, args, method);
			} catch (PersistenceException e) {
				if (DynamicSqlSessionTemplate.this.exceptionTranslator != null) {
					Exception translated = DynamicSqlSessionTemplate.this.exceptionTranslator
							.translateExceptionIfPossible((PersistenceException) e);
					if (translated != null) {
						e = (PersistenceException) translated;
					}
				}
				throw e;
			} finally {
				closeSqlSession(sqlSession, DynamicSqlSessionTemplate.this.getSqlSessionFactory());
			}
		}

		private Object invokeMd(SqlSession sqlSession, Object[] args, Method method) {
			try {
				return method.invoke(sqlSession, args);
			} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
				throw new CustomException(e);
			}
		}
	}

}
