package com.aia.case360.web.pojo;

import java.sql.Timestamp;

public class GetLandingPageClaimHistoryPlas {
	private String policyNo;
	private String claimNo;
	private String insuredName;
	private Timestamp claimSubmissionDate;
	private Timestamp eventDate;
	private String componentName;
	private String incurredAmount;
	private String decision;
	private String claimComment;
	private String lifeAssuredNRIC;
	private String totalPayableAmnt;

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public Timestamp getClaimSubmissionDate() {
		return claimSubmissionDate;
	}

	public void setClaimSubmissionDate(Timestamp claimSubmissionDate) {
		this.claimSubmissionDate = claimSubmissionDate;
	}

	public Timestamp getEventDate() {
		return eventDate;
	}

	public void setEventDate(Timestamp eventDate) {
		this.eventDate = eventDate;
	}

	public String getComponentName() {
		return componentName;
	}

	public void setComponentName(String componentName) {
		this.componentName = componentName;
	}

	public String getIncurredAmount() {
		return incurredAmount;
	}

	public void setIncurredAmount(String incurredAmount) {
		this.incurredAmount = incurredAmount;
	}

	public String getDecision() {
		return decision;
	}

	public void setDecision(String decision) {
		this.decision = decision;
	}

	public String getClaimComment() {
		return claimComment;
	}

	public void setClaimComment(String claimComment) {
		this.claimComment = claimComment;
	}

	public String getLifeAssuredNRIC() {
		return lifeAssuredNRIC;
	}

	public void setLifeAssuredNRIC(String lifeAssuredNRIC) {
		this.lifeAssuredNRIC = lifeAssuredNRIC;
	}

	public String getTotalPayableAmnt() {
		return totalPayableAmnt;
	}

	public void setTotalPayableAmnt(String totalPayableAmnt) {
		this.totalPayableAmnt = totalPayableAmnt;
	}

}
