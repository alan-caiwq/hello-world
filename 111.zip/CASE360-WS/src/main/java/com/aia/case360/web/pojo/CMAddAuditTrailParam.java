package com.aia.case360.web.pojo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class CMAddAuditTrailParam {

  @JsonIgnore
  private String sRowid;
  
  @JsonProperty("CREATED_BY")
  private String createdBy;
  
  @JsonProperty("CM_ACTION")
  private String cmAction;
  
  @JsonProperty("CM_OBJECT_ID")
  private String cmObjectId;
  
  /**
   * 0:request type;1:form id
   */
  private Integer cmType;

  /**
   * @return the sRowid
   */
  public String getsRowid() {
    return sRowid;
  }

  /**
   * @return the createdBy
   */
  public String getCreatedBy() {
    return createdBy;
  }

  /**
   * @return the cmAction
   */
  public String getCmAction() {
    return cmAction;
  }

  /**
   * @return the cmObjectId
   */
  public String getCmObjectId() {
    return cmObjectId;
  }

  /**
   * @return the cmType
   */
  public Integer getCmType() {
    return cmType==null?0:cmType;
  }

  /**
   * @param sRowid the sRowid to set
   */
  public void setsRowid(String sRowid) {
    this.sRowid = sRowid;
  }

  /**
   * @param createdBy the createdBy to set
   */
  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  /**
   * @param cmAction the cmAction to set
   */
  public void setCmAction(String cmAction) {
    this.cmAction = cmAction;
  }

  /**
   * @param cmObjectId the cmObjectId to set
   */
  public void setCmObjectId(String cmObjectId) {
    this.cmObjectId = cmObjectId;
  }

  /**
   * @param cmType the cmType to set
   */
  public void setCmType(Integer cmType) {
    this.cmType = cmType;
  }

  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "CMAddAuditTrailParam [sRowid=" + sRowid + ", createdBy=" + createdBy + ", cmAction="
        + cmAction + ", cmObjectId=" + cmObjectId + ", cmType=" + cmType + "]";
  }
}
