package com.aia.case360.web.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.aia.case360.web.pojo.FRMCaseCheckResult;
import com.aia.case360.web.pojo.FRMCreateCaseParam;
import com.aia.case360.web.pojo.FRMGetFRMCaseDetailInfoParam;
import com.aia.case360.web.pojo.FRMReqTypeInfo;
import com.aia.case360.web.vo.FRMCaseDetailInfoVo;
import com.aia.case360.web.vo.FRMSearchBackfileVo;

public interface FRMScanDao {

  List<FRMSearchBackfileVo> searchBackfile(@Param("policyNums")String policyNums, @Param("reqType")String reqType, @Param("companyNo")String companyNo) throws SQLException;

  FRMCaseCheckResult checkCase(@Param("policyNum")String polNum, @Param("reqType")String reqType, @Param("companyNo")String companyNo, @Param("reqTypeScope")String reqTypeScope, @Param("currentUser")String currentUser, @Param("maxNum")Integer userMaxCaseNum) throws SQLException;

  Boolean createInvestRecord(@Param("policyNum")String polNum, @Param("companyNo")String companyNo, @Param("currentUser")String currentUser) throws SQLException;

  FRMReqTypeInfo getReqTypeInfo(@Param("reqType")String reqType) throws SQLException;

  List<FRMCaseDetailInfoVo> getFRMCaseDetailInfo(FRMGetFRMCaseDetailInfoParam param) throws SQLException;
}
