package com.aia.case360.web.pojo;

import java.io.Serializable;

public class GetRequestStatusParameter implements Serializable {
	// requestNo
	private String requestNo;
	private String callingSystem;

	public String getRequestNo() {
		return requestNo;
	}

	public void setRequestNo(String requestNo) {
		this.requestNo = requestNo;
	}

	public String getCallingSystem() {
		return callingSystem;
	}

	public void setCallingSystem(String callingSystem) {
		this.callingSystem = callingSystem;
	}

}
