package com.aia.case360.web.auditTrail;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.security.UserHelper;
import com.aia.case360.web.dao.NonAIACustomerDao;
import com.aia.case360.web.pojo.NonAIACustomerAuditTrail;

@Component
public class NonAIACustomerAuditTrailEngine extends AuditTrailEngine {
	@Autowired
	private NonAIACustomerDao nonAIACustomerDao;

	@Autowired
	private UserHelper userHelper;

	@Override
	void saveAudit(Boolean isNew, String action, AuditTrail n)
			throws RemoteException {
		NonAIACustomerAuditTrail auditTrail = new NonAIACustomerAuditTrail();
		if (action != null && !"null".equals(action)) {
			try {
				String userId = userHelper.getCurrentUser();
				auditTrail.setCategory(isNew ? "Add" : "Update");
				auditTrail.setActDesc(action);
				auditTrail.setId(new BigDecimal(tableKeyString));
				auditTrail.setCreatedBy(userId);
				auditTrail.setCreatedTimestamp(new Date());
				nonAIACustomerDao.addNonAIACustomerAuditTrail(auditTrail);
			} catch (Exception e) {
				LogUtil.logInfo(m_Logger, tableKeyString
						+ "saveAudit exception:" + e.getMessage());
			}
		}
	}

}