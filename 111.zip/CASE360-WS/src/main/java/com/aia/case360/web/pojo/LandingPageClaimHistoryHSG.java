package com.aia.case360.web.pojo;

public class LandingPageClaimHistoryHSG {
	private String claimNo;
	private String policyNo;
	private String claimType;
	private String claimSubmissionDate;
	private String DOA;
	private String DOD;
	private String HRN;
	private String all3dx;
	private String injuryCause;
	private String doctorName;
	private String surgery;
	private String incurredAmount;
	private String outlierRemarks;
	private String payableAmount;
	private String MMCRAmount;
	private String decision;
	private String decisionCode;
	private String assessorIDORApprovalID;
	private String claimComment;

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getClaimType() {
		return claimType;
	}

	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}

	public String getClaimSubmissionDate() {
		return claimSubmissionDate;
	}

	public void setClaimSubmissionDate(String claimSubmissionDate) {
		this.claimSubmissionDate = claimSubmissionDate;
	}

	public String getDOA() {
		return DOA;
	}

	public void setDOA(String dOA) {
		DOA = dOA;
	}

	public String getDOD() {
		return DOD;
	}

	public void setDOD(String dOD) {
		DOD = dOD;
	}

	public String getHRN() {
		return HRN;
	}

	public void setHRN(String hRN) {
		HRN = hRN;
	}

	public String getAll3dx() {
		return all3dx;
	}

	public void setAll3dx(String all3dx) {
		this.all3dx = all3dx;
	}

	public String getInjuryCause() {
		return injuryCause;
	}

	public void setInjuryCause(String injuryCause) {
		this.injuryCause = injuryCause;
	}

	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public String getSurgery() {
		return surgery;
	}

	public void setSurgery(String surgery) {
		this.surgery = surgery;
	}

	public String getIncurredAmount() {
		return incurredAmount;
	}

	public void setIncurredAmount(String incurredAmount) {
		this.incurredAmount = incurredAmount;
	}

	public String getOutlierRemarks() {
		return outlierRemarks;
	}

	public void setOutlierRemarks(String outlierRemarks) {
		this.outlierRemarks = outlierRemarks;
	}

	public String getPayableAmount() {
		return payableAmount;
	}

	public void setPayableAmount(String payableAmount) {
		this.payableAmount = payableAmount;
	}

	public String getMMCRAmount() {
		return MMCRAmount;
	}

	public void setMMCRAmount(String mMCRAmount) {
		MMCRAmount = mMCRAmount;
	}

	public String getDecision() {
		return decision;
	}

	public void setDecision(String decision) {
		this.decision = decision;
	}

	public String getDecisionCode() {
		return decisionCode;
	}

	public void setDecisionCode(String decisionCode) {
		this.decisionCode = decisionCode;
	}

	public String getAssessorIDORApprovalID() {
		return assessorIDORApprovalID;
	}

	public void setAssessorIDORApprovalID(String assessorIDORApprovalID) {
		this.assessorIDORApprovalID = assessorIDORApprovalID;
	}

	public String getClaimComment() {
		return claimComment;
	}

	public void setClaimComment(String claimComment) {
		this.claimComment = claimComment;
	}

}
