package com.aia.case360.web.pojo;

import java.io.Serializable;

public class PolicyInfoParameter implements Serializable {
	private String policyNo;
	private String companyCode;
	private String source;
	private String linkCaseId;
	private String callIndicator;

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getLinkCaseId() {
		return linkCaseId;
	}

	public void setLinkCaseId(String linkCaseId) {
		this.linkCaseId = linkCaseId;
	}

	public String getCallIndicator() {
		return callIndicator;
	}

	public void setCallIndicator(String callIndicator) {
		this.callIndicator = callIndicator;
	}

	@Override
	public String toString() {
		return "GetPolicyInfoParameter [policyNo=" + policyNo + ", companyCode=" + companyCode + ", source=" + source
				+ "]";
	}

}
