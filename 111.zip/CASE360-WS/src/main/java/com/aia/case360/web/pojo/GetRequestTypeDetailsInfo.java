package com.aia.case360.web.pojo;

public class GetRequestTypeDetailsInfo {
	// processName
	private String processName;
	// requestTypeName
	private String requestTypeName;
	// requestTypeFullName
	private String requestTypeFullName;
	// requestCategory
	private String requestCategory;
	// requestType
	private String requestType;
	// subType
	private String subType;
	// subTypeDesc
	private String subTypeDesc;

	public String getProcessName() {
		return processName;
	}

	public void setProcessName(String processName) {
		this.processName = processName;
	}

	public String getRequestTypeName() {
		return requestTypeName;
	}

	public void setRequestTypeName(String requestTypeName) {
		this.requestTypeName = requestTypeName;
	}

	public String getRequestTypeFullName() {
		return requestTypeFullName;
	}

	public void setRequestTypeFullName(String requestTypeFullName) {
		this.requestTypeFullName = requestTypeFullName;
	}

	public String getRequestCategory() {
		return requestCategory;
	}

	public void setRequestCategory(String requestCategory) {
		this.requestCategory = requestCategory;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public String getSubTypeDesc() {
		return subTypeDesc;
	}

	public void setSubTypeDesc(String subTypeDesc) {
		this.subTypeDesc = subTypeDesc;
	}

}
