package com.aia.case360.uam.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.CallableStatementCallback;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.uam.dao.RoleDao;
import com.aia.case360.uam.domain.RoleInfo;
import com.aia.case360.uam.domain.RoleMenuPara;
import com.aia.case360.uam.domain.RoleMenuVo;
import com.aia.case360.uam.domain.RoleQueryPara;
import com.aia.case360.uam.domain.RoleReqPara;
import com.eistream.sonora.util.StringUtil;

@Component
public class RoleDaoImpl implements RoleDao {
	private Logger m_Logger = LoggerFactory.getLogger(getClass());
	@Override
	public List<Map<String, Object>> getRoleBaseInfoByRoleId(final String roleId) {

		StringBuilder getRoleSql = new StringBuilder(" SELECT * FROM [dbo].[FD_UAM_ROLE]");
		getRoleSql.append(" WHERE UAM_ROLE_ID = ?");
		List<Map<String, Object>> roleBaseInfos = (List<Map<String, Object>>) jdbcTemplate.query(getRoleSql.toString(),
				new PreparedStatementSetter() {

					@Override
					public void setValues(PreparedStatement ps) throws SQLException {
						ps.setString(1, roleId);
					}

				}, new RowMapper<Map<String, Object>>() {

					@Override
					public Map<String, Object> mapRow(ResultSet rs, int index) throws SQLException {
						Map<String, Object> map = new HashMap<String, Object>();
						ResultSetMetaData meta = rs.getMetaData();
						int count = meta.getColumnCount();
						for (int i = 1; i <= count; i++) {
							map.put(meta.getColumnName(i), rs.getObject(i) == null ? "" : rs.getObject(i));
						}
						return map;
					}
				});

		return roleBaseInfos;
	}

	@Override
	public List<Map<String, Object>> getRoleActivity() {
		final String sql = "{call get_request_activity_by_roleid(?)} ";
		List<Map<String, Object>> rows = (List<Map<String, Object>>) jdbcTemplate.query(sql.toString(),
				new RowMapper<Map<String, Object>>() {

					@Override
					public Map<String, Object> mapRow(ResultSet rs, int index) throws SQLException {
						Map<String, Object> map = new HashMap<String, Object>();
						ResultSetMetaData meta = rs.getMetaData();
						int count = meta.getColumnCount();
						for (int i = 1; i <= count; i++) {
							map.put(meta.getColumnName(i), rs.getObject(i) == null ? "" : rs.getObject(i));
						}
						return map;
					}
				});

		return rows;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<Map<String, Object>> getRoleActivityMapping(final String roleId) {

		final String sql = "{call get_request_activity_by_roleid(?)} ";

		List<Map<String, Object>> roleActivityMapping = (List<Map<String, Object>>) jdbcTemplate
				.execute(new CallableStatementCreator() {
					public CallableStatement createCallableStatement(Connection con) throws SQLException {
						String storedProc = sql;

						CallableStatement cs = con.prepareCall(storedProc); // NOSONAR
						cs.setString(1, roleId);
						return cs;
					}
				}, new CallableStatementCallback() {
					public Object doInCallableStatement(CallableStatement cs) throws SQLException, DataAccessException {
						List resultsMap = new ArrayList();
						ResultSet rs = null;
						try {
							rs = cs.executeQuery(); // NOSONAR

							while (rs.next()) {
								Map rowMap = new HashMap();
								rowMap.put("REQ_NAME", rs.getString("REQ_NAME"));
								rowMap.put("REQ_ID", rs.getString("REQ_ID"));
								rowMap.put("ACT_NAME", rs.getString("ACT_NAME"));
								rowMap.put("ACT_ID", rs.getString("ACT_ID"));
								rowMap.put("USE_FLAG", rs.getString("USE_FLAG"));
								resultsMap.add(rowMap);
							}
						} catch (Exception e) {

							LogUtil.logException(m_Logger, roleId, e); 

						}
						return resultsMap;
					}
				});

		return roleActivityMapping;
	}

	@Override
	public boolean deleteRoleReq(String roleId) {

		StringBuilder sql = new StringBuilder(" DELETE FROM [FD_UAM_ROLEREQ_REF] ");
		sql.append(" WHERE UAM_ROLE_ID = ?");

		try {

			jdbcTemplate.update(sql.toString(), new Object[] { roleId }, new int[] { java.sql.Types.VARCHAR });

		} catch (Exception e) {
			LogUtil.logException(m_Logger, roleId, e); 
		}

		return true;
	}

	@Override
	public boolean insertRoleReq(final List<RoleReqPara> roleReqParas) {

		StringBuilder sql2 = new StringBuilder(" INSERT INTO [FD_UAM_ROLEREQ_REF](UAM_ROLE_ID,REQ_ID,ACTIVITY_NAME) ");
		sql2.append(" VALUES(?,?,?) ");
		jdbcTemplate.batchUpdate(sql2.toString(), new BatchPreparedStatementSetter() {

			@Override
			public int getBatchSize() {

				return roleReqParas.size();
			}

			@Override
			public void setValues(PreparedStatement pa, int i) throws SQLException {

				int index = 1;
				pa.setString(index++, roleReqParas.get(i).getUamRoleId());
				pa.setString(index++, roleReqParas.get(i).getReqId());
				pa.setString(index, roleReqParas.get(i).getActivityName());
			}

		});

		return true;
	}

	@Override
	public boolean updateRoleInfo(RoleInfo roleInof) {

		if (roleInof == null) {
			return false;
		}

		StringBuilder sql = new StringBuilder(" UPDATE [FD_UAM_ROLE] SET");
		sql.append("  UAM_IS_ENABLE = ? ");
		sql.append("  ,UAM_REMARK = ?    ");
		sql.append("  ,UAM_ROLE_NAME = ? ");
		sql.append("  ,UAM_ROLE_TYPE = ? ");
		sql.append("  ,UAM_DEP_NAME = ? ");
		sql.append(" WHERE UAM_ROLE_ID = ? ");

		Object args[] = new Object[] { roleInof.getEnable(), roleInof.getRemark(), roleInof.getRoleName(),
				roleInof.getRoleType(), roleInof.getDepartment(), roleInof.getRoleId() };
		int temp = jdbcTemplate.update(sql.toString(), args);

		if (temp > 0) {
			return true;
		} else {
			return false;
		}

	}

	@Override
	public List<Map<String, Object>> getroleMenuByRoleId(final String roleId) {

		StringBuilder sql = new StringBuilder(
				" SELECT RO.UAM_DEP_NAME,RO.UAM_IS_ENABLE,RO.UAM_ROLE_NAME,RO.UAM_ROLE_TYPE,RO.UAM_REMARK,MU.MENU_ID FROM [dbo].[FD_UAM_ROLE] RO ");
		sql.append(" LEFT JOIN [dbo].[FD_UAM_ROLEMENU_REF] MU ON RO.UAM_ROLE_ID = MU.UAM_ROLE_ID ");
		sql.append(" WHERE MU.UAM_ROLE_ID = ? ");

		List<Map<String, Object>> roleMenuMapping = (List<Map<String, Object>>) jdbcTemplate.query(sql.toString(),
				new PreparedStatementSetter() {

					@Override
					public void setValues(PreparedStatement ps) throws SQLException {

						int index = 1;
						ps.setString(index, roleId);

					}

				}, new RowMapper<Map<String, Object>>() {

					@Override
					public Map<String, Object> mapRow(ResultSet rs, int index) throws SQLException {
						Map<String, Object> map = new HashMap<String, Object>();
						ResultSetMetaData meta = rs.getMetaData();
						int count = meta.getColumnCount();
						for (int i = 1; i <= count; i++) {
							map.put(meta.getColumnName(i), rs.getObject(i) == null ? "" : rs.getObject(i));
						}
						return map;
					}
				});

		return roleMenuMapping;
	}

	@Override
	public List<Map<String, Object>> getRoleByUserIdAndRoleType(final String userId,

			final String roleType) {
		StringBuilder sql = new StringBuilder("SELECT RO.UAM_DEP_NAME");
		sql.append(",RO.UAM_IS_ENABLE");
		sql.append(",RO.UAM_REMARK ");
		sql.append(",RO.UAM_ROLE_ID");
		sql.append(",RO.UAM_ROLE_NAME");
		sql.append(",RO.UAM_ROLE_TYPE");
		sql.append(",U.UAM_USER_ID");
		sql.append("FROM FD_UAM_USERS U");
		sql.append("JOIN FD_UAM_USERROLE_REF REF ON upper(U.UAM_USER_ID) = upper(REF.UAM_USER_ID)");
		sql.append("JOIN FD_UAM_ROLE RO ON REF.UAM_ROLE_ID =  RO.UAM_ROLE_ID");
		sql.append("WHERE U.UAM_USER_ID = ? AND RO.UAM_ROLE_TYPE = ?");

		List<Map<String, Object>> role = (List<Map<String, Object>>) jdbcTemplate.query(sql.toString(),
				new PreparedStatementSetter() {

					@Override
					public void setValues(PreparedStatement ps) throws SQLException {

						int index = 1;
						ps.setString(index++, userId);
						ps.setString(index, roleType);

					}

				}, new RowMapper<Map<String, Object>>() {

					@Override
					public Map<String, Object> mapRow(ResultSet rs, int index) throws SQLException {
						Map<String, Object> map = new HashMap<String, Object>();
						ResultSetMetaData meta = rs.getMetaData();
						int count = meta.getColumnCount();
						for (int i = 1; i <= count; i++) {
							map.put(meta.getColumnName(i), rs.getObject(i) == null ? "" : rs.getObject(i));
						}
						return map;
					}
				});
		return role;
	}

	@Override
	public int insertRoleInfo(RoleInfo roleinfo) {

		StringBuilder keysql = new StringBuilder("SELECT isnull(MAX(UAM_ROLE_ID), 0)+1 FROM [FD_UAM_ROLE]");
		int key = jdbcTemplate.queryForObject(keysql.toString(), Integer.class);

		StringBuilder sql = new StringBuilder(
				"INSERT INTO [FD_UAM_ROLE](UAM_ROLE_ID,UAM_DEP_NAME,UAM_IS_ENABLE,UAM_REMARK,UAM_ROLE_NAME,UAM_ROLE_TYPE)");
		sql.append(" VALUES ( ?,?,?,?,?,?) ");

		Object args[] = new Object[] { key, roleinfo.getDepartment(), roleinfo.getEnable(), roleinfo.getRemark(),
				roleinfo.getRoleName(), roleinfo.getRoleType() };

		int temp = jdbcTemplate.update(sql.toString(), args);

		if (temp > 0) {
			return key;
		} else {
			return 0;
		}
	}

	@Override
	public boolean insertRoleMenu(RoleMenuVo roleMenuVo, int roleId) {

		final List<RoleMenuPara> roleMenuParas = new ArrayList<RoleMenuPara>();
		Set<String> menuIds = roleMenuVo.getMenuIds();
		for (String menuId : menuIds) {
			RoleMenuPara roleMenuPara = new RoleMenuPara();
			roleMenuPara.setRoleId(String.valueOf(roleId));
			roleMenuPara.setMenuId(menuId);
			roleMenuParas.add(roleMenuPara);
		}

		StringBuilder sql2 = new StringBuilder(" INSERT INTO FD_UAM_ROLEMENU_REF(UAM_ROLE_ID,MENU_ID) ");
		sql2.append(" VALUES(?,?) ");

		jdbcTemplate.batchUpdate(sql2.toString(), new BatchPreparedStatementSetter() {

			@Override
			public int getBatchSize() {

				return roleMenuParas.size();
			}

			@Override
			public void setValues(PreparedStatement pa, int i) throws SQLException {

				int index = 1;
				pa.setString(index++, roleMenuParas.get(i).getRoleId());
				pa.setString(index, roleMenuParas.get(i).getMenuId());
			}

		});

		return true;
	}

	@Override
	public List<Map<String, Object>> getRolebyPara(final RoleQueryPara roleQueryPara) {

		StringBuilder getRoleSql = new StringBuilder(
				" SELECT case when isnull(d.DEPARTMENT_NM, '') = '' then r.UAM_DEP_NAME else d.DEPARTMENT_NM end as UAM_DEP_NAME,r.UAM_IS_ENABLE,r.UAM_REMARK,r.UAM_ROLE_ID,r.UAM_ROLE_NAME,r.UAM_ROLE_TYPE FROM [dbo].[FD_UAM_ROLE] r left join fd_department d on r.UAM_DEP_NAME=d.DEPARTMENT WHERE 1=1");

		if (!"".equals(valueIsNull(roleQueryPara.getDepartment()))) {
			getRoleSql.append(" AND r.UAM_DEP_NAME = ?");
		}

		if (!"".equals(valueIsNull(roleQueryPara.getRoleName()))) {
			getRoleSql.append(" AND upper(r.UAM_ROLE_NAME) like ?");// change from
																	// UAM_ROLE_NAME
																	// = ? to
																	// upper(UAM_ROLE_NAME)
																	// like ? by
																	// charley
																	// 20180626
		}
		if (roleQueryPara.isEnabled()) {
			getRoleSql.append(" AND isnull(r.UAM_IS_ENABLE, 0) = 1 ");
		}
		if (!"".equals(valueIsNull(roleQueryPara.getRoleType()))) {

			getRoleSql.append(" AND r.UAM_ROLE_TYPE = ?");
		}
		// add order by by charley 20180830 DEFECT 7397
		getRoleSql.append(" order by r.UAM_ROLE_TYPE,UAM_DEP_NAME,r.UAM_ROLE_NAME");
		List<Map<String, Object>> roleBaseInfos = (List<Map<String, Object>>) jdbcTemplate.query(getRoleSql.toString(),
				new PreparedStatementSetter() {

					@Override
					public void setValues(PreparedStatement ps) throws SQLException {

						int index = 1;
						if (!StringUtil.isBlank(roleQueryPara.getDepartment())) {
							ps.setString(index++, roleQueryPara.getDepartment());
						}
						if (!StringUtil.isBlank(roleQueryPara.getRoleName())) {
							ps.setString(index++, "%" + roleQueryPara.getRoleName().toUpperCase() + "%");// add % and
																											// toUpperCase
																											// to
																											// support
																											// query by
																											// charley
																											// 20180626
						}
						if (!StringUtil.isBlank(roleQueryPara.getRoleType())) {
							ps.setString(index, roleQueryPara.getRoleType());
						}
					}

				}, new RowMapper<Map<String, Object>>() {

					@Override
					public Map<String, Object> mapRow(ResultSet rs, int index) throws SQLException {
						Map<String, Object> map = new HashMap<String, Object>();
						ResultSetMetaData meta = rs.getMetaData();
						int count = meta.getColumnCount();
						for (int i = 1; i <= count; i++) {
							map.put(meta.getColumnName(i), rs.getObject(i) == null ? "" : rs.getObject(i));
						}
						return map;
					}
				});

		return roleBaseInfos;
	}

	public List<Map<String, Object>> getMeun() {

		StringBuilder sql = new StringBuilder("SELECT * FROM FD_UAM_MENU");
		List<Map<String, Object>> allMenu = (List<Map<String, Object>>) jdbcTemplate.query(sql.toString(),
				new RowMapper<Map<String, Object>>() {

					@Override
					public Map<String, Object> mapRow(ResultSet rs, int index) throws SQLException {
						Map<String, Object> map = new HashMap<String, Object>();
						ResultSetMetaData meta = rs.getMetaData();
						int count = meta.getColumnCount();
						for (int i = 1; i <= count; i++) {
							map.put(meta.getColumnName(i), rs.getObject(i) == null ? "" : rs.getObject(i));
						}
						return map;
					}
				});

		return allMenu;
	}

	@Override
	public boolean deleteRoleMenu(String roleId, Integer roleType) {

		StringBuilder sql = new StringBuilder(" DELETE FROM FD_UAM_ROLEMENU_REF ");
		sql.append(" WHERE UAM_ROLE_ID = ? and MENU_ID in(select MENU_ID from [FD_UAM_MENU] where MENU_TYPE = "
				+ roleType + " )");

		jdbcTemplate.update(sql.toString(), new Object[] { roleId }, new int[] { java.sql.Types.VARCHAR });

		return false;
	}

	@Override
	public boolean insertRoleMenuReq(final List<RoleMenuPara> roleMenuParas) {

		StringBuilder sql2 = new StringBuilder(" INSERT INTO FD_UAM_ROLEMENU_REF(UAM_ROLE_ID,MENU_ID,RES_TYPE) ");
		sql2.append(" VALUES(?,?,'MENU') ");

		jdbcTemplate.batchUpdate(sql2.toString(), new BatchPreparedStatementSetter() {

			@Override
			public int getBatchSize() {

				return roleMenuParas.size();
			}

			@Override
			public void setValues(PreparedStatement pa, int i) throws SQLException {

				int index = 1;
				pa.setString(index++, roleMenuParas.get(i).getRoleId());
				pa.setString(index, roleMenuParas.get(i).getMenuId());
			}

		});

		return true;
	}

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	private String valueIsNull(String value){
      
      if(value==null){
        return "";
      }else if("".equals(value.trim())){
        return "";
      }else if(value.trim().length()==0){
        return "";
      }else{
        return value;
      }
  }

}
