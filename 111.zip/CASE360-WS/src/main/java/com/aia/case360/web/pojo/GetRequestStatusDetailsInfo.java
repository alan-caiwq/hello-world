package com.aia.case360.web.pojo;

public class GetRequestStatusDetailsInfo {
	// requestNo
	private String requestNo;
	// requestStatus
	private String requestStatus;

	public String getRequestNo() {
		return requestNo;
	}

	public void setRequestNo(String requestNo) {
		this.requestNo = requestNo;
	}

	public String getRequestStatus() {
		return requestStatus;
	}

	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}

}
