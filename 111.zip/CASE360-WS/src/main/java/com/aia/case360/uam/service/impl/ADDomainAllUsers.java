package com.aia.case360.uam.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;
import javax.naming.directory.SearchControls;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ldap.core.LdapTemplate;

import com.aia.case360.uam.domain.UamUserAttributesMapper;

public class ADDomainAllUsers {
	@Autowired
	private LdapTemplate ldapTemplate;

	/**
	 * 
	 * CN=CURPTE01,OU=SPID,OU=Users,OU=CHO,OU=China,OU=AIA,DC=AIA,DC=BIZ get user's
	 * info & put the info to an Map
	 * 
	 * @throws NamingException
	 */
	private List getUserInfoFromAD() throws NamingException {
		// Create the search controls
		SearchControls searchCtls = new SearchControls();
		// Specify the search scope
		searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE);
		// specify the LDAP search filter

		String searchFilter = "company=*SGP*"; // Singapore
		// Specify the Base for the search
		String searchBase = "DC=AIA,DC=BIZ";

		searchCtls.setReturningAttributes(null); // set to return all properties

		try {

			return ldapTemplate.search(searchBase, searchFilter, new UamUserAttributesMapper());

		} catch (Exception e) {
			throw new NamingException(e.getMessage());
		}
	}

	public Map<String, Map<String, String>> getUsersMap() throws NamingException {
		List<Map<String, String>> resultList = getUserInfoFromAD();

		Map<String, Map<String, String>> usersMap = new HashMap<>();
		List<String> lanids = new ArrayList<>();
		for (Map<String, String> user : resultList) {

			String lanid = user.get("sAMAccountName");
			lanids.add(lanid);
			Map<String, String> userMap = new HashMap<>();
			userMap.put("LOGINID", lanid);
			userMap.put("DISPLAYNAME", user.get("displayName"));
			userMap.put("USERCOMPANY", user.get("company"));
			userMap.put("UAM_USER_OFFICE_NUMBER", user.get("telephoneNumber"));

			userMap.put("DELIVERYSTRING", user.get("mail"));
			String leader = user.get("manager");
			if (!("").equals(leader) && leader != null) {
				String leaderlist = leader.substring(0, leader.indexOf('.'));
				userMap.put("UAM_USER_LEADER", leaderlist);
			}
			userMap.put("UAM_USER_DEPARTMENT", user.get("department"));
			usersMap.put(lanid, userMap);
		}

		return usersMap;
	}

}
