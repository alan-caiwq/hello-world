package com.aia.case360.web.pojo;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "LETTERS")
public class COSLetters {
	private List<COS> cosList;

	public List<COS> getCosList() {
		return cosList;
	}

	@XmlElements(value = { @XmlElement(name = "COS") })
	public void setCosList(List<COS> cosList) {
		this.cosList = cosList;
	}

	@Override
	public String toString() {
		return "COSLetters [cosList=" + cosList + ", getCosList()=" + getCosList() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

}
