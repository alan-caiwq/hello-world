package com.aia.case360.uam.service.impl;

import java.rmi.RemoteException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aia.case360.uam.domain.UAMAuditTrail;
import com.aia.case360.uam.domain.UAMGetAuditTrailParam;
import com.aia.case360.uam.domain.UAMGetOrganizationAuditTrailParam;
import com.aia.case360.uam.domain.UAMOrganizationAuditTrail;
import com.aia.case360.uam.service.UAMAuditTrailService;
import com.aia.case360.web.dao.UAMAuditTrailDao;
import com.aia.case360.web.service.impl.AbstractServiceImpl;

@Service
public class UAMAuditTrailServiceImpl extends AbstractServiceImpl implements UAMAuditTrailService {

	@Autowired
	private UAMAuditTrailDao auditTrailDao;

	public boolean addUAMAuditTrail(UAMAuditTrail param, String uuidStr)  throws RemoteException {
		return auditTrailDao.addUAMAuditTrail(param);
	}

	@Override
	public List<UAMAuditTrail> getUAMAuditTrail(UAMGetAuditTrailParam param, String uuidStr)  throws RemoteException {
		return auditTrailDao.getUAMAuditTrail(param);
	}

	@Override
	public List<UAMOrganizationAuditTrail> getUAMOrganizationAuditTrail(UAMGetOrganizationAuditTrailParam param,
			String uuidStr)  throws RemoteException {
		return auditTrailDao.getUAMOrganizationAuditTrail(param);
	}

}
