package com.aia.case360.web.advice;

import java.rmi.RemoteException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.aia.case360.platform.common.Constants;
import com.aia.case360.platform.common.JsonUtil;
import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.common.PropertyUtil;
import com.aia.case360.web.dao.DocumentsRelatedDataDao;
import com.aia.case360.web.dao.EDocAdminDao;
import com.aia.case360.web.pojo.DocLinkParam;
import com.aia.case360.web.pojo.FdDocAuditTrail;
import com.aia.case360.web.pojo.FdDocLink;
import com.aia.case360.web.pojo.OutputVO;
import com.aia.case360.web.service.DocMgmtService;
import com.aia.case360.web.service.SerialNoService;
import com.aia.case360.web.service.impl.AbstractServiceImpl;
import com.aia.case360.web.vo.ExportDocInfoParam;
import com.aia.case360.web.vo.ExportDocsDiskParam;
import com.aia.case360.web.vo.RenameDocFormLinkParam;
import com.aia.case360.web.vo.VoidDocLinkParam;

import net.sf.json.JSONObject;

@Component
@Aspect
public class AuditTrailDocAspect extends AbstractServiceImpl {

  @Autowired
  private SerialNoService serialNoService;
  
  @Autowired
  private EDocAdminDao eDocAdminDao;
  
  @Autowired
  private DocMgmtService docMgmtService;
  
   private static ThreadLocal<String> lastMethod = new ThreadLocal<String>(); 
   String STATUS_VOID = "V";
   String STATUS_NORMAL = "N";
   
   private static final String ADTDOCASPGETCUSERSTR = "AuditTrailDocAspect getCurrentUser ";
   private static final String FORMIDSTR = "FORM_ID";
   private static final String OBJECTIDSTR = "OBJECT_ID";
   private static final String COMPANYCODESTR = "COMPANY_CODE";
   private static final String REQUESTNOSTR = "REQUEST_NO";
   private static final String ISVOIDSTR = "IS_VOID";
   private static final String POLICYNUMSTR = "POLICY_NUM";
   private static final String SERVICEGETSERNOSTR = "serialNoServiceImpl getSerialNo ";
   private static final String LOGICALLINKIDSTR = "LOGICAL_LINK_ID";
   private static final String OLDCLAIMNOSTR = "OLD_CLAIM_NO";
   private static final String CLAIMNOSTR = "CLAIM_NO";
   private static final String COMPANYNOSTR = "COMPANY_NO";
   private static final String OLDFORMIDSTR = "OLD_FORM_ID";
   private static final String OLDPROCESSTYPESTR = "OLD_PROCESS_TYPE";
   private static final String PROCESSTYPESTR = "PROCESS_TYPE";
   private static final String OLDRECEIVEDDTSTR = "OLD_RECEIVED_DT";
   private static final String RECEIVEDDTSTR = "RECEIVED_DT";
   private static final String OLDREQUESTNUMSTR = "OLD_REQUEST_NUM";
   private static final String REQUESTNUMSTR = "REQUEST_NUM";
   private static final String OLD_POL_NUMSTR = "OLD_POL_NUM";
   private static final String POLNUMSTR = "POL_NUM";
   private static final String AUDITINSERTDOCAUDITSTR = "AuditTrailDocAspect insertFdDocAuditTrails ";
   
   
   private static final String BTN_REINDEX = PropertyUtil.getCommonProperty("BTN_REINDEX");
   private static final String BTN_COPYDOC = PropertyUtil.getCommonProperty("BTN_COPYDOC");
   private static final String BTN_RENAMEFORM = PropertyUtil.getCommonProperty("BTN_RENAMEFORM");
   private static final String BTN_VOIDDOC = PropertyUtil.getCommonProperty("BTN_VOIDDOC");
   private static final String BTN_UNVOIDDOC = PropertyUtil.getCommonProperty("BTN_UNVOIDDOC");
   private static final String BTN_ADDDOCNOTE = PropertyUtil.getCommonProperty("BTN_ADDDOCNOTE");
   private static final String BTN_IMPORTDOC = PropertyUtil.getCommonProperty("BTN_IMPORTDOC");
   private static final String BTN_EXPORTTODISK = PropertyUtil.getCommonProperty("BTN_EXPORTTODISK");
   private static final String BTN_PRINTDOC = PropertyUtil.getCommonProperty("BTN_PRINTDOC");
   private static final String BTN_VOIDPAGE = PropertyUtil.getCommonProperty("BTN_VOIDPAGE");
   private static final String BTN_UNVOIDPAGE = PropertyUtil.getCommonProperty("BTN_UNVOIDPAGE");

   @Autowired
   private DocumentsRelatedDataDao documentsRelatedDataDao;

   @Pointcut("execution( * com.aia.case360.web.service.DocMgmtService.*(..))")
	public void pointCutDocMgmtService() {
	    // NOSONAR
   }

   @Pointcut("execution( * com.aia.case360.web.service.DocMgmtService.voidDocLinks(..))")
	public void pointCutVoidDocLinks() {
	    // NOSONAR
   }

   @Pointcut("execution( * com.aia.case360.web.service.DocMgmtService.unvoidDocLinks(..))")
	public void pointCutUnvoidDocLinks() {
	    // NOSONAR
   }

   @Pointcut("execution( * com.aia.case360.web.service.DocMgmtService.renameDocFormLink(..))")
	public void pointCutRenameDocFormLink() {
	    // NOSONAR
   }
   @Pointcut("execution( * com.aia.case360.web.service.DocMgmtService.printDoc(..))")
	public void pointCutPrintDoc() {
	    // NOSONAR
   }

   @Pointcut("execution( * com.aia.case360.web.service.DocumentService.*(..))")
	public void pointCutDocumentService() {
	    // NOSONAR
   }

   @Pointcut("execution( * com.aia.case360.web.service.DocumentsRelatedDataService.*(..))")
	public void pointCutDocumentsRelatedDataService() {
	    // NOSONAR
   }

   @Pointcut("execution( * com.aia.case360.web.dao.DocumentsRelatedDataDao.insertFdDocLinks(..))")
	public void pointCutInsertFdDocLinks() {
	    // NOSONAR
   }

   @Pointcut("execution( * com.aia.case360.web.service.DocumentService.importCasesDoc(..))")
	public void pointCutImportCasesDoc() {
	    // NOSONAR
   }

   @Pointcut("execution( * com.aia.case360.web.service.DocumentService.importPolsDoc(..))")
	public void pointCutImportPolsDoc() {
	    // NOSONAR
   }
   @Pointcut("execution( * com.aia.case360.web.service.DocMgmtService.addDocNotes(..))")
	public void pointCutAddDocNotes() {
	    // NOSONAR
   }

   @Pointcut("execution( * com.aia.case360.web.service.DocMgmtService.voidDocPages(..))")
	public void pointCutVoidPageLinks() {
	    // NOSONAR
   }

   @Pointcut("execution( * com.aia.case360.web.service.DocMgmtService.unvoidDocPages(..))")
	public void pointCutUnVoidPageLinks() {
	    // NOSONAR
   }

   @Before("pointCutVoidPageLinks() || pointCutUnVoidPageLinks()")
	public void beforeVoidPageLinks(JoinPoint jp) {
		LogUtil.logInfo(m_Logger,"AuditTrailDocAspect beforeVoidPageLinks start");
		String message="Function : beforeVoidPageLinks ";
		// "PAGE_INDICATOR":"NNNVNNNNNNNNNN","PAGES_INPUT":"4","DOC_ID":"171782",FORMIDSTR:"SJL1511"
           JSONObject params = (JSONObject) jp.getArgs()[0];
		Map<String, String> inputParam = JsonUtil.getStringMap(params);
		String docId = inputParam.get("DOC_ID");
        List<Map<String, Object>> results = new ArrayList<Map<String, Object>>();
        try {
			results = documentsRelatedDataDao.searchByDocId(docId);
		} catch (Exception e1) {
			LogUtil.logException(m_Logger, message, e1);
		}
        List<FdDocAuditTrail> fdDocAuditTrails = new ArrayList<FdDocAuditTrail>();
        FdDocAuditTrail fdDocAuditTrail = new FdDocAuditTrail();
        fdDocAuditTrail.setCreatedTimestamp(new Date());
        try {
			String userId = userHelper.getCurrentUser().toUpperCase();
            fdDocAuditTrail.setCreatedBy(userId);
       } catch (RemoteException e) {
       		LogUtil.logError(m_Logger,ADTDOCASPGETCUSERSTR+e.toString());
       }
        setAuditTrailInfo(fdDocAuditTrail, inputParam, results);
           String policys = inputParam.get(POLICYNUMSTR) == null ? "" : inputParam.get(POLICYNUMSTR);
		for (String policy : policys.split(",")) {
			FdDocAuditTrail instance = (FdDocAuditTrail) fdDocAuditTrail.getInstance();
             instance.setFromPolNum(policy);
             instance.setToPolNum(policy);
             try {
                instance.setActivityId(serialNoService.getSerialNo("CIW", ""));
             } catch (Exception e) {
				LogUtil.logError(m_Logger, SERVICEGETSERNOSTR + e.toString());
             }
             fdDocAuditTrails.add(instance);
           }
           try {
            batchAddDocAuditTrails(fdDocAuditTrails);
           } catch (Exception e) {
			LogUtil.logInfo(m_Logger,e.toString());
			LogUtil.logError(m_Logger, "beforeVoidPageLinks error " + e.toString());
   }
	}

   private void setAuditTrailInfo(FdDocAuditTrail fdDocAuditTrail,
		Map<String, String> inputParam, List<Map<String, Object>> results) {
	   fdDocAuditTrail.setFromFormId(inputParam.get(FORMIDSTR));
       fdDocAuditTrail.setToFormId(inputParam.get(FORMIDSTR));
		fdDocAuditTrail.setFromObjectId(
				results.get(0).get(OBJECTIDSTR) == null ? "" : results.get(0).get(OBJECTIDSTR).toString());
		fdDocAuditTrail
				.setToObjectId(results.get(0).get(OBJECTIDSTR) == null ? "" : results.get(0).get(OBJECTIDSTR).toString());
		fdDocAuditTrail.setFromComCd(inputParam.get(COMPANYCODESTR) == null ? "011" : inputParam.get(COMPANYCODESTR));
		fdDocAuditTrail.setToComCd(inputParam.get(COMPANYCODESTR) == null ? "011" : inputParam.get(COMPANYCODESTR));
           fdDocAuditTrail.setFromReqNo(inputParam.get(REQUESTNOSTR));
		fdDocAuditTrail.setToReqNo(inputParam.get(REQUESTNOSTR));
		fdDocAuditTrail.setFromStatusInd(
				results.get(0).get(ISVOIDSTR) != null && "1".equals(results.get(0).get(ISVOIDSTR).toString())
						? STATUS_VOID
						: STATUS_NORMAL);
		fdDocAuditTrail.setToStatusInd(
				results.get(0).get(ISVOIDSTR) != null && "1".equals(results.get(0).get(ISVOIDSTR).toString())
						? STATUS_VOID
						: STATUS_NORMAL);
		fdDocAuditTrail.setUserAct(inputParam.get("TYPE").equals("void") ? BTN_VOIDPAGE : BTN_UNVOIDPAGE);
}

@Around("pointCutDocMgmtService()")
	public Object around(ProceedingJoinPoint jp) throws RemoteException {
       Object[] args = jp.getArgs();
       String methodName = jp.getSignature().getName();
       Object result = null;
		try {
			result = jp.proceed(args);
		} catch (Throwable e) {
		  throw LogUtil.logException(m_Logger, "pointCutDocMgmtService around error " + e.toString(), e);
		}
		if (methodName.equalsIgnoreCase("copyToNewCase") || methodName.equalsIgnoreCase("reindexToNewCase")) {
			aT4copyReidxNewCase( methodName, result);
       }
		if (methodName.equalsIgnoreCase("reindexToClaim") || methodName.equalsIgnoreCase("copyToClaim")) {
			at4copyReidxClaim(methodName, result);
       }
       if(methodName.equalsIgnoreCase("reindexToExistCase")||methodName.equalsIgnoreCase("copyToExistCase")){
         AT4copyReidxExsCase(methodName, result);
       }
		if (methodName.equalsIgnoreCase("exportDocsDisk")) {
			aT4expDoc(jp);
       }
		if (methodName.equalsIgnoreCase("reindexToPolicy") || methodName.equalsIgnoreCase("copyToPolicy")) {
         AT4copyReidxPolicy(methodName, result);
       }
       return result;
   }

	private void at4copyReidxClaim(String methodName, Object result) {

		OutputVO result1 = (OutputVO) result;
		Map<String, Object> resultData = (Map<String, Object>) result1.getDatas();
		List<Map<String, String>> logicalLinkIds = (List<Map<String, String>>) resultData.get(LOGICALLINKIDSTR);

     List<FdDocAuditTrail> fdDocAuditTrais = new ArrayList<FdDocAuditTrail>();
		String userId = "";
     try {
			userId = userHelper.getCurrentUser().toUpperCase();
     } catch (RemoteException e) {
            LogUtil.logError(m_Logger,ADTDOCASPGETCUSERSTR+e.toString());
     }
     FdDocAuditTrail fdDocAuditTrail;
     for (Map<String, String> logicalInfo : logicalLinkIds) {
         FdDocAuditTrail docATrail = setDocAudtiTrailVaule(methodName, userId, logicalInfo,"copyToClaim","reindexToClaim");
       try {
         docATrail.setActivityId(serialNoService.getSerialNo("CIW", ""));
       } catch (Exception e) {
				LogUtil.logError(m_Logger, SERVICEGETSERNOSTR + e.toString());
       }
       fdDocAuditTrais.add(docATrail);
     }

	 try {
	    batchAddDocAuditTrails(fdDocAuditTrais);
	 } catch (Exception e) {
        LogUtil.logError(m_Logger, AUDITINSERTDOCAUDITSTR+e.toString());
	 }
  }

  private void batchAddDocAuditTrails(List<FdDocAuditTrail> fdDocAuditTrais) throws RemoteException {
    
    List<FdDocAuditTrail> fdDocAuditTraiList = new ArrayList<>(40);
    for(FdDocAuditTrail param : fdDocAuditTrais) {
      fdDocAuditTraiList.add(param);
      if(fdDocAuditTraiList.size() == 40) {
        documentsRelatedDataDao.insertFdDocAuditTrails(fdDocAuditTraiList);
        fdDocAuditTraiList.clear();
      }
    }
    
    if(!fdDocAuditTraiList.isEmpty()) {
      documentsRelatedDataDao.insertFdDocAuditTrails(fdDocAuditTraiList);
    }
  }

  private FdDocAuditTrail setDocAudtiTrailVaule(String methodName, String userId,
      Map<String, String> logicalInfo ,String copyMethodName,String reindexMethodName) {
      FdDocAuditTrail fdDocAuditTrail = new FdDocAuditTrail();
      fdDocAuditTrail.setCreatedTimestamp(new Date());
      fdDocAuditTrail.setCreatedBy(userId);
       if (methodName.equalsIgnoreCase(copyMethodName)) {
         fdDocAuditTrail.setUserAct(BTN_COPYDOC);
       } else if (methodName.equalsIgnoreCase(reindexMethodName)) {
         fdDocAuditTrail.setUserAct(BTN_REINDEX);
       }
       fdDocAuditTrail.setFromClaimNo(valueIsNull(logicalInfo.get(OLDCLAIMNOSTR) ));
       fdDocAuditTrail.setToClaimNo(valueIsNull(logicalInfo.get(CLAIMNOSTR) ));
       fdDocAuditTrail.setFromComCd(logicalInfo.get(COMPANYNOSTR) == null ? "011" : logicalInfo.get(COMPANYNOSTR).toString());
       fdDocAuditTrail.setToComCd(logicalInfo.get(COMPANYNOSTR) == null ? "011" : logicalInfo.get(COMPANYNOSTR).toString());
       fdDocAuditTrail.setFromFormId(valueIsNull(logicalInfo.get(OLDFORMIDSTR)));
       fdDocAuditTrail.setToFormId(valueIsNull(logicalInfo.get(FORMIDSTR)));
       fdDocAuditTrail.setFromObjectId(valueIsNull(logicalInfo.get(OBJECTIDSTR) ));
       fdDocAuditTrail.setToObjectId(valueIsNull(logicalInfo.get(OBJECTIDSTR)));
       fdDocAuditTrail.setFromProcessType(valueIsNull(logicalInfo.get(OLDPROCESSTYPESTR) ));
       fdDocAuditTrail.setToProcessType(valueIsNull(logicalInfo.get(PROCESSTYPESTR)));
       fdDocAuditTrail.setFromReceivedDt(logicalInfo.get(OLDRECEIVEDDTSTR) == null ? null
    	: new Date(Long.valueOf(logicalInfo.get(OLDRECEIVEDDTSTR))));
       fdDocAuditTrail.setToReceivedDt(logicalInfo.get(RECEIVEDDTSTR) == null ? null
    	: new Date(Long.valueOf(logicalInfo.get(RECEIVEDDTSTR))));
       fdDocAuditTrail.setFromReqNo(valueIsNull(logicalInfo.get(OLDREQUESTNUMSTR)));
       fdDocAuditTrail.setToReqNo(valueIsNull(logicalInfo.get(REQUESTNUMSTR)));
       fdDocAuditTrail.setFromStatusInd(
    	logicalInfo.get(ISVOIDSTR) != null && "true".equals(logicalInfo.get(ISVOIDSTR).toString())
    			? STATUS_VOID
    			: STATUS_NORMAL);
       fdDocAuditTrail.setToStatusInd(
    	logicalInfo.get(ISVOIDSTR) != null && "true".equals(logicalInfo.get(ISVOIDSTR).toString())
    			? STATUS_VOID
    			: STATUS_NORMAL);
       fdDocAuditTrail.setFromPolNum(valueIsNull(logicalInfo.get(OLD_POL_NUMSTR) ));
       fdDocAuditTrail.setToPolNum(valueIsNull(logicalInfo.get(POLNUMSTR)));
        fdDocAuditTrail.setLogicalLinkId(logicalInfo.get(LOGICALLINKIDSTR));
        FdDocAuditTrail docATrail = (FdDocAuditTrail) fdDocAuditTrail.getInstance();
    return docATrail;
  }


  private void AT4copyReidxPolicy(String methodName, Object result) {

		@SuppressWarnings("unchecked")
		List<Map<String, String>> logicalLinkIds = (List<Map<String, String>>)((Map<String, Object>)result).get(LOGICALLINKIDSTR);


       List<FdDocAuditTrail> fdDocAuditTrais = new ArrayList<FdDocAuditTrail>();
       String userId ="";
       try {
         userId =userHelper.getCurrentUser().toUpperCase();
       } catch (RemoteException e) {
         m_Logger.error(ADTDOCASPGETCUSERSTR+e.toString(),e);
       }
       for(Map<String, String> logicalInfo : logicalLinkIds) {
         FdDocAuditTrail docATrail = setDocAudtiTrailVaule(methodName, userId, logicalInfo,"copyToPolicy","reindexToPolicy");

         try {
           docATrail.setActivityId(serialNoService.getSerialNo("CIW", ""));
         } catch (Exception e) {
						LogUtil.logError(m_Logger, SERVICEGETSERNOSTR + e.toString());
         }
         fdDocAuditTrais.add(docATrail);
       }
       try {
         batchAddDocAuditTrails(fdDocAuditTrais);
       } catch (Exception e) {
         LogUtil.logError(m_Logger, AUDITINSERTDOCAUDITSTR + e.toString());
       }

		}
	

	private void aT4expDoc(JoinPoint jp) {
		String message="Function : aT4expDoc";
     ExportDocsDiskParam eddp = (ExportDocsDiskParam) jp.getArgs()[0];
     List<FdDocAuditTrail> atList = new ArrayList<FdDocAuditTrail>();
		FdDocAuditTrail fdDocAuditTrail = new FdDocAuditTrail();
     fdDocAuditTrail.setCreatedTimestamp(new Date());
     fdDocAuditTrail.setUserAct(BTN_EXPORTTODISK);
     try {
    	 String userId = userHelper.getCurrentUser().toUpperCase();
         fdDocAuditTrail.setCreatedBy(userId);
     } catch (RemoteException e) {
          LogUtil.logError(m_Logger,ADTDOCASPGETCUSERSTR+e.toString());
     }

	 String logicalLinkId = null;
      int i = 0;
		for (ExportDocInfoParam item : eddp.getDocumentIDs()) {
			if (i == 0) {
				try {
					logicalLinkId = documentsRelatedDataDao.searchLogicLinkId(item.getObjectID(), item.getRequestNum(),
							item.getPolicyNum(), item.getFormId());
				} catch (Exception e1) {
					LogUtil.logException(m_Logger, message, e1);
				}
			}
			FdDocAuditTrail docAT = getDocAT(fdDocAuditTrail, item, logicalLinkId);
	       atList.add(docAT);
	       i++;
     }
     try {
       batchAddDocAuditTrails(atList);
     } catch (Exception e) {
			LogUtil.logError(m_Logger, "AuditTrailDocAspect insertFdDocAuditTraills exsitcase " + e.toString());
     }
  }

  private FdDocAuditTrail getDocAT(FdDocAuditTrail fdDocAuditTrail,
			ExportDocInfoParam item, String logicalLinkId) {
	  FdDocAuditTrail docAT = (FdDocAuditTrail) fdDocAuditTrail.getInstance();
		String docId = item.getDocumentID();
		List<Map<String, Object>> results = new ArrayList<Map<String, Object>>();
		try {
			results = documentsRelatedDataDao.searchByDocId(docId);
		} catch (Exception e1) {
			 LogUtil.logException(m_Logger, "getDocAT", e1);
		}
		docAT.setFromStatusInd(
				results.get(0).get(ISVOIDSTR) != null && "1".equals(results.get(0).get(ISVOIDSTR).toString())
						? STATUS_VOID : STATUS_NORMAL);
		docAT.setToStatusInd(
				results.get(0).get(ISVOIDSTR) != null && "1".equals(results.get(0).get(ISVOIDSTR).toString())
						? STATUS_VOID : STATUS_NORMAL);
	     docAT.setFromReqNo(item.getRequestNum());
	     docAT.setToReqNo(item.getRequestNum());
	     docAT.setFromFormId(item.getFormId());
	     docAT.setToFormId(item.getFormId());
	     docAT.setFromPolNum(item.getPolicyNum());
	     docAT.setToPolNum(item.getPolicyNum());
	     docAT.setToObjectId(item.getObjectID());
	     docAT.setFromObjectId(item.getObjectID());
	     docAT.setFromComCd(StringUtils.isBlank(item.getCompanyCode()) ? "011" : item.getCompanyCode());
	     docAT.setToComCd(StringUtils.isBlank(item.getCompanyCode()) ? "011" : item.getCompanyCode());
	     docAT.setLogicalLinkId(logicalLinkId);
	     try {
	       docAT.setActivityId(serialNoService.getSerialNo("CIW", ""));
	     } catch (Exception e) {
	              LogUtil.logError(m_Logger, SERVICEGETSERNOSTR+e.toString());
	     }
	     return docAT;
	}

  private void AT4copyReidxExsCase(String methodName, Object result) {
    OutputVO result1 = (OutputVO) result;
    Map<String, Object> resultData = (Map<String, Object>) result1.getDatas();
    List<Map<String, String>> logicalLinkIds =
        (List<Map<String, String>>) resultData.get(LOGICALLINKIDSTR);

    List<FdDocAuditTrail> fdDocAuditTrais = new ArrayList<FdDocAuditTrail>();
    try {
      String userId = userHelper.getCurrentUser().toUpperCase();

      for (Map<String, String> logicalInfo : logicalLinkIds) {

        FdDocAuditTrail fdDocAuditTrail =
            setDocAudtiTrailVaule(methodName, userId, logicalInfo, "copyToExistCase",
                "reindexToExistCase");
        try {
          fdDocAuditTrail.setActivityId(serialNoService.getSerialNo("CIW", ""));
        } catch (Exception e) {
          LogUtil.logError(m_Logger, SERVICEGETSERNOSTR + e.toString());
        }
        FdDocAuditTrail docATrail = (FdDocAuditTrail) fdDocAuditTrail.getInstance();
        if (!fdDocAuditTrais.contains(docATrail)) {
          fdDocAuditTrais.add(docATrail);
        }
      }
      batchAddDocAuditTrails(fdDocAuditTrais);
    } catch (RemoteException e) {
      m_Logger.error(ADTDOCASPGETCUSERSTR + e.toString(), e);
    }
  }

	

	private void aT4copyReidxNewCase( String methodName, Object result) {
		OutputVO result1 = (OutputVO) result;
		Map<String, Object> resultData = (Map<String, Object>) result1.getDatas();
		String resReqNum = resultData.get(REQUESTNUMSTR) == null ? "" : String.valueOf(resultData.get(REQUESTNUMSTR));
		List<Map<String, String>> logicalLinkIds = (List<Map<String, String>>) resultData.get(LOGICALLINKIDSTR);

		List<FdDocAuditTrail> fdDocAuditTrais = new ArrayList<FdDocAuditTrail>();
		String userId = "";
		try {
			userId = userHelper.getCurrentUser().toUpperCase();
			for (Map<String, String> logicalInfo : logicalLinkIds) {
			  
			  logicalInfo.put(REQUESTNUMSTR, resReqNum);
			  
			  FdDocAuditTrail fdDocAuditTrail = setDocAudtiTrailVaule(methodName, userId, logicalInfo,"copyToNewCase","reindexToNewCase");
				setActivityId(fdDocAuditTrail);
				
				FdDocAuditTrail docATrail = (FdDocAuditTrail) fdDocAuditTrail.getInstance();
				if (!fdDocAuditTrais.contains(docATrail)) {
					fdDocAuditTrais.add(docATrail);
				}
			}

			batchAddDocAuditTrails(fdDocAuditTrais);
		} catch (Exception e) {
			LogUtil.logError(m_Logger, AUDITINSERTDOCAUDITSTR + e.toString());
		}
	}

	private void setActivityId(FdDocAuditTrail fdDocAuditTrail) {
		try {
				fdDocAuditTrail.setActivityId(serialNoService.getSerialNo("CIW", ""));
	       } catch (Exception e) {
				LogUtil.logError(m_Logger, SERVICEGETSERNOSTR + e.toString());
	       }
	}

	

@Before("pointCutRenameDocFormLink()")
	public void beforeRename(JoinPoint jp) throws RemoteException {
       List<RenameDocFormLinkParam> params = (List<RenameDocFormLinkParam>) jp.getArgs()[0];
       String uuidStr = "pointCutRenameDocFormLink";
       for (RenameDocFormLinkParam renameDocFormLinkParam : params) {
           if("0".equals(renameDocFormLinkParam.getLinkID()) || StringUtils.isEmpty(renameDocFormLinkParam.getLinkID())
                   || "null".equalsIgnoreCase(renameDocFormLinkParam.getLinkID())){
               //call Common Service ,move Attributes to doc link, return S_ROWID
               String objectId = renameDocFormLinkParam.getObjectId();
               Long linkId = docMgmtService.convertAttributesToAttrDocLink(objectId, 1, uuidStr);
               // set S_ROWID
               renameDocFormLinkParam.setLinkID(String.valueOf(linkId));
           }
       }
       
       List<String> linkIDs = new ArrayList<String> ();
       for(RenameDocFormLinkParam param : params){
         linkIDs.add(param.getLinkID());
       }
       List<Map<String, Object>> results = new ArrayList<Map<String, Object>>();
       try {
         results = documentsRelatedDataDao.getDocLinkByID(linkIDs);
       } catch (Exception e1) {
			LogUtil.logError(m_Logger, "documentsRelatedDataDao getDocLinkByID " + e1.toString());
       }
       List<FdDocAuditTrail> fdDocAuditTrails = new ArrayList<FdDocAuditTrail>();
       Map<String, Object> linkIDsResult = new HashMap<String, Object>();

		for (RenameDocFormLinkParam param : params) {

			linkIDsResult = renameDocFormLinkParam(results, fdDocAuditTrails,
					linkIDsResult, param);
       }
       
       try {
         batchAddDocAuditTrails(fdDocAuditTrails);
       } catch (Exception e) {
            LogUtil.logError(m_Logger, "AuditTrailDocAspect insertFdDocAuditTraills rename "+e.toString());
       }

   }

	private Map<String, Object> renameDocFormLinkParam(
			List<Map<String, Object>> results,
			List<FdDocAuditTrail> fdDocAuditTrails,
			Map<String, Object> linkIDsResult, RenameDocFormLinkParam param) {
		for (Map<String, Object> it : results) {
			if (it.get("S_ROWID").toString().equals(param.getLinkID())) {
		 linkIDsResult = it;
	         }
	       }
	
	       FdDocAuditTrail fdDocAuditTrail = new FdDocAuditTrail();
	       fdDocAuditTrail.setCreatedTimestamp(new Date());
	       try {
			String userId = userHelper.getCurrentUser().toUpperCase();
	         fdDocAuditTrail.setCreatedBy(userId);
	       } catch (RemoteException e) {
		    LogUtil.logError(m_Logger,ADTDOCASPGETCUSERSTR+e.toString());
	       }
	       setFdDocAuditTrail(linkIDsResult, param, fdDocAuditTrail);
	       try {
			fdDocAuditTrail.setFromReceivedDt(linkIDsResult.get(RECEIVEDDTSTR) == null ? null
					: Constants.getDBDateTimeFormat().parse(linkIDsResult.get(RECEIVEDDTSTR).toString()));
			fdDocAuditTrail.setToReceivedDt(linkIDsResult.get(RECEIVEDDTSTR) == null ? null
					: Constants.getDBDateTimeFormat().parse(linkIDsResult.get(RECEIVEDDTSTR).toString()));
	       } catch (ParseException e) {
	         // TODO Auto-generated catch block
		      LogUtil.logError(m_Logger,"afterVoidDocLinks dateformat.parse "+e.toString());
	       }
	
		    setFdDocAuitTrail2(linkIDsResult, fdDocAuditTrail);
	
	       try {
	         fdDocAuditTrail.setActivityId(serialNoService.getSerialNo("CIW", ""));
	       } catch (Exception e) {
			LogUtil.logError(m_Logger, SERVICEGETSERNOSTR + e.toString());
	       }
	       if(!fdDocAuditTrails.contains(fdDocAuditTrail)) {
	         fdDocAuditTrails.add(fdDocAuditTrail);
	       }
	       if(!StringUtils.isEmpty(param.getFormID())) {
	         formIdNotEmpty(fdDocAuditTrails, param, fdDocAuditTrail);
	       }
		return linkIDsResult;
	}

	private void formIdNotEmpty(List<FdDocAuditTrail> fdDocAuditTrails,
			RenameDocFormLinkParam param, FdDocAuditTrail fdDocAuditTrail) {
		String mainLinkFormId = eDocAdminDao.getMainLinkFormIdByFormId((String) param.getFormID());
		 if (StringUtils.isNotEmpty(mainLinkFormId)) {
 fdDocAuditTrail = (FdDocAuditTrail) fdDocAuditTrail.getInstance();
 try {
   fdDocAuditTrail.setActivityId(serialNoService.getSerialNo("CIW", ""));
 } catch (Exception e) {
		m_Logger.error(SERVICEGETSERNOSTR+e.toString());
 }
 fdDocAuditTrail.setToFormId(mainLinkFormId);
 fdDocAuditTrail.setLogicalLinkId("");
  if(!fdDocAuditTrails.contains(fdDocAuditTrail)) {
		fdDocAuditTrails.add(fdDocAuditTrail);
  }
		 }
	}

	private void setFdDocAuitTrail2(Map<String, Object> linkIDsResult,
			FdDocAuditTrail fdDocAuditTrail) {
		fdDocAuditTrail.setFromReqNo(
				linkIDsResult.get(REQUESTNUMSTR) == null ? "" : linkIDsResult.get(REQUESTNUMSTR).toString());
		fdDocAuditTrail.setToReqNo(
				linkIDsResult.get(REQUESTNUMSTR) == null ? "" : linkIDsResult.get(REQUESTNUMSTR).toString());
	
		fdDocAuditTrail.setFromStatusInd(
				linkIDsResult.get(ISVOIDSTR) != null && "1".equals(linkIDsResult.get(ISVOIDSTR).toString())
						? STATUS_VOID
						: STATUS_NORMAL);
		fdDocAuditTrail.setToStatusInd(
				linkIDsResult.get(ISVOIDSTR) != null && "1".equals(linkIDsResult.get(ISVOIDSTR).toString())
						? STATUS_VOID
						: STATUS_NORMAL);
		fdDocAuditTrail.setLogicalLinkId(linkIDsResult.get(LOGICALLINKIDSTR) == null ? ""
				: linkIDsResult.get(LOGICALLINKIDSTR).toString());
	}

	private void setFdDocAuditTrail(Map<String, Object> linkIDsResult,
			RenameDocFormLinkParam param, FdDocAuditTrail fdDocAuditTrail) {
		fdDocAuditTrail.setUserAct(BTN_RENAMEFORM);
		fdDocAuditTrail.setFromComCd(
				linkIDsResult.get(COMPANYNOSTR) == null ? "011" : linkIDsResult.get(COMPANYNOSTR).toString());
		fdDocAuditTrail.setToComCd(
				linkIDsResult.get(COMPANYNOSTR) == null ? "011" : linkIDsResult.get(COMPANYNOSTR).toString());
		fdDocAuditTrail
				.setFromFormId(linkIDsResult.get(FORMIDSTR) == null ? "" : linkIDsResult.get(FORMIDSTR).toString());
	       fdDocAuditTrail.setToFormId(param.getFormID());
		fdDocAuditTrail.setFromObjectId(
				linkIDsResult.get(OBJECTIDSTR) == null ? "" : linkIDsResult.get(OBJECTIDSTR).toString());
		fdDocAuditTrail.setToObjectId(
				linkIDsResult.get(OBJECTIDSTR) == null ? "" : linkIDsResult.get(OBJECTIDSTR).toString());
		fdDocAuditTrail
				.setFromPolNum(linkIDsResult.get(POLNUMSTR) == null ? "" : linkIDsResult.get(POLNUMSTR).toString());
		fdDocAuditTrail
				.setToPolNum(linkIDsResult.get(POLNUMSTR) == null ? "" : linkIDsResult.get(POLNUMSTR).toString());
		fdDocAuditTrail.setFromProcessType(
				linkIDsResult.get(PROCESSTYPESTR) == null ? "" : linkIDsResult.get(PROCESSTYPESTR).toString());
	       fdDocAuditTrail.setToProcessType(param.getProcessType());
		fdDocAuditTrail.setLogicalLinkId(linkIDsResult.get(LOGICALLINKIDSTR) == null ? ""
				: linkIDsResult.get(LOGICALLINKIDSTR).toString());
	}

   @Before("pointCutVoidDocLinks() || pointCutUnvoidDocLinks()")
	public void beforeVoidDocLinks(JoinPoint jp) {
		LogUtil.logInfo(m_Logger,"AuditTrailDocAspect beforeVoidDocLinks start");
       List<VoidDocLinkParam> linkIDs = (List<VoidDocLinkParam>) jp.getArgs()[0];
       List<String> links = new ArrayList<String>();
		for (VoidDocLinkParam vdp : linkIDs) {
         links.add(vdp.getLinkID());
       }
		String methodName = jp.getSignature().getName();
       List<Map<String, Object>> results = new ArrayList<Map<String, Object>>();
        try {
          results = documentsRelatedDataDao.getDocLinkByID(links);
        } catch (Exception e1) {
			LogUtil.logError(m_Logger, "documentsRelatedDataDao getDocLinkByID " + e1.toString());
        }
      List<FdDocAuditTrail> fdDocAuditTrais = new ArrayList<FdDocAuditTrail>();

		for (Map<String, Object> doclink : results) {
         setFdDocAuditTrail(methodName, fdDocAuditTrais, doclink);
       }
		LogUtil.logInfo(m_Logger,"AuditTrailDocAspect beforeVoidDocLinks fdDocAuditTrails"+ fdDocAuditTrais.toString() );
      try {
        batchAddDocAuditTrails(fdDocAuditTrais);
      } catch (Exception e) {
            LogUtil.logError(m_Logger, AUDITINSERTDOCAUDITSTR + e.toString());
      }
   }

private void setFdDocAuditTrail(String methodName,
		List<FdDocAuditTrail> fdDocAuditTrais, Map<String, Object> doclink) {
	FdDocAuditTrail fdDocAuditTrail = new FdDocAuditTrail();
	 fdDocAuditTrail.setCreatedTimestamp(new Date());
	 try {
			String userId = userHelper.getCurrentUser().toUpperCase();
	   fdDocAuditTrail.setCreatedBy(userId);
	 } catch (RemoteException e) {
	        LogUtil.logError(m_Logger, ADTDOCASPGETCUSERSTR + e.toString());
	 }
		if ("voidDocLinks".equals(methodName)) {
		 fdDocAuditTrail.setUserAct(BTN_VOIDDOC);
		} else if ("unvoidDocLinks".equals(methodName)) {
		 fdDocAuditTrail.setUserAct(BTN_UNVOIDDOC);
	 }
		fdDocAuditTrail.setFromComCd(doclink.get(COMPANYNOSTR) == null ? "011" : doclink.get(COMPANYNOSTR).toString());
		fdDocAuditTrail.setToComCd(doclink.get(COMPANYNOSTR) == null ? "011" : doclink.get(COMPANYNOSTR).toString());
		fdDocAuditTrail.setFromFormId(valueIsNull(doclink.get(FORMIDSTR) ));
		fdDocAuditTrail.setToFormId(valueIsNull(doclink.get(FORMIDSTR) ));
		fdDocAuditTrail.setFromObjectId(valueIsNull(doclink.get(OBJECTIDSTR)));
		fdDocAuditTrail.setToObjectId(valueIsNull(doclink.get(OBJECTIDSTR) ));
		fdDocAuditTrail.setFromPolNum(valueIsNull(doclink.get(POLNUMSTR)));
		fdDocAuditTrail.setToPolNum(valueIsNull(doclink.get(POLNUMSTR) ));
		fdDocAuditTrail.setFromProcessType(valueIsNull(doclink.get(PROCESSTYPESTR) ));
		fdDocAuditTrail.setToProcessType(valueIsNull(doclink.get(PROCESSTYPESTR)));
		fdDocAuditTrail.setLogicalLinkId(valueIsNull(doclink.get(LOGICALLINKIDSTR) ));

	 try {
			fdDocAuditTrail.setFromReceivedDt(doclink.get(RECEIVEDDTSTR) == null ? null
					: Constants.getDBDateTimeFormat().parse(doclink.get(RECEIVEDDTSTR).toString()));
			fdDocAuditTrail.setToReceivedDt(doclink.get(RECEIVEDDTSTR) == null ? null
					: Constants.getDBDateTimeFormat().parse(doclink.get(RECEIVEDDTSTR).toString()));
		} catch (ParseException e) {
	            LogUtil.logError(m_Logger, "afterVoidDocLinks dateformat.parse " + e.toString());
	 }

		fdDocAuditTrail
				.setFromReqNo(valueIsNull(doclink.get(REQUESTNUMSTR)));
		fdDocAuditTrail.setToReqNo(valueIsNull(doclink.get(REQUESTNUMSTR)));

		fdDocAuditTrail.setFromStatusInd(
				doclink.get(ISVOIDSTR) != null && "1".equals(doclink.get(ISVOIDSTR).toString()) ? STATUS_VOID
						: STATUS_NORMAL);
		fdDocAuditTrail.setToStatusInd(
				doclink.get(ISVOIDSTR) != null && "1".equals(doclink.get(ISVOIDSTR).toString()) ? STATUS_NORMAL
						: STATUS_VOID);

	 try {
	   fdDocAuditTrail.setActivityId(serialNoService.getSerialNo("CIW", ""));
	 } catch (Exception e) {
			LogUtil.logError(m_Logger, SERVICEGETSERNOSTR + e.toString());
	 }
	 if(!fdDocAuditTrais.contains(fdDocAuditTrail)) {
	   fdDocAuditTrais.add(fdDocAuditTrail);
	 }
}

   @Before("pointCutPrintDoc()")
	public void beforePrintDoc(JoinPoint jp) {
	   String[] arr = (String[])jp.getArgs()[1];
       String docId = arr[0];
       String polNum = arr[3];
       String compCd = arr[4];
       String formId = arr[5];
		String objectId = arr[13];
		String requestNo = arr[14];
		String[] pols = polNum.split(",");
		for (int i = 0; i < pols.length; i++) {
        	 List<Map<String, Object>> results = new ArrayList<Map<String, Object>>();
             try {
				results = documentsRelatedDataDao.searchByDocId(docId);
			} catch (Exception e1) {
				 LogUtil.logError(m_Logger, "AuditTrailDocAspect searchByDocId " + e1.toString());
  	        	}
        	 FdDocAuditTrail fdDocAuditTrail = new FdDocAuditTrail();
             fdDocAuditTrail.setCreatedTimestamp(new Date());
             try {
				String userId = userHelper.getCurrentUser().toUpperCase();
               fdDocAuditTrail.setCreatedBy(userId);
             } catch (RemoteException e) {
                  LogUtil.logError(m_Logger, ADTDOCASPGETCUSERSTR + e.toString());
             }
             fdDocAuditTrail.setUserAct(BTN_PRINTDOC);
             fdDocAuditTrail.setFromComCd(compCd == null ? "011" : compCd);
             fdDocAuditTrail.setToComCd(compCd == null ? "011" : compCd);
             fdDocAuditTrail.setFromFormId(formId);
			fdDocAuditTrail.setToFormId(formId);
             fdDocAuditTrail.setFromPolNum(pols[i]);
             fdDocAuditTrail.setToPolNum(pols[i]);
             fdDocAuditTrail.setFromObjectId(objectId);
             fdDocAuditTrail.setToObjectId(objectId);
             fdDocAuditTrail.setFromReqNo(requestNo);
             fdDocAuditTrail.setToReqNo(requestNo);
			checkVoidFlag(results, fdDocAuditTrail);
             try {
               fdDocAuditTrail.setActivityId(serialNoService.getSerialNo("CIW", ""));
             } catch (Exception e) {
				LogUtil.logError(m_Logger, SERVICEGETSERNOSTR + e.toString());
             }
             try {
                 documentsRelatedDataDao.insertOneFdDocAuditTrail(fdDocAuditTrail);
               } catch (Exception e) {
                LogUtil.logError(m_Logger, AUDITINSERTDOCAUDITSTR + e.toString());
               }
   }
	}

	private void checkVoidFlag(List<Map<String, Object>> results, FdDocAuditTrail fdDocAuditTrail) {
		String tmp= "";
		if(results.get(0).get(ISVOIDSTR)!=null) {
			tmp = results.get(0).get(ISVOIDSTR).toString();
		}
		if(tmp.equals("1")) {
			tmp = STATUS_VOID;
		}else {
			tmp = STATUS_NORMAL;
		}
		fdDocAuditTrail.setFromStatusInd(tmp);
		fdDocAuditTrail.setToStatusInd(tmp);
	}

   @After("pointCutAddDocNotes()")
	public void afterAddDocNotes(JoinPoint jp) {
       JSONObject params = (JSONObject) jp.getArgs()[0];
       Map<String, String> inputParam = JsonUtil.getStringMap(params);
       FdDocAuditTrail fdDocAuditTrail = new FdDocAuditTrail();
       fdDocAuditTrail.setCreatedTimestamp(new Date());
		String docId = inputParam.get("DOCUMENTID");
       List<Map<String, Object>> results = new ArrayList<Map<String, Object>>();
       try {
			results = documentsRelatedDataDao.searchByDocId(docId);
		} catch (Exception e1) {
			 LogUtil.logError(m_Logger, "AuditTrailDocAspect searchByDocId " + e1.toString());
	}

		String[] arr = inputParam.get(POLICYNUMSTR).split(",");
		for (int i = 0; i < arr.length; i++) {
    	   setAuditTrailbrforeVoidDocLink(inputParam, fdDocAuditTrail, results,
				arr, i);
		}
	}

private void setAuditTrailbrforeVoidDocLink(Map<String, String> inputParam,
		FdDocAuditTrail fdDocAuditTrail, List<Map<String, Object>> results,
		String[] arr, int i) {
	try {
			String userId = userHelper.getCurrentUser().toUpperCase();
	         fdDocAuditTrail.setCreatedBy(userId);
	       } catch (RemoteException e) {
	         LogUtil.logError(m_Logger, ADTDOCASPGETCUSERSTR + e.toString());
	       }
		fdDocAuditTrail.setFromComCd(inputParam.get(COMPANYCODESTR) == "" ? "011" : inputParam.get(COMPANYCODESTR));
		fdDocAuditTrail.setToComCd(inputParam.get(COMPANYCODESTR) == "" ? "011" : inputParam.get(COMPANYCODESTR));
		fdDocAuditTrail.setFromReqNo(inputParam.get(REQUESTNOSTR) == "" ? "" : inputParam.get(REQUESTNOSTR));
		fdDocAuditTrail.setToReqNo(inputParam.get(REQUESTNOSTR) == "" ? "" : inputParam.get(REQUESTNOSTR));
		fdDocAuditTrail.setFromPolNum(arr[i].toString() == "" ? "" : arr[i].toString());
		fdDocAuditTrail.setToPolNum(arr[i].toString() == "" ? "" : arr[i].toString());
		
		fdDocAuditTrail.setFromObjectId(inputParam.get(OBJECTIDSTR) == "" ? "" : inputParam.get(OBJECTIDSTR));
		fdDocAuditTrail.setFromFormId(inputParam.get(FORMIDSTR) == "" ? "" : inputParam.get(FORMIDSTR));
		fdDocAuditTrail.setToFormId(inputParam.get(FORMIDSTR) == "" ? "" : inputParam.get(FORMIDSTR));
		fdDocAuditTrail.setToObjectId(inputParam.get(OBJECTIDSTR) == "" ? "" : inputParam.get(OBJECTIDSTR));
	   fdDocAuditTrail.setLogicalLinkId(inputParam.get(LOGICALLINKIDSTR));
		
		
		checkVoidFlag(results, fdDocAuditTrail);
		
		
	   fdDocAuditTrail.setUserAct(BTN_ADDDOCNOTE);
	   try {
	     fdDocAuditTrail.setActivityId(serialNoService.getSerialNo("CIW", ""));
	   } catch (Exception e) {
			LogUtil.logError(m_Logger, SERVICEGETSERNOSTR + e.toString());
	   }
	   try {
	    documentsRelatedDataDao.insertOneFdDocAuditTrail(fdDocAuditTrail);
	   } catch (Exception e) {
			LogUtil.logInfo(m_Logger,e.toString());
			LogUtil.logError(m_Logger, "insertOneFdDocAuditTrail error " + e.toString());
   }
}

   @Before("pointCutImportCasesDoc() || pointCutImportPolsDoc()")
	public void setLastMethod(JoinPoint jp) {
		String methodName = jp.getSignature().getName();
     lastMethod.set(methodName);
   }

   @After("pointCutInsertFdDocLinks()")
	public void afterInsertFdDocLink(JoinPoint jp) {
		if (lastMethod != null && ("importCasesDoc".equals(lastMethod.get())
				|| "importPolsDoc".equals(lastMethod.get()))) {
         List<FdDocLink> params = (List<FdDocLink>) jp.getArgs()[0];
         FdDocAuditTrail fdDocAuditTrail = new FdDocAuditTrail();
         fdDocAuditTrail.setCreatedTimestamp(new Date());
         try {
				String userId = userHelper.getCurrentUser().toUpperCase();
           fdDocAuditTrail.setCreatedBy(userId);
         } catch (RemoteException e) {
                  LogUtil.logError(m_Logger,ADTDOCASPGETCUSERSTR+e.toString());
         }
			for (FdDocLink fdl : params) {
           fdDocAuditTrail = setAuditTrailAfterInsertFdDocLink(fdDocAuditTrail,
				fdl);
         }
         lastMethod.remove();
       }
   }

private FdDocAuditTrail setAuditTrailAfterInsertFdDocLink(
		FdDocAuditTrail fdDocAuditTrail, FdDocLink fdl) {
	fdDocAuditTrail.setFromStatusInd(STATUS_NORMAL);
			fdDocAuditTrail.setToStatusInd(STATUS_NORMAL);
	   fdDocAuditTrail.setFromFormId(fdl.getFormId());
			fdDocAuditTrail.setFromComCd(fdl.getCompanyNo() == null ? "011" : fdl.getCompanyNo());
	   fdDocAuditTrail.setFromObjectId(fdl.getObjectId());
	   fdDocAuditTrail.setFromPolNum(fdl.getPolicyNo());
	   fdDocAuditTrail.setFromProcessType(fdl.getProcessType());
	   fdDocAuditTrail.setFromReqNo(fdl.getRequestNo());

	   fdDocAuditTrail.setToFormId(fdl.getFormId());
			fdDocAuditTrail.setToComCd(fdl.getCompanyNo() == null ? "011" : fdl.getCompanyNo());
	   fdDocAuditTrail.setToObjectId(fdl.getObjectId());
	   fdDocAuditTrail.setToPolNum(fdl.getPolicyNo());
	   fdDocAuditTrail.setToProcessType(fdl.getProcessType());
	   fdDocAuditTrail.setToReqNo(fdl.getRequestNo());
	   fdDocAuditTrail.setUserAct(BTN_IMPORTDOC);
	   try {
	     fdDocAuditTrail.setActivityId(serialNoService.getSerialNo("CIW", ""));
	   } catch (Exception e) {
				LogUtil.logError(m_Logger, SERVICEGETSERNOSTR + e.toString());
	   }
	   try {
	    documentsRelatedDataDao.insertOneFdDocAuditTrail(fdDocAuditTrail);
	   } catch (Exception e) {
				LogUtil.logInfo(m_Logger,e.toString());
				LogUtil.logError(m_Logger, "insertOneFdDocAuditTrail error " + e.toString());
	   }
	   String mainLinkFormId = eDocAdminDao.getMainLinkFormIdByFormId((String) fdl.getFormId());
	   if (StringUtils.isNotEmpty(mainLinkFormId)) {
	    fdDocAuditTrail = (FdDocAuditTrail) fdDocAuditTrail.getInstance();
	    fdDocAuditTrail.setFromFormId(mainLinkFormId);
	    fdDocAuditTrail.setToFormId(mainLinkFormId);
	    try {
	      documentsRelatedDataDao.insertOneFdDocAuditTrail(fdDocAuditTrail);
	    } catch (Exception e) {
	      m_Logger.error("insertOneFdDocAuditTrail mainLinkFormId error " + e.toString());
	    }
	   }
	return fdDocAuditTrail;
}
   private String valueIsNull(Object value){
     
     if(value==null){
       return "";
     }else if("".equals(value.toString().trim())){
       return "";
     }else if(value.toString().trim().length()==0){
       return "";
     }else{
       return value.toString().trim();
     }
 }

}
