package com.aia.case360.uam.service.impl;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

import com.aia.case360.common.Constants;
import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.dao.TableIdBean;
import com.aia.case360.uam.domain.CompoenentDTO;
import com.aia.case360.uam.domain.ComponentMapper;
import com.aia.case360.uam.domain.EditUamTeamSettingAuditTrail;
import com.aia.case360.uam.domain.UAMAuditTrail;
import com.aia.case360.uam.domain.UpdateComponentAuditTrail;
import com.aia.case360.uam.domain.UserInOrg;
import com.aia.case360.uam.domain.UserInOrgMapper;
import com.aia.case360.uam.service.UAMOrganizationStructureService;
import com.aia.case360.uam.service.UAMUserAccountService;
import com.aia.case360.web.common.CommonUtil;
import com.aia.case360.web.dao.UAMAuditTrailDao;
import com.aia.case360.web.exception.CustomException;
import com.aia.case360.web.pojo.OutputVO;
import com.aia.case360.web.service.impl.AbstractServiceImpl;

@Service
public class UAMOrganizationStructureServiceImpl extends AbstractServiceImpl
		implements UAMOrganizationStructureService {
	
	private static final String LOCALPARENT_ID = "parentId";

	private static final String COMPONENTID = "COMPONENTID";
	
	private static final String NULLINPUTMSG = "null input parameter";
	
	private static final String TEAMLEADERSSTR = "TEAMLEADERS";
	
	private static final String UAMCOMPONENTIDSTR = "UAM_COMPONENT_ID";
	
	private static final String COMPANYNAMESTR = "COMPANYNAME";
	
	private static final String COMPANYTYPESTR = "COMPANYTYPE";
	
	private static final String PARENTIDSTR = "PARENTID";
	
	private static final String LOWERPOSITIONSTR = "position";
	
	private static final String USERIDSTR = "userId";
	
	private static final String COMPANYIDSTR = "companyId";
	
	private static final String TEAMIDSTR = "TEAMID";

	@Autowired
	private TableIdBean tableIdBean;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private UAMUserAccountService uamUserAccountService;

	@Autowired
	com.aia.case360.web.dao.UserAccountDao userAuthorityDao;

	@Autowired
	UAMAuditTrailDao auditTrailDao;

	/**
	 * All members of all groups under this compnent(only include active )
	 */
	@SuppressWarnings("unchecked")
	@Override
	public OutputVO getUserList(Map<String, Object> request)  throws RemoteException {
		LogUtil.logInfo(m_Logger,"servivce getUserList start");
		OutputVO outputVO = new OutputVO();
		Map<String, Object> resultData = new ConcurrentHashMap<String, Object>();
		Integer parentId = request.get(COMPONENTID) == null ? null
				: Integer.parseInt(request.get(COMPONENTID).toString());
		if (parentId == null) {
			outputVO.addErrorInfo(NULLINPUTMSG);
			return outputVO;
		}
		String processFlag = request.get("PROCESSCASE") == null ? "0" : request.get("PROCESSCASE").toString();
		LogUtil.logInfo(m_Logger,"servivce getUserList QUERY TEAMLEADER start");
		List<Map<String, String>> queryResult = userAuthorityDao.queryTeamLeaders(parentId);
		LogUtil.logInfo(m_Logger,"servivce getUserList QUERY TEAMLEADER end");
		LogUtil.logInfo(m_Logger,"servivce getUserList EXECUTE getOrgChart start");

		String sql = "execute getOrgChart ?";
		Object search[] = { parentId };
		List<CompoenentDTO> orgChart = (List<CompoenentDTO>) jdbcTemplate.query(sql, search, new ComponentMapper());

		Set<BigDecimal> componentIds = new HashSet<BigDecimal>();
		for (CompoenentDTO o : orgChart) {
			if (o.getComponentId() != null) {
				componentIds.add(o.getComponentId());
			}
		}
		LogUtil.logInfo(m_Logger,"servivce getUserList EXECUTE getOrgChart END");
		LogUtil.logInfo(m_Logger,"servivce getUserList EXECUTE query start");
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("ids", componentIds);
		NamedParameterJdbcTemplate npJbdcTemplate = new NamedParameterJdbcTemplate(this.jdbcTemplate.getDataSource());
		String queryUserList = "SELECT distinct null as UAM_COMPONENT_ID "// null
																			// as
																			// by
																			// charley
																			// 20180428
				+ ",'MEMBER' as UAM_USER_POSITION" // null as by charley
													// 20180428
				+ ",h.LOGINID" + ",h.DISPLAYNAME" + ",h.DEPARTMENT as UAM_USER_DEPARTMENT" // null as by charley
																							// 20180428
				+ ",h.DELIVERYSTRING, h.COMPANY as USERCOMPANY, h.UAM_USER_OFFICE_NUMBER"
				+ ",h.UAM_USER_PHONE_NUMBER, h.ACTIVESTATUS, concat((SELECT distinct STUFF("
				+ "(SELECT ',' + CAST(T3.UAM_COMPONENT_NAME AS VARCHAR(MAX))  FROM FD_UAM_USERCOMPONENT_REF T2 left join FD_UAM_COMPONENT T3 on T3.UAM_COMPONENT_ID = t2.UAM_COMPONENT_ID WHERE T2.UAM_USER_POSITION = 'MEMBER' and upper(t1.UAM_USER_ID) = upper(t2.UAM_USER_ID) AND  (T2.UAM_DELETE_FLAG IS NULL OR T2.UAM_DELETE_FLAG != 1)   FOR XML path('')),1,1,'') componentNames FROM FD_UAM_USERCOMPONENT_REF T1"
				+ " where upper(t1.UAM_USER_ID) = upper(h.LOGINID) AND  (T1.UAM_DELETE_FLAG IS NULL OR T1.UAM_DELETE_FLAG != 1)),'') as UAM_USER_TEAM"
//				+ ",c.UAM_COMPONENT_NAME as UAM_USER_TEAM" // null as by charley 20180428
				+ " FROM FD_UAM_USERCOMPONENT_REF r ,( SELECT S.LOGINID, S.DISPLAYNAME"
				+ " ,S.DELIVERYSTRING ,( CASE WHEN S.ACTIVESTATUS = 'Active' THEN ( CASE"
				+ " WHEN isnull(L.USERLANID, '') != '' THEN  ( CASE"
				+ " WHEN isnull(L.DATE_TYPE, '') = 'AM' and dateName(hh,getdate()) > 11 " + " THEN ''"
				+ " WHEN isnull(L.DATE_TYPE, '') = 'PM' and dateName(hh,getdate()) < 12 "
				+ " THEN '' ELSE L.LEAVE_TYPE END) ELSE '' END) ELSE S.ACTIVESTATUS END"
				+ " ) AS ACTIVESTATUS ,U.* FROM [dbo].[SONORAUSERS] S"
				+ " JOIN [dbo].[FD_UAM_USERS] U ON upper(S.LOGINID) = upper(U.UAM_USER_ID)"
				+ " LEFT JOIN fd_leave_management l ON upper(s.LOGINID) = upper(l.USERLANID) and CONVERT(varchar(12) ,l.LEAVE_DATE, 112 )=CONVERT(varchar(12) ,getDate(), 112 ) and l.DELETE_FLAG=0 WHERE upper(S.ACTIVESTATUS) = 'ACTIVE'"
				+ " ) h,FD_UAM_COMPONENT c"
				+ " WHERE r.UAM_COMPONENT_ID = c.UAM_COMPONENT_ID and upper(r.UAM_USER_ID) = upper(h.LOGINID) and r.UAM_USER_POSITION='MEMBER' and isnull(r.UAM_DELETE_FLAG, 0) != 1";// add
																																			// and
																																			// r.UAM_USER_POSITION='MEMBER'
																																			// by
																																			// charley
																																			// 20180423
																																			// only
																																			// get
																																			// users
																																			// which
																																			// position
																																			// is
																																			// MEMBER
		if ("1".equalsIgnoreCase(processFlag.trim())) {
			queryUserList += " and EXISTS (select DISTINCT ur.uam_user_id" + " from "
						   	      + " FD_UAM_USERROLE_REF ur with(nolock) join FD_UAM_ROLE r with(nolock) on ur.UAM_ROLE_ID = r.UAM_ROLE_ID "
						   	      + " join FD_UAM_ROLEMENU_REF urm with(nolock) on ur.UAM_ROLE_ID = urm.UAM_ROLE_ID"
						   	      + " join FD_UAM_MENU m with(nolock) on urm.menu_id = m.menu_id"
						   	      + " where r.UAM_ROLE_TYPE = 'Functional' and isnull(r.UAM_IS_ENABLE, 0) = 1 and isnull(m.DELETE_FLAG, 0) = 0"
						   	      + " and m.menu_id = 'BPROCCASE' AND h.LOGINID = ur.uam_user_id and isnull(ur.UAM_DELETE_FLAG, 0) = 0)";
			   }
		List<UserInOrg> userInOrgs = null;

		if (componentIds.size() > 0) {
			queryUserList += " and r.UAM_COMPONENT_ID IN (:ids)";
			userInOrgs = (List<UserInOrg>) npJbdcTemplate.query(queryUserList, parameters, new UserInOrgMapper());
		} else {
			userInOrgs = (List<UserInOrg>) this.jdbcTemplate.query(queryUserList, new UserInOrgMapper());
		}

		LogUtil.logInfo(m_Logger,"servivce getUserList EXECUTE query end");
		List<Map<String, Object>> allUserList = new ArrayList<Map<String, Object>>();

		for (UserInOrg u : userInOrgs) {

			allUserList.add(u.toMapper());
		}
		resultData.put(TEAMLEADERSSTR, queryResult);
		resultData.put("TEAMMEMBERS", allUserList);
		outputVO.setDatas(resultData);
		return outputVO;
	}

	// add by bsnpc65 2018-9-19 begin
	/**
	 * All members of all groups under this compnent get all user(include active and
	 * inactive)
	 */
	@Override
	public OutputVO getAllUserList(Map<String, Object> request)  throws RemoteException {
		LogUtil.logInfo(m_Logger,"servivce getUserList start");
		OutputVO outputVO = new OutputVO();
		Map<String, Object> resultData = new ConcurrentHashMap<String, Object>();
		String componentId = request.get(COMPONENTID) == null ? "" : request.get(COMPONENTID).toString();
		if (StringUtils.isBlank(componentId)) {
			outputVO.addErrorInfo(NULLINPUTMSG);
			LogUtil.logInfo(m_Logger,NULLINPUTMSG);
			return outputVO;
		}
		LogUtil.logInfo(m_Logger, String.format("componentId : %s", componentId));
		Integer parentId = Integer.parseInt(componentId);
		LogUtil.logInfo(m_Logger,"servivce getUserList QUERY TEAMLEADER start");
		List<Map<String, String>> queryResult = userAuthorityDao.queryAllUsers(parentId);
		LogUtil.logInfo(m_Logger,"servivce getUserList QUERY TEAMLEADER end");
		resultData.put("TEAMMEMBERS", queryResult);
		LogUtil.logInfo(m_Logger,"queryResult:" + queryResult.size());
		outputVO.setDatas(resultData);
		LogUtil.logInfo(m_Logger,"servivce getUserList end");
		return outputVO;
	}
	// add by bsnpc65 2018-9-19 end

	final String queryMaxComponentId = "SELECT MAX(UAM_COMPONENT_ID) UAM_COMPONENT_ID FROM FD_UAM_COMPONENT ";
	final String insertComponentId = "INSERT INTO FD_UAM_COMPONENT (UAM_COMPONENT_ID,UAM_COMPONENT_NAME,UAM_COMPONENT_PARENTID,UAM_COMPONENT_TYPE,DELETE_FLAG) values (?,?,?,?,?)";

	// add
	@Override
	public String addComponent(Map<String, Object> componentInfo)  throws RemoteException {
		LogUtil.logInfo(m_Logger,"UAMOrganizationStructureServiceImpl addComponent params:" + componentInfo);
		Map<String, String> validateMap = new ConcurrentHashMap<String, String>();
		validateMap.put(UAMCOMPONENTIDSTR,valueIsNull(componentInfo.get(UAMCOMPONENTIDSTR)));
		validateMap.put(COMPANYNAMESTR,valueIsNull(componentInfo.get(COMPANYNAMESTR)));
		validateMap.put(COMPANYTYPESTR,valueIsNull(componentInfo.get(COMPANYTYPESTR)));
		validateMap.put(PARENTIDSTR,valueIsNull(componentInfo.get(PARENTIDSTR)));

		List<Map<String, Object>> maxComponentIdRes = this.jdbcTemplate.queryForList(queryMaxComponentId);

		int resultSize = maxComponentIdRes.size();
		LogUtil.logInfo(m_Logger,"resultSize:" + resultSize);
		if (resultSize == 0) {
			throw new CustomException("get MaxComponentId  failure(Wrong Row Id is specified.)",
					HttpStatus.BAD_REQUEST);
		}
		BigDecimal compontIdMax = ((BigDecimal) maxComponentIdRes.get(0).get(Constants.UAM_COMPONENT_ID))
				.add(new BigDecimal(1));
		int isSuccess = this.jdbcTemplate.update(insertComponentId, compontIdMax, validateMap.get(COMPANYNAMESTR),
				validateMap.get(PARENTIDSTR), validateMap.get(COMPANYTYPESTR), "0");
		// update component leaders
		// delete first, then insert
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> teadLeaders = (List<Map<String, Object>>) componentInfo.get(TEAMLEADERSSTR);
		StringBuilder leaderAudit = new StringBuilder();
		if (isSuccess > 0 && teadLeaders != null && teadLeaders.size() > 0) {
			leaderAudit.append(" add leader:");
			List<String> userList = new ArrayList<String>();
			// replace componet id to the correct one(new one)
			for (Map<String, Object> tM : teadLeaders) {
				tM.remove("componentId");
				tM.put("componentId", compontIdMax);
				String position =valueIsNull(tM.get(LOWERPOSITIONSTR));
				position = position.replace("\r\n", "").replace("\r", "").replace("\n", "");
				tM.remove(LOWERPOSITIONSTR);
				tM.put(LOWERPOSITIONSTR, position);
				if (!StringUtils.isBlank(valueIsNull(tM.get(USERIDSTR)))) {
					userList.add(tM.get(USERIDSTR).toString());
				}
			}
			if (userList != null && userList.size() > 0) {
				String userNMs = userAuthorityDao.getUserNames(userList);
				leaderAudit.append(userNMs);
			} else {
				// clear the audit
				leaderAudit = new StringBuilder();
			}
			userAuthorityDao.deleteComponentLeader(compontIdMax.intValue());
			userAuthorityDao.insertComponentLeader(teadLeaders);
		}

		// 2018/06/26 add audit trail add by cuixin -Start
		String actionDesc = "Add " + validateMap.get(COMPANYTYPESTR) + ":" + validateMap.get(COMPANYNAMESTR) + " "
				+ leaderAudit.toString();
		String loginUserId = userHelper.getCurrentUser();
		UAMAuditTrail auditTrailParam = new UAMAuditTrail();
		auditTrailParam.setActionDesc(actionDesc);
		auditTrailParam.setCategory("COMPONENT");
		auditTrailParam.setUamComponentName(compontIdMax.toString());
		auditTrailParam.setUamUserId(loginUserId);
		auditTrailDao.addUAMAuditTrail(auditTrailParam);
		// 2018/06/26 add audit trail add by cuixin -End

		LogUtil.logInfo(m_Logger,"isSuccess:" + isSuccess);
		return compontIdMax.toString();
	}
	
	

	final String updateComponent = "update FD_UAM_COMPONENT set UAM_COMPONENT_NAME = ?, UAM_COMPONENT_TYPE = ? where UAM_COMPONENT_ID = ?";

	@Override
	public String updateComponent(Map<String, Object> params)  throws RemoteException {
		String componentId = params.get(UAMCOMPONENTIDSTR).toString();
		if (componentId != null && componentId.equals("-1")) {
			return addComponent(params);
		}
		// update component leaders
		// delete first, then insert
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> teadLeaders = (List<Map<String, Object>>) params.get(TEAMLEADERSSTR);

		// 2018/06/26 add audit trail add by cuixin -Start
		String tmUserIds = "";
		String tmPositions = "";

		if (teadLeaders != null && teadLeaders.size() > 0) {
			for (Map<String, Object> teamLeaderMapping : teadLeaders) {
				if (StringUtils.isBlank(String.valueOf(teamLeaderMapping.get(USERIDSTR)))) {// add logic to ignore blank
																							// userid by charley
																							// 20180925
					continue;
				}
				if (tmUserIds.length() > 0) {
					tmUserIds += ",";
					tmPositions += ",";
				}
				tmUserIds += String.valueOf(teamLeaderMapping.get(USERIDSTR));
				tmPositions += String.valueOf(teamLeaderMapping.get(LOWERPOSITIONSTR));
			}
		}

		String loginUserId = userHelper.getCurrentUser();

		String companyName = valueIsNull(params.get(COMPANYNAMESTR));
		String companyType = valueIsNull(params.get(COMPANYTYPESTR));

		UpdateComponentAuditTrail updateComponentAuditTrail = new UpdateComponentAuditTrail();
		updateComponentAuditTrail.setLoginUser(loginUserId);
		updateComponentAuditTrail.setTmUserIds(tmUserIds);
		updateComponentAuditTrail.setTmPositions(tmPositions.replace("\r\n", "").replace("\r", "").replace("\n", ""));
		updateComponentAuditTrail.setCompanyName(companyName);
		updateComponentAuditTrail.setCompanyType(companyType);
		updateComponentAuditTrail.setComponentId(new BigDecimal(componentId));
		auditTrailDao.updateComponentAuditTrail(updateComponentAuditTrail);
		// 2018/06/26 add audit trail add by cuixin -End

		userAuthorityDao.deleteComponentLeader(Integer.parseInt(componentId));
		insertComponentLeader(teadLeaders);
		int isSuccess = jdbcTemplate.update(updateComponent, params.get(COMPANYNAMESTR), params.get(COMPANYTYPESTR),
				params.get(UAMCOMPONENTIDSTR));

		if (isSuccess == 0) {
			throw new CustomException("update component failure", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return componentId;
	}

  private void insertComponentLeader(List<Map<String, Object>> teadLeaders) throws RemoteException {
    if (teadLeaders != null && teadLeaders.size() > 0) {
			List<Map<String, Object>> insertLeaders = new ArrayList<Map<String, Object>>();
			for (Map<String, Object> tM : teadLeaders) {// REMOVE \R\N
				if (StringUtils.isBlank(String.valueOf(tM.get(USERIDSTR)))) {// add logic to ignore blank userid by
																			// charley 20180925
					continue;
				}
				String position = valueIsNull(tM.get(LOWERPOSITIONSTR));
				position = position.replace("\r\n", "").replace("\r", "").replace("\n", "");
				tM.remove(LOWERPOSITIONSTR);
				tM.put(LOWERPOSITIONSTR, position);
				insertLeaders.add(tM);
			}
			userAuthorityDao.insertComponentLeader(insertLeaders);
		}
  }

	final String deleteComponent = "update FD_UAM_COMPONENT set DELETE_FLAG = 1 where UAM_COMPONENT_ID = ?";

	@Override
	public boolean deleteComponent(String componentId)  throws RemoteException {

		if (componentId == null || componentId.trim().length() == 0) {
			return false;
		}
		int isSuccess = this.jdbcTemplate.update(deleteComponent, Integer.parseInt(componentId));// modify parameter
																									// componentId
																									// from String to
																									// Integer by
												// charley 20180416

		if (isSuccess == 0) {
			throw new CustomException("update component failure", HttpStatus.INTERNAL_SERVER_ERROR);
		}

		// 2018/06/26 add audit trail add by cuixin -Start
		String loginUser = userHelper.getCurrentUser();

		auditTrailDao.deleteComponentAuditTrail(new BigDecimal(componentId), loginUser);
		// 2018/06/26 add audit trail add by cuixin -End

		return isSuccess > 0;

	}

	// Find all the child nodes based on the parent node
	private List<Map<String, Object>> findChildByParent(String parentId) throws RemoteException {

		String queryGetUamComponentIdList = "SELECT DISTINCT A.UAM_COMPONENT_CODE,A.UAM_COMPONENT_ID as companyId,A.UAM_COMPONENT_NAME as companyName,A.UAM_COMPONENT_PARENTID as parentId,A.UAM_COMPONENT_TYPE, B.UAM_COMPONENT_NAME  parentCompanyName FROM FD_UAM_COMPONENT A left join FD_UAM_COMPONENT B on A.UAM_COMPONENT_PARENTID=B.UAM_COMPONENT_ID ";

		List<Map<String, Object>> queryResult = new ArrayList<Map<String, Object>>();
		if (parentId == null || parentId.trim().length() == 0) {
			return queryResult;
		} else if (parentId.equals(Constants.ALLORGS)) {
			queryResult = jdbcTemplate.queryForList(queryGetUamComponentIdList + " WHERE isnull(A.DELETE_FLAG,0) != 1");
		} else {
			queryGetUamComponentIdList += " where B.UAM_COMPONENT_ID = ? and isnull(A.DELETE_FLAG,0) != 1";
			queryResult = jdbcTemplate.queryForList(queryGetUamComponentIdList, parentId);
		}

		return queryResult;
	}


	@Override
	public List<Map<String, Object>> findAllLeader() {
		String sql = "select upper(UAM_USER_ID) from FD_UAM_USERS";
		List<Map<String, Object>> queryForList = jdbcTemplate.queryForList(sql);
		return queryForList;
	}

	@Override
	public OutputVO organizationlist(final String parentId)  throws RemoteException {
		LogUtil.logInfo(m_Logger,"service organizationlist sart. parentId:" + parentId);
		OutputVO outputVO = new OutputVO();
		// get org datas from DB
		List<Map<String, Object>> treeDatas =  findChildByParent(parentId);
		// find the root
		Map<String, Object> rootTree = getNode(parentId, treeDatas);
		if (rootTree.isEmpty()) {
			// return null data or add error info
			outputVO.addErrorInfo("no organzation");
			return outputVO;
		}
		String nodeId = rootTree.get(COMPANYIDSTR) == null ? "" : rootTree.get(COMPANYIDSTR).toString();
		// get root case childs
		List<Map<String, Object>> childs = getChilds(treeDatas, nodeId);
		if (!childs.isEmpty()) {
			rootTree.put("items", childs);
		}
		outputVO.setDatas(rootTree);
		return outputVO;
	}

	/**
	 * get node's childs
	 * 
	 * @param treeDatas
	 * @param parentId
	 * @return
	 */
	private List<Map<String, Object>> getChilds(List<Map<String, Object>> treeDatas, String parentId) {
		List<Map<String, Object>> child = new ArrayList<Map<String, Object>>();
		for (Map<String, Object> map : treeDatas) {
			String mPid = map.get(LOCALPARENT_ID) == null ? "" : map.get(LOCALPARENT_ID).toString();
			String componentid = map.get(COMPANYIDSTR).toString();
			if (parentId.equalsIgnoreCase(mPid)) {
				List<Map<String, Object>> subChild = getChilds(treeDatas, componentid);
				if (subChild != null && subChild.size() > 0) {
					map.put("items", subChild);
				}
				child.add(map);
			}
		}
		return child;
	}

	/**
	 * get node info by node id
	 * 
	 * @param parentId
	 * @param parentTreeList
	 * @return
	 */
	private Map<String, Object> getNode(String nodeId, List<Map<String, Object>> treeDatas) {
		Map<String, Object> res = new HashMap<String, Object>();
		if (treeDatas != null && treeDatas.size() > 0) {
			for (Map<String, Object> m : treeDatas) {
				String componentId = valueIsNull(m.get(COMPANYIDSTR)) ;
				String parentId =valueIsNull( m.get(LOCALPARENT_ID));
				if (Constants.ALLORGS.equalsIgnoreCase(nodeId)) {
					// find tree root node which has no parent node
					if ("".equalsIgnoreCase(parentId)) {
						res = m;
						break;
					}
				} else if (nodeId.equalsIgnoreCase(componentId)) {
					res = m;
					break;
				}
			}
		}
		return res;
	}

	/**
	 * get team's request type & activity settings
	 */
	@Override
	public OutputVO getTeamSetting(Map<String, Object> request)  throws RemoteException {
		LogUtil.logInfo(m_Logger,"service getTeamSetting start, params : " + request);
		OutputVO outputVO = new OutputVO();
		// get current user & team id
		String userId = userHelper.getCurrentUser();
		if (StringUtils.isBlank(userId)) {
			LogUtil.logError(m_Logger, "cannot get current login userid");
			outputVO.addErrorInfo("cannot get current login userid");
			return outputVO;
		}
		int teamId = request.get(TEAMIDSTR) == null ? 0 : Integer.parseInt(request.get(TEAMIDSTR).toString());
		if (teamId == 0) {
			LogUtil.logError(m_Logger, "incorrect team id : " + teamId);
			outputVO.addErrorInfo("incorrect team info");
			return outputVO;
		}
		// call procedure to query team setting
		List<Map<String, Object>> teamSettings = userAuthorityDao.queryTeamSetting(teamId, userId);
		// query team agency location
		String agencyLocation = userAuthorityDao.queryTeamAgencyLocation(teamId);
		// query team amount authority
		List<Map<String, Object>> teamAmountAuthority = userAuthorityDao.queryTeamAmountAuthority(teamId);
		// construct team amount authority
		List<Map<String, Object>> tsarAuthList = new ArrayList<>();
		List<Map<String, Object>> premiumAuthList = new ArrayList<>();
		if(teamAmountAuthority != null && teamAmountAuthority.size() > 0){
			for(Map<String, Object> m : teamAmountAuthority){
				String valueType = CommonUtil.getString(m.get("VALUE_TYPE"), "");
				if("TSAR".equalsIgnoreCase(valueType)){
					tsarAuthList.add(m);
				} else {
					premiumAuthList.add(m);
				}
			}
		}
		Map<String, Object> datas = new HashMap<>();
		datas.put("TEAMREQ", teamSettings);
		datas.put("AGENCY_LOCATION", agencyLocation);
		datas.put("TSAR_AUTH", tsarAuthList);
		datas.put("PREMIUM_AUTH", premiumAuthList);
		outputVO.setDatas(datas);
		LogUtil.logInfo(m_Logger,"service getTeamSetting end");
		return outputVO;
	}

	/**
	 * update team setting
	 */
	@SuppressWarnings("unchecked")
	@Override
	public OutputVO updateTeamSetting(Map<String, Object> request)  throws RemoteException {
		LogUtil.logInfo(m_Logger,"service updateTeamSetting start:" + request);
		OutputVO outputVO = new OutputVO();
		// get team id
		final int teamId = request.get(TEAMIDSTR) == null ? 0 : Integer.parseInt(request.get(TEAMIDSTR).toString());
		if (teamId == 0) {
			outputVO.addErrorInfo("illegal TEAMID");
			return outputVO;
		}
		String userId = userHelper.getCurrentUser();

		// 2018/06/26 add audit trail add by cuixin -Start
		String reqIds = "";
		String actIds = "";

		List<Map<String, Object>> reqActMappingList = (List<Map<String, Object>>) request.get("SETLIST");
		if (reqActMappingList != null && reqActMappingList.size() > 0) {
			for (Map<String, Object> reqActMapping : reqActMappingList) {
				if (reqIds.length() > 0) {
					reqIds += ",";
					actIds += ",";
				}
				reqIds += String.valueOf(reqActMapping.get("REQTYPE"));
				actIds += String.valueOf(reqActMapping.get("ACTNAME"));
			}
		}

		EditUamTeamSettingAuditTrail teamSettingParam = new EditUamTeamSettingAuditTrail();
		teamSettingParam.setLoginUser(userId);
		teamSettingParam.setComponentId(new BigDecimal(teamId));
		teamSettingParam.setReqIds(reqIds);
		teamSettingParam.setActIds(actIds);
		auditTrailDao.editUAMTeamSettingAuditTrail(teamSettingParam);
		// 2018/06/26 add audit trail add by cuixin -End

		userAuthorityDao.deleteTeamSetting(teamId);
		List<Map<String, Object>> settingList = (List<Map<String, Object>>) request.get("SETLIST");
		if (settingList != null && settingList.size() > 0) {
			for (Map<String, Object> oneSet : settingList) {
				oneSet.put(TEAMIDSTR, teamId);
				oneSet.put("USERID", userId);
			}
			userAuthorityDao.insertTeamSetting(settingList);
		}
		outputVO = processTeamAmountAuth(teamId, request);
		LogUtil.logInfo(m_Logger,"service updateTeamSetting end");
		return outputVO;
	}

	private OutputVO processTeamAmountAuth(int teamId, Map<String, Object> request) {
		OutputVO outputVO = new OutputVO();
		try {
			List<Map<String, Object>> amountAuthMapList = (List<Map<String, Object>>) request.get("AUTH");
			//  delete team's amount authority configuration & add new record for team's amount
			userAuthorityDao.updateTeamAmountAuthority(teamId, amountAuthMapList);
			String agencyLocation = CommonUtil.getString(request.get("AGENCY_LOCATION"), "");
			userAuthorityDao.updateTeamAgencyLocation(teamId, agencyLocation);
		} catch (RemoteException e) {
			LogUtil.logException(m_Logger, "process team amount authority failed", e);
			outputVO.addInfo("updateTeamSetting failed", e.getMessage(), OutputVO.FAIL_CODE);
		}
		return outputVO;
	}

	@Override
	public OutputVO getTeamMember(Map<String, Object> request)  throws RemoteException {
		LogUtil.logInfo(m_Logger,"service getTeamMember start, params : " + request);
		OutputVO outputVO = new OutputVO();
		String loginUser = request.get("loginUser") == null ? null : request.get("loginUser").toString();
		if (StringUtils.isEmpty(loginUser)) {
			outputVO.addErrorInfo(NULLINPUTMSG);
			return outputVO;
		}
		List<Map<String, Object>> teamMemberMap = userAuthorityDao.queryTeamMember(loginUser);
		outputVO.setDatas(teamMemberMap);
		LogUtil.logInfo(m_Logger,"service getTeamMember end");
		return outputVO;
	}
	
	private String valueIsNull(Object value){
      
      if(value==null){
        return "";
      }else if("".equals(value.toString().trim())){
        return "";
      }else if(value.toString().trim().length()==0){
        return "";
      }else{
        return value.toString().trim();
      }
    }
}
