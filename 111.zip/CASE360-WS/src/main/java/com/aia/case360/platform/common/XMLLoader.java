package com.aia.case360.platform.common;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;

/**
 * XML helpers
 * 
 * @author hophVWK
 *
 */
public class XMLLoader {
	
	private XMLLoader() {}
	private static final Logger LOG = LoggerFactory.getLogger(XMLLoader.class);
	private static final DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
	private static DocumentBuilder db = null;

	static {
		try {
			dbf.setNamespaceAware(true);
			db = dbf.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			LOG.error("Unable to instantiate the XML parser", e);
		}
	}

	/**
	 * Create a new empty document
	 * 
	 * @return
	 */
	public static Document createEmptyDocument() {
		return db.newDocument();
	}
}
