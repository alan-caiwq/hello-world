package com.aia.case360.web.pojo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import com.aia.case360.web.auditTrail.AuditEntityIgnoreCondition;
import com.aia.case360.web.auditTrail.AuditFieldSpecialAction;
import com.aia.case360.web.auditTrail.AuditFileTypeEnum;
import com.aia.case360.web.auditTrail.AuditTrail;
import com.aia.case360.web.auditTrail.annotation.AuditEntity;
import com.aia.case360.web.auditTrail.annotation.AuditField;
import com.aia.case360.web.common.CommonUtil;
import com.fasterxml.jackson.annotation.JsonFormat;

@AuditEntity(entityName = "Activity", formDataName = "FD_ACT_INFO", tableName = "FD_ACT_INFO")
public class ActInfo implements AuditTrail {
	private String acl;
	private BigDecimal sRowid;

	@AuditField(fieldName = "Activity Name", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private String actNm;

	@AuditField(fieldName = "Batch Submission", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private int batchSubmission;
	private String createdBy;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	private Date effectiveDate;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	private Date createdTimestamp;

	private short isEnabled;
	private String lastUpdatedBy;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	private Date lastUpdatedTimestamp;

	private int sequenceNum;

	private String workstepname;

	@AuditField(fieldName = "SLA Hours", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private BigDecimal slaHour;
	private String reqType;
	private int versionNum;

	@AuditField(fieldName = "Is TrainerReview", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private short isTrainerReview;

	@AuditField(fieldName = "ActionSignal Value", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private String actionSignalValue;

	@AuditField(fieldName = "Processor Type", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private int processorType;

	@AuditField(fieldName = "Action Signal Type", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private int actionSignalType;

	@AuditField(fieldName = "Processor Act", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private String processorAct;

	@AuditField(fieldName = "Processor Type", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private String processorReqtype;

	public String getAcl() {
		return acl;
	}

	public void setAcl(String acl) {
		this.acl = acl;
	}

	public String getActNm() {
		return actNm;
	}

	public void setActNm(String actNm) {
		this.actNm = actNm;
	}

	public int getBatchSubmission() {
		return batchSubmission;
	}

	public void setBatchSubmission(int batchSubmission) {
		this.batchSubmission = batchSubmission;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public short getIsEnabled() {
		return isEnabled;
	}

	public void setIsEnabled(short isEnabled) {
		this.isEnabled = isEnabled;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Date lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public BigDecimal getsRowid() {
		return sRowid;
	}

	public void setsRowid(BigDecimal sRowid) {
		this.sRowid = sRowid;
	}

	public int getSequenceNum() {
		return sequenceNum;
	}

	public void setSequenceNum(int sequenceNum) {
		this.sequenceNum = sequenceNum;
	}

	public String getWorkstepname() {
		return workstepname;
	}

	public void setWorkstepname(String workstepname) {
		this.workstepname = workstepname;
	}

	public BigDecimal getSlaHour() {
		return slaHour;
	}

	public void setSlaHour(BigDecimal slaHour) {
		this.slaHour = slaHour;
	}

	public String getReqType() {
		return reqType;
	}

	public void setReqType(String reqType) {
		this.reqType = reqType;
	}

	public int getVersionNum() {
		return versionNum;
	}

	public void setVersionNum(int versionNum) {
		this.versionNum = versionNum;
	}

	public short getIsTrainerReview() {
		return isTrainerReview;
	}

	public void setIsTrainerReview(short isTrainerReview) {
		this.isTrainerReview = isTrainerReview;
	}

	public String getActionSignalValue() {
		return actionSignalValue;
	}

	public void setActionSignalValue(String actionSignalValue) {
		this.actionSignalValue = actionSignalValue;
	}

	public int getProcessorType() {
		return processorType;
	}

	public void setProcessorType(int processorType) {
		this.processorType = processorType;
	}

	public int getActionSignalType() {
		return actionSignalType;
	}

	public void setActionSignalType(int actionSignalType) {
		this.actionSignalType = actionSignalType;
	}

	public String getProcessorAct() {
		return processorAct;
	}

	public void setProcessorAct(String processorAct) {
		this.processorAct = processorAct;
	}

	public String getProcessorReqtype() {
		return processorReqtype;
	}

	public void setProcessorReqtype(String processorReqtype) {
		this.processorReqtype = processorReqtype;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	@Override
	public String toString() {
		return "ActInfo [acl=" + acl + ", actNm=" + actNm + ", batchSubmission=" + batchSubmission + ", createdBy="
				+ createdBy + ", createdTimestamp=" + createdTimestamp + ", isEnabled=" + isEnabled + ", lastUpdatedBy="
				+ lastUpdatedBy + ", lastUpdatedTimestamp=" + lastUpdatedTimestamp + ", sRowid=" + sRowid
				+ ", sequenceNum=" + sequenceNum + ", workstepname=" + workstepname + ", slaHour=" + slaHour
				+ ", reqType=" + reqType + ", versionNum=" + versionNum + ", isTrainerReview=" + isTrainerReview
				+ ", actionSignalValue=" + actionSignalValue + ", processorType=" + processorType
				+ ", actionSignalType=" + actionSignalType + ", processorAct=" + processorAct + ", effectiveDate="
				+ effectiveDate + ", processorReqtype=" + processorReqtype + "]";
	}

	@Override
	public List<AuditFieldSpecialAction> registFieldSpecialActionlist() {

		List<AuditFieldSpecialAction> result = null;
		return result;
	}

	@Override
	public BigDecimal getRowID() {
		if(getsRowid() != null && getsRowid().intValue() > 0){
			return getsRowid();
		}
		return null;
	}

	@Override
	public String getKeyDisplayName() {
		return getActNm();
	}

	@Override
	public String getKey() {
		return CommonUtil.getString(reqType);
	}

	@Override
	public List<AuditEntityIgnoreCondition> registIgnoreEntitylist() {

		List<AuditEntityIgnoreCondition> ignoreList = new ArrayList<AuditEntityIgnoreCondition>();
		ignoreList.add(new AuditEntityIgnoreCondition("isEnabled", (short) 0));

		return ignoreList;
	}

}
