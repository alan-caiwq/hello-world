package com.aia.case360.web.pojo;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import com.aia.case360.web.auditTrail.AuditEntityIgnoreCondition;
import com.aia.case360.web.auditTrail.AuditFieldSpecialAction;
import com.aia.case360.web.auditTrail.AuditFileTypeEnum;
import com.aia.case360.web.auditTrail.AuditTrail;
import com.aia.case360.web.auditTrail.annotation.AuditEntity;
import com.aia.case360.web.auditTrail.annotation.AuditField;
import com.fasterxml.jackson.annotation.JsonFormat;

@AuditEntity(entityName = "Request Type", formDataName = "Request type audit trail", tableName = "FD_REQTYPE_AUDITTRAIL")
public class FdReqType implements AuditTrail {

	private String acl;
	private BigDecimal sRowid;

	@AuditField(fieldName = "Request Type Code", fieldType = AuditFileTypeEnum.FIELD)
	private String reqTypeCode;

	@AuditField(fieldName = "QA Type", fieldType = AuditFileTypeEnum.FIELD)
	private String qaType;

	@AuditField(fieldName = "Target", fieldType = AuditFileTypeEnum.FIELD)
	private String target;

	@AuditField(fieldName = "Benchmark", fieldType = AuditFileTypeEnum.FIELD)
	private String benchmark;

	@AuditField(fieldName = "Request Type", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private String reqType;

	@AuditField(fieldName = "SLA Days", fieldType = AuditFileTypeEnum.FIELD)
	private int slaDays;

	@AuditField(fieldName = "Department", fieldType = AuditFileTypeEnum.FIELD)
	private String department;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	@AuditField(fieldName = "Effective Date", fieldType = AuditFileTypeEnum.FIELD)
	private Date effectiveDate;

	@AuditField(fieldName = "Is Disable", fieldType = AuditFileTypeEnum.FIELD)
	private short isDisable;

	@AuditField(fieldName = "Is Urgent", fieldType = AuditFileTypeEnum.FIELD)
	private short isUrgent;

	// @AuditField(fieldName = "Status", fieldType = AuditFileTypeEnum.FIELD)
	private String reqtypeStatus;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	private Date createdTimestamp;

	private String createdBy;
	private String lastUpdatedBy;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	private Date lastUpdatedTimestamp;

	@AuditField(fieldName = "Display Name", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private String displayName;

	@AuditField(fieldName = "Process Name", fieldType = AuditFileTypeEnum.FIELD)
	private String processNm;
	
	// 
	private String subTemplate;
	
	public String getSubTemplate() {
		return subTemplate;
	}

	public void setSubTemplate(String subTemplate) {
		this.subTemplate = subTemplate;
	}

	private int versionNum;

	// @AuditField(fieldName = "Request Type Group", fieldType =
	// AuditFileTypeEnum.FIELD)
	private String reqTypeGrp;
	@AuditField(fieldName = "Request Type Description", fieldType = AuditFileTypeEnum.FIELD)
	private String reqTypeDesc;

	@AuditField(fieldName = "Cut Over Time ", fieldType = AuditFileTypeEnum.FIELD)
	private String cutOffTime;

	@AuditField(fieldName = "Buddy Check", fieldType = AuditFileTypeEnum.FIELD)
	private short buddyCheck;
	@AuditField(fieldName = "Buddy Request Type", fieldType = AuditFileTypeEnum.FIELD)
	private String buddyReqType;

	@AuditField(fieldName = "Category", fieldType = AuditFileTypeEnum.FIELD)
	private String category;
	private short rejectgetjob;

	@AuditField(fieldName = "Traffic Light Value1", fieldType = AuditFileTypeEnum.FIELD)
	private int trafficLightValue1;
	@AuditField(fieldName = "Traffic Light Value2", fieldType = AuditFileTypeEnum.FIELD)
	private int trafficLightValue2;
	private String subReqtypeList;

	@AuditField(fieldName = "Action Informations", fieldType = AuditFileTypeEnum.RELATION)
	private List<ActInfo> actInfos;

	@AuditField(fieldName = "Mandatory Docs", fieldType = AuditFileTypeEnum.RELATION)
	private List<MandatoryDoc> mandatoryDocs;

	@AuditField(fieldName = "Check List", fieldType = AuditFileTypeEnum.RELATION)
	private List<ReqTypeCheckItem> checklist;

	@AuditField(fieldName = "Buddy Req Type", fieldType = AuditFileTypeEnum.RELATION)
	private List<String> buddyReqTypeList;

	@AuditField(fieldName = "Version List", fieldType = AuditFileTypeEnum.RELATION)
	private List<ReqTypeVersion> versionList;

	private BigDecimal parentId;

	private String dataFrom;
	
	@AuditField(fieldName = "UNI Options", fieldType = AuditFileTypeEnum.FIELD)
	private String valueType;
	
	@AuditField(fieldName = "Risk Type", fieldType = AuditFileTypeEnum.FIELD)
	private String riskType;
	
	@AuditField(fieldName = "SAR Group", fieldType = AuditFileTypeEnum.FIELD)
	private String sarGroup;
	
	@AuditField(fieldName = "Premium Type", fieldType = AuditFileTypeEnum.FIELD)
	private String premiumType;

	
	
	/**
   * @return the premiumType
   */
  public String getPremiumType() {
    return premiumType==null?"":premiumType;
  }

  /**
   * @param premiumType the premiumType to set
   */
  public void setPremiumType(String premiumType) {
    this.premiumType = premiumType;
  }

  /**
   * @return the valueType
   */
  public String getValueType() {
    return valueType==null?"":valueType;
  }

  /**
   * @return the riskType
   */
  public String getRiskType() {
    return riskType==null?"":riskType;
  }

  /**
   * @return the sarGroup
   */
  public String getSarGroup() {
    return sarGroup==null?"":sarGroup;
  }

  /**
   * @param valueType the valueType to set
   */
  public void setValueType(String valueType) {
    this.valueType = valueType;
  }

  /**
   * @param riskType the riskType to set
   */
  public void setRiskType(String riskType) {
    this.riskType = riskType;
  }

  /**
   * @param sarGroup the sarGroup to set
   */
  public void setSarGroup(String sarGroup) {
    this.sarGroup = sarGroup;
  }

  public String getReqType() {
		return reqType;
	}

	public void setReqType(String reqType) {
		this.reqType = reqType;
	}

	public int getSlaDays() {
		return slaDays;
	}

	public void setSlaDays(int slaDays) {
		this.slaDays = slaDays;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getReqtypeStatus() {
		return reqtypeStatus;
	}

	public void setReqtypeStatus(String reqtypeStatus) {
		this.reqtypeStatus = reqtypeStatus;
	}

	public Date getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Date lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getProcessNm() {
		return processNm;
	}

	public void setProcessNm(String processNm) {
		this.processNm = processNm;
	}

	public int getVersionNum() {
		return versionNum;
	}

	public void setVersionNum(int versionNum) {
		this.versionNum = versionNum;
	}

	public String getReqTypeGrp() {
		return reqTypeGrp;
	}

	public void setReqTypeGrp(String reqTypeGrp) {
		this.reqTypeGrp = reqTypeGrp;
	}

	public String getReqTypeDesc() {
		return reqTypeDesc;
	}

	public void setReqTypeDesc(String reqTypeDesc) {
		this.reqTypeDesc = reqTypeDesc;
	}

	public String getCutOffTime() {
		return cutOffTime;
	}

	public void setCutOffTime(String cutOffTime) {
		this.cutOffTime = cutOffTime;
	}

	public String getBuddyReqType() {
		return buddyReqType;
	}

	public void setBuddyReqType(String buddyReqType) {
		this.buddyReqType = buddyReqType;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getAcl() {
		return acl;
	}

	public void setAcl(String acl) {
		this.acl = acl;
	}

	public int getTrafficLightValue1() {
		return trafficLightValue1;
	}

	public void setTrafficLightValue1(int trafficLightValue1) {
		this.trafficLightValue1 = trafficLightValue1;
	}

	public int getTrafficLightValue2() {
		return trafficLightValue2;
	}

	public void setTrafficLightValue2(int trafficLightValue2) {
		this.trafficLightValue2 = trafficLightValue2;
	}

	public BigDecimal getsRowid() {
		return sRowid;
	}

	public void setsRowid(BigDecimal sRowid) {
		this.sRowid = sRowid;
	}

	public short getIsDisable() {
		return isDisable;
	}

	public void setIsDisable(short isDisable) {
		this.isDisable = isDisable;
	}

	public short getIsUrgent() {
		return isUrgent;
	}

	public void setIsUrgent(short isUrgent) {
		this.isUrgent = isUrgent;
	}

	public short getBuddyCheck() {
		return buddyCheck;
	}

	public void setBuddyCheck(short buddyCheck) {
		this.buddyCheck = buddyCheck;
	}

	public List<MandatoryDoc> getMandatoryDocs() {
		return mandatoryDocs;
	}

	public void setMandatoryDocs(List<MandatoryDoc> mandatoryDocs) {
		this.mandatoryDocs = mandatoryDocs;
	}

	public List<ActInfo> getActInfos() {
		return actInfos;
	}

	public void setActInfos(List<ActInfo> actInfos) {
		this.actInfos = actInfos;
	}

	public short getRejectgetjob() {
		return rejectgetjob;
	}

	public void setRejectgetjob(short rejectgetjob) {
		this.rejectgetjob = rejectgetjob;
	}



  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
//  @Override
//  public String toString() {
//    return "FdReqType [acl=" + acl + ", sRowid=" + sRowid + ", reqTypeCode=" + reqTypeCode
//        + ", qaType=" + qaType + ", target=" + target + ", benchmark=" + benchmark + ", reqType="
//        + reqType + ", slaDays=" + slaDays + ", department=" + department + ", effectiveDate="
//        + effectiveDate + ", isDisable=" + isDisable + ", isUrgent=" + isUrgent
//        + ", reqtypeStatus=" + reqtypeStatus + ", createdTimestamp=" + createdTimestamp
//        + ", createdBy=" + createdBy + ", lastUpdatedBy=" + lastUpdatedBy
//        + ", lastUpdatedTimestamp=" + lastUpdatedTimestamp + ", displayName=" + displayName
//        + ", processNm=" + processNm + ", versionNum=" + versionNum + ", reqTypeGrp=" + reqTypeGrp
//        + ", reqTypeDesc=" + reqTypeDesc + ", cutOffTime=" + cutOffTime + ", buddyCheck="
//        + buddyCheck + ", buddyReqType=" + buddyReqType + ", category=" + category
//        + ", rejectgetjob=" + rejectgetjob + ", trafficLightValue1=" + trafficLightValue1
//        + ", trafficLightValue2=" + trafficLightValue2 + ", subReqtypeList=" + subReqtypeList
//        + ", actInfos=" + actInfos + ", mandatoryDocs=" + mandatoryDocs + ", checklist="
//        + checklist + ", buddyReqTypeList=" + buddyReqTypeList + ", versionList=" + versionList
//        + ", parentId=" + parentId + ", dataFrom=" + dataFrom + ", valueType=" + valueType
//        + ", riskType=" + riskType + ", sarGroup=" + sarGroup + ", premiumType=" + premiumType
//        + "]";
//  }

	
	@Override
	public String toString() {
		return "FdReqType [acl=" + acl + ", sRowid=" + sRowid
				+ ", reqTypeCode=" + reqTypeCode + ", qaType=" + qaType
				+ ", target=" + target + ", benchmark=" + benchmark
				+ ", reqType=" + reqType + ", slaDays=" + slaDays
				+ ", department=" + department + ", effectiveDate="
				+ effectiveDate + ", isDisable=" + isDisable + ", isUrgent="
				+ isUrgent + ", reqtypeStatus=" + reqtypeStatus
				+ ", createdTimestamp=" + createdTimestamp + ", createdBy="
				+ createdBy + ", lastUpdatedBy=" + lastUpdatedBy
				+ ", lastUpdatedTimestamp=" + lastUpdatedTimestamp
				+ ", displayName=" + displayName + ", processNm=" + processNm
				+ ", subTemplate=" + subTemplate + ", versionNum=" + versionNum
				+ ", reqTypeGrp=" + reqTypeGrp + ", reqTypeDesc=" + reqTypeDesc
				+ ", cutOffTime=" + cutOffTime + ", buddyCheck=" + buddyCheck
				+ ", buddyReqType=" + buddyReqType + ", category=" + category
				+ ", rejectgetjob=" + rejectgetjob + ", trafficLightValue1="
				+ trafficLightValue1 + ", trafficLightValue2="
				+ trafficLightValue2 + ", subReqtypeList=" + subReqtypeList
				+ ", actInfos=" + actInfos + ", mandatoryDocs=" + mandatoryDocs
				+ ", checklist=" + checklist + ", buddyReqTypeList="
				+ buddyReqTypeList + ", versionList=" + versionList
				+ ", parentId=" + parentId + ", dataFrom=" + dataFrom
				+ ", valueType=" + valueType + ", riskType=" + riskType
				+ ", sarGroup=" + sarGroup + ", premiumType=" + premiumType
				+ "]";
	}
	
	public List<ReqTypeCheckItem> getChecklist() {
		return checklist;
	}

	public void setChecklist(List<ReqTypeCheckItem> checklist) {
		this.checklist = checklist;
	}

	public String getSubReqtypeList() {
		return subReqtypeList;
	}

	public void setSubReqtypeList(String subReqtypeList) {
		this.subReqtypeList = subReqtypeList;
	}

	public String getDataFrom() {
		return dataFrom;
	}

	public void setDataFrom(String dataFrom) {
		this.dataFrom = dataFrom;
	}

	public List<String> getBuddyReqTypeList() {
		return buddyReqTypeList;
	}

	public void setBuddyReqTypeList(List<String> buddyReqTypeList) {
		this.buddyReqTypeList = buddyReqTypeList;
	}

	public List<ReqTypeVersion> getVersionList() {
		return versionList;
	}

	public void setVersionList(List<ReqTypeVersion> versionList) {
		this.versionList = versionList;
	}

	public BigDecimal getParentId() {
		return parentId;
	}

	public void setParentId(BigDecimal parentId) {
		this.parentId = parentId;
	}

	public String getReqTypeCode() {
		return reqTypeCode;
	}

	public void setReqTypeCode(String reqTypeCode) {
		this.reqTypeCode = reqTypeCode;
	}

	public String getQaType() {
		return qaType;
	}

	public void setQaType(String qaType) {
		this.qaType = qaType;
	}

	public String getTarget() {
		return target;
	}

	public void setTarget(String target) {
		this.target = target;
	}

	public String getBenchmark() {
		return benchmark;
	}

	public void setBenchmark(String benchmark) {
		this.benchmark = benchmark;
	}

	@Override
	public List<AuditFieldSpecialAction> registFieldSpecialActionlist() {
		// TODO Auto-generated method stub
		List<AuditFieldSpecialAction> result = null;
		return result;

	}

	@Override
	public BigDecimal getRowID() {
		if(sRowid != null && sRowid.intValue() > 0){
			return sRowid;
		}
		return null;
	}

	@Override
	public String getKeyDisplayName() {
		// TODO Auto-generated method stub
		return getDisplayName();
	}

	@Override
	public String getKey() {
		// TODO Auto-generated method stub
		return getReqType();
	}

	@Override
	public List<AuditEntityIgnoreCondition> registIgnoreEntitylist() {
		// TODO Auto-generated method stub
		List<AuditEntityIgnoreCondition> result = null;
		return result;
	}

}
