package com.aia.case360.uam.domain;

public class UAMUserEditAuditTrail {

	private String activeStatus;
	private String department;
	private String uamUserPhoneNumber;
	private String userCompany;
	private String calCompany;
	private String displayName;
	private String deliveryString;
	private String uamUserId;
	private String curUser;
	private String roleIds;
	private String teams;

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "UAMUserEditAuditTrail [activeStatus=" + activeStatus + ", department=" + department
				+ ", uamUserPhoneNumber=" + uamUserPhoneNumber + ", userCompany=" + userCompany + ", calCompany="
				+ calCompany + ", displayName=" + displayName + ", deliveryString=" + deliveryString + ", uamUserId="
				+ uamUserId + ", curUser=" + curUser + ", roleIds=" + roleIds + ", teams=" + teams + "]";
	}

	/**
	 * @return the activeStatus
	 */
	public String getActiveStatus() {
		return activeStatus;
	}

	/**
	 * @return the department
	 */
	public String getDepartment() {
		return department;
	}

	/**
	 * @return the uamUserPhoneNumber
	 */
	public String getUamUserPhoneNumber() {
		return uamUserPhoneNumber;
	}

	/**
	 * @return the userCompany
	 */
	public String getUserCompany() {
		return userCompany;
	}

	/**
	 * @return the calCompany
	 */
	public String getCalCompany() {
		return calCompany;
	}

	/**
	 * @return the displayName
	 */
	public String getDisplayName() {
		return displayName;
	}

	/**
	 * @return the deliveryString
	 */
	public String getDeliveryString() {
		return deliveryString;
	}

	/**
	 * @return the uamUserId
	 */
	public String getUamUserId() {
		return uamUserId;
	}

	/**
	 * @return the curUser
	 */
	public String getCurUser() {
		return curUser;
	}

	/**
	 * @return the roleIds
	 */
	public String getRoleIds() {
		return roleIds;
	}

	/**
	 * @return the teams
	 */
	public String getTeams() {
		return teams;
	}

	/**
	 * @param activeStatus the activeStatus to set
	 */
	public void setActiveStatus(String activeStatus) {
		this.activeStatus = activeStatus;
	}

	/**
	 * @param department the department to set
	 */
	public void setDepartment(String department) {
		this.department = department;
	}

	/**
	 * @param uamUserPhoneNumber the uamUserPhoneNumber to set
	 */
	public void setUamUserPhoneNumber(String uamUserPhoneNumber) {
		this.uamUserPhoneNumber = uamUserPhoneNumber;
	}

	/**
	 * @param userCompany the userCompany to set
	 */
	public void setUserCompany(String userCompany) {
		this.userCompany = userCompany;
	}

	/**
	 * @param calCompany the calCompany to set
	 */
	public void setCalCompany(String calCompany) {
		this.calCompany = calCompany;
	}

	/**
	 * @param displayName the displayName to set
	 */
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	/**
	 * @param deliveryString the deliveryString to set
	 */
	public void setDeliveryString(String deliveryString) {
		this.deliveryString = deliveryString;
	}

	/**
	 * @param uamUserId the uamUserId to set
	 */
	public void setUamUserId(String uamUserId) {
		this.uamUserId = uamUserId;
	}

	/**
	 * @param curUser the curUser to set
	 */
	public void setCurUser(String curUser) {
		this.curUser = curUser;
	}

	/**
	 * @param roleIds the roleIds to set
	 */
	public void setRoleIds(String roleIds) {
		this.roleIds = roleIds;
	}

	/**
	 * @param teams the teams to set
	 */
	public void setTeams(String teams) {
		this.teams = teams;
	}
}
