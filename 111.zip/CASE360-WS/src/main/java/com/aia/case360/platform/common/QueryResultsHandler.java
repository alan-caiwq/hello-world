package com.aia.case360.platform.common;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.eistream.sonora.fields.FmsFieldTO;
import com.eistream.sonora.fields.FmsRowSet;
import com.eistream.sonora.fields.FmsRowSetTO;
import com.eistream.sonora.fields.FmsRowTO;

public class QueryResultsHandler {

	private QueryResultsHandler() {}
	/**
	 * Convert from the Case360 data types to a native Java type
	 * 
	 * @param fmsRowSetTOs
	 * @return
	 */
	public static ArrayList<Map<String, String>> convertQueryResultsAsString(FmsRowSetTO[] fmsRowSetTOs) {
		ArrayList<Map<String, String>> queryResults = new ArrayList<Map<String, String>>();

		for (FmsRowSetTO fmsRowSetTO : fmsRowSetTOs) {
			for (FmsRowTO resultRow : fmsRowSetTO.getResultRows()) {
				Map<String, String> rowFields = new HashMap<String, String>();
				for (FmsFieldTO fmsField : resultRow.getFieldList()) {
					String val = getFieldValueAsString(fmsField);
					rowFields.put(fmsField.getFieldName(), (null == val) ? "" : val);
				}

				queryResults.add(rowFields);
			}
		}

		return queryResults;
	}

	/**
	 * Convert from the Case360 data types to a native Java type
	 * 
	 * @param fmsRowSetTOs
	 * @return
	 */
	public static ArrayList<Map<String, Object>> convertQueryResultsAsObject(FmsRowSetTO[] fmsRowSetTOs) {
		ArrayList<Map<String, Object>> queryResults = new ArrayList<Map<String, Object>>();

		for (FmsRowSetTO fmsRowSetTO : fmsRowSetTOs) {
			for (FmsRowTO resultRow : fmsRowSetTO.getResultRows()) {
				Map<String, Object> rowFields = new HashMap<String, Object>();
				for (FmsFieldTO fmsField : resultRow.getFieldList()) {
					rowFields.put(fmsField.getFieldName(), getFieldValueAsObject(fmsField));
				}

				queryResults.add(rowFields);
			}
		}

		return queryResults;
	}

	/**
	 * 
	 * @param fmsRowSetTO
	 * @return
	 */
	public static Map<String, Object> convertQueryRowAsObject(FmsRowSetTO fmsRowSetTO) {
		Map<String, Object> rowFields = new HashMap<String, Object>();
		if (fmsRowSetTO.getRowCount() > 0) {
			FmsRowTO resultRow = fmsRowSetTO.getResultRows()[0];
			for (FmsFieldTO fmsField : resultRow.getFieldList()) {
				rowFields.put(fmsField.getFieldName(), getFieldValueAsObject(fmsField));
			}
		}

		return rowFields;
	}

	/**
	 * 
	 * @param fmsRowSet
	 * @return
	 */
	public static Map<String, Object> convertQueryResultsAsObject(FmsRowSet fmsRowSet) {
		Map<String, Object> rowFields = new HashMap<String, Object>();
		FmsRowSetTO fmsRowSetTO = fmsRowSet.getFmsRowSetTO();
		if (fmsRowSetTO.getRowCount() > 0) {
			FmsRowTO resultRow = fmsRowSetTO.getResultRows()[0];
			for (FmsFieldTO fmsField : resultRow.getFieldList()) {
				rowFields.put(fmsField.getFieldName(), getFieldValueAsObject(fmsField));
			}
		}

		return rowFields;
	}

	public static Map<String, Object> convertQueryResultsAsObject(FmsRowTO fmsRow) {
		Map<String, Object> rowFields = new HashMap<String, Object>();
		if (fmsRow == null)
			return rowFields;
		for (FmsFieldTO fmsField : fmsRow.getFieldList()) {
			rowFields.put(fmsField.getFieldName(), getFieldValueAsObject(fmsField));
		}

		return rowFields;
	}

	/**
	 * 
	 * @param fmsRowSet
	 * @return
	 */
	public static Map<String, Object> convertQueryResultsAsObjects(FmsRowSet fmsRowSet) {
		

		return convertQueryResultsAsObject(fmsRowSet);
	}

	/**
	 * Dump the field as an object nodes and handling.
	 * 
	 * @param field
	 * @return
	 */
	private static Object getFieldValueAsObject(FmsFieldTO field) {
		if (field == null)
			return null;

		Object ret = "";

		if (!field.getNullValue()) {
			switch (field.getDataType()) {
			case 1:
				ret = Boolean.valueOf(field.getBooleanValue());
				break;
			case 2:
				ret = Integer.valueOf(field.getIntValue());
				break;
			case 4:
				ret = field.getStringValue();
				break;
			case 5:
				ret = (null == field.getCalendarValue()) ? null : field.getCalendarValue();
				break;
			case 6:
				ret = (null == field.getBigDecimalValue()) ? null : field.getBigDecimalValue();
				break;
			case 11:
				String temp = field.getStringValue();
				ret = temp;

				break;
			default:
				ret = (null == field.getStringValue()) ? null : field.getStringValue();
				break;
			}
		}

		return ret;
	}

	/**
	 * Dump the field as an object nodes and handling.
	 * 
	 * @param field
	 * @return
	 */
	private static String getFieldValueAsString(FmsFieldTO field) {
		if (field == null)
			return null;

		String ret = "";

		SimpleDateFormat DATE_FORMATTER = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

		if (!field.getNullValue()) {
			switch (field.getDataType()) {
			case 1:
				ret = Boolean.toString(field.getBooleanValue());
				break;
			case 2:
				ret = Integer.toString(field.getIntValue());
				break;
			case 4:
				ret = valueIsNull(field.getStringValue()) ;
				break;
			case 11:
				String temp = field.getStringValue();
				ret = temp;
				break;
			case 5:
				ret = (null == field.getCalendarValue()) ? ""
						: DATE_FORMATTER.format(field.getCalendarValue().getTime());
				break;
			case 6:
				ret = (null == field.getBigDecimalValue()) ? "" : field.getBigDecimalValue().toString();
				break;
			default:
				ret = (null == field.getStringValue()) ? null : field.getStringValue();
				break;

			}
		}

		return ret;
	}

	/**
	 * Convert a FmsRowSetTO into an XML blob
	 * 
	 * @param fmsRowSetTOs
	 * @return
	 */
	public static Document convertQueryResultsToXml(FmsRowSetTO[] fmsRowSetTOs, String rowName) {
		Document doc = XMLLoader.createEmptyDocument();

		Element docElem = doc.createElement("results");
		doc.appendChild(docElem);

		for (FmsRowSetTO fmsRowSetTO : fmsRowSetTOs) {
			for (FmsRowTO resultRow : fmsRowSetTO.getResultRows()) {
				Element row = doc.createElement(rowName);
				for (FmsFieldTO fmsField : resultRow.getFieldList()) {
					Element value = doc.createElement(fmsField.getFieldName());
					String val = getFieldValueAsString(fmsField);
					if (null != val)
						value.appendChild(doc.createTextNode(val));
					row.appendChild(value);
				}

				docElem.appendChild(row);
			}
		}

		return doc;
	}

	/**
	 * 
	 * @param fmsRowTO
	 * @return
	 */
	public static Map<String, Object> convertQueryRowAsObject(FmsRowTO fmsRowTO) {
		Map<String, Object> rowFields = new HashMap<String, Object>();

		for (FmsFieldTO fmsField : fmsRowTO.getFieldList()) {
			rowFields.put(fmsField.getFieldName(), getFieldValueAsObject(fmsField));
		}

		return rowFields;
	}
	
	   private static String valueIsNull(String value){
	      
	      if(value==null){
	        return "";
	      }else if("".equals(value.trim())){
	        return "";
	      }else if(value.trim().length()==0){
	        return "";
	      }else{
	        return value;
	      }
	  }


}
