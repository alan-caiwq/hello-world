package com.aia.case360.web.dao;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.aia.case360.web.vo.PpcDefinition;

@Repository
public interface PrePrintContractDao {

	List<PpcDefinition> getAllTemplates()  throws RemoteException;

	int newTemplate(Map<String, String> paraMap)  throws RemoteException;

	int editTemplate(Map<String, String> paraMap)  throws RemoteException;

	int delTemplate(Map<String, String> paraMap)  throws RemoteException;

	int updateFsDocuments(Map<String, String> paraMap)  throws RemoteException;

}
