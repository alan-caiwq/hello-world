package com.aia.case360.platform.audittrail.impl;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.aia.case360.platform.audittrail.AuditTrailHelper;
import com.aia.case360.platform.common.DateUtil;
import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.common.PropertyUtil;
import com.aia.case360.platform.dao.TableIdBean;
import com.aia.case360.platform.formdata.DataTableHelper;
import com.aia.case360.platform.process.impl.RepositoryKey;
import com.aia.case360.platform.query.QueryHelper;
import com.aia.case360.platform.security.UserHelper;
import com.aia.case360.web.service.impl.AbstractHelperImpl;

/**
 * 
 * @author bsnpbrs
 *
 */
@Component
public class AuditTrailHelperImpl extends AbstractHelperImpl implements AuditTrailHelper {
	private static final String LOCALWFWORKSTEPNAME = "WFWORKSTEPNAME";

	private static final String LOCALSLACOUNT = "SLA_COUNT";

	private static final String LOCALWORKFLOWID = "WORKFLOWID";

	private static final String LOCALTABLENAMEAUDITTRAIL = "TABLE_NAME_AUDIT_TRAIL";

	@Autowired
	private TableIdBean dataTableIds;

	@Autowired
	private QueryHelper queryHelper;

	@Autowired
	private DataTableHelper dtHelper;

	@Autowired
	private UserHelper userHelper;

	/**
	 * append data to Audit Trail values
	 * 
	 * @param Map must have parameter that : flp_user_name:FLP_USER_NM,
	 *            case_Id:LINKCASEID, audit_Trail_Reason:ACTION_NM (Corresponding
	 *            Audit Trail 's name); user_Id:CURRENT_USER, rp_Key_Str:RP_KEY_STR,
	 * 
	 * @return processName Corresponding Audit Trail 's workstep
	 * @throws RemoteException
	 * @throws SQLException
	 */
	@Override
	public boolean appendToAuditTrail(Map<String, String> fldPairs) throws RemoteException, SQLException {
		boolean flag = false;
		String message = "function appendToAuditTrail";
		LogUtil.logInfo(m_Logger,message + "is start . ");

		String userId_name = PropertyUtil.getCommonProperty("CURRENT_USER");
		if (!fldPairs.containsKey(userId_name)) {
			fldPairs.get(userId_name);
			fldPairs.put(userId_name, userHelper.getCurrentUser());
		}

		try {
			BigDecimal auditTrailTableId = new BigDecimal(
					dataTableIds.getTableIds().get(PropertyUtil.getTableIDProperty(LOCALTABLENAMEAUDITTRAIL)));

			String rpKeyStr = fldPairs.get("RP_KEY_STR");

			if (!rpKeyStr.equals("")) {
				RepositoryKey rpKey = RepositoryKey.getInstance(rpKeyStr);
				fldPairs.put(PropertyUtil.getCommonProperty(LOCALWORKFLOWID).toString(),
						String.valueOf(rpKey.getWorkflowId()));
				fldPairs.put(PropertyUtil.getCommonProperty("WFWORKITEMID_FK"), String.valueOf(rpKey.getWorkItemId()));

			}
			dtHelper.createTableRow(auditTrailTableId, fldPairs);
			LogUtil.logInfo(m_Logger,message + " is leaving .");
			flag = true;
		} catch (RemoteException e) {
			 
			throw LogUtil.logException(m_Logger, message, e);
		}
		return flag;
	}

	@Override
	public Map<String, String> getUserIdTrace(String caseId) throws RemoteException {

		return null;
	}

	/**
	 * create new data in Audit Trail values
	 * 
	 * @param auditTrailReason Corresponding Audit Trail 's name
	 * @return processName Corresponding Audit Trail 's workstep
	 * @throws RemoteException
	 * @throws SQLException
	 */
	@Override
	public boolean createAuditTrail(String caseId, String auditTrailReason, String userId, String rpKeyStr)
			throws RemoteException, SQLException {
		boolean flag = false;
		StringBuilder sb = new StringBuilder();
		sb.append("Add Audit Trail data.");
		try {
			String auditTrailTableId = dataTableIds.getTableIds()
					.get(PropertyUtil.getTableIDProperty(LOCALTABLENAMEAUDITTRAIL));
			Map<String, String> createMap = new HashMap<String, String>();
			createMap.put(PropertyUtil.getCommonProperty("CREATED_BY"), userId);
			createMap.put(PropertyUtil.getCommonProperty("LINKCASEID"), caseId);
			createMap.put(PropertyUtil.getCommonProperty("ACTION_DESC"), auditTrailReason);
			createMap.put(PropertyUtil.getCommonProperty("CREATED_DT"), DateUtil.getCurrentTime());
			if (!"".equals(rpKeyStr)) {
				RepositoryKey rpKey = RepositoryKey.getInstance(rpKeyStr);
				createMap.put(PropertyUtil.getCommonProperty(LOCALWORKFLOWID), String.valueOf(rpKey.getWorkflowId()));
			}
			dtHelper.createTableRow(new BigDecimal(auditTrailTableId), createMap);

			sb.append("caseId:").append(caseId).append(";userId:").append(userId);
			sb.append(".Add data success.");
			LogUtil.logInfo(m_Logger,sb.toString());

			flag = true;
		} catch (RemoteException e) {
			 
			throw LogUtil.logException(m_Logger, sb.toString(), e);
		}
		return flag;
	}

	/**
	 * create new data in Audit Trail values
	 * 
	 * @param auditTrailReason Corresponding Audit Trail 's name
	 * @return processName Corresponding Audit Trail 's workstep
	 * @throws RemoteException
	 * @throws SQLException
	 */
	@Override
	public boolean createAuditTrail(String caseId, String auditTrailReason, String userId, String rpKeyStr,
			String flpUserName) throws RemoteException, SQLException {
		boolean flag = false;
		StringBuilder sb = new StringBuilder();
		sb.append("Add Audit Trail data.");
		try {
			RepositoryKey rpKey = RepositoryKey.getInstance(rpKeyStr);
			String auditTrailTableId = dataTableIds.getTableIds()
					.get(PropertyUtil.getTableIDProperty(LOCALTABLENAMEAUDITTRAIL));
			Map<String, String> createMap = new HashMap<String, String>();
			createMap.put(PropertyUtil.getCommonProperty("CURRENT_USER"), userId);
			createMap.put(PropertyUtil.getCommonProperty("FLP_USER_NM"), flpUserName);
			createMap.put(PropertyUtil.getCommonProperty("LINKCASEID"), caseId);
			createMap.put(PropertyUtil.getCommonProperty("ACTION_NM"), auditTrailReason);
			createMap.put(PropertyUtil.getCommonProperty("CREATE_TIMESTAMP"), DateUtil.getCurrentTime());
			createMap.put(PropertyUtil.getCommonProperty(LOCALWORKFLOWID), String.valueOf(rpKey.getWorkflowId()));
			createMap.put(PropertyUtil.getCommonProperty("WFWORKITEMID_FK"), String.valueOf(rpKey.getWorkItemId()));
			dtHelper.createTableRow(new BigDecimal(auditTrailTableId), createMap);

			sb.append("caseId:").append(caseId).append(";userId:").append(userId);
			sb.append(".Add data success.");
			LogUtil.logInfo(m_Logger,sb.toString());

			flag = true;
		} catch (RemoteException e) {
			 
			throw LogUtil.logException(m_Logger, sb.toString(), e);
		}
		return flag;
	}

	@Override
	public ArrayList<Map<String, Object>> getBackLogReport(String reportType) throws RemoteException {

		ArrayList<Map<String, Object>> result = new ArrayList<Map<String, Object>>();

		if (reportType.equals("1")) {
			// Grouping by Process
			Map<String, String> queryParams = new HashMap<String, String>();
			queryParams.put("LOGINID_USER", "1");

			ArrayList<Map<String, Object>> resultSLA = new ArrayList<Map<String, Object>>();
			ArrayList<Map<String, Object>> resultPend = new ArrayList<Map<String, Object>>();
			try {
				resultSLA = queryHelper.doQuery(queryParams, "backlogReportgroupByProcessSLA");
				resultPend = queryHelper.doQuery(queryParams, "backlogReportgroupByProcessPend");

				for (Map<String, Object> mapPend : resultPend) {
					getBackLogTypeOne(result, resultSLA, mapPend);
				}
				return result;
			} catch (RemoteException e) {

				LogUtil.logException(m_Logger, reportType, e);
			}

		} else if (reportType.equals("2")) {
			// Grouping by Activity
			Map<String, String> queryParams = new HashMap<String, String>();
			ArrayList<Map<String, Object>> resultSLA = new ArrayList<Map<String, Object>>();
			ArrayList<Map<String, Object>> resultPend = new ArrayList<Map<String, Object>>();
			;
			ArrayList<Map<String, Object>> resultWait = new ArrayList<Map<String, Object>>();
			;
			try {
				resultSLA = queryHelper.doQuery(queryParams, "backlogReportgroupByActivitySLA");
				resultPend = queryHelper.doQuery(queryParams, "backlogReportgroupByActivityPend");
				resultWait = queryHelper.doQuery(queryParams, "backlogReportgroupByActivityWait");

				for (Map<String, Object> mapWait : resultWait) {
					getBackLogTypeTwo(result, resultSLA, resultPend, mapWait);
				}
				return result;
			} catch (RemoteException e) {
				LogUtil.logException(m_Logger, reportType, e);
				 
			}
		}
		return result;

	}

  private void getBackLogTypeTwo(ArrayList<Map<String, Object>> result,
      ArrayList<Map<String, Object>> resultSLA, ArrayList<Map<String, Object>> resultPend,
      Map<String, Object> mapWait) {
    Map<String, Object> map = new HashMap<String, Object>();
    String workStepName = mapWait.get(LOCALWFWORKSTEPNAME).toString();
    map.put(LOCALWFWORKSTEPNAME, mapWait.get(LOCALWFWORKSTEPNAME).toString());
    for (Map<String, Object> mapSLA : resultSLA) {
    	if (workStepName.equalsIgnoreCase(mapSLA.get(LOCALWFWORKSTEPNAME).toString())) {
    		int slaStatus = Integer.parseInt(mapSLA.get("SLASTATUS").toString());
    		switch (slaStatus) {
    		case 1:
    			map.put("GREEN_SLA", mapSLA.get(LOCALSLACOUNT));
    			break;
    		case 2:
    			map.put("YELLOW_SLA", mapSLA.get(LOCALSLACOUNT));
    			break;
    		case 3:
    			map.put("RED_SLA", mapSLA.get(LOCALSLACOUNT));
    			break;
    		default:
    			break;
    		}
    	}
    }
    for (Map<String, Object> mapPend : resultPend) {
    	if (workStepName.equalsIgnoreCase(mapPend.get(LOCALWFWORKSTEPNAME).toString())) {
    		map.put("PEND_COUNT ", mapPend.get("PEND_COUNT "));
    	}
    }
    result.add(map);
  }

  private void getBackLogTypeOne(ArrayList<Map<String, Object>> result,
      ArrayList<Map<String, Object>> resultSLA, Map<String, Object> mapPend) {
    String processPend = mapPend.get("PROCESS_NAME").toString();
    String policyTypePend = mapPend.get("POLICY_TYPE").toString();
    String productTypePend = mapPend.get("PRODUCT_TYPE").toString();
    for (Map<String, Object> mapSLA : resultSLA) {
    	String processSLA = mapSLA.get("PROCESS_NAME").toString();
    	String policyTypeSLA = mapSLA.get("POLICY_TYPE").toString();
    	String productTypeSLA = mapSLA.get("PRODUCT_TYPE").toString();
    	if (processSLA.equals(processPend) && policyTypeSLA.equals(policyTypePend)
    			&& productTypeSLA.equals(productTypePend)) {
    		int slaStatus = Integer.parseInt(mapSLA.get("SLASTATUS").toString());
    		switch (slaStatus) {
    		case 1:
    			mapPend.put("GREEN_SLA", mapSLA.get(LOCALSLACOUNT));
    			break;
    		case 2:
    			mapPend.put("YELLOW_SLA", mapSLA.get(LOCALSLACOUNT));
    			break;
    		case 3:
    			mapPend.put("RED_SLA", mapSLA.get(LOCALSLACOUNT));
    			break;
    		default:
    			break;
    		}
    	}
    }
    result.add(mapPend);
  }
}