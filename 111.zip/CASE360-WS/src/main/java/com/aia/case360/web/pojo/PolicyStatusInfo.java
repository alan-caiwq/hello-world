package com.aia.case360.web.pojo;

public class PolicyStatusInfo {
	private String category;
	private String lookUpCode;
	private String lookUpValue;
	private String lookUpGroup;

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getLookUpCode() {
		return lookUpCode;
	}

	public void setLookUpCode(String lookUpCode) {
		this.lookUpCode = lookUpCode;
	}

	public String getLookUpValue() {
		return lookUpValue;
	}

	public void setLookUpValue(String lookUpValue) {
		this.lookUpValue = lookUpValue;
	}

	public String getLookUpGroup() {
		return lookUpGroup;
	}

	public void setLookUpGroup(String lookUpGroup) {
		this.lookUpGroup = lookUpGroup;
	}

	@Override
	public String toString() {
		return "PolicyStatusInfo [category=" + category + ", lookUpCode=" + lookUpCode + ", lookUpValue=" + lookUpValue
				+ ", lookUpGroup=" + lookUpGroup + "]";
	}

}
