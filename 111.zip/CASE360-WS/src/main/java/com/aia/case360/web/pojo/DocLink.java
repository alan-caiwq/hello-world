package com.aia.case360.web.pojo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

public class DocLink implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String claimNo;
	private String companyNo;

	@DateTimeFormat(pattern = "yyyy-MM-ddHH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-ddHH:mm:ss", timezone = "GMT+8")
	private Date createdDt;
	private String formId;
	private short isDeleted;
	private short isLogical;
	private short isMigrated;
	private short isVoid;
	private String objectId;
	private String polNum;
	private String processType;

	// operation type 1: copy 2:split
	private String operType;

	// if document is customer document, 1 or other values
	private String isClient;

	// copy/split page number 1,3,5...
	private String pageNum;

	private String clientId;

	private String nric;

	@DateTimeFormat(pattern = "yyyy-MM-ddHH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-ddHH:mm:ss", timezone = "GMT+8")
	private Date receivedDt;
	private String requestNum;
	private BigDecimal sRowid;
	private int pendingSeq;
	private BigDecimal linkCaseId;

	@DateTimeFormat(pattern = "yyyy-MM-ddHH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-ddHH:mm:ss", timezone = "GMT+8")
	private Date receiveddate;
	private String isResolved;

	@DateTimeFormat(pattern = "yyyy-MM-ddHH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-ddHH:mm:ss", timezone = "GMT+8")
	private Date lastUpdatedTimestamp;
	private String logicalLinkId;
	private String orgRequestNo;

	private String originalFormId;

	private String orginalProcessType;

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public String getCompanyNo() {
		return companyNo;
	}

	public void setCompanyNo(String companyNo) {
		this.companyNo = companyNo;
	}

	public Date getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	public String getFormId() {
		return formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}

	public short getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(short isDeleted) {
		this.isDeleted = isDeleted;
	}

	public short getIsLogical() {
		return isLogical;
	}

	public void setIsLogical(short isLogical) {
		this.isLogical = isLogical;
	}

	public short getIsMigrated() {
		return isMigrated;
	}

	public void setIsMigrated(short isMigrated) {
		this.isMigrated = isMigrated;
	}

	public short getIsVoid() {
		return isVoid;
	}

	public void setIsVoid(short isVoid) {
		this.isVoid = isVoid;
	}

	public String getObjectId() {
		return objectId;
	}

	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}

	public String getPolNum() {
		return polNum;
	}

	public void setPolNum(String polNum) {
		this.polNum = polNum;
	}

	public String getProcessType() {
		return processType;
	}

	public void setProcessType(String processType) {
		this.processType = processType;
	}

	public Date getReceivedDt() {
		return receivedDt;
	}

	public void setReceivedDt(Date receivedDt) {
		this.receivedDt = receivedDt;
	}

	public String getRequestNum() {
		return requestNum;
	}

	public void setRequestNum(String requestNum) {
		this.requestNum = requestNum;
	}

	public BigDecimal getsRowid() {
		return sRowid;
	}

	public void setsRowid(BigDecimal sRowid) {
		this.sRowid = sRowid;
	}

	public int getPendingSeq() {
		return pendingSeq;
	}

	public void setPendingSeq(int pendingSeq) {
		this.pendingSeq = pendingSeq;
	}

	public Date getReceiveddate() {
		return receiveddate;
	}

	public void setReceiveddate(Date receiveddate) {
		this.receiveddate = receiveddate;
	}

	public String getIsResolved() {
		return isResolved;
	}

	public void setIsResolved(String isResolved) {
		this.isResolved = isResolved;
	}

	public Date getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Date lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public String getLogicalLinkId() {
		return logicalLinkId;
	}

	public void setLogicalLinkId(String logicalLinkId) {
		this.logicalLinkId = logicalLinkId;
	}

	public String getOrgRequestNo() {
		return orgRequestNo;
	}

	public void setOrgRequestNo(String orgRequestNo) {
		this.orgRequestNo = orgRequestNo;
	}

	public String getOperType() {
		return operType;
	}

	public void setOperType(String operType) {
		this.operType = operType;
	}

	public String getIsClient() {
		return isClient;
	}

	public void setIsClient(String isClient) {
		this.isClient = isClient;
	}

	public String getPageNum() {
		return pageNum;
	}

	public void setPageNum(String pageNum) {
		this.pageNum = pageNum;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public BigDecimal getLinkCaseId() {
		return linkCaseId;
	}

	public void setLinkCaseId(BigDecimal linkCaseId) {
		this.linkCaseId = linkCaseId;
	}

	public String getOriginalFormId() {
		return originalFormId;
	}

	public void setOriginalFormId(String originalFormId) {
		this.originalFormId = originalFormId;
	}

	public String getOrginalProcessType() {
		return orginalProcessType;
	}

	public void setOrginalProcessType(String orginalProcessType) {
		this.orginalProcessType = orginalProcessType;
	}

	public String getNric() {
		return nric;
	}

	public void setNric(String nric) {
		this.nric = nric;
	}
}
