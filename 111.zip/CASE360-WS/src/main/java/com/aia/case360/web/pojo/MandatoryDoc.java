package com.aia.case360.web.pojo;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import com.aia.case360.web.auditTrail.AuditEntityIgnoreCondition;
import com.aia.case360.web.auditTrail.AuditFieldSpecialAction;
import com.aia.case360.web.auditTrail.AuditFileTypeEnum;
import com.aia.case360.web.auditTrail.AuditTrail;
import com.aia.case360.web.auditTrail.annotation.AuditEntity;
import com.aia.case360.web.auditTrail.annotation.AuditField;
import com.aia.case360.web.common.CommonUtil;
import com.fasterxml.jackson.annotation.JsonFormat;

@AuditEntity(entityName = "Mandatory Doc", formDataName = "Request type audit trail", tableName = "FD_REQTYPE_AUDITTRAIL")
public class MandatoryDoc implements AuditTrail {
	private String acl;
	private BigDecimal sRowid;
	private String createdBy;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	private Date effectiveDate;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	private Date createdTimestamp;
	private String lastUpdatedBy;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	private Date lastUpdatedTimestamp;
	private int sequenceNum;
	@AuditField(fieldName = "FormID", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private String formId;
	private String reqType;
	private int versionNum;
	@AuditField(fieldName = "Doc Type", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private String documentType;
	@AuditField(fieldName = "Form Category", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private String formCategory;

	public MandatoryDoc(String reqType, int versionNum) {
		super();
		this.reqType = reqType;
		this.versionNum = versionNum;
	}

	public MandatoryDoc() {
		super();
	}

	public String getAcl() {
		return acl;
	}

	public void setAcl(String acl) {
		this.acl = acl;
	}

	public BigDecimal getsRowid() {
		return sRowid;
	}

	public void setsRowid(BigDecimal sRowid) {
		this.sRowid = sRowid;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Date lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public int getSequenceNum() {
		return sequenceNum;
	}

	public void setSequenceNum(int sequenceNum) {
		this.sequenceNum = sequenceNum;
	}

	public String getFormId() {
		return formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}

	public String getReqType() {
		return reqType;
	}

	public void setReqType(String reqType) {
		this.reqType = reqType;
	}

	public int getVersionNum() {
		return versionNum;
	}

	public void setVersionNum(int versionNum) {
		this.versionNum = versionNum;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getFormCategory() {
		return formCategory;
	}

	public void setFormCategory(String formCategory) {
		this.formCategory = formCategory;
	}

	@Override
	public String toString() {
		return "MandatoryDoc [acl=" + acl + ", sRowid=" + sRowid + ", createdBy=" + createdBy + ", createdTimestamp="
				+ createdTimestamp + ", lastUpdatedBy=" + lastUpdatedBy + ", lastUpdatedTimestamp="
				+ lastUpdatedTimestamp + ", sequenceNum=" + sequenceNum + ", formId=" + formId + ", reqType=" + reqType
				+ ", versionNum=" + versionNum + ", effectiveDate=" + effectiveDate + ",documentType=" + documentType
				+ "]";
	}

	@Override
	public List<AuditFieldSpecialAction> registFieldSpecialActionlist() {
		// TODO Auto-generated method stub
		List<AuditFieldSpecialAction> result = null;
		return result;
	}

	@Override
	public BigDecimal getRowID() {
		// TODO Auto-generated method stub
		return getsRowid();
	}

	@Override
	public String getKeyDisplayName() {
		// TODO Auto-generated method stub
		return getFormId();
	}

	@Override
	public String getKey() {
		return CommonUtil.getString(reqType);
	}

	@Override
	public List<AuditEntityIgnoreCondition> registIgnoreEntitylist() {
		// TODO Auto-generated method stub
		List<AuditEntityIgnoreCondition> result = null;
		return result;
	}

}
