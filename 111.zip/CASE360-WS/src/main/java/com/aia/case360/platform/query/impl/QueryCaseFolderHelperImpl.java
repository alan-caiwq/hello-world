package com.aia.case360.platform.query.impl;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.stereotype.Component;

import com.aia.case360.platform.common.CaseUtilities;
import com.aia.case360.platform.common.DataFieldUtil;
import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.common.PropertyUtil;
import com.aia.case360.platform.common.QueryResultsHandler;
import com.aia.case360.platform.query.QueryCaseFolderHelper;
import com.aia.case360.web.service.impl.AbstractHelperImpl;
import com.eistream.sonora.fields.FieldPropertiesTO;
import com.eistream.sonora.fields.FmsRowSetTO;

@Component
public class QueryCaseFolderHelperImpl extends AbstractHelperImpl implements QueryCaseFolderHelper {

	public ArrayList<Map<String, Object>> doQuery(Map<String, String> queryParams, String queryName)
			throws RemoteException {

		String message = "queryName:" + queryName;

		String paramStr = DataFieldUtil.getInMapStr(queryParams);

		if (paramStr != null && paramStr.length() > 0) {
			message += "," + paramStr;
		} else {
			message += ", no query parameters input!";
		}

		ArrayList<Map<String, Object>> queryResults;

		try {
			FmsRowSetTO[] queryResultsSet = doQuery4RowSet(queryParams, queryName);

			queryResults = QueryResultsHandler.convertQueryResultsAsObject(queryResultsSet);
			LogUtil.logInfo(m_Logger,message);
			return queryResults;
		} catch (RemoteException e) {
			 
			LogUtil.logError(m_Logger, message + " " + e.getMessage());
			e = new RemoteException(message, e);
			throw e;
		}
	}

	private FmsRowSetTO[] doQuery4RowSet(Map<String, String> queryParams, String queryName) throws RemoteException {
		String message = "queryName:" + queryName;

		String paramStr = DataFieldUtil.getInMapStr(queryParams);

		if (paramStr != null && paramStr.length() > 0) {
			message += "," + paramStr;
		} else {
			message += ", no query parameters input!";
		}

		// Get the list of contents
		FieldPropertiesTO[] queryFields = null;
		if (queryParams != null) {
			queryFields = new FieldPropertiesTO[queryParams.size()];

			int fieldsNum = 0;
			for (Entry<String, String> paramName : queryParams.entrySet()) {
				queryFields[fieldsNum++] = CaseUtilities.createFieldPropertyTO(paramName.getKey(), paramName.getValue());
			}
		}
		try {
			FmsRowSetTO[] queryResultsSet = getWsEJB().doQueryByScriptName(queryName, queryFields);

			LogUtil.logInfo(m_Logger,message);
			return queryResultsSet;
		} catch (RemoteException e) {
			LogUtil.logError(m_Logger, message + " " + e.getMessage());
			e = new RemoteException(message, e);
			throw e;
		}
	}

	@Override
	public ArrayList<Map<String, Object>> getWorkFolder(Map<String, String> parameters) throws RemoteException {
		String message = "queryName: getWorkFolder";
		LogUtil.logInfo(m_Logger,message);
		LogUtil.logInfo(m_Logger,parameters.toString());

		String query = PropertyUtil.getScriptAndQueryProperty("QUERY_GETWORKFOLDER_CUSTOMER");
		return doQuery(parameters, query);
	}

	@Override
	public String getDiscussionId(String discussionName) throws RemoteException {
		String message = "queryName: getDiscussionId";
		LogUtil.logInfo(m_Logger,message);
		Map<String, String> parameters = new HashMap<String, String>();
		String query = PropertyUtil.getScriptAndQueryProperty("QUERY_SEARCHDISCUSSION");
		parameters.put("NAME", discussionName);
		ArrayList<Map<String, Object>> result = doQuery(parameters, query);
		String discussionId = result.get(0).get("DISCUSSIONID").toString();
		return discussionId;
	}

	@Override
	public ArrayList<Map<String, Object>> getWorkFolderByReqNo(String requestNo) throws RemoteException {
		String message = "casefolder queryName: getWorkFolderByReqNo";
		LogUtil.logInfo(m_Logger,message + "is start . ");
		Map<String, String> parameters = new HashMap<String, String>();
		parameters.put("REQUEST_NUM", requestNo);
		LogUtil.logInfo(m_Logger,message + "is leaving . ");
		return doQuery(parameters, PropertyUtil.getScriptAndQueryProperty("QUERY_WORKFOLDER"));
	}

	@Override
	public ArrayList<Map<String, Object>> getWorkFolderByPolNum(String policyNum, String department, String processName)
			throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(PropertyUtil.getCommonProperty("POL_NUM"), policyNum);
		queryParams.put(PropertyUtil.getCommonProperty("DEPARTMENT"), department);
		queryParams.put(PropertyUtil.getCommonProperty("PROCESS_NAME"), processName);
		String query = PropertyUtil.getScriptAndQueryProperty("QUERY_GETALLWORKFOLDER");
		return doQuery(queryParams, query);
	}

	@Override
	public ArrayList<Map<String, Object>> getActiveWorkFolderByPolNum(String policyNum, String department,
			String processName) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(PropertyUtil.getCommonProperty("POL_NUM"), policyNum);
		queryParams.put(PropertyUtil.getCommonProperty("DEPARTMENT"), department);
		queryParams.put(PropertyUtil.getCommonProperty("PROCESS_NAME"), processName);
		queryParams.put(PropertyUtil.getCommonProperty("IS_COMPLETED"), "0");
		String query = PropertyUtil.getScriptAndQueryProperty("QUERY_GETALLWORKFOLDER");
		return doQuery(queryParams, query);
	}

	@Override
	public ArrayList<Map<String, Object>> getCustomer(String clientId) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(PropertyUtil.getCommonProperty("CLIENT_ID"), clientId);
		String query = PropertyUtil.getScriptAndQueryProperty("QUERY_GETCUSTOMER");
		return doQuery(queryParams, query);
	}

	@Override
	public ArrayList<Map<String, Object>> getWorkFolderByCaseID(String caseID) throws RemoteException {
		String message = "casefolder queryName: getWorkFolderByCaseID. caseID:" + caseID;
		LogUtil.logInfo(m_Logger,message + "is start . ");
		Map<String, String> parameters = new HashMap<String, String>();
		parameters.put("CASEFOLDERID", caseID);
		parameters.put("IS_COMPLETED", "1");

		LogUtil.logInfo(m_Logger,message + "is leaving . ");
		return doQuery(parameters, PropertyUtil.getScriptAndQueryProperty("QUERY_WORKFOLDER"));

	}
}