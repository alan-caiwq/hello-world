package com.aia.case360.platform.query;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public interface QueryFormDataHelper {

	/**
	 * 
	 * Get userId's own job list by workstep
	 * 
	 * @param userId   login userId should be registered in Case360 side.
	 * @param workstep activity name indicates which activity queue for finding
	 *                 workitems of the current user
	 * @return queryResults
	 * @throws RemoteException
	 */
	public ArrayList<Map<String, Object>> getNotes(String caseId) throws RemoteException;

	public ArrayList<Map<String, Object>> getAuditTrail(String caseId) throws RemoteException;

	public ArrayList<Map<String, Object>> getCFAuditTrail(String caseId) throws RemoteException;

	public ArrayList<Map<String, Object>> getFlpDoc(String caseId) throws RemoteException;

	public ArrayList<Map<String, Object>> getChangeItems(String caseId) throws RemoteException;

	public ArrayList<Map<String, Object>> getCfAndDocRelation(String caseId) throws RemoteException;

	public ArrayList<Map<String, Object>> getReqTypeDef(String reqType) throws RemoteException;

	public String getWorkStepHistoryUser(Map<String, String> inputParamsMap) throws RemoteException;

	public ArrayList<Map<String, Object>> getPolicyInfo(String polNum) throws RemoteException;

	public ArrayList<Map<String, Object>> getFormDefinition(String docId) throws RemoteException;

	public ArrayList<Map<String, Object>> getPolicyOwner(String linkCaseId) throws RemoteException;

	public ArrayList<Map<String, Object>> searchSignature(Map<String, String> inputParamsMap) throws RemoteException;

	public ArrayList<Map<String, Object>> searchEmailTemplete(Map<String, String> inputParamsMap)
			throws RemoteException;

	public ArrayList<Map<String, Object>> getPOByPolNum(String polNum) throws RemoteException;

	public ArrayList<Map<String, Object>> getProduct(String polNum) throws RemoteException;

	public List<BigDecimal> getPendingReasonId(String caseId, String pendingSeq) throws RemoteException;

	public List<String> getPendingReason(String caseId, String pendingSeq) throws RemoteException;

	public ArrayList<Map<String, Object>> getOfficeEmail(String officeCode) throws RemoteException;

	public ArrayList<Map<String, Object>> getUserProfile(String userId) throws RemoteException;

	public ArrayList<Map<String, Object>> genCallbackRpt() throws RemoteException;

	public ArrayList<Map<String, Object>> getPolicyRole(String policyNum) throws RemoteException;
}