package com.aia.case360.platform.common;

import java.sql.Timestamp;
import java.text.DateFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class DateUtil {

	private static final String DATEFORMAT_DD_MM_YYYY_HH_MM_SS_1 = "dd-MM-yyyy HH:mm:ss";
	private static final String DATEFORMAT_YYYY_MM_DD = "yyyy-MM-dd";
	private static final String DATEFORMAT_YYYY_M_MDD = "yyyyMMdd";
	private static final String DATEFORMAT_DD_MMM_YYYY_HH_MM_SS = "dd MMM yyyy HH:mm:ss";
	private static final String DATEFORMAT_DD_MM_YYYY = "dd/MM/yyyy";
	private static final String DATEFORMAT_DD_MM_YYYY_HH_MM_SS = "dd/MM/yyyy HH:mm:ss";
	private static final String DATEFORMAT_YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
	private static final String TIMEFORMAT = " 00:00:00";
	public static final String YYYYMMDDTIME = "yyyy/MM/dd HH:mm:ss";

	private DateUtil() {
	}

	private static ThreadLocal<Calendar> calendarThreadLocal = new ThreadLocal<>();
	private static ThreadLocal<SimpleDateFormat> simpleDateFormatThreadLocal = new ThreadLocal<>();

	/**
	 * 
	 * @return
	 * @author bsnpc37
	 * @date: Apr 18, 2018 9:43:13 AM
	 */
	public static Calendar getCalendar() {
		Calendar calendar = calendarThreadLocal.get();
		if (calendar == null) {
			calendar = Calendar.getInstance();
		}
		return calendar;
	}

	/**
	 * 
	 * @return
	 * @author bsnpc37
	 * @date: Apr 18, 2018 9:43:19 AM
	 */
	public static SimpleDateFormat getSimpleDateFormat() {
		SimpleDateFormat simpleDateFormat = simpleDateFormatThreadLocal.get();
		if (simpleDateFormat == null) {
			simpleDateFormat = new SimpleDateFormat();
			simpleDateFormatThreadLocal.set(simpleDateFormat);
		}
		return simpleDateFormat;
	}

	public static final Timestamp getTimestamp(String dateTime) {

		Calendar calendar = getCalendar();
		SimpleDateFormat df = getSimpleDateFormat();
		df.applyPattern(DATEFORMAT_YYYY_MM_DD_HH_MM_SS);
		// Albert. it was called by update table function.so need able to handle
		// null value.
		if (dateTime == null) {
			return null;
		}
		Date tmpDate = null;
		try {
			if (dateTime.length() == 10) {
				dateTime += TIMEFORMAT;
			}
			// for dateformat: 20170201
			else if (dateTime.length() == 8) {
				dateTime = dateTime.subSequence(0, 4) + "-" + dateTime.substring(4, 6) + "-" + dateTime.substring(6, 8);
				dateTime += TIMEFORMAT;
			}

			if (dateTime.contains("-")) {
				if (dateTime.split("-")[0].length() == 2) {
					df.applyPattern(DATEFORMAT_DD_MM_YYYY_HH_MM_SS_1);
				}
				tmpDate = df.parse(dateTime);
			} else if (dateTime.contains("/")) {
				SimpleDateFormat df1 = getSimpleDateFormat();
				if (dateTime.split("/")[0].length() == 2) {
					df1.applyPattern(com.aia.case360.common.Constants.DATE_TIME_FORMAT);
				} else {
					df1.applyPattern(YYYYMMDDTIME);
				}

				tmpDate = df1.parse(dateTime);
			}
			if (tmpDate != null) {
				calendar.setTimeInMillis(tmpDate.getTime());
			}
		} catch (ParseException e) {
			return null;
		}
		SimpleDateFormat formatter2 = getSimpleDateFormat();
		formatter2.applyPattern(DATEFORMAT_YYYY_MM_DD_HH_MM_SS);
		String time = df.format(calendar.getTime());
		return Timestamp.valueOf(time);
	}

	public static final Timestamp getTimestamp(Long dateTime) {

		SimpleDateFormat df = getSimpleDateFormat();
		df.applyPattern(DATEFORMAT_YYYY_MM_DD_HH_MM_SS);
		Calendar calendar = getCalendar();
		calendar.setTimeInMillis(dateTime);
		String time = df.format(calendar.getTime());
		return Timestamp.valueOf(time);
	}

	public static final String getCurrentTime() {
		SimpleDateFormat df = getSimpleDateFormat();
		df.applyPattern(DATEFORMAT_YYYY_MM_DD_HH_MM_SS);
		Calendar calendar = getCalendar();
		return df.format(calendar.getTime());
	}

	public static final String getCurrentTime1() {
		SimpleDateFormat df2 = getSimpleDateFormat();
		df2.applyPattern(DATEFORMAT_YYYY_M_MDD);
		Calendar calendar = getCalendar();
		return df2.format(calendar.getTime());
	}

	// Added by Leo Li
	public static String stringDateToStringDate(String strTime) throws ParseException {
		Date date = null;
		SimpleDateFormat formatter = getSimpleDateFormat();
		formatter.applyPattern(DATEFORMAT_YYYY_MM_DD);
		date = formatter.parse(strTime);
		SimpleDateFormat formatter2 = getSimpleDateFormat();
		formatter2.applyPattern(DATEFORMAT_DD_MM_YYYY);
		return formatter2.format(date);
	}

	public static String stringDateTimeToStringDateTime2(String strTime) throws ParseException {

		if (strTime == null || strTime.trim().length() < 1) {
			return "";
		}

		Date date = null;
		SimpleDateFormat formatter = getSimpleDateFormat();
		if (strTime.length() == 10) {
			formatter.applyPattern(DATEFORMAT_DD_MM_YYYY);
		} else {
			formatter.applyPattern(DATEFORMAT_DD_MM_YYYY_HH_MM_SS);
		}
		date = formatter.parse(strTime);
		SimpleDateFormat formatter2 = getSimpleDateFormat();
		formatter2.applyPattern(DATEFORMAT_YYYY_MM_DD_HH_MM_SS);
		return formatter2.format(date);
	}

	public static String stringDateTimeToStringDateTime(String strTime) throws ParseException {
		Date date = null;
		SimpleDateFormat formatter = getSimpleDateFormat();
		formatter.applyPattern(DATEFORMAT_YYYY_MM_DD_HH_MM_SS);
		date = formatter.parse(strTime);
		SimpleDateFormat formatter2 = getSimpleDateFormat();
		formatter2.applyPattern(DATEFORMAT_DD_MM_YYYY_HH_MM_SS);
		return formatter2.format(date);
	}

	/**
	 * 
	 * @param strTime
	 * @return
	 * @throws ParseException
	 * @author bsnpc37
	 * @date: Apr 26, 2018 2:05:23 PM
	 */
	public static String stringDateTimeToEnglishDateTime(String strTime) throws ParseException {

		if (strTime == null || strTime.trim().length() < 1) {
			return "";
		}

		Date date = null;
		SimpleDateFormat formatter = getSimpleDateFormat();
		if (strTime.contains("-")) {
			formatter.applyPattern(DATEFORMAT_YYYY_MM_DD_HH_MM_SS);
		} else if (strTime.contains("/")) {
			formatter.applyPattern(DATEFORMAT_DD_MM_YYYY_HH_MM_SS);
		}
		date = formatter.parse(strTime);
		SimpleDateFormat formatter2 = getSimpleDateFormat();
		formatter2.applyPattern(DATEFORMAT_DD_MMM_YYYY_HH_MM_SS);
		formatter2.setDateFormatSymbols(new DateFormatSymbols(Locale.ENGLISH));
		return formatter2.format(date);
	}

	// end
	public static String convertDateFornmat(String strTime, String sourceFormatStr, String formatStr)
			throws ParseException {
		Date date = null;
		SimpleDateFormat formatter = getSimpleDateFormat();
		formatter.applyPattern(sourceFormatStr);
		date = formatter.parse(strTime);
		SimpleDateFormat formatter2 = getSimpleDateFormat();
		formatter2.applyPattern(formatStr);
		return formatter2.format(date);
	}

}