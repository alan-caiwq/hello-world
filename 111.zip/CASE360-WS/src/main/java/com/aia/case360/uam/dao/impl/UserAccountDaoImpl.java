package com.aia.case360.uam.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.aia.case360.uam.dao.UserAccountDao;

@Component
public class UserAccountDaoImpl implements UserAccountDao {

	@Override
	public List<Map<String, Object>> getAuthorityByUserId(final String userId) {

		StringBuilder sql = new StringBuilder(" SELECT   RORE.UAM_ROLE_ID ");
		sql.append(" ,RORE.REQ_ID ");
		sql.append(" ,RORE.ACTIVITY_NAME AS ACT_ID ");
		sql.append(" ,REQ.DISPLAY_NAME AS REQ_NAME ");
		sql.append(" ,ACT.ACT_NM ");
		sql.append(" ,AA.PRIMARY_TRAINER_NM ");
		sql.append(" ,AA.IS_TRAINEE ");
		sql.append(" ,AA.BAK_TRAINER_NM ");
		sql.append(" ,AA.UAM_USER_ID ");
		sql.append(" FROM FD_UAM_ROLE RO ");
		sql.append(" LEFT JOIN FD_UAM_ROLEREQ_REF RORE ON RO.UAM_ROLE_ID = RORE.UAM_ROLE_ID ");
		sql.append(" LEFT JOIN FD_REQTYPE REQ ON REQ.REQ_TYPE+CONVERT(VARCHAR,REQ.VERSION_NUM ) = RORE.REQ_ID ");
		sql.append(
				" LEFT JOIN FD_ACT_INFO ACT ON ACT.REQ_TYPE+ACT.WORKSTEPNAME+CONVERT(VARCHAR,ACT.VERSION_NUM) = RORE.ACTIVITY_NAME ");
		sql.append(" LEFT JOIN ( ");
		sql.append(
				" SELECT RO.UAM_ROLE_ID,TRA.PRIMARY_TRAINER_NM,IS_TRAINEE,BAK_TRAINER_NM,US.UAM_USER_ID FROM FD_UAM_ROLE RO ");
		sql.append(" LEFT JOIN [FD_UAM_USERROLE_REF] REF ON REF.UAM_ROLE_ID = RO.UAM_ROLE_ID ");
		sql.append(" LEFT JOIN FD_UAM_USERS US ON upper(REF.UAM_USER_ID) = upper(US.UAM_USER_ID) ");
		sql.append(" LEFT JOIN [FD_UAM_USERTRAINING_REF] TRA ON upper(TRA.UAM_USER_ID) = upper(US.UAM_USER_ID) ");
		sql.append(" ) AA ON RO.UAM_ROLE_ID = AA.UAM_ROLE_ID ");
		sql.append(" WHERE upper(AA.UAM_USER_ID) = ? ");

		List<Map<String, Object>> Authoritys = (List<Map<String, Object>>) jdbcTemplate.query(sql.toString(),
				new PreparedStatementSetter() {

					@Override
					public void setValues(PreparedStatement ps) throws SQLException {

						int index = 1;
						ps.setString(index, userId.toUpperCase());

					}

				}, new RowMapper<Map<String, Object>>() {

					@Override
					public Map<String, Object> mapRow(ResultSet rs, int index) throws SQLException {
						Map<String, Object> map = new HashMap<String, Object>();
						ResultSetMetaData meta = rs.getMetaData();
						int count = meta.getColumnCount();
						for (int i = 1; i <= count; i++) {
							map.put(meta.getColumnName(i), rs.getObject(i) == null ? "" : rs.getObject(i));
						}
						return map;
					}
				});

		return Authoritys;
	}

	@Override
	public boolean deleteUserRoleByUserId(final String userId) {

		StringBuilder sql = new StringBuilder("DELETE FROM FD_UAM_USERROLE_REF WHERE upper(UAM_USER_ID) = ?");
		int sccuess = jdbcTemplate.update(sql.toString(), new Object[] { userId.toUpperCase() },
				new int[] { java.sql.Types.VARCHAR });
		return sccuess > 0 ? true : false;
	}

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public boolean insertUsers(Set<String> lanIds) {
		final List<String> adLanids = new ArrayList<String>();

		for (String lanid : lanIds) {
			adLanids.add(lanid.toUpperCase());
		}

		StringBuilder sql = new StringBuilder("INSERT INTO FD_UAM_USERS(UAM_USER_ID) VALUES(?) ");
		jdbcTemplate.batchUpdate(sql.toString(), new BatchPreparedStatementSetter() {

			@Override
			public int getBatchSize() {

				return adLanids.size();
			}

			@Override
			public void setValues(PreparedStatement pa, int i) throws SQLException {

				int index = 1;
				pa.setString(index, adLanids.get(i));

			}

		});
		return true;
	}

	@Override
	public List<Map<String, Object>> getUserInfoInFirestNodeByReq(final String req) {
		StringBuilder sql = new StringBuilder("SELECT * FROM [dbo].[FD_UAM_USERAUTH_REF] UAR");
		sql.append(" JOIN FD_UAM_USERS US ON  upper(UAR.UAM_USER_ID) = upper(US.UAM_USER_ID) ");
		sql.append(" WHERE ACT_NM = ( ");
		sql.append(" SELECT TOP 1 REQ.REQ_TYPE+ACT.ACT_NM+ACT.WORKSTEPNAME FROM [dbo].[FD_REQTYPE] REQ ");
		sql.append(
				" JOIN [dbo].[FD_ACT_INFO] ACT ON REQ.REQ_TYPE = ACT.REQ_TYPE WHERE ACT.IS_ENABLED = 1 AND  REQ.REQ_TYPE = ? ORDER BY ACT.WORKSTEPNAME DESC )");

		List<Map<String, Object>> result = (List<Map<String, Object>>) jdbcTemplate.query(sql.toString(),
				new PreparedStatementSetter() {

					@Override
					public void setValues(PreparedStatement ps) throws SQLException {

						int index = 1;
						ps.setString(index, req);

					}

				}, new RowMapper<Map<String, Object>>() {

					@Override
					public Map<String, Object> mapRow(ResultSet rs, int index) throws SQLException {
						Map<String, Object> map = new HashMap<String, Object>();
						ResultSetMetaData meta = rs.getMetaData();
						int count = meta.getColumnCount();
						for (int i = 1; i <= count; i++) {
							map.put(meta.getColumnName(i), rs.getObject(i) == null ? "" : rs.getObject(i));
						}
						return map;
					}
				});
		return result;
	}

	@Override
	public String getDeptByUserId(final String userId) {
		StringBuilder sql = new StringBuilder("  SELECT UAM_USER_DEPARTMENT FROM FD_UAM_USERS WHERE UAM_USER_ID = ? ");

		List<Map<String, Object>> result = (List<Map<String, Object>>) jdbcTemplate.query(sql.toString(),
				new PreparedStatementSetter() {

					@Override
					public void setValues(PreparedStatement ps) throws SQLException {

						int index = 1;
						ps.setString(index, userId.toUpperCase());

					}

				}, new RowMapper<Map<String, Object>>() {

					@Override
					public Map<String, Object> mapRow(ResultSet rs, int index) throws SQLException {
						Map<String, Object> map = new HashMap<String, Object>();
						ResultSetMetaData meta = rs.getMetaData();
						int count = meta.getColumnCount();
						for (int i = 1; i <= count; i++) {
							map.put(meta.getColumnName(i), rs.getObject(i) == null ? "" : rs.getObject(i));
						}
						return map;
					}
				});

		if (result == null || result.size() == 0) {
			return null;
		}

		return result.get(0).get("UAM_USER_DEPARTMENT").toString();
	}

	@Override
	public List<Map<String, Object>> getTrainee(final Map<String, String> param) {
		StringBuilder sql = new StringBuilder(
				"SELECT IS_TRAINEE,PRIMARY_TRAINER_NM,BAK_TRAINER_NM FROM FD_UAM_USERTRAINING_REF WHERE ACTIVITY_NAME = ? AND UAM_USER_ID = ?");

		List<Map<String, Object>> result = (List<Map<String, Object>>) jdbcTemplate.query(sql.toString(),
				new PreparedStatementSetter() {

					@Override
					public void setValues(PreparedStatement ps) throws SQLException {

						int index = 1;
						ps.setString(index++, param.get("actName"));
						ps.setString(index, param.get("userId").toUpperCase());

					}

				}, new RowMapper<Map<String, Object>>() {

					@Override
					public Map<String, Object> mapRow(ResultSet rs, int index) throws SQLException {
						Map<String, Object> map = new HashMap<String, Object>();
						ResultSetMetaData meta = rs.getMetaData();
						int count = meta.getColumnCount();
						for (int i = 1; i <= count; i++) {
							map.put(meta.getColumnName(i), rs.getObject(i) == null ? "" : rs.getObject(i));
						}
						return map;
					}
				});
		return result;
	}

	// added by bsnpc1g
	@Override
	public String getCompanyByUserId(final String userId) {
		StringBuilder sql = new StringBuilder("  SELECT USERCOMPANY FROM FD_UAM_USERS WHERE UAM_USER_ID = ? ");

		List<Map<String, Object>> result = (List<Map<String, Object>>) jdbcTemplate.query(sql.toString(),
				new PreparedStatementSetter() {

					@Override
					public void setValues(PreparedStatement ps) throws SQLException {

						int index = 1;
						ps.setString(index, userId.toUpperCase());

					}

				}, new RowMapper<Map<String, Object>>() {

					@Override
					public Map<String, Object> mapRow(ResultSet rs, int index) throws SQLException {
						Map<String, Object> map = new HashMap<String, Object>();
						ResultSetMetaData meta = rs.getMetaData();
						int count = meta.getColumnCount();
						for (int i = 1; i <= count; i++) {
							map.put(meta.getColumnName(i), rs.getObject(i) == null ? "" : rs.getObject(i));
						}
						return map;
					}
				});
		if (result.size() > 0) {
			return result.get(0).get("USERCOMPANY").toString();
		} else {
			return "";
		}

	}

	@Override
	public List<Map<String, String>> getTeamByUserId(final String userId) {
		StringBuilder sql = new StringBuilder("  SELECT UAM_USER_TEAM FROM FD_UAM_USERS WHERE UAM_USER_ID = ? ");

		List<Map<String, String>> result = (List<Map<String, String>>) jdbcTemplate.query(sql.toString(),
				new PreparedStatementSetter() {

					@Override
					public void setValues(PreparedStatement ps) throws SQLException {

						int index = 1;
						ps.setString(index, userId.toUpperCase());

					}

				}, new RowMapper<Map<String, String>>() {

					@Override
					public Map<String, String> mapRow(ResultSet rs, int index) throws SQLException {
						Map<String, String> map = new HashMap<String, String>();
						ResultSetMetaData meta = rs.getMetaData();
						int count = meta.getColumnCount();
						for (int i = 1; i <= count; i++) {
							map.put("currentUser", rs.getString(i) == null ? "" : rs.getString(i));
						}
						return map;
					}
				});

		return result;
	}

	@Override
	public List<Map<String, String>> getTeamList() {
		StringBuilder sql = new StringBuilder("SELECT UAM_COMPONENT_NAME,UAM_COMPONENT_ID FROM FD_UAM_COMPONENT with(nolock)");

		List<Map<String, String>> result = (List<Map<String, String>>) jdbcTemplate.query(sql.toString(),
				new PreparedStatementSetter() {

					@Override
					public void setValues(PreparedStatement ps) throws SQLException {
						// NOSONAR
					}

				}, new RowMapper<Map<String, String>>() {

					@Override
					public Map<String, String> mapRow(ResultSet rs, int index) throws SQLException {
						Map<String, String> map = new HashMap<String, String>();
						ResultSetMetaData meta = rs.getMetaData();
						int count = meta.getColumnCount();
						for (int i = 1; i <= count; i++) {
							map.put(meta.getColumnName(i), rs.getString(i) == null ? "" : rs.getString(i));
						}
						return map;
					}
				});

		return result;
	}

	// added end

	@Override
	public List<Map<String, String>> getUserTeamAndRole(final String userId) {

		String teamAndRoleListSql = "" + "select " + "concat(( "
				+ " SELECT DISTINCT STUFF((SELECT ',' + CAST(T2.UAM_COMPONENT_ID AS VARCHAR(MAX)) "
				+ "FROM FD_UAM_USERCOMPONENT_REF T2 WHERE upper(t1.UAM_USER_ID) = upper(t2.UAM_USER_ID)  AND t2.UAM_USER_POSITION = 'MEMBER' AND "
				+ T2_DELETEFILTER + "FOR XML path('')),1,1,'') SOMECOLUMN "
				+ "FROM FD_UAM_USERCOMPONENT_REF T1 where " + T1_DELETEFILTER
				+ " AND t1.UAM_USER_POSITION = 'MEMBER' AND upper(t1.UAM_USER_ID) = ? " + "),'') as UAM_USER_TEAM, "
				+ "concat(( " + "SELECT DISTINCT STUFF((SELECT ',' + CAST(T2.UAM_ROLE_ID AS VARCHAR(MAX)) "
				+ "FROM FD_UAM_USERROLE_REF T2 WHERE upper(t1.UAM_USER_ID) = upper(t2.UAM_USER_ID) AND "
				+ T2_DELETEFILTER + "FOR XML path('')),1,1,'') SOMECOLUMN " + "FROM FD_UAM_USERROLE_REF T1 where "
				+ T1_DELETEFILTER + " AND upper(t1.UAM_USER_ID) = ? " + "),'') as UAM_USER_ROLE";

		List<Map<String, String>> result = (List<Map<String, String>>) jdbcTemplate.query(teamAndRoleListSql,
				new PreparedStatementSetter() {

					@Override
					public void setValues(PreparedStatement ps) throws SQLException {

						int index = 1;
						ps.setString(index++, userId.toUpperCase());
						ps.setString(index, userId.toUpperCase());
					}

				}, new RowMapper<Map<String, String>>() {

					@Override
					public Map<String, String> mapRow(ResultSet rs, int index) throws SQLException {
						Map<String, String> map = new HashMap<String, String>();
						ResultSetMetaData meta = rs.getMetaData();
						int count = meta.getColumnCount();
						for (int i = 1; i <= count; i++) {
							map.put(meta.getColumnName(i), rs.getString(i) == null ? "" : rs.getString(i));
						}
						return map;
					}
				});

		return result;
	}


	private static final String T1_DELETEFILTER = " (T1.UAM_DELETE_FLAG IS NULL OR T1.UAM_DELETE_FLAG != 1) ";
	private static final String T2_DELETEFILTER = " (T2.UAM_DELETE_FLAG IS NULL OR T2.UAM_DELETE_FLAG != 1) ";
}
