package com.aia.case360.platform.query;

import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.eistream.sonora.fields.FmsRowSetTO;

public interface QueryHelper {

	/**
	 * Get user list by workstep
	 * 
	 * @param workstep
	 * @return UserId List
	 * @throws RemoteException
	 * 
	 */
	public ArrayList<Map<String, Object>> getUserListByWorkstep(String workstep) throws RemoteException;

	/**
	 * Get Role List by workstep name
	 * 
	 * @param workstep
	 * @return Role Map List
	 * @throws RemoteException
	 */
	public ArrayList<Map<String, Object>> getRoleListByWorkstep(String workstep) throws RemoteException;

	/**
	 * Get queue names by userId
	 * 
	 * @param userId
	 * @return Queue name Map List
	 * @throws RemoteException
	 */
	public ArrayList<Map<String, Object>> getMyQueueNames(String userId) throws RemoteException;

	/**
	 * Get document information by caseId
	 * 
	 * @param caseId
	 * @return Document url Map List
	 * @throws RemoteException
	 */
	public ArrayList<Map<String, Object>> getDocumentInfo(String caseId, String userId) throws RemoteException;

	/**
	 * Get QueueHeader Queue Name WorkItem Num by userId
	 * 
	 * @param userId Login userId
	 * @return Queue header Map List
	 * @throws RemoteException
	 */
	public ArrayList<Map<String, Object>> getMyQueueHeaders(String userId) throws RemoteException;

	/**
	 * Get QueueHeader Queue Name WorkItem Num by userId,workstep,workflowId
	 * 
	 * @param userId
	 * @param workstep
	 * @param workflowId
	 * @return
	 * @throws RemoteException
	 */
	public ArrayList<Map<String, Object>> getMyQueueHeaders(String userId, String workstep, String workflowId)
			throws RemoteException;

	/**
	 * Get userId's next job by workstep
	 * 
	 * @param userId   login userId should be registered in Case360 side.
	 * @param workstep activity name indicates which activity queue for finding
	 *                 workitems of the current user
	 * @return queryResults
	 * @throws RemoteException
	 */


	/**
	 * 
	 * Get userId's own job list by workstep
	 * 
	 * @param userId   login userId should be registered in Case360 side.
	 * @param workstep activity name indicates which activity queue for finding
	 *                 workitems of the current user
	 * @return queryResults
	 * @throws RemoteException
	 */
	public ArrayList<Map<String, Object>> getJobs(String userId, String workstep, String pndWait)
			throws RemoteException;

	/**
	 * Return all pending reason definitions based on category
	 * 
	 * @param pendingReasonCatory
	 * @return
	 * @throws RemoteException
	 */
	public ArrayList<Map<String, Object>> getPendingReasons(String pendingReasonCatory) throws RemoteException;

	/**
	 * Return all my pending workitems list
	 * 
	 * @param userId
	 * @return
	 * @throws RemoteException
	 */
	public ArrayList<Map<String, Object>> getMyPendings(String userId) throws RemoteException;

	/**
	 * Return the pending workitem number belongs to the userId
	 * 
	 * @param userId
	 * @return
	 * @throws RemoteException
	 */
	public ArrayList<Map<String, Object>> getMyPendingCount(String userId) throws RemoteException;

	/**
	 * Return all un-received pending reason history for the workitem which caseId
	 * indicated
	 * 
	 * @param caseId
	 * @return
	 * @throws RemoteException
	 */
	public ArrayList<Map<String, Object>> getUnreceivedPendingReasons(String caseId) throws RemoteException;

	/**
	 * Return userId for workitem's workstep and caseId
	 * 
	 * @param workstep
	 * @param caseId
	 * @return userId
	 * @throws RemoteException
	 */
	public String getUserId(String caseId, String workstep) throws RemoteException;

	public FmsRowSetTO[] getUnreceivedPendHistory(String caseId) throws RemoteException;

	/**
	 * Return all pending history records for the caseId
	 * 
	 * @param caseId
	 * @return
	 * @throws RemoteException
	 */
	public ArrayList<Map<String, Object>> getAllPendingHistory(String caseId) throws RemoteException;

	/**
	 * Return Audit Trail for the Casefolder
	 * 
	 * @param caseId
	 * @return
	 * @throws RemoteException
	 */
	public ArrayList<Map<String, Object>> getAllAuditTrail(String caseId) throws RemoteException;

	/**
	 * Return queries's form fields
	 * 
	 * @param queryName
	 * @return
	 * @throws RemoteException
	 */
	public ArrayList<String> getFormFields(String queryName) throws RemoteException;

	/**
	 * 
	 * @param queryParams
	 * @param queryName
	 * @return
	 * @throws RemoteException
	 */
	public ArrayList<Map<String, Object>> doQuery(Map<String, String> queryParams, String queryName)
			throws RemoteException;

	/**
	 * 
	 * @param parameters
	 * @return
	 * @throws RemoteException
	 */
	public ArrayList<Map<String, Object>> getUnknownDocList(Map<String, String> parameters) throws RemoteException;

	/**
	 * Get all RequestType and Category
	 * 
	 * @param requestType
	 * @param category
	 * @return
	 * @throws RemoteException
	 */
	public ArrayList<Map<String, Object>> getReqTypeAndCategory(String requestType, String category)
			throws RemoteException;

	/**
	 * Get all RequestType and FormId
	 * 
	 * @param requestType
	 * @param category
	 * @return
	 * @throws RemoteException
	 */
	public ArrayList<Map<String, Object>> getReqTypeAndFormId(String requestType, String formId) throws RemoteException;

	public ArrayList<Map<String, Object>> getFormIdAndDocType() throws RemoteException;

	public ArrayList<Map<String, Object>> getPolicyTable(String policyNum) throws RemoteException;

	public ArrayList<Map<String, Object>> getDocumentTypeTable(String formID) throws RemoteException;

	public ArrayList<Map<String, Object>> getReqTypeConfigTable(String formID) throws RemoteException;

	public ArrayList<Map<String, Object>> getInsuredCoverageTable(String policyNum, String certNum)
			throws RemoteException;

	public ArrayList<Map<String, Object>> getWorkFolderTable(Map<String, String> parameters) throws RemoteException;

	public ArrayList<Map<String, Object>> getWorkItemTable(Map<String, String> parameters) throws RemoteException;

	public ArrayList<Map<String, Object>> getDocIdByMasterId(Map<String, String> parameters) throws RemoteException;

	public ArrayList<Map<String, Object>> getworkfolderByOrganiza(Map<String, String> parameters)
			throws RemoteException;

	public ArrayList<Map<String, Object>> getUnKnowDoc(Map<String, String> parameters) throws RemoteException;

	public ArrayList<Map<String, Object>> getCaseFolderByInsuredCode(Map<String, String> parameters)
			throws RemoteException;

	/**
	 * Get document information
	 * 
	 * @param queryParams
	 * @return Document url Map List
	 * @throws RemoteException
	 */
	public ArrayList<Map<String, Object>> getDocumentInfo(Map<String, String> queryParams) throws RemoteException;

	public ArrayList<Map<String, Object>> getPolicyByPolicyNum(String policyNum) throws RemoteException;

	public ArrayList<Map<String, Object>> getProcessByReqType(String requestType) throws RemoteException;

	public ArrayList<Map<String, Object>> getMasterFolder(String orgCode) throws RemoteException;

	public ArrayList<Map<String, Object>> getMyTeamWorkList(String users) throws RemoteException;

	public ArrayList<Map<String, Object>> getUnassignedWorkList(String user, String workStepName)
			throws RemoteException;

	public ArrayList<Map<String, Object>> getMemberNum(String masterId, String policyNum) throws RemoteException;

	/**
	 * Get work folder by parameters used: Vietnam
	 * 
	 * @param PSO_REQ_NO
	 * @return
	 * @throws RemoteException
	 * @author bsnpbrs 2016.11.1
	 */
	public ArrayList<Map<String, Object>> getWorkFolder(Map<String, String> parameters) throws RemoteException;

	/**
	 * Get work folder by parameters used: Vietnam
	 * 
	 * @param LINKCASEID
	 * @return
	 * @throws RemoteException
	 * @author bsnpbrs 2016.11.1
	 */
	public ArrayList<Map<String, Object>> getChangeItems(Map<String, String> parameters) throws RemoteException;

	/**
	 * Get work folder by parameters used: Vietnam
	 * 
	 * @param LINKCASEID
	 * @return
	 * @throws RemoteException
	 * @author bsnpbrs 2016.11.1
	 */
	ArrayList<Map<String, Object>> getWorkItem(Map<String, String> parameters) throws RemoteException;

	ArrayList<Map<String, Object>> getPendingReason(String id) throws RemoteException;

	ArrayList<Map<String, Object>> getCustomerInfo(String clientId) throws RemoteException;

	ArrayList<Map<String, Object>> getPolicyInfoByClient(String clientId) throws RemoteException;

	ArrayList<Map<String, Object>> getDocsListByClient(String clientId, String userId) throws RemoteException;

	ArrayList<Map<String, Object>> getWorkitemByRepKey(String repositoryKey) throws RemoteException;

	ArrayList<Map<String, Object>> getCustomersByPolNo(String polNum) throws RemoteException;

	ArrayList<Map<String, Object>> getPendingWiRepKey(Map<String, String> queryparam) throws RemoteException;

	ArrayList<Map<String, Object>> getAclByUser(String currentUser) throws RemoteException;

	ArrayList<Map<String, Object>> getUnKnowDocList(Map<String, String> params) throws RemoteException;

	// added by Leo Li
	/**
	 * Get document by object ID
	 * 
	 * @author bsnpc37
	 * @param parameters
	 * @return
	 * @throws RemoteException
	 */
	Map<String, Object> getDocumentByID(Map<String, String> parameters) throws RemoteException;

	ArrayList<Map<String, Object>> getDocumentList(Map<String, String> parameters) throws RemoteException;

	Map<String, Object> getDocumentByIDOMS(Map<String, String> parameters) throws RemoteException;

	ArrayList<Map<String, Object>> getDocumentListOMS(Map<String, String> parameters) throws RemoteException;

	Map<String, Object> getCaseByRequestNo(Map<String, String> parameters) throws RemoteException;

	ArrayList<Map<String, Object>> getRequestType(Map<String, String> parameters) throws RemoteException;

	ArrayList<Map<String, Object>> getParentRequestNoByPolicyNo(Map<String, Object> parameters) throws RemoteException;

	ArrayList<Map<String, Object>> getRequestNoByPolicyNo(Map<String, Object> parameters) throws RemoteException;

	/**
	 * Get form into list
	 * 
	 * @param parameters
	 * @return ArrayList<Map<String, Object>>
	 * @throws RemoteException
	 */
	ArrayList<Map<String, Object>> getFormInfo() throws RemoteException;

	/**
	 * Get case status by request no(For eCare CRS)
	 * 
	 * @param parameters
	 * @return
	 * @throws RemoteException
	 */
	ArrayList<Map<String, Object>> getRequestStatusByRequestNo(Map<String, Object> parameters) throws RemoteException;

	/**
	 * Pending case force Force pend case at any activity, should provide reason
	 * 
	 * @param parameters
	 * @return
	 * @throws RemoteException
	 */
	ArrayList<Map<String, Object>> pendingCase(Map<String, Object> parameters) throws RemoteException;

	// end

	/**
	 * query the system config and the reqtype avalible steps
	 * 
	 * @param query paramters
	 * @return
	 * @throws RemoteException
	 * @author bsnpbud 2018.01.15
	 */
	public ArrayList<Map<String, Object>> getSytemConfigByConfigNameAndValue(Map<String, String> params)
			throws RemoteException;

	public ArrayList<Map<String, Object>> getReqtypeAvalibleSteps(Map<String, String> params) throws RemoteException;

	public ArrayList<Map<String, Object>> getReqtypeCustomInfo(Map<String, String> params) throws RemoteException;

	public ArrayList<Map<String, Object>> getReqTypeFunctions(Map<String, String> params) throws RemoteException;

	public ArrayList<Map<String, Object>> getPendingReasonByInputValue(Map<String, String> params)
			throws RemoteException;

	public ArrayList<Map<String, Object>> getFormIDAndNM(Map<String, String> params) throws RemoteException;

	/**
	 * call Procedure to get query result.
	 * 
	 * @param map
	 * @param procedureName {call getTestData(?, ?)}
	 * @return
	 */
	public List<Map<String, Object>> callProcedureAsQuery(Map<Integer, Object> map, String procedureName);

	/**
	 * call Procedure to get query result.
	 * 
	 * @param map
	 * @param procedureName {call updateTestData(?, ?)}
	 * @return
	 */
	public boolean callProcedureForUpdate(Map<Integer, Object> map, String procedureName);

	/**
	 * 
	 * @param queryParams
	 * @param sql
	 * @throws RemoteException
	 * @throws SQLException
	 */
	public boolean doUpdate(Map<Integer, Object> queryParams, String sql) throws RemoteException, SQLException;

	public String callProcedureGetSingleValue(Map<Integer, Object> map, String procedureName);
}