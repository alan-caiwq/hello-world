package com.aia.case360.web.pojo;

import java.math.BigDecimal;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

public class CustFormDef {

	private String acl;
	private String categoryCode;
	private String categoryNM;
	private String custEdocNm;
	private short isDeleted;// smallint

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	private Date expireTime;
	private String formId;
	private String isSurpressPrint;
	private BigDecimal isVoid; // decimal
	private String lastUpdatedBy;
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	private Date lastUpdatedTimestamp;
	private String notificationType;
	private BigDecimal sRowid;
	private String systemNm;
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	private Date effectiveDt;
	private String formCategory;

	/**
	 * @return the formCategory
	 */
	public String getFormCategory() {
		return formCategory;
	}

	/**
	 * @param formCategory the formCategory to set
	 */
	public void setFormCategory(String formCategory) {
		this.formCategory = formCategory;
	}

	public String getAcl() {
		return acl;
	}

	public void setAcl(String acl) {
		this.acl = acl;
	}

	public String getCategoryCode() {
		return categoryCode;
	}

	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}

	public String getCustEdocNm() {
		return custEdocNm;
	}

	public void setCustEdocNm(String custEdocNm) {
		this.custEdocNm = custEdocNm;
	}

	public Date getExpireTime() {
		return expireTime;
	}

	public void setExpireTime(Date expireTime) {
		this.expireTime = expireTime;
	}

	public String getFormId() {
		return formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}

	public String getIsSurpressPrint() {
		return isSurpressPrint;
	}

	public void setIsSurpressPrint(String isSurpressPrint) {
		this.isSurpressPrint = isSurpressPrint;
	}

	public BigDecimal getIsVoid() {
		return isVoid;
	}

	public void setIsVoid(BigDecimal isVoid) {
		this.isVoid = isVoid;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Date lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public String getNotificationType() {
		return notificationType;
	}

	public void setNotificationType(String notificationType) {
		this.notificationType = notificationType;
	}

	public BigDecimal getsRowid() {
		return sRowid;
	}

	public void setsRowid(BigDecimal sRowid) {
		this.sRowid = sRowid;
	}

	public String getSystemNm() {
		return systemNm;
	}

	public void setSystemNm(String systemNm) {
		this.systemNm = systemNm;
	}

	public Date getEffectiveDt() {
		return effectiveDt;
	}

	public void setEffectiveDt(Date effectiveDt) {
		this.effectiveDt = effectiveDt;
	}

	public short getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(short isDeleted) {
		this.isDeleted = isDeleted;
	}

	public String getCategoryNM() {
		return categoryNM;
	}

	public void setCategoryNM(String categoryNM) {
		this.categoryNM = categoryNM;
	}

}
