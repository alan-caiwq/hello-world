package com.aia.case360.web.pojo;

public class FdDocAttr {

	private String policy_no;

	private String process_type;

	private String object_id;
	
	private String objectName;
	
	private String batchNo;
	
	private String requestNo;

	private String name;

	private String receivedDate;

	private String formId;
	private String submissionChannel;
	private String companyNo;
	
	private String linkIndicator;
	
	private String statusIndicator;
	
	private String pageIndicator;
	
	private String claimNo;

	public String getCompanyNo() {
		return companyNo;
	}

	public void setCompanyNo(String companyNo) {
		this.companyNo = companyNo;
	}

	public String getSubmissionChannel() {
		return submissionChannel;
	}

	public void setSubmissionChannel(String submissionChannel) {
		this.submissionChannel = submissionChannel;
	}

	public String getFormId() {
		return formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}

	public String getReceivedDate() {
		return receivedDate;
	}

	public void setReceivedDate(String receivedDate) {
		this.receivedDate = receivedDate;
	}

	public String getPolicy_no() {
		return policy_no;
	}

	public void setPolicy_no(String policy_no) {
		this.policy_no = policy_no;
	}

	public String getProcess_type() {
		return process_type;
	}

	public void setProcess_type(String process_type) {
		this.process_type = process_type;
	}

	public String getObject_id() {
		return object_id;
	}

	public void setObject_id(String object_id) {
		this.object_id = object_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

  /**
   * @return the objectName
   */
  public String getObjectName() {
    return objectName;
  }

  /**
   * @param objectName the objectName to set
   */
  public void setObjectName(String objectName) {
    this.objectName = objectName;
  }

  /**
   * @return the batchNo
   */
  public String getBatchNo() {
    return batchNo;
  }

  /**
   * @return the requestNo
   */
  public String getRequestNo() {
    return requestNo;
  }

  /**
   * @param batchNo the batchNo to set
   */
  public void setBatchNo(String batchNo) {
    this.batchNo = batchNo;
  }

  /**
   * @param requestNo the requestNo to set
   */
  public void setRequestNo(String requestNo) {
    this.requestNo = requestNo;
  }

  /**
   * @return the linkIndicator
   */
  public String getLinkIndicator() {
    return linkIndicator;
  }

  /**
   * @return the statusIndicator
   */
  public String getStatusIndicator() {
    return statusIndicator;
  }

  /**
   * @return the pageIndicator
   */
  public String getPageIndicator() {
    return pageIndicator;
  }

  /**
   * @param linkIndicator the linkIndicator to set
   */
  public void setLinkIndicator(String linkIndicator) {
    this.linkIndicator = linkIndicator;
  }

  /**
   * @param statusIndicator the statusIndicator to set
   */
  public void setStatusIndicator(String statusIndicator) {
    this.statusIndicator = statusIndicator;
  }

  /**
   * @param pageIndicator the pageIndicator to set
   */
  public void setPageIndicator(String pageIndicator) {
    this.pageIndicator = pageIndicator;
  }

  /**
   * @return the claimNo
   */
  public String getClaimNo() {
    return claimNo;
  }

  /**
   * @param claimNo the claimNo to set
   */
  public void setClaimNo(String claimNo) {
    this.claimNo = claimNo;
  }
}
