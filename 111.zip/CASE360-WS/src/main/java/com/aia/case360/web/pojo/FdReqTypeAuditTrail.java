package com.aia.case360.web.pojo;

import java.math.BigDecimal;
import java.util.Date;

public class FdReqTypeAuditTrail {
	private BigDecimal parent_id;
	private String acl;
	private String action_desc;
	private String category;
	private String created_by;
	private Date created_timestamp;
	private String req_type;
	private String version_num;

	public String getAcl() {
		return acl;
	}

	public void setAcl(String acl) {
		this.acl = acl;
	}

	public void setVersion_num(String version_num) {
		this.version_num = version_num;
	}

	public String getAction_desc() {
		return action_desc;
	}

	public void setAction_desc(String action_desc) {
		this.action_desc = action_desc;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public Date getCreated_timestamp() {
		return created_timestamp;
	}

	public void setCreated_timestamp(Date created_timestamp) {
		this.created_timestamp = created_timestamp;
	}

	public String getReq_type() {
		return req_type;
	}

	public void setReq_type(String req_type) {
		this.req_type = req_type;
	}

	public String getVersion_num() {
		return version_num;
	}

	public BigDecimal getParent_id() {
		return parent_id;
	}

	public void setParent_id(BigDecimal parent_id) {
		this.parent_id = parent_id;
	}

	@Override
	public String toString() {
		return "FdReqTypeAuditTrail [parent_id=" + parent_id + ", acl=" + acl + ", action_desc=" + action_desc
				+ ", category=" + category + ", created_by=" + created_by + ", created_timestamp=" + created_timestamp
				+ ", req_type=" + req_type + ", version_num=" + version_num + "]";
	}

}
