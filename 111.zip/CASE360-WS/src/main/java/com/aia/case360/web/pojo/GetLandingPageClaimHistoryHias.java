package com.aia.case360.web.pojo;

import java.sql.Timestamp;

public class GetLandingPageClaimHistoryHias {
	private String policyNo;
	private String claimNo;
	private String claimType;
	private Timestamp claimSubmissionDate;
	private Timestamp incidentDate;
	private String benefit;
	private String settledAmount;
	private String claimDecision;
	private String assessorID;
	private String lifeAssuredNRIC;
	private String claimComment;

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public String getClaimType() {
		return claimType;
	}

	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}

	public Timestamp getClaimSubmissionDate() {
		return claimSubmissionDate;
	}

	public void setClaimSubmissionDate(Timestamp claimSubmissionDate) {
		this.claimSubmissionDate = claimSubmissionDate;
	}

	public Timestamp getIncidentDate() {
		return incidentDate;
	}

	public void setIncidentDate(Timestamp incidentDate) {
		this.incidentDate = incidentDate;
	}

	public String getBenefit() {
		return benefit;
	}

	public void setBenefit(String benefit) {
		this.benefit = benefit;
	}

	public String getSettledAmount() {
		return settledAmount;
	}

	public void setSettledAmount(String settledAmount) {
		this.settledAmount = settledAmount;
	}

	public String getClaimDecision() {
		return claimDecision;
	}

	public void setClaimDecision(String claimDecision) {
		this.claimDecision = claimDecision;
	}

	public String getAssessorID() {
		return assessorID;
	}

	public void setAssessorID(String assessorID) {
		this.assessorID = assessorID;
	}

	public String getLifeAssuredNRIC() {
		return lifeAssuredNRIC;
	}

	public void setLifeAssuredNRIC(String lifeAssuredNRIC) {
		this.lifeAssuredNRIC = lifeAssuredNRIC;
	}

	public String getClaimComment() {
		return claimComment;
	}

	public void setClaimComment(String claimComment) {
		this.claimComment = claimComment;
	}
}
