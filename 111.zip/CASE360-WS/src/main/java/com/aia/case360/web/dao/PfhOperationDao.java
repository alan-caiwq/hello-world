package com.aia.case360.web.dao;

import java.rmi.RemoteException;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.aia.case360.web.vo.FolderHierarchy;
import com.aia.case360.web.vo.FormHierarchy;

@Repository
public interface PfhOperationDao {

	LinkedList<FolderHierarchy> getTrees(Map<String, Object> paramMap)  throws RemoteException;

	LinkedList<FormHierarchy> getForms(Map<String, Object> paramMap)  throws RemoteException;

	int addFolderHierarchy(Map<String, Object> paramMap)  throws RemoteException;

	int editFolderHierarchy(Map<String, Object> paramMap)  throws RemoteException;

	int delFolderHierarchy(Map<String, Object> paramMap)  throws RemoteException;

	int addFormHierarchy(Map<String, Object> paramMap)  throws RemoteException;

	int editFormHierarchy(Map<String, Object> paramMap)  throws RemoteException;

	int delFormHierarchy(Map<String, Object> paramMap)  throws RemoteException;

	int checkIfIsDynamic(Map<String, Object> paramMap)  throws RemoteException;

	List<Map<String, Object>> getAllFolderIdList()  throws RemoteException;

	List<Map<String, Object>> getFormSRowIds(Map<String, Object> params)  throws RemoteException;

	List<Map<String, Object>> getFolderSRowIds(Map<String, Object> params)  throws RemoteException;

	List<Map<String, Object>> getFolderSRowIdOrders(Map<String, Object> params)  throws RemoteException;

	int checkIfFolderExist(Map<String, Object> paramMap)  throws RemoteException;

	Map<String, Object> getMaxFolderOrder(Map<String, Object> paramMap)  throws RemoteException;

	List<Map<String, Object>> searchFolder(@Param(value = "folderId") String folderId)  throws RemoteException;

}
