package com.aia.case360.web.auditTrail.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import com.aia.case360.web.auditTrail.AuditFileTypeEnum;

/**
 * 
 * @author bsnpbjd
 * @version only the class field annotated as AuditField will shows in Audit.
 *          otherwise, the field will be ignored.
 */
@Documented
@Retention(value = java.lang.annotation.RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface AuditField {
	// the field name shows in audit trail.
	String fieldName();

	// not in user currently.
	String relationName() default "";

	// AuditFileTypeEnum.FIELD means field.
	// AuditFileTypeEnum.RELATION means a reference entity list.
	AuditFileTypeEnum fieldType();
}
