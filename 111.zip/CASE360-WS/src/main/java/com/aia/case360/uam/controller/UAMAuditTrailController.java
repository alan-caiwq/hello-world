package com.aia.case360.uam.controller;

import java.rmi.RemoteException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.aia.case360.uam.domain.UAMAuditTrail;
import com.aia.case360.uam.domain.UAMGetAuditTrailParam;
import com.aia.case360.uam.domain.UAMGetOrganizationAuditTrailParam;
import com.aia.case360.uam.domain.UAMOrganizationAuditTrail;
import com.aia.case360.uam.service.UAMAuditTrailService;
import com.aia.case360.web.webservice.AbstractController;

@RestController
public class UAMAuditTrailController extends AbstractController {

	private static final String LOCAL_GET_UAM_ORGANIZATION_AUDIT_TRAIL = "getUAMOrganizationAuditTrail ";
	private static final String LOCAL_GET_UAM_AUDIT_TRAIL = "getUAMAuditTrail ";
	@Autowired
	UAMAuditTrailService auditTrailService;

	@RequestMapping(value = "/case/uam/audittrail", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<UAMAuditTrail>> getUAMAuditTrail(@Valid @RequestBody UAMGetAuditTrailParam param,
			HttpServletRequest request)  throws RemoteException {
		String uuidStr = getReqUUID();
		m_Logger.info(LOCAL_GET_UAM_AUDIT_TRAIL + uuidStr + " start.");
		m_Logger.info(LOCAL_GET_UAM_AUDIT_TRAIL + uuidStr + " param:" + param);

		List<UAMAuditTrail> result = auditTrailService.getUAMAuditTrail(param, uuidStr);

		HttpHeaders headers = new HttpHeaders();
		headers.set("uuid", uuidStr);

		m_Logger.info(LOCAL_GET_UAM_AUDIT_TRAIL + uuidStr + " end.");

		return new ResponseEntity<List<UAMAuditTrail>>(result, headers, HttpStatus.OK);
	}

	@RequestMapping(value = "/case/uam/organizationAudittrail", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<UAMOrganizationAuditTrail>> getUAMOrganizationAuditTrail(
			@Valid @RequestBody UAMGetOrganizationAuditTrailParam param, HttpServletRequest request)  throws RemoteException {
		String uuidStr = getReqUUID();
		m_Logger.info(LOCAL_GET_UAM_ORGANIZATION_AUDIT_TRAIL + uuidStr + " start.");
		m_Logger.info(LOCAL_GET_UAM_ORGANIZATION_AUDIT_TRAIL + uuidStr + " param:" + param);

		List<UAMOrganizationAuditTrail> result = auditTrailService.getUAMOrganizationAuditTrail(param, uuidStr);

		HttpHeaders headers = new HttpHeaders();
		headers.set("uuid", uuidStr);

		m_Logger.info(LOCAL_GET_UAM_ORGANIZATION_AUDIT_TRAIL + uuidStr + " end.");

		return new ResponseEntity<List<UAMOrganizationAuditTrail>>(result, headers, HttpStatus.OK);
	}
}
