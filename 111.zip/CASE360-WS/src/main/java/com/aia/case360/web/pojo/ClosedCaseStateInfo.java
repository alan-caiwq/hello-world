package com.aia.case360.web.pojo;

public class ClosedCaseStateInfo {

	String policyNo;

	String companyNo;

	String policyStateCode;

	String processCode;

	String createDate;

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getCompanyNo() {
		return companyNo;
	}

	public void setCompanyNo(String companyNo) {
		this.companyNo = companyNo;
	}

	public String getPolicyStateCode() {
		return policyStateCode;
	}

	public void setPolicyStateCode(String policyStateCode) {
		this.policyStateCode = policyStateCode;
	}

	public String getProcessCode() {
		return processCode;
	}

	public void setProcessCode(String processCode) {
		this.processCode = processCode;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

}
