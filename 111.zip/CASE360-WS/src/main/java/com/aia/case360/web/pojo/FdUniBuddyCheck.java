package com.aia.case360.web.pojo;

import java.math.BigDecimal;

public class FdUniBuddyCheck {
	private BigDecimal sRowid;
	private String primaryBackup;
	private String acl;
	private String secondBackup;
	private String uniUser;
	private short isDeleted;// smallint

	public String getPrimaryBackup() {
		return primaryBackup;
	}

	public void setPrimaryBackup(String primaryBackup) {
		this.primaryBackup = primaryBackup;
	}

	public String getAcl() {
		return acl;
	}

	public void setAcl(String acl) {
		this.acl = acl;
	}

	public String getSecondBackup() {
		return secondBackup;
	}

	public void setSecondBackup(String secondBackup) {
		this.secondBackup = secondBackup;
	}

	public short getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(short isDeleted) {
		this.isDeleted = isDeleted;
	}

	public String getUniUser() {
		return uniUser;
	}

	public void setUniUser(String uniUser) {
		this.uniUser = uniUser;
	}

	public BigDecimal getsRowid() {
		return sRowid;
	}

	public void setsRowid(BigDecimal sRowid) {
		this.sRowid = sRowid;
	}

}
