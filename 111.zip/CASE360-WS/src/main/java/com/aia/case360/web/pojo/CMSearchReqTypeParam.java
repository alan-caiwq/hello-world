package com.aia.case360.web.pojo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CMSearchReqTypeParam {
  
  @JsonProperty("DEPARTMENT")
  private String department;
  
  @JsonProperty("CATEGORY")
  private String category;
  
  @JsonProperty("REQ_TYPE")
  private String reqType;

  /**
   * @return the department
   */
  public String getDepartment() {
    return department;
  }

  /**
   * @return the category
   */
  public String getCategory() {
    return category;
  }

  /**
   * @return the reqType
   */
  public String getReqType() {
    return reqType;
  }

  /**
   * @param department the department to set
   */
  public void setDepartment(String department) {
    this.department = department;
  }

  /**
   * @param category the category to set
   */
  public void setCategory(String category) {
    this.category = category;
  }

  /**
   * @param reqType the reqType to set
   */
  public void setReqType(String reqType) {
    this.reqType = reqType;
  }

  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "CMSearchReqTypeParam [department=" + department + ", category=" + category
        + ", reqType=" + reqType + "]";
  }
}
