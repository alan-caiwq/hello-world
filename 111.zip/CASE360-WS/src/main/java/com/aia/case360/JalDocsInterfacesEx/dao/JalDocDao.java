package com.aia.case360.JalDocsInterfacesEx.dao;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import com.aia.case360.JalDocsInterfacesEx.vo.InputParamVo;
import com.aia.case360.JalDocsInterfacesEx.vo.PolNumReqs;

public interface JalDocDao {


	public List<Map<String, Object>> getCodeLookup(String codeClass) throws RemoteException;

	
	/**
	 * 
	 * @param logicalLinkParameters :  String action, String linkId, String parentId, String companyNo, String policyNo,
	 *		String requestNo, String formId, String processType, String status, String receivedDate
	 * @return
	 * @ throws RemoteException
	 */
	public String createLogicalLink(String...logicalLinkParameters ) throws RemoteException;

	public boolean updateEx360infoByLinkId(PolNumReqs polNumReq, String receivedDate, String status);

	public boolean insertExLogicalLink(InputParamVo params, PolNumReqs polNumReq, String receivedDate, String status);

	public Map<String, Object> checkE360LogicalLinkByLinkId(String linkId);

}
