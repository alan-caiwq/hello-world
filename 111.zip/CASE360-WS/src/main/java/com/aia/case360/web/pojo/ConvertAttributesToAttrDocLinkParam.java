package com.aia.case360.web.pojo;

public class ConvertAttributesToAttrDocLinkParam {
	/**
	 * document objectId
	 */
	private String objectId;
	/**
	 * whether to delete record of FD_DOC_ATTRIBUTES 1/delete; 0/not delete
	 */
	private Integer deleteAttributes;

	/**
	 * @return the objectId
	 */
	public String getObjectId() {
		return objectId;
	}

	/**
	 * @return the deleteAttributes
	 */
	public Integer getDeleteAttributes() {
		return deleteAttributes;
	}

	/**
	 * @param objectId the objectId to set
	 */
	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}

	/**
	 * @param deleteAttributes the deleteAttributes to set
	 */
	public void setDeleteAttributes(Integer deleteAttributes) {
		this.deleteAttributes = deleteAttributes;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ConvertAttributesToAttrDocLinkParam [objectId=" + objectId + ", deleteAttributes=" + deleteAttributes
				+ "]";
	}

}
