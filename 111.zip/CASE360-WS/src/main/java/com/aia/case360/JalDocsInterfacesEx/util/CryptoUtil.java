package com.aia.case360.JalDocsInterfacesEx.util;

import java.rmi.RemoteException;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public class CryptoUtil extends Object {

	/**
	 * Generate an AES 128bit key.
	 * 
	 * @return
	 * @ throws RemoteException
	 */
	public static byte[] generateKey()  throws RemoteException {
		try {
			KeyGenerator kgen = KeyGenerator.getInstance("AES");
			kgen.init(128);
			SecretKey skey = kgen.generateKey();
			return skey.getEncoded();
		} catch (Exception e) {
			throw new RemoteException(e.toString());
		}
	}

	/**
	 * Encrypt the source according to the key
	 * 
	 * @param key
	 * @param source
	 * @return
	 * @ throws RemoteException
	 */
	public static String encrypt(byte[] key, byte[] source)  throws RemoteException {
		try {
			SecretKeySpec skeySpec = new SecretKeySpec(key, "AES");
			Cipher cipher = Cipher.getInstance("AES");
			cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
			return byteArrayToString(cipher.doFinal(source));
		} catch (Exception e) {
			throw new RemoteException(e.toString());
		}
	}

	/**
	 * Decrypt the encryped string to the original byte array.
	 * 
	 * @param key
	 * @param encrypted
	 * @return
	 * @ throws RemoteException
	 */
	public static byte[] decrypt(byte[] key, String encrypted)  throws RemoteException {
		try {
			SecretKeySpec skeySpec = new SecretKeySpec(key, "AES");
			Cipher cipher = Cipher.getInstance("AES");
			cipher.init(Cipher.DECRYPT_MODE, skeySpec);
			return cipher.doFinal(stringToByteArray(encrypted));
		} catch (Exception e) {
			throw new RemoteException(e.toString());
		}

	}

	/**
	 * Function to convert the byte array to a displayable hex string
	 * 
	 * @param buf
	 * @return
	 */
	public static String byteArrayToString(byte buf[]) {
		StringBuilder strbuf = new StringBuilder(buf.length * 2);
		int i;

		for (i = 0; i < buf.length; i++) {
			if (((int) buf[i] & 0xff) < 0x10) {
				strbuf.append("0");
			}
			strbuf.append(Long.toString(buf[i] & 0xFF, 16));
		}
		return strbuf.toString();
	}

	/**
	 * Convert the disable hex string to the original byte array
	 * 
	 * @param encodedString
	 * @return
	 */
	public static byte[] stringToByteArray(String encodedString) {

		byte[] returnArray = new byte[encodedString.length() / 2];

		for (int i = 0; i < encodedString.length(); i = i + 2) {
			String token = encodedString.substring(i, i + 2);

			int value = Integer.parseInt(token.substring(0, 1), 16) * 16 + Integer.parseInt(token.substring(1, 2), 16);
			if (value > 127) {
				value = -256 + value;
			}
			returnArray[i / 2] = (byte) value;
		}

		return returnArray;
	}

}
