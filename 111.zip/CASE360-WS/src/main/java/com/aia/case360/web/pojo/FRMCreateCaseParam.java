package com.aia.case360.web.pojo;

import org.apache.commons.lang3.StringUtils;

import com.aia.case360.web.common.CommonUtil;

public class FRMCreateCaseParam {
  /*
   *Manual Create case parameters:
   *PROCESS_TYPE;
   *SUB_REQ_TYPE;
   *ALIAS_NM;
   *CLM_NUM;
   *COMMENTS;
   *NRIC;
   *IS_URGENT;//false
   *REQ_TYPE;//BUDDY_QA_STP_SURRENDER
   *CATEGORY;//Common
   *RECEIVE_DT;//2019-03-2600: 00: 00
   *PARENT_REQUEST_NUM;
   *LOB;//POS
   *COMPANY_NO;//011
   *TSAR;
   *DEPARTMENT;//POS
   *FSC_CODE;
   *USERID;//SONORA
*/  
  private String isUrgent;//false
  private String reqType;//BUDDY_QA_STP_SURRENDER
  private String category;//Common
  private String receiveDt;//2019-03-2600: 00: 00
  private String companyNo;//011
  private String department;//POS
  private String userId;//SONORA
  private String polNum;
  private String objectId;//for retrieve doc
  private String page;//for retrieve doc
  private String reason;
  private String reasonCode;
  private String formId;
  private String comments;
  
  
  /**
   * @return the formId
   */
  public String getFormId() {
    return formId==null?"":formId;
  }

  /**
   * @return the reason
   */
  public String getReason() {
    return reason==null?"":reason;
  }

  /**
   * @return the isUrgent
   */
  public String getIsUrgent() {
    return isUrgent==null?"false":isUrgent;
  }
  /**
   * @return the reqType
   */
  public String getReqType() {
    return CommonUtil.getString(reqType);
  }
  /**
   * @return the category
   */
  public String getCategory() {
    return CommonUtil.getString(category);
  }
  /**
   * @return the receiveDt
   */
  public String getReceiveDt() {
    return CommonUtil.getString(receiveDt);
  }
  /**
   * @return the companyNo
   */
  public String getCompanyNo() {
    return CommonUtil.getString(companyNo, "011");
  }
  /**
   * @return the department
   */
  public String getDepartment() {
    return CommonUtil.getString(department);
  }
  /**
   * @return the userId
   */
  public String getUserId() {
    return CommonUtil.getString(userId);
  }
  /**
   * @param isUrgent the isUrgent to set
   */
  public void setIsUrgent(String isUrgent) {
    this.isUrgent = isUrgent;
  }
  /**
   * @param reqType the reqType to set
   */
  public void setReqType(String reqType) {
    this.reqType = reqType;
  }
  /**
   * @param category the category to set
   */
  public void setCategory(String category) {
    this.category = category;
  }
  /**
   * @param receiveDt the receiveDt to set
   */
  public void setReceiveDt(String receiveDt) {
    this.receiveDt = receiveDt;
  }
  /**
   * @param companyNo the companyNo to set
   */
  public void setCompanyNo(String companyNo) {
    this.companyNo = companyNo;
  }
  /**
   * @param department the department to set
   */
  public void setDepartment(String department) {
    this.department = department;
  }
  /**
   * @param userid the userId to set
   */
  public void setUserId(String userId) {
    this.userId = userId;
  }
  /**
   * @return the polNum
   */
  public String getPolNum() {
    return polNum==null?"":polNum;
  }
  /**
   * @param polNum the polNum to set
   */
  public void setPolNum(String polNum) {
    this.polNum = polNum;
  }
  /**
   * @return the objectId
   */
  public String getObjectId() {
    return objectId==null?"":objectId;
  }
  /**
   * @param objectId the objectId to set
   */
  public void setObjectId(String objectId) {
    this.objectId = objectId;
  }
  /**
   * @return the page
   */
  public String getPage() {
    return StringUtils.isBlank(page)?"":page;
  }
  /**
   * @param page the page to set
   */
  public void setPage(String page) {
    this.page = page;
  }
  
  /**
   * @param reason the reason to set
   */
  public void setReason(String reason) {
    this.reason = reason;
  }

  /**
   * @param formId the formId to set
   */
  public void setFormId(String formId) {
    this.formId = formId;
  }

  /**
   * @return the reasonCode
   */
  public String getReasonCode() {
    return reasonCode;
  }

  /**
   * @param reasonCode the reasonCode to set
   */
  public void setReasonCode(String reasonCode) {
    this.reasonCode = reasonCode;
  }
  
  

  /**
   * @return the comments
   */
  public String getComments() {
    return comments==null?"":comments;
  }

  /**
   * @param comments the comments to set
   */
  public void setComments(String comments) {
    this.comments = comments;
  }

  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "FRMCreateCaseParam [isUrgent=" + isUrgent + ", reqType=" + reqType + ", category="
        + category + ", receiveDt=" + receiveDt + ", companyNo=" + companyNo + ", department="
        + department + ", userId=" + userId + ", polNum=" + polNum + ", objectId=" + objectId
        + ", page=" + page + ", reason=" + reason + ", reasonCode=" + reasonCode + ", formId="
        + formId + ", comments=" + comments + "]";
  }

}
