package com.aia.case360.web.pojo;

public class DocListDetailsInfo {
	// companyNo
	private String companyNo;
	// policyNo
	private String policyNo;
	// uploadDate
	private String uploadDate;
	// receivedDate
	private String receivedDate;
	// objectId
	private String objectId;
	// formId
	private String formId;
	// formName
	private String formName;
	// watermarkText
	private String watermarkText;
	// eDocActionFlag
	private String eDocActionFlag;
	// notiFicationType
	private String notiFicationType;
	// eDocCateGory
	private String eCabinetCategory;
	// availableInFSCInbox
	private String availableInFSCInbox;

	private String customerEDocName;
	private String customerSurpressPrint;

	public String getCustomerEDocName() {
		return customerEDocName;
	}

	public void setCustomerEDocName(String customerEDocName) {
		this.customerEDocName = customerEDocName;
	}

	public String getCustomerSurpressPrint() {
		return customerSurpressPrint;
	}

	public void setCustomerSurpressPrint(String customerSurpressPrint) {
		this.customerSurpressPrint = customerSurpressPrint;
	}

	public String getCompanyNo() {
		return companyNo;
	}

	public void setCompanyNo(String companyNo) {
		this.companyNo = companyNo;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getUploadDate() {
		return uploadDate;
	}

	public void setUploadDate(String uploadDate) {
		this.uploadDate = uploadDate;
	}

	public String getReceivedDate() {
		return receivedDate;
	}

	public void setReceivedDate(String receivedDate) {
		this.receivedDate = receivedDate;
	}

	public String getObjectId() {
		return objectId;
	}

	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}

	public String getFormId() {
		return formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}

	public String getFormName() {
		return formName;
	}

	public void setFormName(String formName) {
		this.formName = formName;
	}

	public String getWatermarkText() {
		return watermarkText;
	}

	public void setWatermarkText(String watermarkText) {
		this.watermarkText = watermarkText;
	}

	public String geteDocActionFlag() {
		return eDocActionFlag;
	}

	public void seteDocActionFlag(String eDocActionFlag) {
		this.eDocActionFlag = eDocActionFlag;
	}

	public String getNotiFicationType() {
		return notiFicationType;
	}

	public void setNotiFicationType(String notiFicationType) {
		this.notiFicationType = notiFicationType;
	}

	public String geteCabinetCategory() {
		return eCabinetCategory;
	}

	public void seteCabinetCategory(String eCabinetCategory) {
		this.eCabinetCategory = eCabinetCategory;
	}

	public String getAvailableInFSCInbox() {
		return availableInFSCInbox;
	}

	public void setAvailableInFSCInbox(String availableInFSCInbox) {
		this.availableInFSCInbox = availableInFSCInbox;
	}

}
