package com.aia.case360.interceptor;

import com.aia.case360.interceptor.RepeatedlyReadRequestWrapper;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

public class RepeatedlyReadFilter implements Filter {

	 public void init(FilterConfig filterConfig) throws ServletException {
	    }
	    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
	        ServletRequest requestWrapper = null;
	        if(request instanceof HttpServletRequest) {
	        	if(!((HttpServletRequest) request).getRequestURI().toUpperCase().contains("IMPORTDOC") 
	        			&& !((HttpServletRequest) request).getRequestURI().toUpperCase().contains("batchFileUpload".toUpperCase()) 
	        			&& !((HttpServletRequest) request).getRequestURI().toUpperCase().contains("ManualCreationCase".toUpperCase()) 
	        			&& !((HttpServletRequest) request).getRequestURI().toUpperCase().contains("comments".toUpperCase()) 
	        			&& !((HttpServletRequest) request).getRequestURI().toUpperCase().contains("FORUPLOADFILE")){ 
	        		requestWrapper = new RepeatedlyReadRequestWrapper((HttpServletRequest) request);
	        	}
	        }
	        if(requestWrapper == null) {
	            chain.doFilter(request, response);
	        } else {
	            chain.doFilter(requestWrapper, response);
	        }
	    }
	    public void destroy() {

	    }
}