package com.aia.case360.web.dao;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

public interface AuditTrailDao {

	public Integer addUAMAuditTrail(List<Map<String, Object>> list)  throws RemoteException;
}
