package com.aia.case360.web.pojo;

import java.math.BigDecimal;

public class FormDocLink {

	private String acl;
	private String formId;
	private String edocDocId;
	private String funcCode;
	private String srcSystem;
	private BigDecimal matchReqFlag; // decimal
	private BigDecimal sRowid; // decimal

	public String getAcl() {
		return acl;
	}

	public void setAcl(String acl) {
		this.acl = acl;
	}

	public String getFormId() {
		return formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}

	public String getEdocDocId() {
		return edocDocId;
	}

	public void setEdocDocId(String edocDocId) {
		this.edocDocId = edocDocId;
	}

	public String getFuncCode() {
		return funcCode;
	}

	public void setFuncCode(String funcCode) {
		this.funcCode = funcCode;
	}

	public BigDecimal getMatchReqFlag() {
		return matchReqFlag;
	}

	public void setMatchReqFlag(BigDecimal matchReqFlag) {
		this.matchReqFlag = matchReqFlag;
	}

	public BigDecimal getsRowid() {
		return sRowid;
	}

	public void setsRowid(BigDecimal sRowid) {
		this.sRowid = sRowid;
	}

	@Override
	public String toString() {
		return "FdFormDocLink [acl=" + acl + ", formId=" + formId + ", edocDocId=" + edocDocId + ", funcCode="
				+ funcCode + ", srcSystem=" + srcSystem + ", matchReqFlag=" + matchReqFlag + ", sRowid=" + sRowid + "]";
	}

	public String getSrcSystem() {
		return srcSystem;
	}

	public void setSrcSystem(String srcSystem) {
		this.srcSystem = srcSystem;
	}

}
