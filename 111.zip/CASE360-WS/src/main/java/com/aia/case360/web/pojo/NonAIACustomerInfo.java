package com.aia.case360.web.pojo;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import com.aia.case360.web.auditTrail.AuditEntityIgnoreCondition;
import com.aia.case360.web.auditTrail.AuditFieldSpecialAction;
import com.aia.case360.web.auditTrail.AuditFileTypeEnum;
import com.aia.case360.web.auditTrail.AuditTrail;
import com.aia.case360.web.auditTrail.annotation.AuditEntity;
import com.aia.case360.web.auditTrail.annotation.AuditField;
import com.fasterxml.jackson.annotation.JsonFormat;

@AuditEntity(entityName = "Non AIA Customer Information", formDataName = "Non AIA Customer", tableName = "FD_NON_AIA_CUSTOMER")
public class NonAIACustomerInfo implements AuditTrail {

	private String acl;
	private BigDecimal sRowid;

	@AuditField(fieldName = "Citizenship", fieldType = AuditFileTypeEnum.FIELD)
	private String citizenShip;

	@DateTimeFormat(pattern = "yyyy-MM-dd 00:00:00")
	@JsonFormat(pattern = "yyyy-MM-dd 00:00:00", timezone = "GMT+8")
	@AuditField(fieldName = "Date Of Birth", fieldType = AuditFileTypeEnum.FIELD)
	private Date dob;

	@AuditField(fieldName = "EMAIL", fieldType = AuditFileTypeEnum.FIELD)
	private String email;

//	@AuditField(fieldName = "GENDER", fieldType = AuditFileTypeEnum.FIELD)
	private Integer gender;
	
	@AuditField(fieldName = "GENDER", fieldType = AuditFileTypeEnum.FIELD)
	private String gendar;
	
	@AuditField(fieldName = "Annual Income", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private String income;

//	@AuditField(fieldName = "Medical Conditions", fieldType = AuditFileTypeEnum.FIELD)
	private Boolean isMedication;
	
	@AuditField(fieldName = "Medical Conditions", fieldType = AuditFileTypeEnum.FIELD)
	private String medCond;

//	@AuditField(fieldName = "Smoking Status", fieldType = AuditFileTypeEnum.FIELD)
	private Boolean isSmoking;
	
	@AuditField(fieldName = "Smoking Status", fieldType = AuditFileTypeEnum.FIELD)
	private String smokStatus;

	//@AuditField(fieldName = "NAME", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private String name;

	//@AuditField(fieldName = "NRIC", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private String nric;

	@AuditField(fieldName = "COMPANY", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private String company;
	
	@AuditField(fieldName = "OCCUPATION", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private String occupation;

	@AuditField(fieldName = "PHONE_NUMBER", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private String phoneNum;

	@AuditField(fieldName = "POL_NUM", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private String policyNum;

	@AuditField(fieldName = "RESIDENCE_CITY", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private String residenceCity;

	@AuditField(fieldName = "USERADDRESS", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private String address;

	@AuditField(fieldName = "VISA_TYPE", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private String visaType;

	@AuditField(fieldName = "IS_NONAIA", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private Boolean isNonAIA;
	
	@AuditField(fieldName = "RETRIVE_METHOD", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private String retrieveMethod;

	@AuditField(fieldName = "OTHER", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private String other;
	
	//@AuditField(fieldName = "HASHSTR", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private String hashStr;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	@AuditField(fieldName = "Effective Date", fieldType = AuditFileTypeEnum.FIELD)
	private Date effectiveDate;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	private Date createdTimestamp;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	private Date lastUpdatedTimestamp;

	private String createdBy;
	private String lastUpdatedBy;

	public String getAcl() {
		return acl;
	}

	public void setAcl(String acl) {
		this.acl = acl;
	}

	public BigDecimal getsRowid() {
		return sRowid;
	}

	public void setsRowid(BigDecimal sRowid) {
		this.sRowid = sRowid;
	}

	public String getCitizenShip() {
		return citizenShip;
	}

	public void setCitizenShip(String citizenShip) {
		this.citizenShip = citizenShip;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Integer getGender() {
		return gender;
	}

	public void setGender(Integer gender) {
		this.gender = gender;
	}

	public String getIncome() {
		return income;
	}

	public void setIncome(String income) {
		this.income = income;
	}

	public Boolean getIsMedication() {
		return isMedication;
	}

	public void setIsMedication(Boolean isMedication) {
		this.isMedication = isMedication;
	}

	public Boolean getIsSmoking() {
		return isSmoking;
	}

	public void setIsSmoking(Boolean isSmoking) {
		this.isSmoking = isSmoking;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNric() {
		return nric;
	}

	public void setNric(String nric) {
		this.nric = nric;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	
	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getOther() {
		return other;
	}

	public void setOther(String other) {
		this.other = other;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public String getPolicyNum() {
		return policyNum;
	}

	public void setPolicyNum(String policyNum) {
		this.policyNum = policyNum;
	}

	public String getResidenceCity() {
		return residenceCity;
	}

	public void setResidenceCity(String residenceCity) {
		this.residenceCity = residenceCity;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getVisaType() {
		return visaType;
	}

	public void setVisaType(String visaType) {
		this.visaType = visaType;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Date getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public Date getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Date lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	
	public Boolean getIsNonAIA() {
		return isNonAIA;
	}

	public void setIsNonAIA(Boolean isNonAIA) {
		this.isNonAIA = isNonAIA;
	}
	
	public String getRetrieveMethod() {
		return retrieveMethod;
	}
	
	public void setRetrieveMethod(String retrieveMethod) {
		this.retrieveMethod = retrieveMethod;
	}

	public String getHashStr() {
		return hashStr;
	}

	public void setHashStr(String hashStr) {
		this.hashStr = hashStr;
	}
	
	public String getGendar() {
		return gendar;
	}

	public void setGendar(String gendar) {
		this.gendar = gendar;
	}

	public String getMedCond() {
		return medCond;
	}

	public void setMedCond(String medCond) {
		this.medCond = medCond;
	}

	public String getSmokStatus() {
		return smokStatus;
	}

	public void setSmokStatus(String smokStatus) {
		this.smokStatus = smokStatus;
	}

	@Override
	public List<AuditFieldSpecialAction> registFieldSpecialActionlist() {
		// TODO Auto-generated method stub
		List<AuditFieldSpecialAction> rs = null;
		return rs;
	}

	@Override
	public List<AuditEntityIgnoreCondition> registIgnoreEntitylist() {
		// TODO Auto-generated method stub
		List<AuditEntityIgnoreCondition> rs = null;
		return rs;
	}

	@Override
	public BigDecimal getRowID() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getKeyDisplayName() {
		// TODO Auto-generated method stub
		return "Customer";
	}

	@Override
	public Object getKey() {
		return String.valueOf(this.sRowid);
	}

	@Override
	public String toString() {
		return "NonAIACustomerInfo [sRowid=" + sRowid + ", name=" + name
				+ ", nric=" + nric + "]";
	}
}
