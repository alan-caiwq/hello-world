package com.aia.case360.web.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

@Repository
public interface CoverSheetingDao {
	public List<Map<String, String>> queryCoverSheeting(Map<String, String> param);

	public String getDeptByReqType(String reqType);
}
