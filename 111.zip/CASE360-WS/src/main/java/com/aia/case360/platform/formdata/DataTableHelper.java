package com.aia.case360.platform.formdata;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import com.eistream.sonora.exceptions.SonoraException;
import com.eistream.sonora.fields.FmsColumnDefinition;
import com.eistream.sonora.fields.FmsRow;
import com.eistream.sonora.fields.FmsRowNative;

public interface DataTableHelper {

	/**
	 * Return FD table the list of column definition
	 * 
	 * @param tableId
	 * @return
	 * @throws RemoteException
	 */
	public List<FmsColumnDefinition> getTableDefinition(BigDecimal tableId) throws RemoteException;

	/**
	 * Return FD table the list of column name
	 * 
	 * @param tableId
	 * @return
	 * @throws RemoteException
	 */
	public List<String> getTableColumnName(BigDecimal tableId) throws RemoteException;

	/**
	 * Create appoint table row.
	 */
	/**
	 * Create a row based on the parameters
	 * 
	 * @param tableId
	 * @param parameters
	 * @return
	 * @throws RemoteException
	 */
	public boolean createTableRow(BigDecimal tableId, Map<String, String> parameters) throws RemoteException;

	/**
	 * 
	 * @param tableId
	 * @param parameters
	 * @return
	 * @throws RemoteException
	 */
	public String createTableRowAndGetRepositoryKey(BigDecimal tableId, Map<String, String> parameters)
			throws RemoteException;

	/**
	 * 
	 * @param parameters
	 * @param fmsRow
	 * @throws RemoteException
	 * @throws SonoraException
	 */
	public void updateTableRow(Map<String, String> parameters, FmsRow fmsRow) throws RemoteException, SonoraException;

	/**
	 * 
	 * @param parameters
	 * @param fmsRow
	 * @throws RemoteException
	 * @throws SonoraException
	 */
	public FmsRow updateTableRow1(Map<String, String> parameters, FmsRow fmsRow)
			throws RemoteException, SonoraException;

	/**
	 * Loop parameter,use parameter to check fmsId's column name.
	 */
	/**
	 * 
	 * @param parameter
	 * @param fmsId
	 * @return
	 * @throws RemoteException
	 */
	public boolean checkTableColumnName(Map<String, String> parameter, BigDecimal fmsId) throws RemoteException;

	/**
	 * 
	 * @param tableId
	 * @param queryName
	 * @param parameters
	 * @return
	 * @throws RemoteException
	 */
	public boolean updateTableRow(BigDecimal tableId, String queryName, Map<String, String> parameters)
			throws RemoteException;

	/**
	 * more way to update row
	 * 
	 * @param tableId
	 * @param rowId
	 * @param parameters
	 * @return
	 * @throws RemoteException
	 */
	public boolean updateRow(BigDecimal tableId, String rowId, Map<String, String> parameters) throws RemoteException;

	/**
	 * 
	 * @param tableId
	 * @param queryName
	 * @param queryParameters
	 * @param updateParameters
	 * @return
	 * @throws RemoteException
	 */
	public boolean updateTableRow(BigDecimal tableId, String queryName, Map<String, String> queryParameters,
			Map<String, String> updateParameters) throws RemoteException;

	/**
	 * 
	 * @param tableId
	 * @param rowId
	 * @return
	 * @throws RemoteException
	 */
	public boolean deleteRow(BigDecimal tableId, String rowId) throws RemoteException;

	/**
	 * create formData only used data migration
	 * 
	 * @param tableId
	 * @param createAmount
	 * @return
	 * @throws RemoteException
	 */
	public String dataMigrationCreateFormData(BigDecimal tableId, String createAmount) throws RemoteException;

	public boolean batchUpdate(List<FmsRowNative> oldFmsRows, List<FmsRowNative> newFmsRows) throws RemoteException;

	public List<FmsRowNative> getRowsByIdList(List<BigDecimal> idList, BigDecimal tableId) throws RemoteException;

	public List<FmsRowNative> getNewRows(BigDecimal tableId, int size) throws RemoteException;

	/**
	 * Physically delete,please be careful with it.
	 * 
	 * @param templateID not table Id
	 * @param rowId
	 * @return
	 * @throws RemoteException
	 */
	public boolean deletePhysicalRow(BigDecimal templateID, String rowId) throws RemoteException;

	/**
	 * batch physically delete,please be careful with it.
	 * 
	 * @param templateID
	 * @param rowId
	 * @param            relationList. cascading delete. The relation must
	 *                   configured in Casetrack.
	 * @return
	 * @throws RemoteException
	 */

	public boolean deletePhysicalRow(BigDecimal tableID, BigDecimal templateID, String rowId, String[] relationList)
			throws RemoteException;

	/**
	 * batch physically delete,please be careful with it.
	 * 
	 * @param tableId
	 * @param queryName
	 * @param queryParameters
	 * @return
	 * @throws RemoteException
	 */

	public boolean batchDeletePhysical(BigDecimal tableId, String queryName, Map<String, String> queryParameters)
			throws RemoteException;

	/**
	 * 
	 * @param tableId
	 * @param rowID
	 * @param relName
	 * @param referenceKeyName
	 * @param fieldValuesList
	 */
	public void updateRel(BigDecimal tableId, String rowID, String relName, String referenceKeyName,
			List<Map<String, String>> fieldValuesList);
}