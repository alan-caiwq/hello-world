package com.aia.case360.web.advice;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.web.dao.DocumentsRelatedDataDao;
import com.aia.case360.web.dao.EDocAdminDao;
import com.aia.case360.web.jdbcDao.DocDao;
import com.aia.case360.web.pojo.FdDocLink;
import com.aia.case360.web.service.DocumentService;
import com.aia.case360.web.service.impl.AbstractServiceImpl;
import com.aia.case360.web.vo.RenameDocFormLinkParam;

@Component
@Aspect
public class LinkFormIdAspect extends AbstractServiceImpl {

	private static final String LOCALFORM_ID = "FORM_ID";

	private static final String LOCALIS_LOGICAL = "IS_LOGICAL";

	@Autowired
	private DocumentsRelatedDataDao docDataDao;

	@Autowired
	private DocumentService docService;
	
	@Autowired
	private EDocAdminDao eDocAdminDao;

	@Autowired
	private DocDao docDao;
	// boolean com.aia.case360.web.jdbcDao.DocDao.deleteById(String s_rowid)
	@Pointcut("execution( * com.aia.case360.web.jdbcDao.DocDao.deleteById(..))")
	public void pointCutDeleteDocLink() {
		// NOSONAR
	}

	//boolean com.aia.case360.web.jdbcDao.DocDao.insertDocLink(Map<String, Object> docLink)
	@Pointcut("execution( * com.aia.case360.web.jdbcDao.DocDao.insertDocLink(..))")
	public void pointCutInsertDocLink() {
		// NOSONAR
	}
	
	// com.aia.case360.web.dao.DocumentsRelatedDataDao.insertFdDocLinks(List<FdDocLink> fdDocLinks)
	@Pointcut("execution( * com.aia.case360.web.dao.DocumentsRelatedDataDao.insertFdDocLinks(..))")
	public void pointCutInsertFdDocLinks() {
		// NOSONAR
	}
	
	//com.aia.case360.web.dao.DocumentsRelatedDataDao.renameDocFormLinks(List<RenameDocFormLinkParam>)
	@Pointcut("execution( * com.aia.case360.web.dao.DocumentsRelatedDataDao.renameDocFormLinks(..))")
	public void pointCutRenameDocFormLinks() {
		// NOSONAR
	}



	@After("pointCutInsertDocLink()")
	public void afterInsertDocLink(JoinPoint jp) {
		String message = "Service Function Name: afterInsertDocLink";
		LogUtil.logInfo(m_Logger,message + " is Entering");
		try {
			@SuppressWarnings("unchecked")
			Map<String, Object> param = (Map<String, Object>) jp.getArgs()[0];
			String mainLinkFormId = eDocAdminDao.getMainLinkFormIdByFormId((String) param.get(LOCALFORM_ID));
			if (StringUtils.isNotEmpty(mainLinkFormId)) {
				// has link form id ,do INSERT LINKFORM DOCLINK
				param.put(LOCALFORM_ID, mainLinkFormId);
				param.put(LOCALIS_LOGICAL, 1);
				boolean isDocLinkExist = docDao.IsDocLinkExist(param);
				if (!isDocLinkExist) {
					boolean insertDocLink = docDao.insertDocLinkNoAspect(param);
					if (insertDocLink) {
						LogUtil.logInfo(m_Logger,message + " ,docDao.insertDocLink success !");
					} else {
						LogUtil.logInfo(m_Logger,message + " ,docDao.insertDocLink fail !");
					}
				}
			}
		} catch (Exception e) {
			 LogUtil.logException(m_Logger, message, e);
		}
		LogUtil.logInfo(m_Logger,message + " is  end");
	}

	@After("pointCutInsertFdDocLinks()")
	public void afterInsertFdDocLinks(JoinPoint jp) {
		String message = "Service Function Name: afterInsertFdDocLinks";
		LogUtil.logInfo(m_Logger,message + " is Entering");
		try {
			@SuppressWarnings("unchecked")
			List<FdDocLink> param = (List<FdDocLink>) jp.getArgs()[0];
			List<FdDocLink> linkFdDocLinks = new ArrayList<>();
			for (FdDocLink fdDocLink : param) {
			    String mainLinkFormId = eDocAdminDao.getMainLinkFormIdByFormId(fdDocLink.getFormId());
				if (StringUtils.isNotEmpty(mainLinkFormId)) {
					// has link form id ,do INSERT LINKFORM DOCLINK
					// check doc link isExist
				    // C360-2419 2.From Form ID and to form ID is displaying wrong information.
					Map<String, Object> docLink = new HashMap<String, Object>();
					docLink.put(LOCALIS_LOGICAL, 1);
					docLink.put(LOCALFORM_ID, mainLinkFormId);
					docLink.put("OBJECT_ID", fdDocLink.getObjectId());
					docLink.put("LINKCASEID", fdDocLink.getCaseId());
					docLink.put("POL_NUM", fdDocLink.getPolicyNo());
					docLink.put("CLAIM_NO", "");
					boolean isDocLinkExist = docDao.IsDocLinkExist(docLink);
					if (!isDocLinkExist) {
						FdDocLink cloneLink = fdDocLink.getCloneInstance();
						cloneLink.setFormId(mainLinkFormId);
						linkFdDocLinks.add(cloneLink);
					}
				}
			}
			int insertFdDocLinks = docDataDao.insertFdDocLinksNoAspect(linkFdDocLinks);
			if (insertFdDocLinks > 0) {
				LogUtil.logInfo(m_Logger,message + " ,docDataDao.insertFdDocLinks success !");
			} else {
				LogUtil.logInfo(m_Logger,message + " ,docDataDao.insertFdDocLinks fail !");
			}
		} catch (Exception e) {
			LogUtil.logException(m_Logger, message, e);
		}
		LogUtil.logInfo(m_Logger,message + " is  end");
	}

	@After("pointCutRenameDocFormLinks()")
	public void afterRenameDocFormLinks(JoinPoint jp) {
		String message = "Service Function Name: afterRenameDocFormLinks";
		try {
			@SuppressWarnings("unchecked")
			List<RenameDocFormLinkParam> param = (List<RenameDocFormLinkParam>) jp.getArgs()[0];

			// for old formId
			for (RenameDocFormLinkParam renameDocFormLinkParam : param) {

				// for new formId
				String newMainLinkFormId = eDocAdminDao.getMainLinkFormIdByFormId(renameDocFormLinkParam.getFormID());
				// if new formId has link form id ,do insert link formId link
				if (StringUtils.isNotEmpty(newMainLinkFormId)) {
					// get fd_doc_link s_rowid
					String linkID = renameDocFormLinkParam.getLinkID();
					List<String> sRowIdList = new ArrayList<>();
					sRowIdList.add(linkID);
					List<Map<String, Object>> docLinkByID = docDataDao.getDocLinkByID(sRowIdList);
					Map<String, Object> docLink = docLinkByID.get(0);
					// change formId to linkFormId
					docLink.put(LOCALIS_LOGICAL, 1);
					docLink.put(LOCALFORM_ID, newMainLinkFormId);
					docLink.put("S_ROWID", null);
					docLink.put("CREATED_DT", new Date());
					boolean isDocLinkExist = docDao.IsDocLinkExist(docLink);
					if (!isDocLinkExist) {
						boolean insertDocLinkRs = docDao.insertDocLinkNoAspect(docLink);
						if (insertDocLinkRs) {
							// log success
							LogUtil.logInfo(m_Logger,message + " ,docDao.insertFdDocLinks success !");
						} else {
							// log fail
							LogUtil.logInfo(m_Logger,message + " ,docDao.insertFdDocLinks fail !");
						}
					}
				}
			}
		} catch (Exception e) {
			LogUtil.logException(m_Logger, message, e);
		}
	}

}
