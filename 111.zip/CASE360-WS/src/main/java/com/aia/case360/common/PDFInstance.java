package com.aia.case360.common;

public class PDFInstance {
	private byte[] content;
	private int pageNumbers;

	public byte[] getContent() {
		return content;
	}

	public int getPageNumbers() {
		return pageNumbers;
	}

	public void setContent(byte[] content) {
		this.content = content;
	}

	public void setPageNumbers(int pageNumbers) {
		this.pageNumbers = pageNumbers;
	}

	
}