package com.aia.case360.web.pojo;

import java.math.BigDecimal;

public class PendingPaymentInfo {
	// policyNo
	private String policyNo;

	// paymentAmountIL
	private BigDecimal paymentAmountIL;

	// pendingCount
	private String pendingCount;

	// caseID
	private String caseID;

	// pendingReason
	private String pendingReason;

	// caseStatus
	private String caseStatus;

	// actionFlag
	private String actionFlag;

	// accountNo
	private String accountNo;

	// subAccountCode
	private String subAccountCode;

	// rowId
	private String rowId;

	// pendingReasonID
	private String pendingReasonID;

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public BigDecimal getPaymentAmountIL() {
		return paymentAmountIL;
	}

	public void setPaymentAmountIL(BigDecimal paymentAmountIL) {
		this.paymentAmountIL = paymentAmountIL;
	}

	public String getPendingCount() {
		return pendingCount;
	}

	public void setPendingCount(String pendingCount) {
		this.pendingCount = pendingCount;
	}

	public String getCaseID() {
		return caseID;
	}

	public void setCaseID(String caseID) {
		this.caseID = caseID;
	}

	public String getPendingReason() {
		return pendingReason;
	}

	public void setPendingReason(String pendingReason) {
		this.pendingReason = pendingReason;
	}

	public String getCaseStatus() {
		return caseStatus;
	}

	public void setCaseStatus(String caseStatus) {
		this.caseStatus = caseStatus;
	}

	public String getActionFlag() {
		return actionFlag;
	}

	public void setActionFlag(String actionFlag) {
		this.actionFlag = actionFlag;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getSubAccountCode() {
		return subAccountCode;
	}

	public void setSubAccountCode(String subAccountCode) {
		this.subAccountCode = subAccountCode;
	}

	public String getRowId() {
		return rowId;
	}

	public void setRowId(String rowId) {
		this.rowId = rowId;
	}

	public String getPendingReasonID() {
		return pendingReasonID;
	}

	public void setPendingReasonID(String pendingReasonID) {
		this.pendingReasonID = pendingReasonID;
	}

}
