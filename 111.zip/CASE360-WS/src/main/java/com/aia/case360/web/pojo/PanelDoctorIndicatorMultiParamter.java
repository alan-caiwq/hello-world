/**
 * 
 */
package com.aia.case360.web.pojo;

/**
 * @author bsnpc55
 *
 */
public class PanelDoctorIndicatorMultiParamter {
	private String policyNo;
	private String claimNo;
	private String companyNo;
	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public String getCompanyNo() {
		return companyNo;
	}

	public void setCompanyNo(String companyNo) {
		this.companyNo = companyNo;
	}

	@Override
	public String toString() {
		return "PanelDoctorIndicatorMultiParamter [policyNo=" + policyNo + ", claimNo=" + claimNo + ", companyNo="
				+ companyNo + "]";
	}

}
