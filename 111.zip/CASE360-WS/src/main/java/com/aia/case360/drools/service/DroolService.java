package com.aia.case360.drools.service;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.drools.KnowledgeBase;
import org.drools.runtime.StatefulKnowledgeSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Service;

import com.aia.case360.drools.dao.RulePropertiesBean;
import com.aia.case360.drools.model.RuleCase;
import com.aia.case360.drools.model.RuleEntity;
import com.aia.case360.drools.model.RuleResult;
import com.aia.case360.drools.model.RuleStep;
import com.aia.case360.platform.common.DateUtil;
import com.aia.case360.platform.common.JsonUtil;
import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.common.PropertyUtil;
import com.aia.case360.platform.dao.TableIdBean;
import com.aia.case360.web.exception.CustomException;
import com.aia.case360.web.pojo.OutputVO;
import com.aia.case360.web.service.impl.AbstractServiceImpl;
import com.eistream.sonora.util.StringUtil;

import net.sf.json.JSONObject;

@Service
public class DroolService extends AbstractServiceImpl {

	private static final String LOCALDEPARTMENT4MES = "Department(";

	private static final String LOCALACTION = "ACTION";

	private static final String LOCALCREATEDBY = "CREATED_BY";

	private static final String LOCALTABLENAMEFDBUSINESSRULES = "TABLE_NAME_FD_BUSINESS_RULES";

	private static final String LOCALISLEAVING = " is leaving . ";

	private static final String LOCALRULESTEP = "RULE_STEP";

	private static final String LOCALISSTART = " is start . ";

	private static final String LOCALRULECASE = "RULE_CASE";

	private static final String LOCALDEPARTMENT = "DEPARTMENT";

	private static final String LOCALRULEID = "RULE_ID";

	private static final String RULEDESTINATION = "RULE_DESTINATION";

	private static final String LOCALLINKCASEID = "LINKCASEID";

	@Autowired
	private TableIdBean dataTableIds;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private RulePropertiesBean rulePropertiesBean;

	public List<RuleResult> excuteRule(JSONObject params) throws CustomException {
		LogUtil.logInfo(m_Logger,"excuteRule -start : " + params.toString());

		List<RuleResult> result = new ArrayList<RuleResult>();
		KnowledgeBase base = DroolServiceSessionFactory.INSTANCE.getSingletonBase();
		StatefulKnowledgeSession kSession = base.newStatefulKnowledgeSession();

		RuleStep ruleStep = new RuleStep();
		if (params.containsKey(LOCALLINKCASEID)) {
			String linkcaseid = params.getString(LOCALLINKCASEID);
			String version = params.getString("VERSION_NUM");
			ruleStep = setRuleStep(linkcaseid, version);
			params.remove(LOCALLINKCASEID);
			params.remove("VERSION_NUM");
		}
		RuleCase ruleCase = setRuleCase(params);

		kSession.setGlobal("resultList", result);
		kSession.insert(ruleCase);
		kSession.insert(ruleStep);
		kSession.fireAllRules();

		for (int i = 0; i < result.size(); i++) {
			RuleResult ruleResult = result.get(i);
			LogUtil.logInfo(m_Logger,i + "rulename ---  " + ruleResult.getRulename());
			LogUtil.logInfo(m_Logger,i + "Destination ---  " + ruleResult.getDestination());
			LogUtil.logInfo(m_Logger,i + "rulename ---  " + ruleResult.getRulename());
			LogUtil.logInfo(m_Logger,i + "Destination --- " + ruleResult.getDestination());
		}
		kSession.dispose();
		LogUtil.logInfo(m_Logger,"excuteRule -end");
		return result;
	}

	private RuleCase setRuleCase(JSONObject params) {
		LogUtil.logInfo(m_Logger,"excuteRule setRuleCase -start : " + params.toString());
		RuleCase ruleCase = new RuleCase();
		try {
			Map<String, String> caseParams = JsonUtil.getStringMap(params);
			for (Entry<String, String> key : caseParams.entrySet()) {
				if (StringUtil.isBlank(key.getKey()) || StringUtil.isBlank(key.getValue())) {
					continue;
				}
				LogUtil.logInfo(m_Logger,"setRuleCase key : " + key.getKey().toUpperCase());
				String value = "";

				value = key.getValue().toUpperCase();
				LogUtil.logInfo(m_Logger,"setRuleCase value : " + value);

				Class<RuleCase> clazz = RuleCase.class;
				Field field = clazz.getDeclaredField(key.getKey().toUpperCase());
				field.setAccessible(true);
				field.set(ruleCase, value);
				field.setAccessible(false);
			}
		} catch (Exception e) {
			LogUtil.logError(m_Logger, "excuteRule setRuleCase -error : " + e.toString());
			throw new CustomException("setRuleCase error : " + e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		LogUtil.logInfo(m_Logger,"excuteRule setRuleCase -end");
		return ruleCase;
	}

	public Map<String, String> calculateRule(JSONObject params) throws CustomException {
		Map<String, String> result = new HashMap<String, String>();

		LogUtil.logInfo(m_Logger,"calculateRule start : " + params.toString());
		List<RuleResult> ruleResults = excuteRule(params);
		LogUtil.logInfo(m_Logger,"calculateRule end : " + params.toString());
		LogUtil.logInfo(m_Logger,String.valueOf(ruleResults.size()));
		String destination = "";
		String extraAct = "";
		StringBuilder rulename = new StringBuilder();
		for (RuleResult rs : ruleResults) {
			rulename.append(rs.getRulename()).append(";");
		}
		if (!ruleResults.isEmpty()) {
		  destination = ruleResults.get(0).getDestination();
		  extraAct = ruleResults.get(0).getExtraAct();
		}

		result.put(RULEDESTINATION, destination);
		result.put("EXTRA_ACT", extraAct);
		result.put("HIT_RULES", rulename.toString());
		LogUtil.logInfo(m_Logger,"DESTINATION : " + destination);
		LogUtil.logInfo(m_Logger,"EXTRA_ACT : " + extraAct);
		LogUtil.logInfo(m_Logger,"HIT_RULES : " + rulename.toString());
		return result;
	}

	public Map<String, String> calculateRule4ws(JSONObject params) {

		Map<String, String> result = new HashMap<String, String>();
		try {
			LogUtil.logInfo(m_Logger,"calculateRule4ws start : " + params.toString());
			List<RuleResult> ruleResults = excuteRule(params);
			String destination = "";
			String extraAct = "";
			StringBuilder rulename = new StringBuilder();
			for (RuleResult rs : ruleResults) {
				rulename.append(rs.getRulename()).append(";");
			}
			if (ruleResults != null && !ruleResults.isEmpty()) {
				destination = ruleResults.get(0).getDestination();
				extraAct = ruleResults.get(0).getExtraAct();
			}
			result.put("RESPONSE_CD", "0");
			result.put("ERR_MSG", "");
			result.put("DESTINATION", destination);
			result.put("EXTRA_ACT", extraAct);
			result.put("HIT_RULES", rulename.toString());
			LogUtil.logInfo(m_Logger,"DESTINATION : " + destination);
			LogUtil.logInfo(m_Logger,"EXTRA_ACT : " + extraAct);
			LogUtil.logInfo(m_Logger,"HIT_RULES : " + rulename.toString());
		} catch (Exception e) {
			result.put("RESPONSE_CD", "1");
			result.put("ERR_MSG", e.toString());
		}
		LogUtil.logInfo(m_Logger,"calculateRule4ws end : " + params.toString());
		return result;
	}


	private RuleStep setRuleStep(String linkedid, String version) throws CustomException {
		LogUtil.logInfo(m_Logger,"excuteRule setRuleStep -start : " + linkedid);
		RuleStep ruleStep = new RuleStep();
		try {
			Map<String, String> stepParams = getStepParams(linkedid, version);
			for (Entry<String, String> key : stepParams.entrySet()) {
				if (key == null || StringUtils.isBlank(key.getKey()) || StringUtils.isBlank(key.getValue())) {
					continue;
				}

				LogUtil.logInfo(m_Logger,"setRuleStep key : " + (key.getKey().toUpperCase()));
				LogUtil.logInfo(m_Logger,"setRuleStep value : " + key.getValue().toUpperCase());
				Class<RuleStep> clazz = RuleStep.class;
				Field field = clazz.getDeclaredField(key.getKey().toUpperCase());
				field.setAccessible(true);
				field.set(ruleStep, key.getValue().toUpperCase());
				field.setAccessible(false);
			}
		} catch (Exception e) {
			LogUtil.logInfo(m_Logger,"excuteRule setRuleStep -error : " + e.toString());
			throw new CustomException("setRuleStep error" + e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		LogUtil.logInfo(m_Logger,"excuteRule setRuleStep -end ");
		return ruleStep;
	}


	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Map<String, String> getStepParams(String linkedid, String version) throws CustomException {

		final Map<String, String> stepParams = new HashMap<String, String>();

		final String SQL_STEP_PARAMS = "SELECT AVAILABLE_STEP,DATA_VALUE FROM FD_CASE_AVAILABLE_STEPS WITH(NOLOCK) WHERE LINKCASEID = ? AND VERSION_NUM = ?";

		try {
			jdbcTemplate.query(SQL_STEP_PARAMS, new Object[] { linkedid, version }, new ResultSetExtractor() {
				public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
					while (rs.next()) {
						stepParams.put(rs.getString("AVAILABLE_STEP"), rs.getString("DATA_VALUE"));
					}
					return stepParams;
				}
			});
		} catch (Exception e) {
			LogUtil.logError(m_Logger, "excuteRule getStepParams -error : " + e.toString());
			 
		}
		LogUtil.logInfo(m_Logger,"stepParams : " + stepParams.toString());
		return stepParams;
	}

	public OutputVO doSearch(String ruleName, String destination, String dept, String ruleCase, String ruleStep) {
		OutputVO outputVo = new OutputVO();
		try {
			Map<String, String> queryParams = new HashMap<String, String>();
			queryParams.put(LOCALRULEID, ruleName);
			queryParams.put(LOCALDEPARTMENT, dept);
			queryParams.put(LOCALRULECASE, ruleCase);
			queryParams.put(LOCALRULESTEP, ruleStep);
			if (destination != null) {
				queryParams.put(RULEDESTINATION, destination.replaceAll("\"", ""));
			}
			String message = "Service Function name : queryBusinessRules";
			LogUtil.logInfo(m_Logger,message + LOCALISSTART);

			List<Map<String, Object>> queryResult = queryHelper.doQuery(queryParams,
					PropertyUtil.getScriptAndQueryProperty("QUERY_GET_BUSINESS_RULES"));
			LogUtil.logInfo(m_Logger,message + LOCALISLEAVING);
			outputVo.setDatas(queryResult);
			outputVo.setMessage("query success");
			outputVo.setCode("0");
		} catch (RemoteException e) {

			outputVo.setMessage(e.getMessage());
			 
			outputVo.setCode("1");
		}
		return outputVo;
	}

	public OutputVO doInsert(RuleEntity rEntity) {
		OutputVO outputVo = new OutputVO();
		String message = "Service Function name : addBusinessRules";
		try {
			
			LogUtil.logInfo(m_Logger,message + LOCALISSTART);

			String userId = userHelper.getCurrentUser();
			String time = DateUtil.getCurrentTime();

			BigDecimal TableId = new BigDecimal(
					dataTableIds.getTableIds().get(PropertyUtil.getTableIDProperty(LOCALTABLENAMEFDBUSINESSRULES)));

			if (validate(rEntity)) {

				String ruleId = rEntity.getDEPARTMENT() + "_" + GetRuleCounter(rEntity.getDEPARTMENT(), 10);
				Map<String, String> inputParams = new HashMap<String, String>();
				inputParams.put(LOCALDEPARTMENT, rEntity.getDEPARTMENT());
				inputParams.put(LOCALRULECASE, rEntity.getRULE_CASE());
				inputParams.put(RULEDESTINATION, rEntity.getRULE_DESTINATION());
				inputParams.put("CREATED_TIMESTAMP", time);
				inputParams.put(LOCALCREATEDBY, userId);
				inputParams.put(LOCALRULESTEP, rEntity.getRULE_STEP());
				inputParams.put(LOCALRULEID, ruleId);
				inputParams.put("COMMENTS", rEntity.getCOMMENTS());
				inputParams.put(LOCALACTION, rEntity.getACTION());
				dtHelper.createTableRow(TableId, inputParams);
				outputVo.setCode("0");
			} else {
				outputVo.setMessage(
						"DEPARTMENT,RULE_CASE,RULE_DESTINATION and RULE_STEP is mandatory.\n And activity must available.");
				outputVo.setCode("1");
			}
			LogUtil.logInfo(m_Logger,message + LOCALISLEAVING);

		} catch (RemoteException e) {

			 LogUtil.logException(m_Logger, message, e);
			outputVo.setMessage(e.getMessage());
			outputVo.setCode("1");
		} catch (Exception e) {

			LogUtil.logException(m_Logger, message, e);
			outputVo.setMessage(e.getMessage());
			outputVo.setCode("1");
		}
		return outputVo;
	}

	private String getWorkStep(String ruleCase) {
		String workStep = null;
		for (String item : ruleCase.split(",")) {
			LogUtil.logInfo(m_Logger,"DroolService: item :" + item);
			
            
            int indexStart = item.indexOf('\"');
            int indexend = item.lastIndexOf('\"');
            LogUtil.logInfo(m_Logger,"DroolService: item ACTIVITY index:" + indexStart + "." + indexend);
            
			if (item.contains("ACTIVITY") && indexStart > 0  && indexend > indexStart) {
			  LogUtil.logInfo(m_Logger,"DroolService: item ACTIVITY:" + item);
			  workStep = item.substring(indexStart + 1, indexend);
			  LogUtil.logInfo(m_Logger,"DroolService: workStep:" + workStep);	

			}
		}
		return workStep;
	}
	private boolean validate(RuleEntity rEntity) {

		boolean valRs = this.validaSpace(rEntity);
		if(!valRs){
			return false;
		}
		boolean avliableWorkStep = false;
		String ruleCase = rEntity.getRULE_CASE().toUpperCase();
		LogUtil.logInfo(m_Logger,"DroolService: ruleCase :" + ruleCase);
		String workStep = this.getWorkStep(ruleCase);
		
		if (workStep != null) {
			try {
				ArrayList<Map<String, Object>> queryResult = queryHelper.doQuery(null,
						PropertyUtil.getScriptAndQueryProperty("QUERY_VAL_PROCESS_STEPS"));
				LogUtil.logInfo(m_Logger,"DroolService: queryResult:" + queryResult);
				avliableWorkStep = loopQueryResult(queryResult, workStep);
			} catch (RemoteException e) {
				LogUtil.logException(m_Logger, "", e);
			}
		} else {
			avliableWorkStep = true;
			LogUtil.logInfo(m_Logger,"DroolService: else avliableWorkStep true.");
		}

		LogUtil.logInfo(m_Logger,"DroolService: avliableWorkStep:" + avliableWorkStep);
		
		// mainProcessSteps
		return avliableWorkStep;
	}
	private boolean loopQueryResult(ArrayList<Map<String, Object>> queryResult,String workStep){
		boolean avliableWorkStep = false;
		for (Map<String, Object> map : queryResult) {
			Object rowItem = map.get("WORKSTEPNAME");
			if (rowItem != null&&((String) rowItem).toUpperCase().equals(workStep)) {
				LogUtil.logInfo(m_Logger,"DroolService: rowItem:" + rowItem);
				avliableWorkStep = true;
				LogUtil.logInfo(m_Logger,"DroolService: rowItem meet.");
			}
		}
		return avliableWorkStep;
	}
	public OutputVO doUpdate(RuleEntity rEntity) {
		OutputVO outputVo = new OutputVO();
		String message = "Service Function name : updateBusinessRules";
		try {
			
			LogUtil.logInfo(m_Logger,message + LOCALISSTART);
			String userId = userHelper.getCurrentUser();
			String time = DateUtil.getCurrentTime();

			BigDecimal TableId = new BigDecimal(
					dataTableIds.getTableIds().get(PropertyUtil.getTableIDProperty(LOCALTABLENAMEFDBUSINESSRULES)));

			if (validate(rEntity)) {
				String rowID = rEntity.getS_ROWID();
				Map<String, String> inputParams = new HashMap<String, String>();

				inputParams.put(LOCALDEPARTMENT, rEntity.getDEPARTMENT());
				inputParams.put(LOCALRULECASE, rEntity.getRULE_CASE());
				inputParams.put(RULEDESTINATION, rEntity.getRULE_DESTINATION());
				inputParams.put("LAST_UPDATED_TIMESTAMP", time);
				inputParams.put("LAST_UPDATED_BY", userId);
				inputParams.put(LOCALRULESTEP, rEntity.getRULE_STEP());
				inputParams.put("COMMENTS", rEntity.getCOMMENTS());
				inputParams.put(LOCALACTION, rEntity.getACTION());
				dtHelper.updateRow(TableId, rowID, inputParams);

				LogUtil.logInfo(m_Logger,message + LOCALISLEAVING);

				outputVo.setMessage("update success");
				outputVo.setCode("0");
			} else {
				outputVo.setMessage(
						"DEPARTMENT,RULE_CASE,RULE_DESTINATION and RULE_STEP is mandatory.\n And activity must available.");
				outputVo.setCode("1");
			}
		} catch (RemoteException e) {

			LogUtil.logException(m_Logger, message, e);
			outputVo.setMessage(e.getMessage());
			outputVo.setCode("1");
		} catch (Exception e) {

			LogUtil.logException(m_Logger, message, e);
			outputVo.setMessage(e.getMessage());
			outputVo.setCode("1");
		}
		return outputVo;
	}

	public OutputVO doDelete(Set<String> rowidList) {
		OutputVO outputVo = new OutputVO();
		String message = "Service Function name : deleteBusinessRules";
		try {
			
			LogUtil.logInfo(m_Logger,message + LOCALISSTART);
			BigDecimal TableId = new BigDecimal(
					dataTableIds.getTableIds().get(PropertyUtil.getTableIDProperty(LOCALTABLENAMEFDBUSINESSRULES)));
			for (String rowId : rowidList) {
				LogUtil.logInfo(m_Logger,"deleteBusinessRules:" + TableId + "." + rowId);
				dtHelper.deleteRow(TableId, rowId);
			}

			LogUtil.logInfo(m_Logger,message + LOCALISLEAVING);
			outputVo.setMessage("delete success");
			outputVo.setCode("0");
		} catch (RemoteException e) {

			LogUtil.logException(m_Logger, message, e);
			outputVo.setMessage(e.getMessage());
			outputVo.setCode("1");
		} catch (Exception e) {

			LogUtil.logException(m_Logger, message, e);
			outputVo.setMessage(e.getMessage());
			outputVo.setCode("1");
		}
		return outputVo;
	}

	public OutputVO doRefreshConfig() {
		OutputVO outputVo = new OutputVO();
		String message = "Service Function name : queryBusinessRules";
		try {
			
			LogUtil.logInfo(m_Logger,message + LOCALISSTART);

			List<Map<String, Object>> queryResult = queryHelper.doQuery(null,
					PropertyUtil.getScriptAndQueryProperty("QUERY_GET_BUSINESS_RULES"));

			List<RuleEntity> ruleList = new ArrayList<RuleEntity>();
			for (Map<String, Object> fdMap : queryResult) {

				if ((fdMap.get(LOCALRULECASE) == null || "".equals(fdMap.get(LOCALRULECASE)))
						&& (fdMap.get(LOCALRULESTEP) == null || "".equals(fdMap.get(LOCALRULESTEP)))) {
					continue;
				}

				RuleEntity ruleEntity = new RuleEntity();
				ruleEntity.setRULE_STEP((String) fdMap.get(LOCALRULESTEP));
				ruleEntity.setRULE_CASE((String) fdMap.get(LOCALRULECASE));
				ruleEntity.setRULE_DESTINATION((String) fdMap.get(RULEDESTINATION));
				ruleEntity.setRULE_ID((String) fdMap.get(LOCALRULEID));
				ruleEntity.setACTION((String) fdMap.get(LOCALACTION));
				ruleList.add(ruleEntity);
			}
			String userId = userHelper.getCurrentUser();
			String time = DateUtil.getCurrentTime();
			BigDecimal TableId = new BigDecimal(
					dataTableIds.getTableIds().get(PropertyUtil.getTableIDProperty("TABLE_NAME_AUDIT_TRAIL")));
			Map<String, String> inputParams = new HashMap<String, String>();
			inputParams.put("ACTION_DESC", "Rule config file updated");
			inputParams.put(LOCALCREATEDBY, userId);
			inputParams.put("CREATED_DT", time);
			inputParams.put("CONFIG_KEY", "BUSINESS_RULE");
			dtHelper.createTableRow(TableId, inputParams);

			rulePropertiesBean.saveChanges(ruleList);
			// refresh session
			DroolServiceSessionFactory.INSTANCE.refreshBase();
			outputVo.setCode("0");
		} catch (RemoteException e) {
			LogUtil.logException(m_Logger, message, e);
			outputVo.setMessage(e.getMessage());
			 
			outputVo.setCode("1");
		} catch (Exception e) {
			LogUtil.logException(m_Logger, message, e);
			outputVo.setMessage(e.getMessage());
			 
			outputVo.setCode("1");
		}
		return outputVo;
	}

	/**
	 * 
	 * @param department POS
	 * @return null error POS_000001 success. @
	 */
	public String GetRuleCounter(String department, int lenth) {
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put("CONFIG_NAME", department + "_RULE_COUNTER");
		Integer sequenceIndex = -1;
		String message = "";
		try {
			LogUtil.logInfo(m_Logger,"Department is " + department + ".");
			ArrayList<Map<String, Object>> queryResult = queryHelper.doQuery(queryParams,
					PropertyUtil.getScriptAndQueryProperty("QUERY_RULE_SEQUENCE_NEXTVALUE").toString());
			int resultSize = queryResult.size();

			switch (resultSize) {

			case 0:
				message = LOCALDEPARTMENT4MES + department + ") no rule counter!";
				LogUtil.logError(m_Logger, message);
				return "";
			case 1:

				String sequenceValue = (String) queryResult.get(0).get("CONFIG_VALUE");

				LogUtil.logInfo(m_Logger,LOCALDEPARTMENT4MES + department + ") rule ID sequence is " + sequenceValue + ".");
				sequenceIndex = Integer.parseInt(sequenceValue);

				if (sequenceIndex == null || sequenceIndex < 0) {
					message = LOCALDEPARTMENT4MES + department + ") rule counter value not correct!";
					LogUtil.logError(m_Logger, message);
					return "";
				}
				break;
			default:
				message = LOCALDEPARTMENT4MES + department + ") mutiple counters found!";
				LogUtil.logError(m_Logger, message);
				return "";
			}
		} catch (RemoteException e) {
			message = LOCALDEPARTMENT4MES + department + ") rule counter value not correct!";
			LogUtil.logException(m_Logger, message, e);
			 
		}

		return fillVacancies((sequenceIndex + 1) + "", lenth);

	}

	public Map<String, Object> getAudit() {
		Map<String, Object> map = new HashMap<String, Object>();

		try {
			ArrayList<Map<String, Object>> queryResult = queryHelper.doQuery(null,
					PropertyUtil.getScriptAndQueryProperty("QUERY_GET_BUSINESS_RULES_AUDIT"));
			if (queryResult.size() > 0) {
				map.put("LAST_UPDATED_BY", queryResult.get(0).get(LOCALCREATEDBY));

				java.util.GregorianCalendar dt = (GregorianCalendar) queryResult.get(0).get("CREATED_DT");
				Date date = dt.getTime();
				map.put("LAST_UPDATED_ON", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date));
			}

		} catch (RemoteException e) {

			LogUtil.logException(m_Logger, "", e);
			return map;
		}
		return map;

	}
	
	private String valueIsNull(String value){
	  
	   if(value==null){
	     return "";
	   }else if("".equals(value.trim())){
	     return "";
	   }else if(value.trim().length()==0){
	     return "";
	   }else{
	     return value;
	   }

	}

	private boolean validaSpace(RuleEntity rEntity) {
		if ("".equals(valueIsNull(rEntity.getDEPARTMENT()))) {
			return false;
		}

		if ("".equals(valueIsNull(rEntity.getRULE_DESTINATION()))) {
			return false;
		}

		if ("".equals(valueIsNull(rEntity.getRULE_CASE())) && "".equals(valueIsNull(rEntity.getRULE_STEP()))) {
			return false;
		}

		return true;
	}
}
