package com.aia.case360.drools.dao;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.aia.case360.drools.model.RuleEntity;
import com.aia.case360.platform.common.LogUtil;

@Component
public class RulePropertiesBean {
	private static final String SETDESTINATION = "setDestination";
	private Logger m_Logger = LoggerFactory.getLogger(getClass());
	private List<RuleEntity> propertiesRules = null;
	private List<RuleEntity> dbRules = null;
	private String ignorePrefix = "SYS_";
	private StringBuilder otherTxt = null;

	private List<RuleEntity> getAllRules() {
		if (dbRules == null) {
			dbRules = getAllRulesFromProperties();
		}
		return getAllRulesFromProperties();
	}

	private List<RuleEntity> getAllRulesFromProperties() {
		otherTxt = new StringBuilder();
		String read = "";
		propertiesRules = new ArrayList<RuleEntity>();
		try (BufferedReader bufread = new BufferedReader(new FileReader(getRuleConfigFile()))){

			RuleEntity ruleItem = null;
			boolean currentItemIsRule = true;
			while ((read = bufread.readLine()) != null) {
				if (!read.startsWith("rule") && !currentItemIsRule) {
					otherTxt.append(read + "\n");
					continue;
				}
				ruleItem = matchRuleProcess(read, ruleItem);
				currentItemIsRule = getCurrentItemIsRule(ruleItem);
				ruleItem = matchRuleCaseStepProcess(read, ruleItem);
			}
			if (ruleItem != null) {
				propertiesRules.add(ruleItem);
			}
			bufread.close();
		} catch (FileNotFoundException e) {
			LogUtil.logException(m_Logger, "", e);
		} catch (IOException e) {
			LogUtil.logException(m_Logger, "", e);
		} 
		return propertiesRules;
	}

	private boolean getCurrentItemIsRule(RuleEntity ruleItem) {
		if(ruleItem == null){
			return false;
		} else {
			return true;
		}
	}

	private RuleEntity matchRuleCaseStepProcess(String read, RuleEntity ruleItem) {
		if (read.contains("RuleCase(") && ruleItem != null) {
			int firstIndex = read.indexOf("RuleCase(") + 9;
			int lastIndex = read.lastIndexOf(')');
			ruleItem.setRULE_CASE(read.substring(firstIndex, lastIndex));
		}
		if (read.contains("RuleStep(") && ruleItem != null) {
			int firstIndex = read.indexOf("RuleStep(") + 9;
			int lastIndex = read.lastIndexOf(')');
			ruleItem.setRULE_STEP(read.substring(firstIndex, lastIndex));
		}
		if (read.contains(SETDESTINATION) && ruleItem != null) {
			read = read.substring(read.indexOf(SETDESTINATION));
			int firstIndex = read.indexOf(SETDESTINATION) + 15;
			int lastIndex = read.indexOf(')');
			String destination = read.substring(firstIndex, lastIndex).replaceAll("\"", "");
			ruleItem.setRULE_DESTINATION(destination);
		}
		return ruleItem;
	}

	private RuleEntity matchRuleProcess(String read, RuleEntity ruleItem) {
		if (read.startsWith("rule") && read.length() > 4) {
			// add last rule item to list.
			if (ruleItem != null) {
				propertiesRules.add(ruleItem);
			}
			// empty it.
			ruleItem = new RuleEntity();

			String ruleName = read.substring(5).trim();
			ruleName = ruleName.replaceAll("\"", "");
			if (ruleName.startsWith(ignorePrefix) || ruleName.startsWith("\"" + ignorePrefix)) {
				ruleItem = null;
				otherTxt.append(read + "\n");
			} else {
				ruleItem.setRULE_ID(ruleName);
			}
		}
		return ruleItem;
	}

	public List<Map<String, String>> search(String ruleName, String destination) {
		List<RuleEntity> ruleList = getAllRules();
		List<Map<String, String>> jsArray = new ArrayList<Map<String, String>>();

		for (RuleEntity rule : ruleList) {

			if (ruleName != null && !"".equals(ruleName)
					&& !rule.getRULE_ID().trim().toUpperCase().contains(ruleName.trim().toUpperCase())) {
				continue;
			}
			if (destination != null && !"".equals(destination)
					&& !rule.getRULE_DESTINATION().trim().toUpperCase().contains(destination.trim().toUpperCase())) {
				continue;
			}
			jsArray.add(rule.toMap());
		}
		LogUtil.logInfo(m_Logger,"RulePropertiesBean doSearch return:" + jsArray.toString());
		return jsArray;
	}

	public Boolean insert(RuleEntity rEntity) {
		try {
			List<RuleEntity> ruleList = getAllRules();
			ruleList.add(rEntity);
			saveChanges(ruleList);
			return true;

		} catch (Exception e) {
			LogUtil.logException(m_Logger, rEntity.toString(), e);
			 
		}
		return false;
	}

	public Boolean update(RuleEntity rEntity) {
		List<RuleEntity> ruleList = getAllRules();
		LogUtil.logInfo(m_Logger,"RulePropertiesBean" + "resourcePath" + rEntity.getRULE_ID().trim());
		try {
			boolean matched = false;
			for (RuleEntity rule : ruleList) {

				if (rule.getRULE_ID().trim().equals(rEntity.getRULE_ID().trim())) {
					rule.setRULE_STEP(rEntity.getRULE_STEP());
					rule.setRULE_CASE(rEntity.getRULE_CASE());
					rule.setRULE_DESTINATION(rEntity.getRULE_DESTINATION());
					matched = true;
				}
			}
			if (matched) {
				saveChanges(ruleList);
				return true;
			} 

		} catch (Exception e) {

			LogUtil.logException(m_Logger, rEntity.toString(), e);
		}
		return false;

	}

	public Boolean delete(Set<String> ruleName) {
		try {
			boolean matched = false;
			List<RuleEntity> ruleList = getAllRules();
			Iterator<RuleEntity> it = ruleList.iterator();
			while (it.hasNext()) {
				RuleEntity item = it.next();

				if (ruleName.contains(item.getRULE_ID())) {
					it.remove();
					matched = true;
				}
			}
			if (matched) {
				saveChanges(ruleList);
				return true;
			} 
		} catch (Exception e) {

			LogUtil.logException(m_Logger, ruleName.toString(), e);
		}
		return false;
	}

	private File getRuleConfigFile() {
		File file = new File("D:/DroolsRules/sgp.rule.drl");
		if (!file.exists()) {
			try {
			boolean fileData=	file.createNewFile();
			if(fileData){
				LogUtil.logInfo(m_Logger, "create success");
			}else{
				LogUtil.logInfo(m_Logger, "create failed");
			}
			} catch (IOException e) {
				LogUtil.logException(m_Logger, "", e);
				 
			}
		}
		return file;
	}

	public void saveChanges(List<RuleEntity> jsArrayAll) {
		StringBuilder sContent = new StringBuilder();
		sContent.append("package sgp.rule\n" + "import com.aia.case360.drools.model.RuleCase\n"
				+ "import com.aia.case360.drools.model.RuleStep\n" + "import com.aia.case360.drools.model.RuleResult\n"
				+ "global java.util.List resultList\n");


		File f = getRuleConfigFile();
		File backupFile;
        String message="Function : saveChanges";
		for (RuleEntity rule : jsArrayAll) {
			sContent.append(rule.toTxt());
		}
		getAllRulesFromProperties();
		sContent.append(otherTxt.toString());
		try (FileWriter fileWritter = new FileWriter(f, false);
				BufferedWriter bufread = new BufferedWriter(fileWritter);){
			SimpleDateFormat df = new SimpleDateFormat();
			df.applyPattern("yyyy-MM-dd HHmmss");
			backupFile = new File(f.getAbsolutePath() + "." + df.format(new Date()));
		    boolean renameFile=	f.renameTo(backupFile);
		    if(renameFile){
		    	LogUtil.logInfo(m_Logger, message+" rename file success");
		    }else{
		    	LogUtil.logInfo(m_Logger, message+" rename file failed");
		    }
			f = getRuleConfigFile();
			bufread.write(sContent.toString());
			bufread.flush();
		} catch (IOException e) {
			LogUtil.logException(m_Logger, jsArrayAll.toString(), e);
		}
	}

}
