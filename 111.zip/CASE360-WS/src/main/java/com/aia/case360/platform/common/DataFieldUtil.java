package com.aia.case360.platform.common;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aia.case360.platform.caches.Impl.FieldCache;
import com.eistream.sonora.exceptions.SonoraException;
import com.eistream.sonora.fields.FmsRow;
import com.eistream.sonora.fields.FmsRowNative;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * DataFieldUtil: get all input data for log informaiton
 * 
 * @author bsnpbdu
 *
 */
public final class DataFieldUtil {
	private static Logger m_Logger = LoggerFactory.getLogger(DataFieldUtil.class.getClass());

	/**
	 * This function will get List value to form String object
	 * 
	 * @param data
	 * @return
	 */
	public final static String getInListStr(List<String> data) {
		if (null == data || data.isEmpty())
			return "";
		StringBuilder sb = new StringBuilder();
		for (String temp : data) {
			sb.append(temp);
			sb.append(",");
		}
		String result = sb.toString();
		return result.substring(0, result.length() - 1);

	}

	/**
	 * convert Map into String
	 * 
	 * @param maps Map input
	 * @return String value
	 */
	public final static <K, V> String getInMapStr(Map<K, V> maps) {
		StringBuilder sb = new StringBuilder();
		if (maps == null || maps.isEmpty())
			return null;
		for (Entry<K, V> k : maps.entrySet()) {
			sb.append("[");
			sb.append(k.getKey());
			sb.append(":");
			sb.append(k.getValue());
			sb.append("],");
		}

		String result = sb.toString();
		return result.substring(0, result.length() - 1);

	}

	public final static Map<String, Object> getObejceMap(Map<String, String> maps) {
		Map<String, Object> result = new HashMap<String, Object>();
		for (Entry<String, String> k : maps.entrySet()) {
			result.put(k.getKey(), k.getValue());
		}
		return result;
	}

	/**
	 * convert 2 List object to one Map
	 * 
	 * @param fieldNames
	 * @param fieldValues
	 * @return
	 */
	public final static Map<String, String> getList2Map(List<String> fieldNames, List<String> fieldValues) {

		Map<String, String> result = new HashMap<String, String>();

		if (fieldValues == null || fieldNames == null) {
			return result;
		}
		if (fieldNames.isEmpty() || fieldValues.isEmpty()) {
			return result;
		}
		if (fieldNames.size() != fieldValues.size()) {
			return result;
		}

		for (int i = 0; i < fieldNames.size(); i++) {
			if (DataFieldUtil.isNull(fieldValues.get(i))) {
				continue;
			}
			result.put(fieldNames.get(i), fieldValues.get(i));
		}

		return result;
	}

	public final static boolean isNull(String... values) {
		boolean result = false;
		for (String temp : values) {
			if (result) {
				return result;
			}
			result = (null == temp || temp.trim().length() < 1) || result;

		}
		return result;
	}

	/**
	 * convert input
	 * 
	 * @param params
	 * @return
	 */
	public final static Map<String, String> getParamsMap(String[]... params) {
		Map<String, String> result = new HashMap<String, String>();

		for (String[] param : params) {
			result.put(param[0], param[1]);
		}
		return result;
	}

	public final static <E> List<Map<String, Object>> getPOJORowList(Class<E> clazz, List<E> rowList)
			throws RemoteException {

		List<Map<String, Object>> result = new ArrayList<Map<String, Object>>();
		Field[] fs = clazz.getDeclaredFields();

		for (E dElem : rowList) {
			Map<String, Object> fldPairs = new HashMap<String, Object>();
			for (Field fd : fs) {
				try {
					fd.setAccessible(true);
					if (fd.isAccessible())
						fldPairs.put(fd.getName(), fd.get(dElem));
				} catch (IllegalArgumentException e) {
					LogUtil.logException(m_Logger , rowList.toString(), e);
					 
				} catch (IllegalAccessException e) {
					LogUtil.logException(m_Logger , rowList.toString(), e);
					 
				}
			}
			result.add(fldPairs);

		}
		return result;
	}

	public static List<FmsRowNative> copyFmsRowNativeList(List<FmsRowNative> inList) {
		List<FmsRowNative> result = new ArrayList<FmsRowNative>();

		for (FmsRowNative row : inList) {
			result.add((FmsRowNative) row.clone());
		}
		return result;
	}

	/**
	 * get request prarmeters
	 * 
	 * @param request
	 * @return
	 */
	public static Map<String, String> getRequestParamsMap(HttpServletRequest request) {

		List<String> fieldFlds = new ArrayList<String>();
		List<String> fieldVals = new ArrayList<String>();

		if (  request.getParameterMap() != null && request.getParameterMap().size() > 0) {
			Map<String, String[]> paramPairs = request.getParameterMap();
			for (Entry<String, String[]> key : paramPairs.entrySet()) {
				if (key != null && StringUtils.isNotBlank(key.getKey()) && StringUtils.isNotBlank(key.getValue()[0])) {
					if (key.getKey().trim().toLowerCase().equals("loginid")) {
						// If key is loginID, make the value to Upper letter by smart
						String loginid = key.getValue()[0].toUpperCase();
						fieldFlds.add(key.getKey().trim());
						fieldVals.add(loginid.trim());
					} else {
						fieldFlds.add(key.getKey().trim());
						fieldVals.add(key.getValue()[0].trim());
					}
				}
			}
		} else {
			return null;
		}

		Map<String, String> params2 = DataFieldUtil.getList2Map(fieldFlds, fieldVals);
		return params2;
	}

	public static List<Map<String, String>> getRequestParamsList(JSONObject request, String keyName) {

		List<Map<String, String>> paramsList = new ArrayList<Map<String, String>>();
		if (  !request.isEmpty()) {
			String keyValue = request.get(keyName).toString();
			JSONArray array = JSONArray.fromObject(keyValue);
			if (!array.isEmpty()) {
				for (int i = 0; i < array.size(); i++) {
					JSONObject j = array.getJSONObject(i);
					if (!j.isEmpty()) {
						Map<String, String> paramPairs = DataFieldUtil.getRequestParamsMap(j);
						paramsList.add(paramPairs);
					}

				}
			} else {
				return paramsList;
			}
		} else {
			return paramsList;
		}
		return paramsList;
	}

	/**
	 * get request prarmeters
	 * 
	 * @param request
	 * @return
	 */
	public static Map<String, String> getRequestParamsMap(JSONObject request) {

		List<String> fieldFlds = new ArrayList<String>();
		List<String> fieldVals = new ArrayList<String>();

		if (  !request.isEmpty()) {
			Iterator<String> keys = request.keys();
			while (keys.hasNext()) {
				String key = keys.next();
				fieldFlds.add(key);
				fieldVals.add(request.getString(key));
			}
		} else {
			return null;
		}

		Map<String, String> params2 = DataFieldUtil.getList2Map(fieldFlds, fieldVals);
		return params2;
	}

	/**
	 * get request prarmeters that key=keyName
	 * 
	 * @param request
	 * @return
	 */
	public static List<String> getRequestParamsMap(HttpServletRequest request, String keyName) {

		List<String> values = new ArrayList<String>();

		if (  request.getParameterMap() != null && request.getParameterMap().size() > 0) {
			Map<String, String[]> paramPairs = request.getParameterMap();
			for (Entry<String, String[]> key : paramPairs.entrySet()) {

				if (key != null && key.getKey().equals(keyName) && StringUtils.isNotBlank(key.getValue()[0])) {
					values = Arrays.asList(key.getValue());
					break;
				}
			}
		}
		return values;
	}

	/**
	 * get request files and prarmeters
	 * 
	 * @param request
	 * @return
	 */
	public static List<String> getRequestFilePathsAndParams(HttpServletRequest request, Map<String, String> fields)
			throws RemoteException {
       String message="Function : getRequestFilePathsAndParams";
		try {
			request.setCharacterEncoding("UTF-8");

		} catch (UnsupportedEncodingException e1) {
			LogUtil.logException(m_Logger, message, e1);
			throw new RemoteException("request faild");
		}
		DiskFileItemFactory fileFactory = new DiskFileItemFactory();
		File filesDir = new File("uploadfile");
		if (!filesDir.exists()) {
			filesDir.mkdirs();
		}

		fileFactory.setRepository(filesDir);

		ServletFileUpload uploader = new ServletFileUpload(fileFactory);
		List<String> filePaths = new ArrayList<String>();
		String filePath = null;
		try {

			List<FileItem> fileItemsList = uploader.parseRequest(request);

			Iterator<FileItem> fileItemsIterator = fileItemsList.iterator();

			while (fileItemsIterator.hasNext()) {

				FileItem fileItem = fileItemsIterator.next();
				if (fileItem != null && fileItem.isFormField()) {
					String formname = fileItem.getFieldName().trim();
					String formcontent = fileItem.getString().trim();
					fields.put(formname, formcontent);
					continue;
				} else if (fileItem != null) {
					String fileName = fileItem.getName();
					String s = fileName.substring(fileName.lastIndexOf(File.separator) + 1, fileName.length());
					fields.put(PropertyUtil.getCommonProperty("FILE_NAME"), s);
					filePath = filesDir + File.separator + s;

					if (!DataFieldUtil.isNull(fileItem.getName())) {
						File file = new File(filePath);
						fileItem.write(file);
					}
					filePaths.add(filePath);

				}
			}

			return filePaths;
		} catch (Exception e) {
			 
			throw new RemoteException(e.getMessage());
		}
	}

	/**
	 * get request files and prarmeters
	 * 
	 * @param request
	 * @param list    field like CHG_ITEM_ID
	 * @return
	 */
	public static List<String> getRequestFilePathsAndParams(HttpServletRequest request, Map<String, String> fields,
			List<String> chgIds, String listField) throws RemoteException {
        String message="Function : getRequestFilePathsAndParams";
		try {
			request.setCharacterEncoding("UTF-8");

		} catch (UnsupportedEncodingException e1) {
			LogUtil.logException(m_Logger, message, e1);
			throw new RemoteException("request faild");
		}
		DiskFileItemFactory fileFactory = new DiskFileItemFactory();
		File filesDir = new File("uploadfile");
		if (!filesDir.exists()) {
			filesDir.mkdirs();
		}

		fileFactory.setRepository(filesDir);

		ServletFileUpload uploader = new ServletFileUpload(fileFactory);
		List<String> filePaths = new ArrayList<String>();
		String filePath = null;
		try {

			List<FileItem> fileItemsList = uploader.parseRequest(request);

			Iterator<FileItem> fileItemsIterator = fileItemsList.iterator();

			while (fileItemsIterator.hasNext()) {

				FileItem fileItem = fileItemsIterator.next();
				if (fileItem != null && fileItem.isFormField()) {
					String formname = fileItem.getFieldName().trim();
					String formcontent = fileItem.getString().trim();
					if (formname.equalsIgnoreCase(listField)) {
						chgIds.add(formcontent);
					} else {
						fields.put(formname, formcontent);

					}
					continue;
				} else if (fileItem != null) {
					String fileName = fileItem.getName();
					String s = fileName.substring(fileName.lastIndexOf(File.separator) + 1, fileName.length());
					fields.put(PropertyUtil.getCommonProperty("FILE_NAME"), s);
					filePath = filesDir + File.separator + s;

					if (!DataFieldUtil.isNull(fileItem.getName())) {
						File file = new File(filePath);
						fileItem.write(file);
					}
					filePaths.add(filePath);

				}
			}
			return filePaths;
		} catch (Exception e) {
			 
			throw new RemoteException(e.getMessage());
		}
	}

	public static List<String> getWortStep(String workStep) {
		List<String> list = new ArrayList<String>();
		String[] s = workStep.split("_");
		String realWorkStepName = "";
		if (s.length == 3) {
			realWorkStepName = s[0] + "_" + s[1];
			list.add("PND_WAIT");
			list.add(realWorkStepName);
		} else {
			list.add(workStep);
		}
		return list;
	}

	public static void main(String[] args) {
		ArrayList<String> me = new ArrayList<String>();
		Map<String, String> he = new HashMap<String, String>();
		for (int i = 1; i < 10; i++) {
			me.add("" + i + "|");
			he.put("" + i, i + "");
		}

	}

	// added by Leo Li
	public static void updateTableRow(Map<String, String> parameters, FmsRow fmsRow)
			throws RemoteException, SonoraException {
		Iterator<Map.Entry<String, String>> it = parameters.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<String, String> entry = it.next();
			if (fmsRow.getField(entry.getKey()) == null) {
				continue;
			}
			
			verifyValue(fmsRow, entry);
			
		}
	}
	// end

  private static void verifyValue(FmsRow fmsRow, Map.Entry<String, String> entry)
      throws RemoteException, SonoraException {
    if (FieldCache.getFieldType(entry.getKey()).equalsIgnoreCase("Decimal")) {
        if(!"".equals(valueIsNull(entry.getValue()))){
    		fmsRow.setValue(entry.getKey(), new BigDecimal(entry.getValue().toString()));
         }
     } else if (FieldCache.getFieldType(entry.getKey()).equalsIgnoreCase("Integer")) {
         if(!"".equals(valueIsNull(entry.getValue()))){
    		fmsRow.setValue(entry.getKey(), new Integer(entry.getValue()));
         }
     } else if (FieldCache.getFieldType(entry.getKey()).equalsIgnoreCase("Boolean")) {
         if(!"".equals(valueIsNull(entry.getValue()))){
    		entryBooleanValue(fmsRow, entry);
         }
     } else if (FieldCache.getFieldType(entry.getKey()).equalsIgnoreCase("Timestamp")) {
         if(!"".equals(valueIsNull(entry.getValue()))){
    		fmsRow.setValue(entry.getKey(), DateUtil.getTimestamp(entry.getValue()));
         }
     }else {
         fmsRow.setValue(entry.getKey(), valueIsNull(entry.getValue()));
     }
  }

  private static void entryBooleanValue(FmsRow fmsRow, Map.Entry<String, String> entry)
      throws SonoraException {
    String fieldValue = entry.getValue();
    // Albert wang.On 20180206.Convert "1" and "true" to true value.
    Boolean b = false;
    if (StringUtils.isNotBlank(fieldValue)
    		&& (fieldValue.trim().equals("1") || fieldValue.trim().equalsIgnoreCase("true"))) {
    	b = true;
    }
    fmsRow.setValue(entry.getKey(), b);
  }
	
	private static String valueIsNull(String value){
      
      if(value==null){
        return "";
      }else if("".equals(value.trim())){
        return "";
      }else if(value.trim().length()==0){
        return "";
      }else{
        return value;
      }
    }
}
