package com.aia.case360.web.pojo;

import java.io.Serializable;

public class GetSuppressPendingParameter implements Serializable {

	// codeCategory
	private String codeCategory;
	private String callingSystem;

	public String getCodeCategory() {
		return codeCategory;
	}

	public void setCodeCategory(String codeCategory) {
		this.codeCategory = codeCategory;
	}

	public String getCallingSystem() {
		return callingSystem;
	}

	public void setCallingSystem(String callingSystem) {
		this.callingSystem = callingSystem;
	}

}
