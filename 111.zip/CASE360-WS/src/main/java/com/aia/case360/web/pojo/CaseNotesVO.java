package com.aia.case360.web.pojo;

import java.util.Date;

/**
 * Case Note VO
 * 
 * @author bsnpbys
 *
 */
public class CaseNotesVO {

	private Integer sRowId;

	private String createBy;

	private Date createDate;

	private Integer linkCaseId;

	private String comments;

	private String category;

	private boolean isSystem;

	private boolean isVoid;

	public Integer getsRowId() {
		return sRowId;
	}

	public void setsRowId(Integer sRowId) {
		this.sRowId = sRowId;
	}

	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Integer getLinkCaseId() {
		return linkCaseId;
	}

	public void setLinkCaseId(Integer linkCaseId) {
		this.linkCaseId = linkCaseId;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public boolean isSystem() {
		return isSystem;
	}

	public void setSystem(boolean isSystem) {
		this.isSystem = isSystem;
	}

	public boolean isVoid() {
		return isVoid;
	}

	public void setVoid(boolean isVoid) {
		this.isVoid = isVoid;
	}
}
