package com.aia.case360.uam.domain;

import java.util.List;

public class RequestType {

	@Override
	public String toString() {
		return "RequestType [requestTypeName=" + requestTypeName + ", data=" + data + "]";
	}

	private String requestTypeName;

	private String reqId;

	private List<String> data;

	public String getRequestTypeName() {
		return requestTypeName;
	}

	public void setRequestTypeName(String requestTypeName) {
		this.requestTypeName = requestTypeName;
	}

	public List<String> getData() {
		return data;
	}

	public void setData(List<String> data) {
		this.data = data;
	}

	public String getReqId() {
		return reqId;
	}

	public void setReqId(String reqId) {
		this.reqId = reqId;
	}

}
