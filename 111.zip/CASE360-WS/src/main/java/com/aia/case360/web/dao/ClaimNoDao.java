package com.aia.case360.web.dao;

import java.rmi.RemoteException;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.aia.case360.web.pojo.ClaimNo;
import com.aia.case360.web.pojo.DocListOMSParameter;

@Repository
public interface ClaimNoDao {

	List<ClaimNo> queryClaimNo(DocListOMSParameter params)  throws RemoteException;
}
