package com.aia.case360.web.dao;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.aia.case360.web.pojo.AutoFileGetAutoFileRequestNoCaseIdResult;
import com.aia.case360.web.pojo.DocLinkParam;
import com.aia.case360.web.pojo.FdDocAttr;

public interface AutoFileDao {

	public AutoFileGetAutoFileRequestNoCaseIdResult getAutoFileRequestNoCaseId(Map<String, Object> getReqNoParams)  throws RemoteException;
	
	public int insertFdDocAttrs(List<FdDocAttr> fdDocAttrs);

	public void batchAddDocLinkWithNoAspect(@Param("list") List<DocLinkParam> list) throws RemoteException;
}
