package com.aia.case360.web.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.aia.case360.web.pojo.FdDocAttributes;
import com.aia.case360.web.pojo.FdDocLink;
import com.aia.case360.web.pojo.FdDocMigCtrl;

//@Repository
public interface DocMigCtrlDao {
	public int queryStatusByObjId(String objectId);

	public int isObjIdExist(String objectId);

	public int insertOneFdDocMigCtrl(FdDocMigCtrl fdDocMigCtrl);

	public int insertFdDocMigCtrl(List<FdDocMigCtrl> fdDocMigCtrls);

	public int updateStatus(@Param("migStatus") String migStatus, @Param("objectId") String objectId);

	public List<FdDocMigCtrl> queryFdDocMigCtrl(String objectId);

	public List<String> getMaxObjId();

	public List<String> getNoNeedObjId(String objectId);

	public List<FdDocAttributes> getAttributesFromEIMAGE(Map<String, Object> param);

	public List<FdDocLink> getNewLogicalLinkEXTIMAGE(Map<String, Object> param);

	public int insertFdDocAttributes(List<FdDocAttributes> attrList);

	public int updateAttributes(List<FdDocAttributes> attrList);

	public List<FdDocAttributes> getModifyAttrFromEIMAGE(List<String> objectIdlist);

	public List<String> queryObjectIdFromEXTIMAGE(String maxAuditId);

	public int updateSysConfigValue(Map<String, String> param);

	public List<Map<String, Object>> queryOneSysConfig(Map<String, String> param);

	public List<FdDocLink> getLogicalLinkEXTIMAGE(Map<String, Object> param);

	// use for script get information from EX360
	public List<Map<String, Object>> getAttrFromEIMAGE(Map<String, Object> param);

	public List<Map<String, Object>> getUpAttrFromEIMAGE(Map<String, Object> param);

	public List<Map<String, Object>> getUpLCLinkEXTIMAGE(Map<String, Object> param);

	public List<Map<String, Object>> getLCLinkEXTIMAGE(Map<String, Object> param);

	public List<Map<String, Object>> getAttributesMapFromEIMAGE(Map<String, Object> param);

	public List<Map<String, Object>> getUpAuditTrailEXTIMAGE(Map<String, Object> param);

	public List<Map<String, Object>> getUpAttributesMapFromEIMAGE(Map<String, Object> param);

	public List<Map<String, Object>> getMaxLCIdFromDocLink(Map<String, Object> param);

}
