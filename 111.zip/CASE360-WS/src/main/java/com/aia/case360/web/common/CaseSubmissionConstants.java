package com.aia.case360.web.common;

public class CaseSubmissionConstants {

	public static final String REQ_TYPE = "REQ_TYPE";
	public static final String IS_URGENT = "IS_URGENT";
	public static final String RECEIVE_DT = "RECEIVE_DT";
	public static final String PROCESS_TYPE = "PROCESS_TYPE";
	public static final String PARENT_REQUEST_NUM = "PARENT_REQUEST_NUM";
	public static final String REQUEST_NUM = "REQUEST_NUM";
	public static final String DEPARTMENT = "DEPARTMENT";
	public static final String LOB = "LOB";
	public static final String CATEGORY = "CATEGORY";
	public static final String SUB_REQ_TYPE = "SUB_REQ_TYPE";
	public static final String ALIAS_NM = "ALIAS_NM";
	public static final String TSAR = "TSAR";
	public static final String USERID = "USERID";
	public static final String COMMENTS = "COMMENTS";
	public static final String COMPANY_NO = "COMPANY_NO";
	public static final String PRODUCT_TYPE = "PRODUCT_TYPE";
	public static final String ROOT_CASE_ID = "ROOT_CASE_ID";
	public static final String FSC_CODE = "FSC_CODE";
	public static final String TISA = "TISA";
	public static final String COMPANYNO = "COMPANYNO";
	public static final String AGENCY_LOCATION = "AGENCY_LOCATION";
	
	public static final String USER_ACTIVE = "Active";
	public static final String TRAINER_STATUS_FULL = "FULL";
	public static final String TRAINER_STATUS_INACTIVE = "Inactive";
	public static final String TRAINER_STATUS_LEAVE = "Leave";

	public static final String PRIMARY_TRAINER_NM = "PRIMARY_TRAINER_NM";
	public static final String POL_NUM = "POL_NUM";
	public static final String CREATE_BY = "CREATE_BY";
	public static final String LINKCASEID = "LINKCASEID";
	public static final String OBJECT_ID = "OBJECT_ID";
	public static final String CASEID = "CASEID";
	public static final String POLICY_NUM = "POLICY_NUM";
	public static final String MANUAL_CREATION = "Manual Creation";
	public static final String IS_VALID = "IS_VALID";
	public static final String DUMMY_POLICY_FLAG = "DUMMY_POLICY_FLAG";
	public static final String SUBMIT_CHANNEL = "SUBMIT_CHANNEL";
	public static final String SOURCE_SYSTEM = "SOURCE_SYSTEM";
	public static final String IS_VOID = "IS_VOID";
	public static final String IS_SYSTEM = "IS_SYSTEM";
	public static final String CREATED_TIMESTAMP = "CREATED_TIMESTAMP";
	public static final String CREATED_BY = "CREATED_BY";
	public static final String FORM_ID = "FORM_ID";
	public static final String RECEIVED_DT = "RECEIVED_DT";
	public static final String REQUEST_TYPE_CATEGORY = "REQUEST_TYPE_CATEGORY";
	public static final String REQ_TYPE_GRP = "REQ_TYPE_GRP";
	public static final String CREATE_DATE = "CREATE_DATE";
	public static final String FILENAME = "FILENAME";
	public static final String PAGE_INDICATOR = "PAGE_INDICATOR";
	public static final String FILE_EXTENSION = "FILE_EXTENSION";

	public static final String PARENT_CASE_ID = "PARENT_CASE_ID";
	public static final String NAME = "NAME";
	public static final String FORM_CATEGORY = "FORM_CATEGORY";
	public static final String FORM_NAME = "FORM_NAME";
	public static final String SOURCE_SYSTEM_CODE = "SOURCE_SYSTEM_CODE";
	public static final String FROM_OBJECT_ID = "FROM_OBJECT_ID";
	public static final String TO_OBJECT_ID = "TO_OBJECT_ID";
	public static final String USER_ACT = "USER_ACT";
	public static final String FROM_FORM_ID = "FROM_FORM_ID";
	public static final String FROM_POL_NUM = "FROM_POL_NUM";
	public static final String FROM_COM_CD = "FROM_COM_CD";
	public static final String LINK_STATUS = "LINK_STATUS";
	public static final String LAST_UPDATED_TIMESTAMP = "LAST_UPDATED_TIMESTAMP";
	public static final String LAST_UPDATED_BY = "LAST_UPDATED_BY";
	public static final String IS_LOGICAL = "IS_LOGICAL";
	public static final String POLICY_NO = "POLICY_NO";
	public static final String REQUEST_NO = "REQUEST_NO";
	public static final String REQUEST_TYPE = "REQUEST_TYPE";
	public static final String ORI_POL_NUMS = "ORI_POL_NUMS";
	public static final String CREATED_DT = "CREATED_DT";
	public static final String CODE_TRUE = "true";
	public static final String CODE_FALSE = "false";
	public static final String DESTINATION = "DESTINATION";

	public static final String ACTIVE = "Active";
	public static final String INACTIVE = "Inactive";
	public static final String ACTIVESTATUS = "ACTIVESTATUS";
	public static final String DATE_TYPE = "DATE_TYPE";
	public static final String LEAVE = "Leave";
	// added by bsnpc1g on 2018-12-14 : used to get the non AIA customer NRIC
	public static final String NRIC = "NRIC";
	// added end on 2018-12-14
	public static final String CLAIM_NO = "CLAIM_NO";
	
	private CaseSubmissionConstants() {

	}

}
