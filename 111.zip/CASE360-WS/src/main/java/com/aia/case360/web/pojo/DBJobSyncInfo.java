package com.aia.case360.web.pojo;

import java.math.BigDecimal;

public class DBJobSyncInfo {
	
	private BigDecimal caseId;
	
	private String policyNo;
	
	private String companyNo;
	
	//private String uwid;
	
	private String UWID;

	private String plas_status;
	
	private String uw_statCode;
	
	private String uw_batchCode;
	
	private String followUpCode;
	
	public String getFollowUpCode() {
		return followUpCode;
	}

	public void setFollowUpCode(String followUpCode) {
		this.followUpCode = followUpCode;
	}

	public BigDecimal getCaseId() {
		return caseId;
	}

	public void setCaseId(BigDecimal caseId) {
		this.caseId = caseId;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getCompanyNo() {
		return companyNo;
	}

	public void setCompanyNo(String companyNo) {
		this.companyNo = companyNo;
	}

	/*public String getUwid() {
		return uwid;
	}

	public void setUwid(String uwid) {
		this.uwid = uwid;
	}*/
	
	

	public String getPlas_status() {
		return plas_status;
	}

	public String getUWID() {
		return UWID;
	}

	public void setUWID(String uWID) {
		UWID = uWID;
	}

	public void setPlas_status(String plas_status) {
		this.plas_status = plas_status;
	}

	public String getUw_statCode() {
		return uw_statCode;
	}

	public void setUw_statCode(String uw_statCode) {
		this.uw_statCode = uw_statCode;
	}

	public String getUw_batchCode() {
		return uw_batchCode;
	}

	public void setUw_batchCode(String uw_batchCode) {
		this.uw_batchCode = uw_batchCode;
	}
	
	

}
