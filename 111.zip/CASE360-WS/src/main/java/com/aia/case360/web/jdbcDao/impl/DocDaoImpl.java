package com.aia.case360.web.jdbcDao.impl;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.common.PropertyUtil;
import com.aia.case360.web.jdbcDao.DocDao;

/**
 * 
 * @author bsnpbpf 2018/08/28 CASEPP-5778 After reindex to new case, display
 *         duplicate documents on policy document tree. mod by bsnpc1n
 *
 */
@Repository
public class DocDaoImpl implements DocDao {
  
    protected Logger m_Logger = LoggerFactory.getLogger(getClass());
  
	private static final String GET_DOCUMENT_PROPERTIES_SQL = "SELECT FDAS.ORI_POL_NUMS,FDAS.BATCH_NO,FDAS.BOX_NO,FD.SUBMIT_CHANNEL,CONVERT(VARCHAR(20), FDAS.SCAN_DT, 120) AS SCAN_DT,CONVERT(VARCHAR(20), FDAS.RECEIVED_DT, 120) AS RECEIVED_DT,'' AS SIGNATURE_DATE,FDAS.COMPANY_NO,FDAS.PROCESS_TYPE,(CASE FFD.FORM_LEVEL WHEN 'P' THEN 'Case level' WHEN 'C' THEN 'Customer level' END) AS FORM_LEVEL,(CASE FD.IS_VOID WHEN 1 THEN 'VOID' ELSE 'Normal' END) AS STATUS FROM FS_DOCUMENTS FD LEFT JOIN FD_DOC_ATTR FDAS ON FD.OBJECT_ID = FDAS.OBJECT_ID LEFT JOIN FD_FORM_DEFINITION FFD ON FDAS.FORM_ID = FFD.FORM_ID WHERE ISNULL(FD.IS_MIGRATED, 0) = 0 AND FD.OBJECT_ID = ? UNION ALL SELECT FDAL.POLICY_NO AS ORI_POL_NUMS,FDAL.BATCH_NO,FDAL.BOX_NO,FD.SUBMIT_CHANNEL,CONVERT(VARCHAR(20), FDAL.SCAN_DT, 120) AS SCAN_DT,CONVERT(VARCHAR(20), FDAL.RECEIVED_DT, 120) AS RECEIVED_DT,'' AS SIGNATURE_DATE,FDAL.COMPANY_NO,FDAL.PROCESS_TYPE,(CASE FFD.FORM_LEVEL WHEN 'P' THEN 'Case level' WHEN 'C' THEN 'Customer level' END) AS FORM_LEVEL,(CASE FD.IS_VOID WHEN 1 THEN 'VOID' ELSE 'Normal' END ) AS STATUS FROM FS_DOCUMENTS FD LEFT JOIN FD_DOC_ATTRIBUTES FDAL ON FD.OBJECT_ID = FDAL.OBJECT_ID LEFT JOIN FD_FORM_DEFINITION FFD ON FDAL.FORM_ID = FFD.FORM_ID WHERE ISNULL(FD.IS_MIGRATED, 0) = 1 AND FD.OBJECT_ID = ?";
	private static final String GET_DOCUMENT_NOTES_SQL = "SELECT IS_VOID, COMMENTS NOTE, CONVERT(VARCHAR,CREATED_TIMESTAMP,120) CREATED_DT, CREATED_BY, (CASE IS_CONFIDENTIAL WHEN 0 THEN 'Normal' ELSE 'Confidential' END) SECURITY_LEVEL,fd.FORM_NM,dn.FORM_ID,dn.CANCELED_BY, CONVERT(VARCHAR,dn.CANCELED_TIMESTAMP,120) CANCELED_DT,dn.S_ROWID,CASE ISNULL(IS_VOID,0) WHEN 0 THEN 'Normal' ELSE 'Cancel' END AS IS_CANCEL  FROM FD_DOC_NOTE dn WITH(NOLOCK) LEFT JOIN FD_FORM_DEFINITION fd WITH(NOLOCK) ON dn.FORM_ID = fd.FORM_ID WHERE dn.OBJECT_ID = ? AND dn.FORM_ID = ? ORDER BY CREATED_DT DESC";

	private static final String GET_C_OBJECTID_DOC_CTRL_SQL = PropertyUtil
			.getCommonProperty("GET_C_OBJECTID_DOC_CTRL_SQL");
	private static final String GET_EXOBJNAMEINFO_DOC_LINK_SQL = PropertyUtil
			.getCommonProperty("GET_EXOBJNAMEINFO_DOC_LINK_SQL");
	private static final String GET_DOCID_DOCUMENTS_SQL = PropertyUtil.getCommonProperty("GET_DOCID_DOCUMENTS_SQL");
	private static final String UPDATE_OBJECTID_ATTR_SQL = PropertyUtil.getCommonProperty("UPDATE_OBJECTID_ATTR_SQL");

	private static final String UPDATE_OBJECTID_LINK_SQL = 	PropertyUtil.getCommonProperty("UPDATE_OBJECTID_LINK_SQL");	
	private static final String UPDATE_OBJECTID_DOCLINK_SQL = PropertyUtil.getCommonProperty("UPDATE_OBJECTID_DOCLINK_SQL");
	private static final String UPDATE_OBJECTID_DOCLINKSTATUS_SQL = PropertyUtil.getCommonProperty("UPDATE_OBJECTID_DOCLINKSTATUS_SQL");	
	private static final String UPDATE_OBJECTID_FAILED_DOCLINKSTATUS_SQL = PropertyUtil.getCommonProperty("UPDATE_OBJECTID_FAILED_DOCLINKSTATUS_SQL");
	private static final String UPDATE_OBJECTID_DOCUMENTS_SQL = PropertyUtil.getCommonProperty("UPDATE_OBJECTID_DOCUMENTS_SQL");
	private static final String UPDATE_OBJECTID_DOCCTRL_SQL = PropertyUtil.getCommonProperty("UPDATE_OBJECTID_DOCCTRL_SQL");
	private static final String UPDATE_FROM_OBJECTID_DOCAUDIT_SQL = PropertyUtil.getCommonProperty("UPDATE_FROM_OBJECTID_DOCAUDIT_SQL");
	private static final String UPDATE_TO_OBJECTID_DOCAUDIT_SQL = PropertyUtil.getCommonProperty("UPDATE_TO_OBJECTID_DOCAUDIT_SQL");	
	
	// Sync Case360ToExe360, add by wanjun

	private static final String GET_CASE360_INFO_VOID_PAGE_FS_DOCUMENT_SQL = PropertyUtil.getCommonProperty("GET_CASE360_INFO_VOID_PAGE_FS_DOCUMENT_SQL");
	private static final String GET_CASE360_OBJECTID_PAGE_VOID_AUDIT_TRAIL_SQL = PropertyUtil.getCommonProperty("GET_CASE360_OBJECTID_PAGE_VOID_AUDIT_TRAIL_SQL");
	
	private static final String GET_MAX_ROWID_FROM_CONFIG_SQL = PropertyUtil.getCommonProperty("GET_MAX_ROWID_FROM_CONFIG_SQL");
	private static final String UPDATE_TO_MAX_ROWID_SQL = PropertyUtil.getCommonProperty("UPDATE_TO_MAX_ROWID_SQL");
	private static final String GET_MAX_ROWID_VOID_PAGE_FROM_AUDIT_TRAIL_SQL = PropertyUtil.getCommonProperty("GET_MAX_ROWID_VOID_PAGE_FROM_AUDIT_TRAIL_SQL");
	private static final String GET_DOCINFO_FROM_DOC_LINK_SQL = PropertyUtil.getCommonProperty("GET_DOCINFO_FROM_DOC_LINK_SQL");
	private static final String GET_DOC_OBJECTID_LIST_FROM_DOC_LINK_SQL = PropertyUtil.getCommonProperty("GET_DOC_OBJECTID_LIST_FROM_DOC_LINK_SQL");
	
	private static final String FORM_ID="FORM_ID";
	private static final String CLIENT_ID="CLIENT_ID";
	private static final String S_ROWID="S_ROWID";
	private static final String HASHSTR="HASHSTR";
	
	private static final String OBJECT_ID="OBJECT_ID";
	private static final String POL_NUM="POL_NUM";
	private static final String CLAIM_NO="CLAIM_NO";
	private static final String LINKCASEID="LINKCASEID";
	private static final String RECEIVED_DT="RECEIVED_DT";
	private static final String C360_LOGICAL_LINK_ID="C360_LOGICAL_LINK_ID";
	private static final String LOGICAL_LINK_ID="LOGICAL_LINK_ID";
	   
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public void addDocNotes()  throws RemoteException {
	    String message = "FunctionName: addDocNotes";
		LogUtil.logInfo(m_Logger,message + " jdbcTemplate:" + jdbcTemplate.hashCode());
	}

	@Override
	public boolean reindexToClient(Map<String, Object> param)  throws RemoteException {
		if (param == null) {
			return false;
		}
		String formId = param.get(FORM_ID) == null ? null : param.get(FORM_ID).toString();
		String nric = param.get("NRIC") == null ? null : param.get("NRIC").toString();
		String clientid = param.get(CLIENT_ID) == null ? null : param.get(CLIENT_ID).toString();
		String sRowId = param.get(S_ROWID) == null ? null : param.get(S_ROWID).toString();

		// encrypt nric, hashStr
		String hashStr = param.get(HASHSTR).toString();

		StringBuilder sql = new StringBuilder(" UPDATE FD_DOC_CLIENT SET");


		sql.append("  FORM_ID = ? ");
		sql.append("  ,NRIC = ?    ");
		sql.append("  ,CLIENT_ID = ? ");
		sql.append("  ,HASHSTR = ? ");

		sql.append(" WHERE S_ROWID = ? ");

		Object args[] = new Object[] { formId, nric, clientid, hashStr, sRowId };
		;

		int temp = jdbcTemplate.update(sql.toString(), args);

		if (temp > 0) {
			return true;
		} else {
			return false;
		}

	}

	@Override
	public boolean deleteById(String rowId) {
		//
		StringBuilder sql = new StringBuilder(
				" UPDATE FD_DOC_LINK SET IS_DELETED = 1,LAST_UPDATED_TIMESTAMP=GETDATE(),LINK_STATUS=20 ");

		sql.append(" WHERE S_ROWID = ? ");

		int count = jdbcTemplate.update(sql.toString(), new Object[] { rowId }, new int[] { java.sql.Types.VARCHAR });

		return count > 0;
	}

	@Override
	public boolean insertDocLink(Map<String, Object> docLink) {
		StringBuilder sql = new StringBuilder(
				" INSERT INTO [FD_DOC_LINK] ([CREATED_DT] ,[FORM_ID] ,[OBJECT_ID],[POL_NUM] ,[REQUEST_NUM] ,[PROCESS_TYPE] ,[IS_VOID],[CLAIM_NO] ,[LINKCASEID],[COMPANY_NO],[IS_LOGICAL] ,[IS_MIGRATED],[RECEIVED_DT] ,[IS_DELETED],LOGICAL_LINK_ID,C360_LOGICAL_LINK_ID,LAST_UPDATED_TIMESTAMP,LINK_STATUS) ");
		sql.append(" VALUES(GETDATE(),?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,GETDATE(),10)  ");

		Object args[] = new Object[] { docLink.get(FORM_ID),
				docLink.get(OBJECT_ID), docLink.get(POL_NUM),
				docLink.get("REQUEST_NUM"), docLink.get("PROCESS_TYPE"),
				docLink.get("IS_VOID"), docLink.get(CLAIM_NO),
				docLink.get(LINKCASEID), docLink.get("COMPANY_NO"),
				docLink.get("IS_LOGICAL"),docLink.get("IS_MIGRATED"),
				docLink.get(RECEIVED_DT),
				docLink.get("IS_DELETED"),docLink.get(LOGICAL_LINK_ID),docLink.get(C360_LOGICAL_LINK_ID) };


		int count = jdbcTemplate.update(sql.toString(), args);

		return count > 0;
	}

	@Override
    public boolean insertDocLinkNoAspect(Map<String, Object> docLink) {

		return insertDocLink(docLink);
	}

	@Override
	public boolean IsDocLinkExist(Map<String, Object> params) {
		StringBuilder sql = new StringBuilder(" SELECT COUNT(1)  FROM [FD_DOC_LINK] WITH(NOLOCK) WHERE 1=1  ");
		List<Object> argsList = new ArrayList<Object>();

		appandSql(params, sql, argsList);
		// 2018/08/28 CASEPP-5778 After reindex to new case, display duplicate documents
		// on policy document tree. mod by bsnpc1n
		if (!StringUtils.isEmpty(params.get(LOGICAL_LINK_ID))) {
			sql.append(" AND LOGICAL_LINK_ID = ? ");
			argsList.add(params.get(LOGICAL_LINK_ID));
		} else {
			sql.append(" AND isnull(LOGICAL_LINK_ID,'') ='' ");
		}
		
        if (!StringUtils.isEmpty(params.get(C360_LOGICAL_LINK_ID))) {
          sql.append(" AND C360_LOGICAL_LINK_ID = ? ");
          argsList.add(params.get(C360_LOGICAL_LINK_ID));
        }else{
            sql.append(" AND isnull(C360_LOGICAL_LINK_ID,'') ='' ");
        }
        
		if (!StringUtils.isEmpty(params.get(POL_NUM))) {
			sql.append(" AND POL_NUM = ? ");
			argsList.add(params.get(POL_NUM));
		} else {
			sql.append(" AND POL_NUM IS NULL ");
		}
		if (!StringUtils.isEmpty(params.get(CLAIM_NO))) {
			sql.append(" AND CLAIM_NO = ? ");
			argsList.add(params.get(CLAIM_NO));
		} else {
			sql.append(" AND CLAIM_NO IS NULL ");
		}
		if (!StringUtils.isEmpty(params.get(FORM_ID))) {
			sql.append(" AND FORM_ID = ? ");
			argsList.add(params.get(FORM_ID));
		} else {
			sql.append(" AND FORM_ID IS NULL ");
		}

		sql.append(" AND ISNULL(IS_DELETED,0) = 0");
		Object[] args = argsList.toArray(new Object[0]);
		int count = jdbcTemplate.queryForObject(sql.toString(), args, Integer.class);
		return count > 0;
	}

	private void appandSql(Map<String, Object> params, StringBuilder sql,
			List<Object> argsList) {
		if (!StringUtils.isEmpty(params.get(OBJECT_ID))) {
			sql.append(" AND OBJECT_ID = ? ");
			argsList.add(params.get(OBJECT_ID));
		}
		if (!StringUtils.isEmpty(params.get(LINKCASEID))) {
			sql.append(" AND LINKCASEID = ? ");
			argsList.add(params.get(LINKCASEID));
		} else {
			sql.append(" AND LINKCASEID IS NULL ");
		}
	}

    @Override
    public boolean IsDocLinkExist(Map<String, Object> params, Boolean withLogicalLinkId) {
        StringBuilder sql = new StringBuilder(" SELECT COUNT(1)  FROM [FD_DOC_LINK] WITH(NOLOCK) WHERE 1=1  ");
        List<Object> argsList = new ArrayList<Object>();

        appandSql(params, sql, argsList);
        
        if(withLogicalLinkId) {
          // 2018/08/28 CASEPP-5778 After reindex to new case, display duplicate documents
          // on policy document tree. mod by bsnpc1n
          if (!StringUtils.isEmpty(params.get(LOGICAL_LINK_ID))) {
            sql.append(" AND LOGICAL_LINK_ID = ? ");
            argsList.add(params.get(LOGICAL_LINK_ID));
          } else {
            sql.append(" AND isnull(LOGICAL_LINK_ID,'') ='' ");
          }
          
          if (!StringUtils.isEmpty(params.get(C360_LOGICAL_LINK_ID))) {
            sql.append(" AND C360_LOGICAL_LINK_ID = ? ");
            argsList.add(params.get(C360_LOGICAL_LINK_ID));
          }else{
            sql.append(" AND isnull(C360_LOGICAL_LINK_ID,'') ='' ");
          }
        }
        
        if (!StringUtils.isEmpty(params.get(POL_NUM))) {
            sql.append(" AND POL_NUM = ? ");
            argsList.add(params.get(POL_NUM));
        } else {
            sql.append(" AND POL_NUM IS NULL ");
        }
        if (!StringUtils.isEmpty(params.get(CLAIM_NO))) {
            sql.append(" AND CLAIM_NO = ? ");
            argsList.add(params.get(CLAIM_NO));
        } else {
            sql.append(" AND CLAIM_NO IS NULL ");
        }
        if (!StringUtils.isEmpty(params.get(FORM_ID))) {
            sql.append(" AND FORM_ID = ? ");
            argsList.add(params.get(FORM_ID));
        } else {
            sql.append(" AND FORM_ID IS NULL ");
        }

        sql.append(" AND ISNULL(IS_DELETED,0) = 0");
        Object[] args = argsList.toArray(new Object[0]);
        int count = jdbcTemplate.queryForObject(sql.toString(), args, Integer.class);
        return count > 0;
    }

	@Override
	public boolean updateDocLinkFormId(Map<String, Object> docLink) {
		//
		StringBuilder sql = new StringBuilder(
				" UPDATE FD_DOC_LINK  SET FORM_ID=? WHERE S_ROWID=? ,LAST_UPDATED_TIMESTAMP=GETDATE(),LINK_STATUS=20");

		Object args[] = new Object[] { docLink.get(FORM_ID), docLink.get(S_ROWID) };

		int count = jdbcTemplate.update(sql.toString(), args);

		return count > 0;
	}

	@Override
	public boolean updateDocClient(Map<String, Object> doc_client, String splitSql) {
		//
		StringBuilder sql = new StringBuilder(" UPDATE FD_DOC_CLIENT  SET ");
		sql.append(splitSql);
		sql.append(" WHERE S_ROWID=? ");

		Object args[] = new Object[] { doc_client.get(S_ROWID) };

		int count = jdbcTemplate.update(sql.toString(), args);

		return count > 0;
	}

	@Override
	public boolean insertDocClient(Map<String, Object> doc_client) {
		// encrypt nric, hashStr
		StringBuilder sql = new StringBuilder(
				" INSERT INTO FD_DOC_CLIENT(CLIENT_ID,CREATED_DT,FORM_ID,OBJECT_ID,RECEIVED_DT,NRIC,PENDING_SEQ,HASHSTR) VALUES(?,GETDATE(),?,?,?,?,?,?) ");

		Object args[] = new Object[] { doc_client.get(CLIENT_ID), doc_client.get(FORM_ID),
				doc_client.get(OBJECT_ID), doc_client.get(RECEIVED_DT), doc_client.get("NRIC"),
				doc_client.get("PENDING_SEQ"), doc_client.get(HASHSTR) };

		int count = jdbcTemplate.update(sql.toString(), args);

		return count > 0;
	}

	@Override
	public boolean verifyDocClient(Map<String, Object> doc_client) {
		//
		StringBuilder sql = new StringBuilder(
				" select count(1) from fd_doc_CLIENT where ISNULL(IS_DELETED,0)=0 AND OBJECT_ID=? AND HASHSTR=? AND FORM_ID=? ");

		Object args[] = new Object[] { doc_client.get(OBJECT_ID), doc_client.get(HASHSTR),
				doc_client.get(FORM_ID) };

		int count = jdbcTemplate.queryForObject(sql.toString(), args, Integer.class);

		return count > 0;
	}

	@Override
	public boolean updatePageIndicator(String docId, String pageInd) {

		StringBuilder sql = new StringBuilder(" UPDATE FS_DOCUMENTS  SET PAGE_INDICATOR=? WHERE DOCUMENTID=?");
		Object args[] = new Object[] { pageInd, docId };

		int count = jdbcTemplate.update(sql.toString(), args);

		return count > 0;
	}

	// added by bsnpc1g on 03/19/2018: for the use of retrieving document properties
	@Override
	public List<Map<String, String>> viewDocPrpt(final String objectId) {

		return jdbcTemplate.query(GET_DOCUMENT_PROPERTIES_SQL, new PreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, objectId);
				ps.setString(2, objectId);
			}

		}, new RowMapper<Map<String, String>>() {

			@Override
			public Map<String, String> mapRow(ResultSet rs, int index) throws SQLException {
				Map<String, String> map = new HashMap<String, String>();
				ResultSetMetaData meta = rs.getMetaData();
				int count = meta.getColumnCount();
				for (int i = 1; i <= count; i++) {
					map.put(meta.getColumnName(i), rs.getString(i) == null ? "" : rs.getString(i));
				}
				return map;
			}
		});
	}
	// added end

	@Override
	public boolean insertDocAttr(String objectId) {

		StringBuilder sql = new StringBuilder();
		sql.append("INSERT INTO FD_DOC_ATTR (");
		sql.append(" ACL,AGENCY,AGENT_NM,ASSIGN_REASON_CD,ASSIGN_USER_ID,AUTO_FILING");
		sql.append(" ,BATCH_NO,BOXNO,CLM_CATEGORY,COH_USER_ID,COMPANY_NO,CURRENT_USER_ID,FORM_DESC");
		sql.append(
				" ,INPROGRESS_MIG,INPROGRESS_USER_ID,IS_CLM_FORM,IS_MAJOR_CLAIM,IS_MED_CASE,IS_POS_FORM,IS_POS_ILP_FORM,IS_UNI_FORM");
		sql.append(" ,ITEM_STATUS,JOB_STATUS,KIV_REASON,KIV_REASON_CD,KIV_USER_ID");
		sql.append(" ,LAST_PROC_USER_ID,LINK_INDICATOR,LOBA_STATUS,LOBAD_SYNC_RETRIED,LOBAD_SYNCED");
		sql.append(" ,OBJECT_CLASS,OBJECT_NAME,OBJECT_SERVER,OBJECT_TYPE");
		sql.append(" ,ORG_COMPANY_NO,ORG_POLICY_NO,ORG_REQUEST_NO,ORG_REQUEST_TYPE,ORIGINAL_USER_ID");
		sql.append(" ,POLICY_NO,POLICY_TYPE,POS_REQUEST_CATEGORY,PROCESS_TYPE");
		sql.append(
				" ,QUEUE_ID,REFER_FROM_USER_ID,REFER_REASON_CD,REFER_TO_MR,REFER_TO_USER_ID,REFER_USER_LIST,REQUEST_NO");
		sql.append(
				" ,REQUEST_TYPE,ROU_ERROR,ROU_ERROR_RETRY_COUNT,SOURCE_SYSTEM_CODE,STATUS_INDICATOR,TAADD,TACI,TCI,UNI_PLAN_NM");
		sql.append(
				" ,UNI_PLAN_TYPE,WF_NON_WF,WF_STATUS,WFR_CR_USER_ID,WFR_UPD_USER_ID,WORKITEM_FORM_ID,NRIC,OBJECT_ID,NAME,RECEIVED_DT");
		sql.append(" ) SELECT ");
		sql.append(" ACL,AGENCY,AGENT_NM,ASSIGN_REASON_CD,ASSIGN_USER_ID,AUTO_FILING,BATCH_NO,BOX_NO");
		sql.append(" ,CLM_CATEGORY,COH_USER_ID,COMPANY_NO,CURRENT_USER_ID,FORM_DESC,INPROGRESS_MIG,INPROGRESS_USER_ID");
		sql.append(" ,IS_CLM_FORM,IS_MAJOR_CLAIM,IS_MED_CASE,IS_POS_FORM,IS_POS_ILP_FORM,IS_UNI_FORM");
		sql.append(" ,ITEM_STATUS,JOB_STATUS,KIV_REASON,KIV_REASON_CD,KIV_USER_ID");
		sql.append(" ,LAST_PROC_USER_ID,LINK_INDICATOR,LOBA_STATUS,LOBAD_SYNC_RETRIED,LOBAD_SYNCED");
		sql.append(" ,OBJECT_CLASS,OBJECT_NAME,OBJECT_SERVER,OBJECT_TYPE");
		sql.append(" ,ORG_COMPANY_NO,ORG_POLICY_NO,ORG_REQUEST_NO,ORG_REQUEST_TYPE,ORIGINAL_USER_ID");
		sql.append(" ,POLICY_NO,POLICY_TYPE,POS_REQUEST_CATEGORY,PROCESS_TYPE");
		sql.append(
				" ,QUEUE_ID,REFER_FROM_USER_ID,REFER_REASON_CD,REFER_TO_MR,REFER_TO_USER_ID,REFER_USER_LIST,REQUEST_NO,REQUEST_TYPE");
		sql.append(
				" ,ROU_ERROR,ROU_ERROR_RETRY_COUNT,SOURCE_SYSTEM_CODE,STATUS_INDICATOR,TAADD,TACI,TCI,UNI_PLAN_NM,UNI_PLAN_TYPE");
		sql.append(
				" ,WF_NON_WF,WF_STATUS,WFR_CR_USER_ID,WFR_UPD_USER_ID,WORKITEM_FORM_ID,NRIC,OBJECT_ID,NAME,RECEIVED_DT");
		sql.append(" FROM FD_DOC_ATTRIBUTES WHERE OBJECT_ID=?");

		Object args[] = new Object[] { objectId };

		int count = jdbcTemplate.update(sql.toString(), args);

		return count > 0;

	}

	@Override
	public boolean updateIsMoved(String objectId) {

		StringBuilder sql = new StringBuilder(" UPDATE FS_DOCUMENTS SET IS_MOVED=1 WHERE OBJECT_ID=?");
		Object args[] = new Object[] { objectId };

		int count = jdbcTemplate.update(sql.toString(), args);

		return count > 0;
	}



	@Override
	public List<Map<String, String>> searchDocNotes(final String objectId, final String formId) {
		PreparedStatementSetter pss = new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, objectId);
				ps.setString(2, formId);
			}

		};
		RowMapper<Map<String, String>> rm = new RowMapper<Map<String, String>>() {
			@Override
			public Map<String, String> mapRow(ResultSet rs, int index) throws SQLException {
				Map<String, String> map = new HashMap<String, String>();
				ResultSetMetaData meta = rs.getMetaData();
				int count = meta.getColumnCount();
				for (int i = 1; i <= count; i++) {
					map.put(meta.getColumnName(i), rs.getString(i) == null ? "" : rs.getString(i));
				}
				return map;
			}
		};
		return jdbcTemplate.query(GET_DOCUMENT_NOTES_SQL, pss, rm);
	}

	@Override
	public boolean addDocNotes(Map<String, String> inputParams) {

		StringBuilder sql = new StringBuilder();
		sql.append(
				"INSERT INTO FD_DOC_NOTE(IS_CONFIDENTIAL, COMMENTS, CREATED_TIMESTAMP, CREATED_BY,OBJECT_ID,FORM_ID) VALUES(?,?,?,?,?,?)");
		int count = jdbcTemplate.update(sql.toString(),
				new Object[] { inputParams.get("IS_CONFIDENTIAL"), inputParams.get("COMMENTS"),
						inputParams.get("CREATED_TIMESTAMP"), inputParams.get("CREATED_BY"),
						inputParams.get(OBJECT_ID), inputParams.get(FORM_ID) });
		return count > 0;
	}

	@Override
	public List<Map<String, Object>> getCObjectIdListDocCtrl() {

		StringBuilder sql = new StringBuilder(GET_C_OBJECTID_DOC_CTRL_SQL);
		List<Map<String, Object>> cObjectIdList = jdbcTemplate.queryForList(sql.toString());

		return cObjectIdList;
	}

	@Override
	public List<Map<String, Object>> getExObjNameInfoDocLink(String cObjectId) {

		StringBuilder sql = new StringBuilder(GET_EXOBJNAMEINFO_DOC_LINK_SQL);
		List<Map<String, Object>> exObjNameInfoList = jdbcTemplate.queryForList(sql.toString(), new Object[] { cObjectId });

		return exObjNameInfoList;
	}

	@Override
	public Map<String, Object> getDocIdDOCUEMNTS(String cObjectId) {
		Map<String, Object> docIdMap = null;
		StringBuilder sql = new StringBuilder(GET_DOCID_DOCUMENTS_SQL);
		docIdMap = jdbcTemplate.queryForMap(sql.toString(), new Object[] { cObjectId });

		return docIdMap;
	}

	@Override
	public boolean updateDocAttrObjectId(String eObjectId, String cObjectId) {
		StringBuilder sql = new StringBuilder(UPDATE_OBJECTID_ATTR_SQL);
		int count = jdbcTemplate.update(sql.toString(), new Object[] { eObjectId, cObjectId });
		return count >= 0;
	}

	@Override
	public boolean updateDocLinkObjectId(String sLogicalLinkId, int linkStatus, String lastUpdateBy, BigDecimal sRowId,String lastUpdateTime){
		StringBuilder sql = new StringBuilder(UPDATE_OBJECTID_LINK_SQL);
		int count = jdbcTemplate.update(sql.toString(), new Object[] {sLogicalLinkId, linkStatus, lastUpdateBy, sRowId, lastUpdateTime});

		return count > 0;
	}

	@Override
	public boolean updateDocLinkObjectIdEx(String eObjectId, String cObjectId) {
		StringBuilder sql = new StringBuilder(UPDATE_OBJECTID_DOCLINK_SQL);
		int count = jdbcTemplate.update(sql.toString(), new Object[] { eObjectId, cObjectId });
		return count > 0;
	}
	
	@Override
	public boolean updateDocLinkStatusObjectIdEx(int linkStatus, String lastUpdateBy, BigDecimal sRowId,
			String lastUpdateTime) {
		StringBuilder sql = new StringBuilder(UPDATE_OBJECTID_DOCLINKSTATUS_SQL);
		int count = jdbcTemplate.update(sql.toString(), new Object[] {linkStatus, lastUpdateBy, sRowId, lastUpdateTime});
		return count > 0;
	}
	
	@Override
	public boolean updateFailedDocLinkStatusObjectIdEx(int linkStatus, String objectId) {
		StringBuilder sql = new StringBuilder(UPDATE_OBJECTID_FAILED_DOCLINKSTATUS_SQL);
		int count = jdbcTemplate.update(sql.toString(), new Object[] {linkStatus, objectId});
		return count > 0;
	}
	@Override
	public boolean updateDocumentsObjectId(String eObjectId, String cObjectId) {
		StringBuilder sql = new StringBuilder(UPDATE_OBJECTID_DOCUMENTS_SQL);
		int count = jdbcTemplate.update(sql.toString(), new Object[] { eObjectId, cObjectId });
		return count >= 0;
	}

	@Override
	public boolean updateDocCtrlObjectIdStatus(String eObjectId, String eObjectName, String migStatus,
			String cObjectId) {
		StringBuilder sql = new StringBuilder(UPDATE_OBJECTID_DOCCTRL_SQL);
		int count = jdbcTemplate.update(sql.toString(), new Object[] { eObjectId, eObjectName, migStatus, cObjectId });
		return count >= 0;
	}

	@Override
	public boolean updateAuditTrailFromObjectId(String eObjectId, String cObjectId) {
		StringBuilder sql = new StringBuilder(UPDATE_FROM_OBJECTID_DOCAUDIT_SQL);
		int count = jdbcTemplate.update(sql.toString(), new Object[] { eObjectId, cObjectId });
		return count >= 0;
	}

	@Override
	public boolean updateAuditTrailToObjectId(String eObjectId, String cObjectId) {
		StringBuilder sql = new StringBuilder(UPDATE_TO_OBJECTID_DOCAUDIT_SQL);
		int count = jdbcTemplate.update(sql.toString(), new Object[] { eObjectId, cObjectId });
		return count >= 0;
	}


	@Override
	public List<Map<String, Object>> getCase360ObjectIdVoidPageFromAuditTrail(BigDecimal rowId) {
			
			StringBuilder sql = new StringBuilder(GET_CASE360_OBJECTID_PAGE_VOID_AUDIT_TRAIL_SQL);
			List<Map<String,Object>> objectIdList = jdbcTemplate.queryForList(sql.toString(),new Object[]{rowId});
			
			return objectIdList;
		}
	
		@Override
		public Map<String, Object> getCase360InfoPageIndFromFSDocument(String ObjectId) {
			
			Map<String,Object> case360Info = null;
			
			StringBuilder sql = new StringBuilder(GET_CASE360_INFO_VOID_PAGE_FS_DOCUMENT_SQL);
			case360Info = jdbcTemplate.queryForMap(sql.toString(),new Object[]{ObjectId});
			
			return case360Info;
		}

		@Override
		public Map<String, Object> getLatestRowIdFromConfig(String configName) {
			
			Map<String,Object> configValue = null;
			
			StringBuilder sql = new StringBuilder(GET_MAX_ROWID_FROM_CONFIG_SQL);
			configValue = jdbcTemplate.queryForMap(sql.toString(),new Object[]{configName});
			
			return configValue;
		}
		
		@Override
		public boolean updateLatestRowIdInConfig(String configName, BigDecimal rowId) {
			
			StringBuilder sql = new StringBuilder(UPDATE_TO_MAX_ROWID_SQL);
			int count = jdbcTemplate.update(sql.toString(),
					new Object[] {rowId,configName});
			return count > 0;
		}
		
		@Override
		public Map<String, Object> getMaxRowIdForVoidPageFromAuditTrail(BigDecimal rowId) {
			
			Map<String,Object> configValue = null;
			
			StringBuilder sql = new StringBuilder(GET_MAX_ROWID_VOID_PAGE_FROM_AUDIT_TRAIL_SQL);
			configValue = jdbcTemplate.queryForMap(sql.toString(), new Object[]{rowId});
			
			return configValue;
		}


		@Override
		public List<Map<String, Object>> getDocObjectIDListFromDocLink() {
			
			StringBuilder sql = new StringBuilder(GET_DOC_OBJECTID_LIST_FROM_DOC_LINK_SQL);
			List<Map<String,Object>> objectIdInfoList = jdbcTemplate.queryForList(sql.toString());
			
			return objectIdInfoList;
		}
		
		@Override
		public List<Map<String, Object>> getDocInfoFromDocLink(String ObjectId) {
			
			StringBuilder sql = new StringBuilder(GET_DOCINFO_FROM_DOC_LINK_SQL);
			List<Map<String,Object>> docInfoList = jdbcTemplate.queryForList(sql.toString(),new Object[]{ObjectId,ObjectId});
			
			return docInfoList;
		}

	
		
}
