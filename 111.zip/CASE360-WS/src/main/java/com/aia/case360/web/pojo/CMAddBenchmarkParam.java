package com.aia.case360.web.pojo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CMAddBenchmarkParam {
  
  @JsonProperty("BENCHMARK_NAME")
  private String benchmarkName;
  
  @JsonProperty("COMPANY_NO")
  private String companyNo;
  
  @JsonProperty("DEPARTMENT")
  private String department;
  
  @JsonProperty("STATUS")
  private Integer cmStatus;
  
  @JsonProperty("BENCHMARK_VOLUME")
  private Integer benchmarkVolume;
  
  @JsonProperty("VOLUME_RANGE_BOTTOM")
  private Integer volumeRangeBottom;
  
  @JsonProperty("VOLUME_RANGE_TOP")
  private Integer volumeRangeTop;
  
  @JsonProperty("CM_NOTE_TYPE")
  private Integer cmNoteType;
  
  @JsonProperty("USER_ID")
  private String userId;
  
  @JsonProperty("REQ_TYPES")
  private String reqTypes;
  
  @JsonProperty("RECEIVERS")
  private String receivers;
  
  @JsonProperty("FORM_IDS")
  private String formIds;
  
  /**
   * 0:request type;1:form id
   */
  private Integer cmType;

  /**
   * @return the benchmarkName
   */
  public String getBenchmarkName() {
    return benchmarkName;
  }

  /**
   * @return the companyNo
   */
  public String getCompanyNo() {
    return companyNo;
  }

  /**
   * @return the department
   */
  public String getDepartment() {
    return department;
  }

  /**
   * @return the cmStatus
   */
  public Integer getCmStatus() {
    return cmStatus;
  }

  /**
   * @return the benchmarkVolume
   */
  public Integer getBenchmarkVolume() {
    return benchmarkVolume;
  }

  /**
   * @return the volumeRangeBottom
   */
  public Integer getVolumeRangeBottom() {
    return volumeRangeBottom;
  }

  /**
   * @return the volumeRangeTop
   */
  public Integer getVolumeRangeTop() {
    return volumeRangeTop;
  }

  /**
   * @return the cmNoteType
   */
  public Integer getCmNoteType() {
    return cmNoteType;
  }

  /**
   * @return the userId
   */
  public String getUserId() {
    return userId;
  }

  /**
   * @return the reqTypes
   */
  public String getReqTypes() {
    return reqTypes;
  }

  /**
   * @return the receivers
   */
  public String getReceivers() {
    return receivers;
  }

  /**
   * @param benchmarkName the benchmarkName to set
   */
  public void setBenchmarkName(String benchmarkName) {
    this.benchmarkName = benchmarkName;
  }

  /**
   * @param companyNo the companyNo to set
   */
  public void setCompanyNo(String companyNo) {
    this.companyNo = companyNo;
  }

  /**
   * @param department the department to set
   */
  public void setDepartment(String department) {
    this.department = department;
  }

  /**
   * @param cmStatus the cmStatus to set
   */
  public void setCmStatus(Integer cmStatus) {
    this.cmStatus = cmStatus;
  }

  /**
   * @param benchmarkVolume the benchmarkVolume to set
   */
  public void setBenchmarkVolume(Integer benchmarkVolume) {
    this.benchmarkVolume = benchmarkVolume;
  }

  /**
   * @param volumeRangeBottom the volumeRangeBottom to set
   */
  public void setVolumeRangeBottom(Integer volumeRangeBottom) {
    this.volumeRangeBottom = volumeRangeBottom;
  }

  /**
   * @param volumeRangeTop the volumeRangeTop to set
   */
  public void setVolumeRangeTop(Integer volumeRangeTop) {
    this.volumeRangeTop = volumeRangeTop;
  }

  /**
   * @param cmNoteType the cmNoteType to set
   */
  public void setCmNoteType(Integer cmNoteType) {
    this.cmNoteType = cmNoteType;
  }

  /**
   * @param userId the userId to set
   */
  public void setUserId(String userId) {
    this.userId = userId;
  }

  /**
   * @param reqTypes the reqTypes to set
   */
  public void setReqTypes(String reqTypes) {
    this.reqTypes = reqTypes;
  }

  /**
   * @param receivers the receivers to set
   */
  public void setReceivers(String receivers) {
    this.receivers = receivers;
  }

  /**
   * @return the formIds
   */
  public String getFormIds() {
    return formIds;
  }

  /**
   * @return the cmType
   */
  public Integer getCmType() {
    return cmType==null?0:cmType;
  }

  /**
   * @param formIds the formIds to set
   */
  public void setFormIds(String formIds) {
    this.formIds = formIds;
  }

  /**
   * @param cmType the cmType to set
   */
  public void setCmType(Integer cmType) {
    this.cmType = cmType;
  }

  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "CMAddBenchmarkParam [benchmarkName=" + benchmarkName + ", companyNo=" + companyNo
        + ", department=" + department + ", cmStatus=" + cmStatus + ", benchmarkVolume="
        + benchmarkVolume + ", volumeRangeBottom=" + volumeRangeBottom + ", volumeRangeTop="
        + volumeRangeTop + ", cmNoteType=" + cmNoteType + ", userId=" + userId + ", reqTypes="
        + reqTypes + ", receivers=" + receivers + ", formIds=" + formIds + ", cmType=" + cmType
        + "]";
  }
}
