package com.aia.case360.web.pojo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CMSearchReceiverParam {

  @JsonProperty("USER_ID")
  private String userId;

  /**
   * @return the userId
   */
  public String getUserId() {
    return userId;
  }

  /**
   * @param userId the userId to set
   */
  public void setUserId(String userId) {
    this.userId = userId;
  }

  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "CMSearchReceiverParam [userId=" + userId + "]";
  }
}
