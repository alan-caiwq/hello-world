package com.aia.case360.ilClaim.service;

import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public interface DecisionService {

	public List<Map<String, String>> getTrainerDecision(String claimNos, Map<String, String> params)  throws SQLException;

	public List<Map<String, String>> getTLDecision(String claimNos, Map<String, String> params)  throws SQLException;

	public List<Map<String, String>> getQualifiedDecision(String claimNos, Map<String, String> params)  throws SQLException;

}
