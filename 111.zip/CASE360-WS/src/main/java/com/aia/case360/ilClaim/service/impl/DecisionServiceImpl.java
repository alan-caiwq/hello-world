package com.aia.case360.ilClaim.service.impl;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.aia.case360.ilClaim.dao.DecisionBean;
import com.aia.case360.ilClaim.service.DecisionService;

/**
 * claim decision approval
 * 
 * @author bsnpc0y
 *
 */
@Service
public class DecisionServiceImpl implements DecisionService {

	private DecisionBean decisionDao = new DecisionBean();

	/**
	 * Trainer Trainee Approval
	 * @throws SQLException 
	 */
	@Override
	public List<Map<String, String>> getTrainerDecision(String claimNos, Map<String, String> params)  throws SQLException {

		List<Map<String, String>> result = null;
		String childClaimNos = "";
		if (null != claimNos && claimNos.length() > 0) {

			childClaimNos = claimNos.replaceAll(",", "','");
			params.put("childClaimNo", "'" + childClaimNos + "'");

			return decisionDao.getClaimDecision(params);
		} else {
			return result;
		}
	}

	/**
	 * TL Approval
	 * @throws SQLException 
	 */
	@Override
	public List<Map<String, String>> getTLDecision(String claimNos, Map<String, String> params)  throws SQLException {

		return getTrainerDecision(claimNos,params);
	}

	/**
	 * Qualified Approval
	 * @throws SQLException 
	 */
	@Override
	public List<Map<String, String>> getQualifiedDecision(String claimNos, Map<String, String> params) throws SQLException
			  {

		return getTrainerDecision(claimNos,params);
	}

}
