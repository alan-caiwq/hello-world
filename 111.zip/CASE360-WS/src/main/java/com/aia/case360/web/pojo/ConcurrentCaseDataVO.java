package com.aia.case360.web.pojo;

public class ConcurrentCaseDataVO {

	private String sRowId;

	private String ruleName;

	private String reqType;

	private String activityName;

	private String department;

	private String parentId;

	private String activityDisplayName;

	private String reqTypeCategory;

	private String reqTypeCategoryNM;

	private String reqTypeName;

	public String getsRowId() {
		return sRowId;
	}

	public void setsRowId(String sRowId) {
		this.sRowId = sRowId;
	}

	public String getRuleName() {
		return ruleName;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	public String getReqType() {
		return reqType;
	}

	public void setReqType(String reqType) {
		this.reqType = reqType;
	}

	public String getActivityName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

	public String getActivityDisplayName() {
		return activityDisplayName;
	}

	public void setActivityDisplayName(String activityDisplayName) {
		this.activityDisplayName = activityDisplayName;
	}

	public String getReqTypeCategory() {
		return reqTypeCategory;
	}

	public void setReqTypeCategory(String reqTypeCategory) {
		this.reqTypeCategory = reqTypeCategory;
	}

	public String getReqTypeCategoryNM() {
		return reqTypeCategoryNM;
	}

	public void setReqTypeCategoryNM(String reqTypeCategoryNM) {
		this.reqTypeCategoryNM = reqTypeCategoryNM;
	}

	public String getReqTypeName() {
		return reqTypeName;
	}

	public void setReqTypeName(String reqTypeName) {
		this.reqTypeName = reqTypeName;
	}

}
