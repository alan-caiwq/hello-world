package com.aia.case360.JalDocsInterfacesEx.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.CallableStatementCallback;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.aia.case360.JalDocsInterfacesEx.dao.JalDocDao;
import com.aia.case360.JalDocsInterfacesEx.vo.InputParamVo;
import com.aia.case360.JalDocsInterfacesEx.vo.PolNumReqs;
import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.common.PropertyUtil;

@Repository
public class JalDocDaoImpl implements JalDocDao {

	@Autowired
	private JdbcTemplate locatorJdbcTemplate;

	@Autowired
	private JdbcTemplate dbiwJdbcTemplate;

	private Logger m_Logger = LoggerFactory.getLogger(getClass());

	private String eCodeLookupSql = PropertyUtil.getCommonProperty("E_CODE_LOOKUP_SQL");
	private String eLogicalLinkSql = PropertyUtil.getCommonProperty("E_LOGICAL_LINK_SQL");
	// add by wanjun

	private static final String UPDATE_EX360_TLOGIC_LINK_SQL = PropertyUtil.getCommonProperty("UPDATE_EX360_TLOGIC_LINK_SQL");
	private static final String INSERT_EX360_LOGICALLINK_SQL = PropertyUtil.getCommonProperty("INSERT_EX360_LOGICALLINK_SQL");
	private static final String CHECK_C360_LOGICALLINK_EXIST_SQL = PropertyUtil.getCommonProperty("CHECK_C360_LOGICALLINK_EXIST_SQL");


	@Override
	public List<Map<String, Object>> getCodeLookup(String codeClass) throws DataAccessException {
		LogUtil.logInfo(m_Logger,"ImportDocDaoImpl: getCodeLookup sql======="+ eCodeLookupSql);
		List<Map<String, Object>> codeLookupList = new ArrayList<Map<String, Object>>();
		try {
			codeLookupList = dbiwJdbcTemplate.queryForList(eCodeLookupSql, new Object[] { codeClass });

		} catch (DataAccessException e) {
			LogUtil.logError(m_Logger, e.getMessage());
			throw e;
		}

		return codeLookupList;
	}

	@Override
	public String createLogicalLink(final String... logicalLinkParameters) throws DataAccessException {

		StringBuilder sb = new StringBuilder();
		final String action = logicalLinkParameters[0];
		final String linkId = logicalLinkParameters[1];
		final String parentId = logicalLinkParameters[2];
		final String companyNo = logicalLinkParameters[3];
		final String policyNo = logicalLinkParameters[4];
		final String requestNo = logicalLinkParameters[5];
		final String formId = logicalLinkParameters[6];
		final String processType = logicalLinkParameters[7];
		final String status = logicalLinkParameters[8];
		final String receivedDate = logicalLinkParameters[9];
		
		
		sb.append(action).append(", linkId=").append(linkId).append(", parentId=").append(parentId)
				.append(", companyNo=").append(companyNo).append(", policyNo=").append(policyNo).append(", requestNo=")
				.append(requestNo).append(", formId=").append(formId).append(", processType=").append(processType)
				.append(", status=").append(status).append(", receivedDate=").append(receivedDate);
		LogUtil.logInfo(m_Logger," procLogicalLink action="+ sb);
		LogUtil.logInfo(m_Logger,"ImportDocDaoImpl: procLogicalLink eLogicalLinkSql======="+ eLogicalLinkSql);

		String newLinkId = (String) locatorJdbcTemplate.execute(

				new CallableStatementCreator() {
					public CallableStatement createCallableStatement(Connection con) throws SQLException {

						CallableStatement cstmt = con.prepareCall(eLogicalLinkSql); // NOSONAR
						cstmt.setString(1, action);
						cstmt.setString(2, linkId);
						cstmt.setString(3, parentId);
						cstmt.setString(4, companyNo);
						cstmt.setString(5, policyNo);
						cstmt.setString(6, requestNo);
						cstmt.setString(7, processType);
						cstmt.setString(8, formId);
						cstmt.setString(9, status);
						cstmt.setString(10, receivedDate);
						cstmt.setString(11, "");
						cstmt.registerOutParameter(12, Types.VARCHAR);
						return cstmt;
					}
				}, new CallableStatementCallback<Object>() {
					public Object doInCallableStatement(CallableStatement cs) throws SQLException, DataAccessException {
						int result = 0;
						String strLinkId = "";
						result = cs.executeUpdate();
						if (result > 0) {
							strLinkId = cs.getString(12);
						}

						return strLinkId;
					}
				});

		return newLinkId;

	}

	@Override
	public boolean updateEx360infoByLinkId(PolNumReqs polNumReq, String receivedDate, String status) {
		StringBuilder sql = new StringBuilder(UPDATE_EX360_TLOGIC_LINK_SQL);
		int count = locatorJdbcTemplate.update(sql.toString(),
				new Object[] { polNumReq.getPolNum(), polNumReq.getRequestNo(), polNumReq.getFormId(),

				polNumReq.getProcessType(), status, receivedDate, polNumReq.getLogicalLinkId() });
		return count > 0;
	}

	@Override
	public boolean insertExLogicalLink(InputParamVo params, PolNumReqs polNumReq, String receivedDate, String status) {
		StringBuilder sql = new StringBuilder(INSERT_EX360_LOGICALLINK_SQL);
		int count = locatorJdbcTemplate.update(sql.toString(),
				new Object[] { polNumReq.getLogicalLinkId(), params.getCaseObjectId(), polNumReq.getCompany(),
						polNumReq.getPolNum(), polNumReq.getRequestNo(), polNumReq.getFormId(),
						polNumReq.getProcessType(), status, receivedDate, params.getLinkIndicator(), new Date() });
		return count > 0;
	}

	@Override
	public Map<String, Object> checkE360LogicalLinkByLinkId(String linkId) {
		StringBuilder sql = new StringBuilder(CHECK_C360_LOGICALLINK_EXIST_SQL);
		Map<String, Object> ex360Count = null;
		ex360Count = locatorJdbcTemplate.queryForMap(sql.toString(), new Object[] { linkId });

		return ex360Count;

	}
}
