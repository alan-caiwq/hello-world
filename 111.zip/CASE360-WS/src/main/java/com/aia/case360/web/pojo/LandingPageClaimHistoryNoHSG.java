package com.aia.case360.web.pojo;

public class LandingPageClaimHistoryNoHSG {

	private String claim;
	private String childClm;
	private String policy;
	private String claimType;
	private String eventDate;
	private String diagnosisDate;
	private String causeCategoryAndDescription;
	private String incurredAmnPerChildClm;
	private String totalPayableAmntPerChildClm;
	private String compCode;
	private String compName;
	private String decision1;
	private String decision2;
	private String decisionReasonCodeAndDescription;
	private String paidIndicator;
	private String assessorID;
	private String claimComment;

	public String getClaim() {
		return claim;
	}

	public void setClaim(String claim) {
		this.claim = claim;
	}

	public String getChildClm() {
		return childClm;
	}

	public void setChildClm(String childClm) {
		this.childClm = childClm;
	}

	public String getPolicy() {
		return policy;
	}

	public void setPolicy(String policy) {
		this.policy = policy;
	}

	public String getClaimType() {
		return claimType;
	}

	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}

	public String getEventDate() {
		return eventDate;
	}

	public void setEventDate(String eventDate) {
		this.eventDate = eventDate;
	}

	public String getDiagnosisDate() {
		return diagnosisDate;
	}

	public void setDiagnosisDate(String diagnosisDate) {
		this.diagnosisDate = diagnosisDate;
	}

	public String getCauseCategoryAndDescription() {
		return causeCategoryAndDescription;
	}

	public void setCauseCategoryAndDescription(String causeCategoryAndDescription) {
		this.causeCategoryAndDescription = causeCategoryAndDescription;
	}

	public String getIncurredAmnPerChildClm() {
		return incurredAmnPerChildClm;
	}

	public void setIncurredAmnPerChildClm(String incurredAmnPerChildClm) {
		this.incurredAmnPerChildClm = incurredAmnPerChildClm;
	}

	public String getTotalPayableAmntPerChildClm() {
		return totalPayableAmntPerChildClm;
	}

	public void setTotalPayableAmntPerChildClm(String totalPayableAmntPerChildClm) {
		this.totalPayableAmntPerChildClm = totalPayableAmntPerChildClm;
	}

	public String getCompCode() {
		return compCode;
	}

	public void setCompCode(String compCode) {
		this.compCode = compCode;
	}

	public String getCompName() {
		return compName;
	}

	public void setCompName(String compName) {
		this.compName = compName;
	}

	public String getDecision1() {
		return decision1;
	}

	public void setDecision1(String decision1) {
		this.decision1 = decision1;
	}

	public String getDecision2() {
		return decision2;
	}

	public void setDecision2(String decision2) {
		this.decision2 = decision2;
	}

	public String getDecisionReasonCodeAndDescription() {
		return decisionReasonCodeAndDescription;
	}

	public void setDecisionReasonCodeAndDescription(String decisionReasonCodeAndDescription) {
		this.decisionReasonCodeAndDescription = decisionReasonCodeAndDescription;
	}

	public String getPaidIndicator() {
		return paidIndicator;
	}

	public void setPaidIndicator(String paidIndicator) {
		this.paidIndicator = paidIndicator;
	}

	public String getAssessorID() {
		return assessorID;
	}

	public void setAssessorID(String assessorID) {
		this.assessorID = assessorID;
	}

	public String getClaimComment() {
		return claimComment;
	}

	public void setClaimComment(String claimComment) {
		this.claimComment = claimComment;
	}

}
