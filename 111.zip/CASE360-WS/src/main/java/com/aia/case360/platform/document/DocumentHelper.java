package com.aia.case360.platform.document;

import java.io.IOException;
import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.FinderException;
import javax.ejb.RemoveException;

import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;

import com.aia.case360.web.vo.ExportDocInfoParam;
import com.aia.case360.web.vo.FileResult;
import com.eistream.sonora.filestore.FSVersionElement;
import com.eistream.sonora.filestore.FileStoreElement;
import com.eistream.utilities.UtilityException;
import com.itextpdf.text.DocumentException;

public interface DocumentHelper {

	/**
	 * upload document and attach to the caesfolder and update infomation
	 * 
	 * @param caseId
	 * @param request
	 * @return true is upload success false is upload faild
	 * @throws RemoteException
	 */

	public List<BigDecimal> uploadDoc(String caseId, String formId, List<String> filePaths,
			Map<String, String> docFields, List<String> chgIds) throws RemoteException;

	/**
	 * upload document and return document`s physicalLocation
	 * 
	 * @param request
	 * @return
	 * @throws RemoteException
	 */

	/**
	 * document remove attach to the casefolderId
	 * 
	 * @param caseId
	 * @param docId
	 * @return true is success false is faild
	 * @throws RemoteException
	 */
	public String reIndexDoc(String caseId, String docId) throws RemoteException;

	/**
	 * document remove attach to the casefolderId
	 * 
	 * @param caseId
	 * @param docId
	 * @return true is success false is faild
	 * @throws RemoteException
	 */
	public String reIndexDoc(String caseId, List<String> formIds) throws RemoteException;

	/**
	 * download documents that documents will merge to a zip.
	 * 
	 * @param docIds
	 * @return zipDoc path on server
	 * @throws RemoteException
	 */
	public String downloadDocs(List<String> docIds) throws RemoteException;

	/**
	 * download documents that documents will merge to a zip with encrypt.
	 * String pages,String password, String rootPath, String nric
	 * @param docIds
	 * @param isExportPage
	 * @param pages
	 * @param isZip
	 * @param password
	 * @param rootPath
	 * @param nric
	 * @return FileResult
	 * @throws RemoteException
	 */
	public FileResult exportDocs(List<ExportDocInfoParam> docIds, boolean isExportPage,  boolean isZip,
			boolean isEncrypt, String...exportDocParameters) throws IOException, DocumentException;

	/**
	 * get the username of the document creator
	 * 
	 * @param docId
	 * @return
	 * @throws RemoteException
	 */
	public String getUserIdByDocId(String docId) throws RemoteException;

	/**
	 * get document creation time
	 * 
	 * @param docId
	 * @return
	 * @throws RemoteException
	 */
	public Timestamp getDocCreateDate(String docId) throws RemoteException;

	/**
	 * Get the latest version of document creation
	 * 
	 * @param docId
	 * @return
	 * @throws RemoteException
	 */
	public String getDocLatestVersion(String docId) throws RemoteException;

	/**
	 * Get document CaseId by docId
	 * 
	 * @param docId
	 * @return
	 * @throws RemoteException
	 */
	public List<Map<String, Object>> getCaseIdByDocId(String docId) throws RemoteException;

	/**
	 * Get docId by Indexing workitem repository key
	 * 
	 * @return dcoument id
	 * @throws RemoteException
	 */
	public String getDocIdByIndex(String rpKeyStr) throws RemoteException;

	/**
	 * Delete document
	 * 
	 * @param docId
	 * @return true is successed false is faild
	 * @throws RemoteException
	 */
	public boolean deleteDoc(String docId) throws RemoteException;

	/**
	 * delete a document only mark it as deleted
	 * 
	 * @param docId
	 * @return true is successed false is faild
	 * @throws RemoteException
	 */
	public boolean setLogicalDeletionFlag(String docId) throws RemoteException;

	/**
	 * Update Indexing delete Sign It means update WFTIMEOUTTIME and WFFLOWEXITTIME
	 * of PI_INDEXING. effect : Put them from null to current time.
	 * 
	 * @return true is successed false is faild
	 * @throws RemoteException
	 */
	public boolean deleteIndexWorkitem(String rpKeyStr) throws RemoteException;

	/**
	 * Delete Indexing
	 * 
	 * @param deleteType 0: Physics delete 1: Logic delete
	 * @return true is successed false is faild
	 * @throws RemoteException
	 */
	public boolean deleteIndex(int deleteType, String rpKeyStr) throws RemoteException;

	/**
	 * query Indexing Type
	 * 
	 * @param queryType 0: 1: Own Indexing 2: Locked Indexing 3: valid Indexing 4:
	 *                  invalid Indexing
	 * @return
	 * @throws RemoteException
	 */
	public int getIndexItemCount(int queryType) throws RemoteException;

	/**
	 * search document some information
	 * 
	 * @param queryParams
	 * @return document information
	 * @throws RemoteException
	 */
	public ArrayList<Map<String, Object>> doSearch(Map<String, String> queryParams) throws RemoteException;

	/**
	 * Get the list version of document
	 * 
	 * @param docId
	 * @return result include version,userId,timeStamp
	 * @throws RemoteException
	 */
	public List<Map<String, Object>> getDocVersionList(String docId) throws RemoteException;

	/**
	 * Mark the unknown document as 'Invalid';
	 * 
	 * @return true is successed false is faild
	 * @throws RemoteException
	 */
	public boolean invalidDoc(String rpKeyStr) throws RemoteException;

	/**
	 * Link the unknown document to an existing workitem;
	 * 
	 * @param docId
	 * 
	 * @return true is successed false is faild
	 * @throws RemoteException
	 */
	public boolean linkDocToWorkFolder(String caseId, String docId, String rpKeyStr) throws RemoteException;

	/**
	 * Create a new workitem and link the unknown document to it;
	 * 
	 * @param docId
	 * 
	 * @return
	 * @throws RemoteException
	 */
	public boolean linkDocToNewWorkItem(String docId, String displayName, Map<String, String> parameters,
			String rpKeyStr) throws RemoteException;

	/**
	 * add document version and not create new docId
	 * 
	 * @param request : can get file from it
	 * @param docId   : that will add version on it
	 * @return return new version`s viewURL
	 * @throws RemoteException
	 */
	public String addDocVersion(String filePath, String docId) throws RemoteException;

	/**
	 * This method will split an existing TIFF Document into 2 separated TIFF
	 * Document,and new TIFF will into Indexing.
	 * 
	 * @param docId    the existing TIFF Document ID
	 * @param pageNums indicates which pages will be moved into a new TIFF Document
	 * @return
	 * @throws RemoteException
	 */
	public String splitTIFFDoc(String docId, int[] pageNums) throws RemoteException;

	/**
	 * This method will set File Store custom fields values
	 * 
	 * @param docId
	 * @param fieldProperties
	 * @return
	 * @throws RemoteException
	 */
	boolean setFSFields(String docId, Map<String, String> fieldProperties) throws RemoteException;

	/**
	 * This method will return document information by documentid
	 * 
	 * @param docId
	 * @return
	 * @throws RemoteException
	 */
	public List<Map<String, String>> getDocumentInfo(String docId) throws RemoteException;

	public void clearVoidPages() throws RemoteException;

	public boolean indexDocIdToCaseId(String caseId, BigDecimal docId) throws RemoteException;

	public boolean indexDocIdToChgId(String chgId, BigDecimal docId) throws RemoteException;

	public List<BigDecimal> saveDoc(List<String> filePaths) throws RemoteException, SQLException;

	public List<BigDecimal> saveSigFS(List<String> filePaths) throws RemoteException, SQLException;

	public List<BigDecimal> saveDocOnOWS(List<String> filePaths) throws RemoteException, SQLException;

	public byte[] getPageInJpeg(String docId, int page)
			throws RemoteException, FinderException, UtilityException, IOException;

	public int getTotalPageNum(String docId) throws RemoteException, FinderException, UtilityException;

	public HashMap<String, String> saveSignature(String docId, int page, int x, int y, int width, int height,
			boolean rel_position) throws RemoteException, FinderException, UtilityException, IOException;

	public boolean updateFileStoryFields(Map<String, String> fields, BigDecimal docId) throws RemoteException;

	public List<BigDecimal> uploadDoc(List<String> filePaths, Map<String, String> docFields) throws RemoteException;

	public List<BigDecimal> uploadDoc(List<String> filePaths, List<Map<String, String>> docFieldsList)
			throws RemoteException;

	public List<BigDecimal> uploadDocOnOWS(List<String> filePaths, List<Map<String, String>> docFields)
			throws RemoteException;

	public void remove(BigDecimal tableId, BigDecimal S_ROWID) throws RemoteException, RemoveException, FinderException;

	/**
	 * Get PDF fullPath
	 * 
	 * @param objId
	 * @return String
	 * @author bsnpc1w 2017.9.25
	 * @throws FinderException
	 */
	public String getFullPath(String docId) throws IOException, DocumentException, FinderException;

	public FileStoreElement getElement(BigDecimal documentId, Boolean flag) throws RemoteException, FinderException;

	public List<FSVersionElement> getDocumentElements(BigDecimal documentId, Boolean flag)
			throws RemoteException, FinderException;

	public void getFile(BigDecimal documentId, Integer currentVersion, String targetFileName)
			throws RemoteException, FinderException;

	public String generateObjectId(BigDecimal id, Integer digits) throws RemoteException;

	// added by Leo Li
	/**
	 * @param tableId
	 * @param templateId
	 * @param contents
	 * @param doucumentName
	 * @param params
	 * @return
	 * @throws RemoteException
	 * @author bsnpc37
	 * @date: 2018-3-30 14:13:56
	 */
	BigDecimal creatFileStoreFromByte(BigDecimal tableId, BigDecimal templateId, byte[] contents, String doucumentName,
			Map<String, String> params) throws RemoteException;

	/**
	 * 
	 * @param documentID
	 * @param contents
	 * @param doucumentName
	 * @throws RemoteException
	 * @author bsnpc37
	 * @date: 2018-3-30- 14:14:26
	 */
	void creatFileStoreFromByte(BigDecimal documentID, byte[] contents, String doucumentName) throws RemoteException;

	/**
	 * 
	 * @param documentId
	 * @return
	 * @ throws RemoteException
	 * @author bsnpc37
	 * @date: 2018-3-30 14:14:44
	 */
	String getFile(BigDecimal documentId)  throws RemoteException;
	// end

	/**
	 * 
	 * @param documentId
	 * @return
	 * @ throws RemoteException
	 * @author bsnpc37
	 * @throws IOException 
	 * @throws DocumentException 
	 * @throws FinderException 
	 * @date: 2018-3-30 14:14:44
	 */
	Map<String, String> getFile(BigDecimal documentId, String callingSystem)  throws RemoteException, IOException, DocumentException, FinderException;

	/**
	 * 
	 * @param documentId
	 * @param callingSystem
	 * @return
	 * @ throws RemoteException
	 * @author bsnpc37(Leo Li)
	 * @throws FinderException 
	 * @throws IOException 
	 * @throws InvalidPasswordException 
	 * @date: Aug 6, 2018 9:58:01 AM
	 */
	Map<String, String> getFilePdf(BigDecimal documentId, Boolean isWaterFlag, String callingSystem)  throws RemoteException, FinderException, InvalidPasswordException, IOException;
	// end

	/**
	 * 
	 * @param documentId
	 * @return
	 * @ throws RemoteException
	 * @author bsnpcjy
	 * @date: 2018-7-19 17:14:00
	 */
	byte[] getFileByte(BigDecimal documentId)  throws RemoteException;
	// end
	String getFileName(ExportDocInfoParam exportDocInfoParam) throws RemoteException;
	
	public Map<String, String> getDocPool(String stats,boolean isUpdate) throws Exception;
}