package com.aia.case360.uam;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class RoleUtil {

	private RoleUtil() {}
	

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static Map mapCombine(List<Map> list) {
		Map<Object, List> map = new HashMap<Object, List>();
		for (Map m : list) {
			Iterator<Object> it = m.keySet().iterator();
			while (it.hasNext()) {
				Object key = it.next();
				if (!map.containsKey(key)) {
					List newList = new ArrayList<Object>();
					newList.add(m.get(key));
					map.put(key, newList);
				} else {
					map.get(key).add(m.get(key));
				}
			}
		}
		return map;
	}

}
