package com.aia.case360.uam.service;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

public interface UAMUserGroupService {
	// paging to show the role list
	public List<Map<String, Object>> searchUserGroup(Map<String, String> params)  throws RemoteException;

}
