package com.aia.case360.uam.domain;

import java.util.List;

/**
 * REQ_NAME is REQ_TYPE display name REQ_ID is REQ_TYPE
 * 
 * @author bsnpbdu
 *
 */
public class RequsetTypeInfo {

	private String REQ_NAME;

	private String REQ_ID;

	private List<ActivictyInfo> ACTIVITYS;

	public String getREQ_NAME() {
		return REQ_NAME;
	}

	public void setREQ_NAME(String rEQ_NAME) {
		REQ_NAME = rEQ_NAME;
	}

	public String getREQ_ID() {
		return REQ_ID;
	}

	public void setREQ_ID(String rEQ_ID) {
		REQ_ID = rEQ_ID;
	}

	public List<ActivictyInfo> getACTIVITYS() {
		return ACTIVITYS;
	}

	public void setACTIVITYS(List<ActivictyInfo> aCTIVITYS) {
		ACTIVITYS = aCTIVITYS;
	}

}
