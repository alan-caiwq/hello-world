package com.aia.case360.platform.casefolder;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import com.eistream.sonora.fields.FmsRow;

/**
 * A <code>CasefolderHelper</code> is the common helper class for the operations
 * on special Casefolder.
 *
 * @author bsnpbdu
 *
 */
public interface CasefolderHelper {

	/**
	 * update one specified casefolder's field with the value
	 * 
	 * @param caseIdText casefolder id text string
	 * @param fldName    the customer field name of the casefolder
	 * @param fldValue   the value for the customer filed of the casefolder
	 * @return true update field value successfully <br>
	 *         false update field value failed
	 */

	public boolean updateCasefolder(String caseIdText, String fldName, String fldValue) throws RemoteException;

	/**
	 * update one specified casefolder's a set of fields with corresponding values
	 * 
	 * @param caseIdStr casefolder id text string
	 * @param fldNames  the customer field names of the casefolder
	 * @param fldValues the values for the customer fileds of the casefolder
	 * @return true update fields value successfully <br>
	 *         false update fields value failed
	 * @throws RemoteException
	 */
	public boolean updateCasefolder(String caseIdStr, List<String> fldNames, List<String> fldValues)
			throws RemoteException;

	/**
	 * update casefolder's fields with the values
	 * 
	 * @param caseIdStr casefolder id text string
	 * @param params    the customer params of the casefolder
	 * @return true update field value successfully <br>
	 *         false update field value failed
	 */

	public boolean updateCasefolder(String caseIdStr, Map<String, String> params) throws RemoteException;

	/**
	 * Create a casefolder from XML definition
	 * 
	 * @param cfXml casefolder xml definition
	 * @throws RemoteException
	 */
	public void createCasefolderFromXml(String cfXml) throws RemoteException;

	/**
	 * get casefolder columns value for specific caseId, for KEY_GENERIC and
	 * LINKCASEID are hard-code, in order to workitem
	 * 
	 * @param caseId BigDecimal type as casefolder primary key
	 * @return Map which contains all customer fields value for casefolder
	 * @throws RemoteException
	 */
	public Map<String, Object> getCasefolderDetail(BigDecimal caseId) throws RemoteException;

	/**
	 * Create case folder
	 * 
	 * @param displayName
	 * @param parameters
	 * @throws RemoteException
	 */
	public BigDecimal createCaseFolder(String displayName, Map<String, String> parameters) throws RemoteException;

	public FmsRow getFmsRow(BigDecimal fmsRowID, Map<String, String> parameters) throws RemoteException;

	/**
	 * delete case folder
	 * 
	 * @param casefolderId
	 * @return
	 * @throws RemoteException
	 */
	public boolean deleteCaseFolder(BigDecimal casefolderId) throws RemoteException;

	/**
	 * get a casefolder XML String
	 * 
	 * @param caseid
	 * @return
	 * @throws RemoteException
	 */
	public String getCasefolderAsXml(BigDecimal caseid) throws RemoteException;

	/**
	 * create case By requestType
	 * 
	 * @param mainCaseId
	 * @param requestType
	 * @return new caseId
	 * @throws RemoteException
	 */
	public String createChildCase(String mainCaseId, String requestType) throws RemoteException;

	/**
	 * create case used data migration
	 * 
	 * @param displayName
	 * @param createAmount
	 * @return
	 * @throws RemoteException
	 */
	public String dataMigrationCreateMasterFolder(String displayName, String createAmount) throws RemoteException;

	public String cretaeWorkFolderByReqType(String mfCaseId, String requestType, String policyNum)
			throws RemoteException;

	public String generateReqNo(String lob, String isChild, String parentReqNo) throws RemoteException;

	public String generateDumyPolicy() throws RemoteException;

	public String checkPolicyFormat(String policyNum) throws RemoteException;

	public String getProStartActByReqType(String reqType) throws RemoteException;

	public String convertRequestNo(String requestNo) throws RemoteException;

}
