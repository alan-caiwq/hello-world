/**
 * 
 */
package com.aia.case360.web.pojo;

/**
 * @author bsnpc55
 *
 */
public class MDRTIndicatorMultiInfo {

	private String agentCode;
	private String dteEffective;
	private String description;

	public String getAgentCode() {
		return agentCode;
	}

	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}

	public String getDteEffective() {
		return dteEffective;
	}

	public void setDteEffective(String dteEffective) {
		this.dteEffective = dteEffective;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
