package com.aia.case360.web.pojo;

import java.util.Date;

public class FdReqTypeCategoryAuditTrail {
	private String acl;
	private String action_desc;
	private String category;
	private String req_type_category;
	private String created_by;
	private Date created_timestamp;

	public String getAcl() {
		return acl;
	}

	public void setAcl(String acl) {
		this.acl = acl;
	}

	public String getAction_desc() {
		return action_desc;
	}

	public void setAction_desc(String action_desc) {
		this.action_desc = action_desc;
	}

	public String getReq_type_category() {
		return req_type_category;
	}

	public void setReq_type_category(String req_type_category) {
		this.req_type_category = req_type_category;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public Date getCreated_timestamp() {
		return created_timestamp;
	}

	public void setCreated_timestamp(Date created_timestamp) {
		this.created_timestamp = created_timestamp;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	@Override
	public String toString() {
		return "FdReqTypeAuditTrail  acl=" + acl + ", action_desc=" + action_desc + ", req_type_category="
				+ req_type_category + ", category=" + category + " , created_by=" + created_by + ", created_timestamp="
				+ created_timestamp + "]";
	}

}
