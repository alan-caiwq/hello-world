package com.aia.case360.web.job;

import java.rmi.RemoteException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.aia.case360.mybatis.SqlSessionContentHolder;
import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.common.PropertyUtil;
import com.aia.case360.web.service.WebAPIinternalService;

import oracle.sql.OffsetDST;

/**
 * @Author: huiyun ma
 * @Create Date: 03/02/2018
 */

@Component
@Aspect
public class DynamicDataSourceAspect {

	protected Logger m_Logger = LoggerFactory.getLogger(getClass());
	
	private static final String SYBASE = "Sybase"; 
	private static final String EIMAGE = "EIMAGE"; 
	private static final String EXTIMAGE = "EXTIMAGE"; 

	private static final String ODSSchema=PropertyUtil.getCommonProperty("ODSSchema").trim();

	@Pointcut("execution( * com.aia.case360.web.dao.*.*(..))")
	public void pointCut() {
		// NOSONAR
	}

	@Autowired
	private WebAPIinternalService webAPIinternalService;

	@Before("pointCut()")
	public void before(JoinPoint jp) {
		String methodName = jp.getSignature().getName();
		beforeAssist(methodName);
		// add by bsnpc55 4 ods schema
		if (SqlSessionContentHolder.getContextType().equalsIgnoreCase(SqlSessionContentHolder.SESSION_FACTORY_ODS)) {
			Object[] o=jp.getArgs();
			Map<String, Object> param=(Map<String, Object>) jp.getArgs()[0];
			param.put("ODSSchema", ODSSchema);
			m_Logger.debug(param.toString());
		}
	}

  private void beforeAssist(String methodName) {
    if (methodName.endsWith("IL")) {
			SqlSessionContentHolder.setContextType(SqlSessionContentHolder.SESSION_FACTORY_IL);
		} else if (methodName.endsWith("Plas") || methodName.endsWith("Hias") || methodName.endsWith(SYBASE)) {
			SqlSessionContentHolder.setContextType(SqlSessionContentHolder.SESSION_FACTORY_PLASANDHIAS);
		} else if (methodName.endsWith("ODS")) {
			SqlSessionContentHolder.setContextType(SqlSessionContentHolder.SESSION_FACTORY_ODS);
		}else if (methodName.endsWith("Edoc")) {
			SqlSessionContentHolder.setContextType(SqlSessionContentHolder.SESSION_FACTORY_EDOC);
		} else if (methodName.endsWith("AMS")) {
			SqlSessionContentHolder.setContextType(SqlSessionContentHolder.SESSION_FACTORY_AMS);
		} else if (methodName.endsWith(EIMAGE)) {
			SqlSessionContentHolder.setContextType(SqlSessionContentHolder.SESSION_FACTORY_EIMAGE);
		} else if (methodName.endsWith(EXTIMAGE)) {
			SqlSessionContentHolder.setContextType(SqlSessionContentHolder.SESSION_FACTORY_EXTIMAGE);
		} else {
			SqlSessionContentHolder.setContextType(SqlSessionContentHolder.SESSION_FACTORY_SONORA);
		}
  }

//   @Around(value = "pointCut()")
	@Around("execution( * com.aia.case360.web.dao.*.*(..))")
	public Object LogJdbc(ProceedingJoinPoint jp) throws RemoteException {
		String name = jp.getSignature().getName();
		Long startTime = System.currentTimeMillis();
		m_Logger.info(name + " start time " + new Date(startTime));
		Object object;
		try {
			object = jp.proceed();
		} catch (Throwable e) {
			LogUtil.logError(m_Logger,new Exception(e));
			throw new RemoteException(e.getMessage(), e);
		}
		Long endTime = System.currentTimeMillis();
		m_Logger.info(name + " end time " + new Date(endTime));
		m_Logger.info(name + " cost time " + (endTime - startTime) + "ms");
		return object;
	}

}