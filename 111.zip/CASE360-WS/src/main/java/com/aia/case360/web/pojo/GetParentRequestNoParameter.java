package com.aia.case360.web.pojo;

import java.io.Serializable;

public class GetParentRequestNoParameter implements Serializable {
	// companyNo
	private String companyNo;
	// policyNo
	private String policyNo;
	// processName
	private String processName;
	private String callingSystem;

	public String getCompanyNo() {
		return companyNo;
	}

	public void setCompanyNo(String companyNo) {
		this.companyNo = companyNo;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getProcessName() {
		return processName;
	}

	public void setProcessName(String processName) {
		this.processName = processName;
	}

	public String getCallingSystem() {
		return callingSystem;
	}

	public void setCallingSystem(String callingSystem) {
		this.callingSystem = callingSystem;
	}

}
