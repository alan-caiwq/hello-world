package com.aia.case360.web.dao;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.aia.case360.web.pojo.CaseCreateInfo;
import com.aia.case360.web.pojo.PolicyStatusInfo;
import com.aia.case360.web.pojo.WebapiAudittrail;

@Repository
public interface WebAPICaseDao {
	/**
	 * insert Link For Doc With Case And Pol insert Link For Doc WithPol
	 * (FD_DOC_LINK)
	 * 
	 * @param params
	 * @return
	 * @author bsnpc37
	 * @date: 2018-4-12 9:37:53
	 */
	int insertDocLink(Map<String, String> params) throws SQLException;

	/**
	 * insert Policy(FD_POLICY)
	 * 
	 * @param params
	 * @return
	 * @author bsnpc37
	 * @date: 2018-4-12 10:05:26
	 */
	/**
	 * insertComments
	 * 
	 * @param params
	 * @return
	 * @author bsnpc57
	 * @date: 2018-6-52 15:27:57
	 */
	int insertComments(Map<String, Object> params) throws SQLException;

	/**
	 * update Signature
	 * 
	 * @param params
	 * @return
	 * @author bsnpc37
	 * @date: 2018-4-12 11:27:57
	 */
	/**
	 * get Signature
	 * 
	 * @param queryParams
	 * @return
	 * @throws SQLException
	 * @author bsnpc37
	 * @date: 2018-4-12 14:51:45
	 */
	ArrayList<Map<String, Object>> getSignature(Map<String, String> queryParams) throws SQLException;

	/**
	 * insert into FD_DOC_ATTRIBUTES
	 * 
	 * @param queryParams
	 * @return
	 * @throws SQLException
	 * @author bsnpc37
	 * @date: 2018-4-17 18:59:26
	 */
	int insertDocAttribute(Map<String, String> queryParams) throws SQLException;

	/**
	 * getFormId validate formID exist in FD_FORM_DEFINITION
	 * 
	 * @param formID
	 * @return
	 * @throws SQLException
	 * @author bsnpc37
	 * @date: Apr 19, 2018 2:17:41 PM
	 */
	List<String> getFormId(String formID) throws SQLException;

	/**
	 * get row from FD_WCF_LINK and CF_WORK
	 * 
	 * @param formID
	 * @return
	 * @throws SQLException
	 * @author bsnpc37
	 * @date: Apr 20, 2018 3:01:54 PM
	 */
	List<Map<String, Object>> getWcfLink(Map<String, String> params) throws SQLException;

	/**
	 * get case from cf_work
	 * 
	 * @param params
	 * @return
	 * @throws SQLException
	 * @author bsnpc37
	 * @date: Apr 24, 2018 9:56:11 AM
	 */
	List<Map<String, Object>> getCase(Map<String, String> params) throws SQLException;

	/**
	 * select wcf_link and cf_work to get parent request no
	 * 
	 * @param params
	 * @return
	 * @throws SQLException
	 * @author bsnpc37
	 * @date: Apr 24, 2018 10:48:15 AM
	 */
	List<Map<String, Object>> getParentRequestNo(Map<String, String> params) throws SQLException;

	/**
	 * for uploadDocument
	 * 
	 * @param params
	 * @return
	 * @throws SQLException
	 * @author bsnpc37(Leo Li)
	 * @date: May 10, 2018 1:35:32 PM
	 */
	List<Map<String, Object>> getCaseByPolicyNoAndFormID(Map<String, String> params) throws SQLException;

	/**
	 * for uploadDocument
	 * 
	 * @param params
	 * @return
	 * @throws SQLException
	 * @author bsnpc37(Leo Li)
	 * @date: May 12, 2018 1:35:32 PM
	 */
	List<Map<String, Object>> getCaseByPolicyNoAndPendingReason(Map<String, String> params) throws SQLException;

	/**
	 * 
	 * @param params
	 * @return
	 * @author bsnpc37(Leo Li)
	 * @date: May 21, 2018 9:40:06 AM
	 */
	List<CaseCreateInfo> getDataForCreateChildCase(Map<String, String> params) throws SQLException;

	/**
	 * 
	 * @param string
	 * @return
	 * @author bsnpc37(Leo Li)
	 * @date: May 21, 2018 3:09:52 PM
	 */
	List<String> getFormIDByLinkCaseId(String string) throws SQLException;

	/**
	 * 
	 * @param params
	 * @return
	 * @throws SQLException
	 * @author bsnpc37(Leo Li)
	 * @date: May 22, 2018 10:42:16 AM
	 */
	int updateRequestTypeStatus(Map<String, String> params) throws SQLException;

	/**
	 * 
	 * @param params
	 * @return
	 * @throws SQLException
	 * @author bsnpc37(Leo Li)
	 * @date: May 22, 2018 2:39:36 PM
	 */
	void insertRequestTypeRule(Map<String, String> params) throws SQLException;

	/**
	 * 
	 * @param linkCaseID
	 * @return
	 * @throws SQLException
	 * @author bsnpc37(Leo Li)
	 * @date: May 22, 2018 4:50:01 PM
	 */
	List<Map<String, Object>> getCaseInfoFromPiWork(String linkCaseID) throws SQLException;

	/**
	 * 
	 * @param createCaseNoteParams
	 * @author bsnpc37(Leo Li)
	 * @date: May 24, 2018 5:57:00 PM
	 */
	void insertCaseNote(Map<String, String> createCaseNoteParams) throws SQLException;

	/**
	 * 
	 * @param parentCaseParam
	 * @return
	 * @author bsnpc37(Leo Li)
	 * @date: May 25, 2018 11:45:56 AM
	 */
	List<Map<String, Object>> getParentCaseInfo(Map<String, String> parentCaseParam) throws SQLException;

	/**
	 * 
	 * @param requestType
	 * @return
	 * @author bsnpc37(Leo Li)
	 * @date: May 28, 2018 2:32:45 PM
	 */
	List<Map<String, Object>> getReqInfo(String requestType) throws SQLException;

	/**
	 * 
	 * @param formID
	 * @return
	 * @author bsnpc37(Leo Li)
	 * @date: May 29, 2018 3:00:23 PM
	 */
	List<Map<String, Object>> getRequestTypeByformID(String formID) throws SQLException;

	/**
	 * 
	 * @param params
	 * @author bsnpc37(Leo Li)
	 * @date: Jul 4, 2018 5:34:29 PM
	 */
	Map<String, BigDecimal> insertCaseDataForCommonProcess(Map<String, String> params) throws SQLException;

	/**
	 * 
	 * @param params
	 * @return
	 * @author bsnpc37(Leo Li)
	 * @date: Jul 20, 2018 11:06:26 AM
	 */
	List<Map<String, Object>> getPendingInfo(Map<String, String> params) throws SQLException;

	void insertNotifyRecord(Map<String, String> insertParam) throws SQLException;

	/**
	 * 
	 * @param getCaseParameters
	 * @return
	 * @return List<Map<String,Object>>
	 * @date 2:17:55 PM
	 * @author bsnpc55
	 */
	List<Map<String, Object>> getPIWork(HashMap<String, String> getCaseParameters);

	/**
	 * 
	 * @param closeCaseParams
	 * @return void
	 * @date 3:02:12 PM
	 * @author bsnpc55
	 */
	void updateCaseArchiveFlg(HashMap<String, String> closeCaseParams);

	/**
	 * 
	 * @param params
	 * @return
	 * @throws SQLException
	 * @author bsnpc37(Leo Li)
	 * @date: Aug 27, 2018 3:57:35 PM
	 */
	Map<String, BigDecimal> createChildCase(Map<String, String> params) throws SQLException;

	/**
	 * 
	 * @param params
	 * @return
	 * @throws SQLException
	 * @author bsnpc37(Leo Li)
	 * @date: Sep 4, 2018 9:52:15 AM
	 */
	int insertCloseCaseCache(Map<String, String> params) throws SQLException;

	List<PolicyStatusInfo> getPolicStatusDesc(Map<String, String> params) throws SQLException;

	int getCaseISAPPROVED(Map<String, String> insertParams) throws SQLException;
	/**
	 * 
	 * @param params
	 * @throws SQLException
	 * @author bsnpc37(Leo Li)
	 * @date: Jan 3, 2019 2:22:16 PM
	 */
	void createCaseWebapiAudittrail(WebapiAudittrail webapiAudittrail) throws SQLException;

	/**
	 * get policyNo from FD_XML_FOLDER by requestNo
	 * @description 
	 * @param requestNo
	 * @return
	 * @author bsnpc37(Leo Li)
	 * @date Jan 14, 2019 1:35:18 PM
	 */
	String getPolicyNoForUni(String requestNo);
	/**
	 * update IS_READY_PROCESSING = 1,when start processing succefully
	 * @description 
	 * @param requestNo
	 * @author bsnpc37(Leo Li)
	 * @date Jan 21, 2019 9:56:11 AM
	 */
	void updateCommonProcess(String requestNo);
	/**
	 * delete failed case data in CF_WORK and FD_WCF_LINK
	 * @description 
	 * @param caseFolderId
	 * @author bsnpc37(Leo Li)
	 * @date Mar 25, 2019 10:33:50 AM
	 */
	void deleteCaseAndLink(String caseFolderId);

	List<Map<String, String>> validateBatchNo(Map<String, String> params);
	
}
