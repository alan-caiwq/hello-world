package com.aia.case360.uam.service.impl;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.common.PropertyUtil;
import com.aia.case360.platform.dao.TableIdBean;
import com.aia.case360.uam.constants.UAMConstants;
import com.aia.case360.uam.dao.RoleDao;
import com.aia.case360.uam.domain.ActivictyInfo;
import com.aia.case360.uam.domain.MenuInfo;
import com.aia.case360.uam.domain.RequsetTypeInfo;
import com.aia.case360.uam.domain.RoleActivityVo;
import com.aia.case360.uam.domain.RoleInfo;
import com.aia.case360.uam.domain.RoleMenuPara;
import com.aia.case360.uam.domain.RoleMenuVo;
import com.aia.case360.uam.domain.RoleQueryPara;
import com.aia.case360.uam.domain.RoleReqActVo;
import com.aia.case360.uam.domain.RoleReqPara;
import com.aia.case360.uam.domain.UAMAuditTrail;
import com.aia.case360.uam.domain.UAMRoleAuditTrail;
import com.aia.case360.uam.service.UAMMenuService;
import com.aia.case360.uam.service.UAMUserRoleService;
import com.aia.case360.web.dao.MenuDao;
import com.aia.case360.web.dao.UAMAuditTrailDao;
import com.aia.case360.web.dao.UserAccountDao;
import com.aia.case360.web.pojo.OutputVO;
import com.aia.case360.web.service.impl.AbstractServiceImpl;
import com.itextpdf.text.pdf.PdfStructTreeController.returnType;

import net.sf.json.JSONArray;

@Service
public class UAMUserRoleServiceImpl extends AbstractServiceImpl implements UAMUserRoleService {
    private static final String LOCALMENU_ID = "MENU_ID";

	private static final String LOCALUAM_ACT_ID = "UAM_ACT_ID";

	private static final String LOCALUAM_REQ_ID = "UAM_REQ_ID";

	private static final String LOCALMENU_REF = "menuRef";

	private static final String LOCALREQ_ACT_MAPPING = "reqActMapping";

	private static final String LOCALUAM_REMARK = "UAM_REMARK";

	private static final String LOCALUAM_DEP_NAME = "UAM_DEP_NAME";

	private static final String LOCALUAM_IS_ENABLE = "UAM_IS_ENABLE";

	private static final String LOCALUAM_ROLE_NAME = "UAM_ROLE_NAME";

	private static final String LOCALUAM_ROLE_ID = "UAM_ROLE_ID";

	private static final String LOCALUAM_ROLE_TYPE = "UAM_ROLE_TYPE";

	private static final String LOCALROLE_BASE_INFO = "roleBaseInfo";
	
	private static final String FORM_CATEGORYS = "FORMCATEGORYS";

	@Autowired
    private MenuDao menuDao;

    @Autowired
    private UAMMenuService menuService;

    @Autowired
    UAMAuditTrailDao auditTrailDao;

    @Autowired
    private UserAccountDao userAuthorityDao;


	@Override
	public List<Map<String, Object>> getRolesByRoleInfo(RoleQueryPara roleQueryPara)  throws RemoteException {

		return roleDao.getRolebyPara(roleQueryPara);
	}

	@Override
	public List<Map<String, Object>> getRoleAndActivityInfoByRoleId(String RoleId)  throws RemoteException {

		List<Map<String, Object>> result= null;
		return result;
	}

	@Override
	public boolean addRequestTypeAndActivity(String roleId, Map<String, String> params)  throws RemoteException {

		boolean isSuccess = false;

		try {

			BigDecimal UAMComponentTableId = new BigDecimal(
					tableIdBean.getTableIds().get(PropertyUtil.getTableIDProperty(TABLEID_FD_UAM_ROLE)));

			isSuccess = dtHelper.updateRow(UAMComponentTableId, roleId, params);

		} catch (Exception e) {
			LogUtil.logException(m_Logger, params.toString(), e);
		}
		return isSuccess;
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean modifyRole(Map<String, Object> params)  throws RemoteException {
		LogUtil.logInfo(m_Logger,"method modifyRole start");
		Map<String, Object> para = (Map<String, Object>) params.get(LOCALROLE_BASE_INFO);

		String roleType = String.valueOf(para.get(LOCALUAM_ROLE_TYPE));

		if (roleType == null || roleType.trim().length() < 1) {
			return false;
		}
		RoleInfo roleInfo = new RoleInfo();
		roleInfo.setValues(para);

		// 2018/06/22 add audit trail add by cuixin -Start
        modifyRoleAuditTrail(params);
        // 2018/06/22 add audit trail add by cuixin -End

		roleDao.updateRoleInfo(roleInfo);

		boolean result = false;

		if (UAMConstants.ROLE_TYPE_ACT.equals(roleType)) {
		  result = updateRoleAct(params);
		} else if (UAMConstants.ROLE_TYPE_MU.equals(roleType) || UAMConstants.ROLE_TYPE_FUC.equals(roleType)) {
			result = updateRoleMenu(params, roleType);
		}
		else if (UAMConstants.ROLE_TYPE_CATE.equals(roleType)) {
			result = updateRoleFormCategory(para, roleInfo.getRoleId());
		}
		LogUtil.logInfo(m_Logger,"method modifyRole end");
		return result;
	}

	@SuppressWarnings("unchecked")
	private void modifyRoleAuditTrail(Map<String, Object> params)  throws RemoteException {

		boolean cantGetUAM = cantGetUAM(params);
        if (cantGetUAM == false) return;
        
		Long roleId = Long
				.valueOf(String.valueOf(((Map<String, Object>) params.get(LOCALROLE_BASE_INFO)).get(LOCALUAM_ROLE_ID)));

		String roleName = String.valueOf(((Map<String, Object>) params.get(LOCALROLE_BASE_INFO)).get(LOCALUAM_ROLE_NAME));

		Integer uamIsEnable = Integer
				.valueOf(String.valueOf(((Map<String, Object>) params.get(LOCALROLE_BASE_INFO)).get(LOCALUAM_IS_ENABLE)));

		String uamDepName = String.valueOf(((Map<String, Object>) params.get(LOCALROLE_BASE_INFO)).get(LOCALUAM_DEP_NAME));

		String uamRemark = String.valueOf(((Map<String, Object>) params.get(LOCALROLE_BASE_INFO)).get(LOCALUAM_REMARK));

		List<Map<String, Object>> reqActMappingList = (List<Map<String, Object>>) params.get(LOCALREQ_ACT_MAPPING);

		List<Map<String, Object>> FORMCATEGORYSMappingList = (List<Map<String, Object>>) ((Map<String, Object>) params
				.get(LOCALROLE_BASE_INFO)).get(FORM_CATEGORYS);

		List<Map<String, Object>> menuRefMappingList = (List<Map<String, Object>>) params.get(LOCALMENU_REF);

    String loginUserId = "";
		try {
      loginUserId = userHelper.getCurrentUser();
			if (loginUserId == null || "".equals(loginUserId)) {
				LogUtil.logError(m_Logger, "get login userId failed");
        return;
      }
		} catch (Exception e) {
			LogUtil.logError(m_Logger, "get login userId failed");
      return;
    }

    // get old role info
	String roleType = String.valueOf(((Map<String, Object>) params.get(LOCALROLE_BASE_INFO)).get(LOCALUAM_ROLE_TYPE));


    UAMRoleAuditTrail roleAuditTrail = new UAMRoleAuditTrail();

    int roleTypeInt = setRoleType(roleType);
    if(roleTypeInt == 0){
    	return;
    }
    constructRoleAuditTrail(roleAuditTrail, roleTypeInt, reqActMappingList, menuRefMappingList, FORMCATEGORYSMappingList);

    roleAuditTrail.setRoleType(roleTypeInt);
    roleAuditTrail.setRoleId(roleId);
    roleAuditTrail.setRoleName(roleName);

    roleAuditTrail.setDepartment(uamDepName);
    roleAuditTrail.setEnable(uamIsEnable);
    roleAuditTrail.setRemark(uamRemark);
    roleAuditTrail.setLoginUser(loginUserId);

    auditTrailDao.editUAMRoleAuditTrail(roleAuditTrail);
  }

	private void constructRoleAuditTrail(UAMRoleAuditTrail roleAuditTrail,
			int roleTypeInt, List<Map<String, Object>> reqActMappingList, List<Map<String, Object>> menuRefMappingList, List<Map<String, Object>> FORMCATEGORYSMappingList) {
		 String menuId = "";
		    String uamReqId = "";
		    String uamActId =  "";
		 // roleType:1 request type; 2 menu 3 function 4 formCategory
	    // roleId
	    // reqId
	    // actIds
	    // menuIds
		if (roleTypeInt == 1) {
			if (reqActMappingList != null && reqActMappingList.size() > 0) {
				for (Map<String, Object> reqActMapping : reqActMappingList) {
					if (uamReqId.length() > 0) {
				        uamReqId += ",";
				        uamActId += ",";
				    }
			      uamReqId += String.valueOf(reqActMapping.get(LOCALUAM_REQ_ID));
			      uamActId +=  String.valueOf(reqActMapping.get(LOCALUAM_ACT_ID));
			    }
			}
		} else if (roleTypeInt == 2 || roleTypeInt == 3) {
			menuId = getMenuId(menuRefMappingList, menuId);
		} else if (roleTypeInt == 4 && FORMCATEGORYSMappingList != null && FORMCATEGORYSMappingList.size() > 0) {
			menuId = getMenuId4RoleTpeIs4(FORMCATEGORYSMappingList, menuId);
	    }

	    roleAuditTrail.setReqIds(uamReqId);
	    roleAuditTrail.setActIds(uamActId);
	    roleAuditTrail.setMenuIds(menuId);
	}

	@SuppressWarnings("unchecked")
	private boolean cantGetUAM(Map<String, Object> params) {
		if (params == null || params.isEmpty()) {
			LogUtil.logError(m_Logger, "params is empty");
			return false;
		}
		if (params.get(LOCALROLE_BASE_INFO) == null || !(params.get(LOCALROLE_BASE_INFO) instanceof Map)
				|| ((Map<String, Object>) params.get(LOCALROLE_BASE_INFO)).get(LOCALUAM_ROLE_TYPE) == null) {
			LogUtil.logError(m_Logger, "Can not get UAM_ROLE_TYPE in modifyRoleAuditTrail");
			return false;
		}
		if (((Map<String, Object>) params.get(LOCALROLE_BASE_INFO)).get(LOCALUAM_ROLE_ID) == null
				|| "".equals(((Map<String, Object>) params.get(LOCALROLE_BASE_INFO)).get(LOCALUAM_ROLE_ID))) {
			LogUtil.logError(m_Logger, "Can not get UAM_ROLE_ID in modifyRoleAuditTrail");
			return false;
		}
		if (((Map<String, Object>) params.get(LOCALROLE_BASE_INFO)).get(LOCALUAM_ROLE_NAME) == null
				|| "".equals(((Map<String, Object>) params.get(LOCALROLE_BASE_INFO)).get(LOCALUAM_ROLE_NAME))) {
			LogUtil.logError(m_Logger, "Can not get UAM_ROLE_NAME in modifyRoleAuditTrail");
			return false;
		}
		 return true;
	}

	private int setRoleType(String roleType) {
		int roleTypeInt = 0;
		if (UAMConstants.ROLE_TYPE_ACT.equals(roleType)) {
			roleTypeInt = 1;
		} else if (UAMConstants.ROLE_TYPE_MU.equals(roleType)) {
			roleTypeInt = 2;
		} else if (UAMConstants.ROLE_TYPE_FUC.equals(roleType)) {
		    roleTypeInt = 3;
		} else if (UAMConstants.ROLE_TYPE_CATE.equals(roleType)) {
			roleTypeInt = 4;
		} else {
			LogUtil.logError(m_Logger, "Wrong role type: " + String.valueOf(roleType));
			roleTypeInt = 0;
		}
		return roleTypeInt;
	}

	private String getMenuId4RoleTpeIs4(
			List<Map<String, Object>> FORMCATEGORYSMappingList, String menuId) {
		for (Map<String, Object> FORMCATEGORYMapping : FORMCATEGORYSMappingList) {
			if (menuId.length() > 0) {
		menuId += ",";
        }
        menuId += String.valueOf(FORMCATEGORYMapping.get("FORM_CATEGORY"));
      }
		return menuId;
	}

	private String getMenuId(List<Map<String, Object>> menuRefMappingList,
			String menuId) {
		if (menuRefMappingList != null && menuRefMappingList.size() > 0) {

			for (Map<String, Object> menuRefMapping : menuRefMappingList) {
				if (menuId.length() > 0) {
		menuId += ",";
        }
        menuId += String.valueOf(menuRefMapping.get(LOCALMENU_ID));
      }
     }
		return menuId;
	}

	private boolean judgeNull(Map<String, Object> oldMap, String[] oldKey, Map<String, Object> newMap, String[] newKey) {
		if (oldMap == null || oldMap.isEmpty() || oldKey == null || oldKey.length == 0 || newMap == null
				|| newMap.isEmpty() || newKey == null || newKey.length == 0 || oldKey.length != newKey.length) {
			return false;
		} else {
			return true;
		}
	}
  @SuppressWarnings("unused")
	private String getMapDiffValueMessage(Map<String, Object> oldMap, String[] oldKey, Map<String, Object> newMap,
			String[] newKey, String[] alias) {
		boolean rs = judgeNull(oldMap, oldKey, newMap, newKey);
		if (!rs) {
			return "";
		}
    String oldValue = "";
    String newValue = "";
    String actionDesc = "";
    String aliaName = "";
    for (int i = 0; i < newKey.length; i++) {
      oldValue = oldMap.get(oldKey[i]) == null ? "" : String.valueOf(oldMap.get(oldKey[i]));
      newValue = newMap.get(newKey[i]) == null ? "" : String.valueOf(newMap.get(newKey[i]));
      if (!newValue.equalsIgnoreCase(oldValue)) {
        if (actionDesc.length() > 0) {
          actionDesc += ",";
        }
				aliaName = alias != null && alias.length > i && !StringUtils.isEmpty(alias[i]) ? alias[i] : newKey[i];
        actionDesc += aliaName + " change from " + oldValue + " to " + newValue + ";";
      }
    }
    return actionDesc;
  }

  private boolean updateRoleFormCategory(Map<String, Object> params, String roleId) {

	  LogUtil.logInfo(m_Logger,"method updateRoleFormCategory start");
		LogUtil.logInfo(m_Logger,"delete all FormCategory");
    menuDao.deleteRoleFormCategory(Integer.parseInt(roleId));
	  @SuppressWarnings("unchecked")
    List<Map<String, Object>> formCategorys = (List<Map<String, Object>>) params.get(FORM_CATEGORYS);
      if (formCategorys != null && formCategorys.size() > 0) {
			for (Map<String, Object> mFC : formCategorys) {
            mFC.put("roleId", roleId);
          }
          try {
            // INSERT ROLE'S FORM CATEGORY
            menuDao.insertRoleFormCategory(formCategorys);
          } catch (Exception e) {
				LogUtil.logError(m_Logger, "updateRoleFormCategory error:" + e);
				 
            return false;
          }
      }
		LogUtil.logInfo(m_Logger,"method updateRoleFormCategory end");
    return true;
  }


	

	private boolean updateRoleAct(Map<String, Object> params) {
		@SuppressWarnings("unchecked")
		Map<String, Object> para = (Map<String, Object>) params.get(LOCALROLE_BASE_INFO);
		if (para == null || para.get(RoleInfo.fieldNames.UAM_ROLE_ID.name()) == null) {
			return false;
		}
		roleDao.deleteRoleReq(String.valueOf(para.get(RoleInfo.fieldNames.UAM_ROLE_ID.name())));

		List<RoleReqPara> roleReqParas = new ArrayList<RoleReqPara>();
		JSONArray jsonArray = JSONArray.fromObject(params.get(LOCALREQ_ACT_MAPPING));
		for (int i = 0; i < jsonArray.size(); i++) {

			RoleReqPara roleReqPara = new RoleReqPara();

			roleReqPara.setActivityName(jsonArray.getJSONObject(i).getString(LOCALUAM_ACT_ID));
			roleReqPara.setReqId(jsonArray.getJSONObject(i).getString(LOCALUAM_REQ_ID));
			roleReqPara.setUamRoleId(jsonArray.getJSONObject(i).getString(LOCALUAM_ROLE_ID));
			roleReqParas.add(roleReqPara);
		}

		roleDao.insertRoleReq(removeDuplicate(roleReqParas));

		return true;
	}

	private boolean updateRoleMenu(Map<String, Object> params, String roleType) {
		Map para = (Map) params.get(LOCALROLE_BASE_INFO);
		if (UAMConstants.ROLE_TYPE_MU.equalsIgnoreCase(roleType)) {// add judgement: when menu delete the relation which
																	// is menu, else button
		  roleDao.deleteRoleMenu(String.valueOf(para.get(LOCALUAM_ROLE_ID)), 0);
		} else {
			roleDao.deleteRoleMenu(String.valueOf(para.get(LOCALUAM_ROLE_ID)), 1);
		}
		JSONArray jsonArray = JSONArray.fromObject(params.get(LOCALMENU_REF));

		List<RoleMenuPara> roleMenuParas = new ArrayList<RoleMenuPara>();
		Set<String> menuIds = new HashSet<String>();

		for (int i = 0; i < jsonArray.size(); i++) {
			String menuId = jsonArray.getJSONObject(i).getString(LOCALMENU_ID);
			if (!menuIds.contains(menuId)) {
				menuIds.add(menuId);
				RoleMenuPara roleMenuPara = new RoleMenuPara();
				roleMenuPara.setMenuId(jsonArray.getJSONObject(i).getString(LOCALMENU_ID));
				roleMenuPara.setRoleId(jsonArray.getJSONObject(i).getString(LOCALUAM_ROLE_ID));
				roleMenuParas.add(roleMenuPara);
			}
		}
		return roleDao.insertRoleMenuReq(roleMenuParas);

	}

	@Override
	public boolean addRoleMenu(RoleMenuVo roleMenuVo) {

		RoleInfo roleInfo = new RoleInfo();
		roleInfo.setDepartment(roleMenuVo.getDepartment());
		roleInfo.setEnable(roleMenuVo.getEnable());
		roleInfo.setRemark(roleMenuVo.getRemark());
		roleInfo.setRoleId(roleMenuVo.getRoleId());
		roleInfo.setRoleName(roleMenuVo.getRoleName());
		roleInfo.setRoleType(roleMenuVo.getRoleType());

		int roleId = roleDao.insertRoleInfo(roleInfo);

		roleDao.insertRoleMenu(roleMenuVo, roleId);

		return true;
	}

	@Override
	public boolean addRoleAct(RoleReqActVo roleReqActVo) {

		return false;
	}

	@Override
	public Object getRoleInfoByRoleId(String roleId) {

		List<Map<String, Object>> roleBaseInfos = roleDao.getRoleBaseInfoByRoleId(roleId);

		String roleType = (String) roleBaseInfos.get(0).get(LOCALUAM_ROLE_TYPE);

		if (UAMConstants.ROLE_TYPE_ACT.equals(roleType)) {
			return getAllRequestAndActivty(roleBaseInfos.get(0));
		}
		if (UAMConstants.ROLE_TYPE_MU.equals(roleType)) {
			return getAllRoleMenu(roleBaseInfos.get(0));
		}
		if (UAMConstants.ROLE_TYPE_FUC.equals(roleType)) {
			return getAllRoleFunction(roleBaseInfos.get(0));
		}
		if (UAMConstants.ROLE_TYPE_CATE.equals(roleType)) {
			return getAllRoleCategory(roleBaseInfos.get(0));
		}

		return roleType;
	}

	@SuppressWarnings("unchecked")
  private Object getAllRoleCategory(Map<String, Object> roleBaseInfo) {
	    Map<String, Object> result = new ConcurrentHashMap<String, Object>();
		result.put("uam_DEP_NAME", roleBaseInfo.get(LOCALUAM_DEP_NAME));
	    result.put("uam_IS_ENABLE", roleBaseInfo.get(LOCALUAM_IS_ENABLE));
	    result.put("uam_REMARK", roleBaseInfo.get(LOCALUAM_REMARK));
	    result.put("uam_ROLE_ID", roleBaseInfo.get(LOCALUAM_ROLE_ID));
	    result.put("uam_ROLE_NAME", roleBaseInfo.get(LOCALUAM_ROLE_NAME));
	    result.put("uam_ROLE_TYPE", roleBaseInfo.get(LOCALUAM_ROLE_TYPE));
	    String roleIdStr = roleBaseInfo.get(LOCALUAM_ROLE_ID) == null ? "" : roleBaseInfo.get(LOCALUAM_ROLE_ID).toString();
	    Map<String, Object> map = new ConcurrentHashMap<String, Object>();
	    map.put("ROLEID", roleIdStr);
	    try {
          OutputVO formCategory = menuService.getFormCategory(map);
			result.putAll((Map<String, Object>) formCategory.getDatas());
        } catch (Exception e) {
			LogUtil.logException(m_Logger, roleBaseInfo.toString(), e);
        }
		return result;
	}

	private Object getAllRoleFunction(Map<String, Object> roleBaseInfo) {

		return getAllRoleMenu(roleBaseInfo);
	}

	private Object getAllRoleMenu(Map<String, Object> roleBaseInfo) {
		MenuInfo menuInfo = new MenuInfo();
		menuInfo.setValues(roleBaseInfo);
		List<Map<String, Object>> rows = roleDao.getroleMenuByRoleId(String.valueOf(roleBaseInfo.get(LOCALUAM_ROLE_ID)));
		menuInfo.setMenuInfo(rows);
		return menuInfo;
	}

	
	@Override
	public Object getAllRequestAndActivty(Map<String, Object> roleBaseInfo) {

		String roleId = null;
		RoleActivityVo roleActivityVo = new RoleActivityVo();
		if (roleBaseInfo != null) {

			roleActivityVo.setValues(roleBaseInfo);
			roleId = String.valueOf(roleBaseInfo.get(LOCALUAM_ROLE_ID));
		}
		/**
		 * search all req_types of this RoleId, then return all activities list of these
		 * req_types
 */
		List<Map<String, Object>> rows = roleDao.getRoleActivityMapping(roleId);
		String reqId;
		String reqId_old = null;
		List<RequsetTypeInfo> RequsetTypeInfos = new ArrayList<RequsetTypeInfo>();
		List<ActivictyInfo> activictyInfos = null;

		for (Map<String, Object> row : rows) {
			reqId = String.valueOf(row.get("REQ_ID"));
			String req_name = String.valueOf(row.get("REQ_NAME"));
			String act_id = String.valueOf(row.get("ACT_ID"));
			String act_name = String.valueOf(row.get("ACT_NAME"));
			String use_flag = String.valueOf(row.get("USE_FLAG"));

			if (!reqId.equals(reqId_old)) {
				RequsetTypeInfo requsetTypeInfo = new RequsetTypeInfo();
				activictyInfos = new ArrayList<ActivictyInfo>();
				requsetTypeInfo.setREQ_ID(reqId);
				requsetTypeInfo.setREQ_NAME(req_name);
				requsetTypeInfo.setACTIVITYS(activictyInfos);
				reqId_old = reqId;
				ActivictyInfo activictyInfo = new ActivictyInfo();
				activictyInfo.setACT_ID(act_id);
				activictyInfo.setACT_NAME(act_name);
				activictyInfo.setUSE_FLAG(use_flag);
				activictyInfos.add(activictyInfo);
				RequsetTypeInfos.add(requsetTypeInfo);
			} else {
				ActivictyInfo activictyInfo = new ActivictyInfo();
				activictyInfo.setACT_ID(act_id);
				activictyInfo.setACT_NAME(act_name);
				activictyInfo.setUSE_FLAG(use_flag);
				activictyInfos.add(activictyInfo);
			}

		}

		roleActivityVo.setREQUESTTYPES(RequsetTypeInfos);

		return roleActivityVo;
	}

	@Override
	public Object getRoleByUserIdAndRoleType(Map<String, Object> para) {

		String userId = (String) para.get("userId");
		String roleType = (String) para.get("roleType");

		return roleDao.getRoleByUserIdAndRoleType(userId, roleType);
	}

	@Override
	public OutputVO addRole(Map<String, Object> param)  throws RemoteException {
		OutputVO outputVO = new OutputVO();
		@SuppressWarnings("rawtypes")
		Map para = (Map) param.get(LOCALROLE_BASE_INFO);
		String roleType = String.valueOf(para.get(LOCALUAM_ROLE_TYPE));
		String roleName = String.valueOf(para.get(LOCALUAM_ROLE_NAME));
		String roleDept = String.valueOf(para.get(LOCALUAM_DEP_NAME));
		// add logic to validate input parameter, if null parameter in, return
		if (StringUtils.isBlank(roleType)) {
			outputVO.addErrorInfo("role type cannot be null");
			return outputVO;
		}
		if (StringUtils.isBlank(roleName)) {
			outputVO.addErrorInfo("role name cannot be null");
			return outputVO;
		}
		if (StringUtils.isBlank(roleDept)) {
			outputVO.addErrorInfo("department cannot be null");
			return outputVO;
		}
		RoleInfo roleInfo = new RoleInfo();
		roleInfo.setEnable(String.valueOf(para.get(LOCALUAM_IS_ENABLE)));
		roleInfo.setRemark(String.valueOf(para.get(LOCALUAM_REMARK)));
		roleInfo.setRoleName(roleName);
		roleInfo.setDepartment(roleDept);
		roleInfo.setRoleType(roleType);

		RoleQueryPara roleQueryPara = new RoleQueryPara();
		roleQueryPara.setRoleName(roleInfo.getRoleName());
		List<Map<String, Object>> currentRoles = userAuthorityDao.queryRoleByRoleName(roleName);
		if (currentRoles != null && !currentRoles.isEmpty()) {// add validation to ignore null pointerRemoteException by
																// charley 20180424
			outputVO.addErrorInfo("role name already exist");
			return outputVO;
		}

		int roleId = roleDao.insertRoleInfo(roleInfo);
		  // 2018/06/22 add audit trail add by cuixin -Start
		StringBuilder actionDesc = new StringBuilder(
				"Add role " + roleInfo.getRoleName() + "(Department: " + roleInfo.getDepartment() + ", Role Type: "
						+ roleInfo.getRoleType() + ", Enable: " + roleInfo.getEnable() + ",");
		StringBuilder detalMessage = new StringBuilder();
		if (UAMConstants.ROLE_TYPE_ACT.equals(roleType)) {
			 roleTypeEqACT(param, roleId, detalMessage);
		}
		if (UAMConstants.ROLE_TYPE_MU.equals(roleType) || UAMConstants.ROLE_TYPE_FUC.equals(roleType)) {
			OutputVO outvo = roleTypeEqMUAndFUC(param, outputVO, roleType, roleId, detalMessage);
			if(outvo != null){
				return outvo;
			}
			
		}
		if (UAMConstants.ROLE_TYPE_CATE.equalsIgnoreCase(roleType)) {
			roleTypeEqCATE(para, roleId, detalMessage);
		}
		actionDesc.append(detalMessage.toString());
		actionDesc.append(")");
		String loginUserId = userHelper.getCurrentUser();
        UAMAuditTrail auditTrailParam = new UAMAuditTrail();
        auditTrailParam.setActionDesc(actionDesc.toString());
        auditTrailParam.setCategory("ROLE");
        auditTrailParam.setUamComponentName(String.valueOf(roleId));
        auditTrailParam.setUamUserId(loginUserId);
        auditTrailDao.addUAMAuditTrail(auditTrailParam);
		// 2018/06/22 add audit trail add by cuixin -End
		return outputVO;
	}

	private OutputVO roleTypeEqMUAndFUC(Map<String, Object> param,
			OutputVO outputVO, String roleType, int roleId,
			StringBuilder detalMessage) throws RemoteException {
		detalMessage.append(UAMConstants.ROLE_TYPE_MU.equals(roleType) ? "menu:" : "function:");
		Set<String> menuIds = new HashSet<String>();
		RoleMenuVo roleMenuVo = new RoleMenuVo();
		JSONArray jsonArray = JSONArray.fromObject(param.get(LOCALMENU_REF));
		if (jsonArray.isEmpty()) {
			outputVO.addErrorInfo("no menu info input");
			return outputVO;
		}
		// get menu code & value mapping
		List<Map<String, Object>> menuCodeMapList = userAuthorityDao.getMenuCodeMap();
		// convert list map to map, key is the menu_id
		Map<String, Object> menuCodeMap = convertListToMap(menuCodeMapList);
		for (int i = 0; i < jsonArray.size(); i++) {
			String menuId = jsonArray.getJSONObject(i).getString(LOCALMENU_ID);
			menuIds.add(menuId);
			String menuName = menuCodeMap.get(menuId) == null ? menuId : menuCodeMap.get(menuId).toString();
			if (!StringUtils.isBlank(menuName)) {
				if (i != 0) {
					detalMessage.append(",");
				}
				detalMessage.append(menuName);
			}
		}

		roleMenuVo.setMenuIds(menuIds);
		roleDao.insertRoleMenu(roleMenuVo, roleId);
		return null;
	}

	private void roleTypeEqCATE(Map para, int roleId, StringBuilder detalMessage)
			throws RemoteException {
		detalMessage.append("form category:");
		int i = 0;
  List<Map<String, Object>> formCategorys = (List<Map<String, Object>>) para.get(FORM_CATEGORYS);
        if (formCategorys != null && formCategorys.size() > 0) {
			for (Map<String, Object> mFC : formCategorys) {
		    mFC.put("roleId", roleId);
				if (i == 0) {
		    	i = 1;
		    } else {
		    	detalMessage.append(",");
		    }
		    detalMessage.append(mFC.get("FORM_CATEGORY"));
		  }
		  // insert roleFormCategory
		  menuDao.insertRoleFormCategory(formCategorys);
        }
	}

	private void roleTypeEqACT(Map<String, Object> param, int roleId,
			StringBuilder detalMessage) throws RemoteException {
		detalMessage.append("RequestType & Activity:");
		List<RoleReqPara> roleReqParas = new ArrayList<RoleReqPara>();

		JSONArray jsonArray = JSONArray.fromObject(param.get(LOCALREQ_ACT_MAPPING));
		Map<String, String> reqActCodeMap = getReqActCodeMap(jsonArray);
		String reqLast = "";
		for (int i = 0; i < jsonArray.size(); i++) {
			RoleReqPara roleReqPara = new RoleReqPara();
			String reqId = jsonArray.getJSONObject(i).getString(LOCALUAM_REQ_ID);
			String actId = jsonArray.getJSONObject(i).getString(LOCALUAM_ACT_ID);
			roleReqPara.setUamRoleId(String.valueOf(roleId));
			roleReqPara.setReqId(reqId);
			roleReqPara.setActivityName(actId);
			roleReqParas.add(roleReqPara);
			String reqAndActNM = reqActCodeMap.get(reqId + "," + actId);
			String reqName = "";
			String actName = "";
			String[] reqActArr = reqAndActNM.split(",");
			reqName = reqActArr[0];
			if (!reqAndActNM.endsWith(",")) {
				actName = reqActArr[1];
			}
			if (StringUtils.isBlank(reqName)) {
				reqName = reqId;
			}
			if (StringUtils.isBlank(actName)) {
				actName = actId;
			}
			if (StringUtils.isBlank(reqLast)) {
				reqLast = reqId;
				detalMessage.append(reqName + "(" + actName);
			} else if (reqLast.equalsIgnoreCase(reqId)) {
				detalMessage.append("," + actName);
			} else {
				detalMessage.append(")," + reqName + "(" + actName);
			}
			if (i == jsonArray.size() - 1) {
				detalMessage.append(")");
			}
		}
		roleDao.insertRoleReq(removeDuplicate(roleReqParas));
	}

	private Map<String, String> getReqActCodeMap(JSONArray jsonArray)  throws RemoteException {
		Map<String, String> result = new HashMap<String, String>();
		// concstruct query params
		List<String> queryParamList = new ArrayList<String>();
		for (int i = 0; i < jsonArray.size(); i++) {
			String reqId = jsonArray.getJSONObject(i).getString(LOCALUAM_REQ_ID);
			String actId = jsonArray.getJSONObject(i).getString(LOCALUAM_ACT_ID);
			queryParamList.add(reqId + "," + actId);
		}
		if (queryParamList.size() > 0) {
			List<Map<String, String>> reqActMapList = userAuthorityDao.findReqActCodeMapList(queryParamList);
			if (reqActMapList != null && reqActMapList.size() > 0) {
				for (Map<String, String> tReqAct : reqActMapList) {
					Map<String, String> tM = new HashMap<String, String>();
					tM.put(tReqAct.get("RCODE"), tReqAct.get("RNAME"));
					result.putAll(tM);
				}
			}
		}
		return result;
	}

	private Map<String, Object> convertListToMap(List<Map<String, Object>> menuCodeMapList) {
		Map<String, Object> result = new ConcurrentHashMap<String, Object>();
		for (int i = 0; menuCodeMapList != null && menuCodeMapList.size() > 0 && i < menuCodeMapList.size(); i++) {
			Map<String, Object> map = menuCodeMapList.get(i);
			result.put(map.get(LOCALMENU_ID).toString(), map.get("MENU_NM"));
		}
		return result;
	}

	private List<RoleReqPara> removeDuplicate(List<RoleReqPara> rs) {
		Set<RoleReqPara> set = new TreeSet<RoleReqPara>(new Comparator<RoleReqPara>() {
					@Override
					public int compare(RoleReqPara r1, RoleReqPara r2) {

				return (r1.getActivityName().trim() + r1.getReqId().trim())
						.compareTo(r2.getActivityName().trim() + r2.getReqId().trim());
					}
				});
		set.addAll(rs);
		return new ArrayList<RoleReqPara>(set);
	}

	@Autowired
	private TableIdBean tableIdBean;

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	private RoleDao roleDao;

	private static final String TABLEID_FD_UAM_ROLE = "TABLEID_FD_UAM_ROLE";

	@Override
	public List<Map<String, Object>> getAllRoles() {
		RoleQueryPara roleQueryPara = new RoleQueryPara();
		roleQueryPara.setEnabled(true);
		return roleDao.getRolebyPara(roleQueryPara);
	}
}
