/**
 * 
 */
package com.aia.case360.web.pojo;

/**
 * @author bsnpc55
 *
 */
public class GetCWAdetailsMultiParamter {

}
