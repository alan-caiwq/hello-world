package com.aia.case360.web.pojo;

import java.util.Date;

public class FdWcfClient {

	private String clientId;
	private String sRowId;
	private String polNum;
	private String nric;
	private int isNonaia;
	private String linkcaseId;
	private String polRole;
	private int isDeleted;
	private String name;
	private String dob;
	private String createdBy;
	private String updatedBy;
	private Date createdTimestamp;
	private Date updatedTimestamp;
	private String Hashstr;
	private String Cust_nm;

	public String getHashstr() {
		return Hashstr;
	}

	public void setHashstr(String hashstr) {
		Hashstr = hashstr;
	}

	public String getCust_nm() {
		return Cust_nm;
	}

	public void setCust_nm(String cust_nm) {
		Cust_nm = cust_nm;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getsRowId() {
		return sRowId;
	}

	public void setsRowId(String sRowId) {
		this.sRowId = sRowId;
	}

	public String getPolNum() {
		return polNum;
	}

	public void setPolNum(String polNum) {
		this.polNum = polNum;
	}

	public String getNric() {
		return nric;
	}

	public void setNric(String nric) {
		this.nric = nric;
	}

	public int getIsNonaia() {
		return isNonaia;
	}

	public void setIsNonaia(int isNonaia) {
		this.isNonaia = isNonaia;
	}

	public String getLinkcaseId() {
		return linkcaseId;
	}

	public void setLinkcaseId(String linkcaseId) {
		this.linkcaseId = linkcaseId;
	}

	public String getPolRole() {
		return polRole;
	}

	public void setPolRole(String polRole) {
		this.polRole = polRole;
	}

	public int getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(int isDeleted) {
		this.isDeleted = isDeleted;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public Date getUpdatedTimestamp() {
		return updatedTimestamp;
	}

	public void setUpdatedTimestamp(Date updatedTimestamp) {
		this.updatedTimestamp = updatedTimestamp;
	}

}
