package com.aia.case360.platform.casefolder.impl;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.aia.case360.platform.caches.Impl.FieldCache;
import com.aia.case360.platform.casefolder.CasefolderHelper;
import com.aia.case360.platform.common.DataFieldUtil;
import com.aia.case360.platform.common.DateUtil;
import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.common.PropertyUtil;
import com.aia.case360.platform.common.ScriptUtil;
import com.aia.case360.platform.formdata.DataTableHelper;
import com.aia.case360.web.service.impl.AbstractHelperImpl;
import com.eistream.sonora.casefolder.core.CaseFolderElement;
import com.eistream.sonora.exceptions.SonoraException;
import com.eistream.sonora.fields.FmsField;
import com.eistream.sonora.fields.FmsRow;
import com.eistream.sonora.fields.FmsRowConflict;
import com.eistream.sonora.fields.FmsRowNative;

/**
 * A <code>CasefolderHelper</code> is the common helper class for the operations
 * on special Casefolder.
 *
 * @author bsnpbdu
 *
 */
@Component
public class CasefolderHelperImpl extends AbstractHelperImpl implements CasefolderHelper {
	private static final String LOCALREQUESTNUM = "REQUEST_NUM";
	private static final String LOCALCASEFOLDERID = "CasefolderId :";
	private static final String LOCALUPDATETIMESTAMP = "UPDATE_TIMESTAMP";
	private static final String LOCALFUNCIONTNAMEUPDATECASEFOLDERSTARTWITH = "FunciontName updateCasefolder start with ";
	@Autowired
	private DataTableHelper dtHelper;

	/**
	 * update one specified casefolder's field with the value
	 * 
	 * @param caseIdText casefolder id text string
	 * @param fldName    the customer field name of the casefolder
	 * @param fldValue   the value for the customer filed of the casefolder
	 * @return true update field value successfully <br>
	 *         false update field value failed
	 */

	public boolean updateCasefolder(String caseIdText, String fldName, String fldValue) throws RemoteException {
		LogUtil.logInfo(m_Logger,LOCALFUNCIONTNAMEUPDATECASEFOLDERSTARTWITH);
		String message = caseIdText + ":" + fldName + ":" + fldValue;
		LogUtil.logInfo(m_Logger,message);
		try {

			BigDecimal caseId = getCaseId(caseIdText);
			FmsRow ocustomerFields = getCfsEJB().getCaseFolderFields(caseId);
			FmsRow ncustomerFields = getCfsEJB().getCaseFolderFields(caseId);
			FmsField[] ss = ncustomerFields.getFieldList();
			for (FmsField s : ss) {
				LogUtil.logInfo(m_Logger,s.getFmsFieldTO().getFieldName() + "'''" + s.getValue());
			}
			ncustomerFields.getField(fldName).setValue(fldValue);
			FmsRowConflict resultObj = getCfsEJB().setCaseFolderFields(caseId, ocustomerFields, ncustomerFields, true);
			if (resultObj == null) {
				return true;
			}
			LogUtil.logInfo(m_Logger,message + " is levaing");
			return resultObj.conflictCount <= 0;
		} catch (RemoteException e) {
			 
			throw LogUtil.logException(m_Logger, message, e);
		} catch (FinderException e) {
			 
			throw LogUtil.logException(m_Logger, message, e);
		} catch (SonoraException e) {
			 
			throw LogUtil.logException(m_Logger, message, e);
		}

	}

	/**
	 * update one specified casefolder's a set of fields with corresponding values
	 * 
	 * @param caseIdStr casefolder id text string
	 * @param fldNames  the customer field names of the casefolder
	 * @param fldValues the values for the customer fileds of the casefolder
	 * @return true update fields value successfully <br>
	 *         false update fields value failed
	 * @throws RemoteException
	 */
	public boolean updateCasefolder(String caseIdStr, List<String> fldNames, List<String> fldValues)
			throws RemoteException {

		LogUtil.logInfo(m_Logger,LOCALFUNCIONTNAMEUPDATECASEFOLDERSTARTWITH);
		BigDecimal caseId = getCaseId(caseIdStr);

		String message = caseIdStr + ": fieldNames:" + DataFieldUtil.getInListStr(fldNames) + ": fieldValues: "
				+ DataFieldUtil.getInListStr(fldValues);
		LogUtil.logInfo(m_Logger,message);
		fldNames.add(LOCALUPDATETIMESTAMP);
		fldValues.add(DateUtil.getCurrentTime());
		try {

			if (fldNames.size() != fldValues.size()) {
				message = message + ":Invalid input fields name & value!";
				throw LogUtil.logException(m_Logger, "",new RemoteException(message));
			}

			FmsRow ocustomerFields = getCfsEJB().getCaseFolderFields(caseId);
			FmsRow ncustomerFields = getCfsEJB().getCaseFolderFields(caseId);

			int fldSequence = 0;
			for (String fldName : fldNames) {

				if (null == fldName || fldName.trim().length() == 0) {
					throw LogUtil.logException(m_Logger, "",new RemoteException(message));
				}
				if (ncustomerFields.getField(fldName) == null) {
					continue;
				}

				updateCasefolderAssist(fldValues, ncustomerFields, fldSequence, fldName);
				fldSequence++;
			}
			FmsRowConflict resultObj = getCfsEJB().setCaseFolderFields(caseId, ocustomerFields, ncustomerFields, true);
			if (resultObj == null) {
				LogUtil.logInfo(m_Logger,message);
				return true;
			}
			LogUtil.logInfo(m_Logger,message + "  there are " + resultObj.conflictCount + " conflicts!");
			return resultObj.conflictCount <= 0;
		} catch (RemoteException e) {
			 
			throw LogUtil.logException(m_Logger, "",new RemoteException(message));
		} catch (FinderException e) {
			 
			throw LogUtil.logException(m_Logger, "",new RemoteException(message));
		} catch (SonoraException e) {
			 
			throw LogUtil.logException(m_Logger, "",new RemoteException(message));
		}

	}

  private void updateCasefolderAssist(List<String> fldValues, FmsRow ncustomerFields,
      int fldSequence, String fldName) throws RemoteException, SonoraException {
    if (FieldCache.getFieldType(fldName).equalsIgnoreCase("Decimal")&&!"".equals(valueIsNull(fldValues.get(fldSequence)))) {
    		ncustomerFields.getField(fldName.trim()).setValue(new BigDecimal(fldValues.get(fldSequence)));
    } else if (FieldCache.getFieldType(fldName).equalsIgnoreCase("Integer")&&!"".equals(valueIsNull(fldValues.get(fldSequence)))) {
    	
    		ncustomerFields.getField(fldName.trim()).setValue(new Integer(fldValues.get(fldSequence)));
    	
    } else if (FieldCache.getFieldType(fldName).equalsIgnoreCase("Boolean")&&!"".equals(valueIsNull(fldValues.get(fldSequence)))) {
    		ncustomerFields.getField(fldName.trim()).setValue(new Boolean(fldValues.get(fldSequence)));
    	
    } else if (FieldCache.getFieldType(fldName).equalsIgnoreCase("Timestamp")&&!"".equals(valueIsNull(fldValues.get(fldSequence)))) {
    		ncustomerFields.getField(fldName.trim()).setValue(DateUtil.getTimestamp(fldValues.get(fldSequence)));
    
    } else if(!"".equals(valueIsNull(fldValues.get(fldSequence)))) {
    		ncustomerFields.getField(fldName.trim()).setValue(fldValues.get(fldSequence));
    	
    }
  }

	/*
	 * common out for performanceissue private String getFieldType(String filedName)
	 * throws RemoteException { FmsFieldDefinition fmsFile; String fieldDataType =
	 * null; FieldDataType
	 * fdType = fmsFile.getDataType(); fieldDataType = fdType.toString(); } catch
	 * (FinderException e) {   throw
	 * LogUtil.logException(m_Logger, e); } return fieldDataType; } / /** update one
	 * specified casefolder's a set of fields with corresponding values
	 * 
	 * @param caseIdStr casefolder id text string
	 * 
	 * @param params the customer params of the casefolder
	 * 
	 * @return true update fields value successfully <br> false update fields value
	 * failed
	 * 
	 * @throws RemoteException
	 */
	public boolean updateCasefolder(String caseIdStr, Map<String, String> params) throws RemoteException {
		LogUtil.logInfo(m_Logger,LOCALFUNCIONTNAMEUPDATECASEFOLDERSTARTWITH);
		BigDecimal caseId = getCaseId(caseIdStr);

		String message = caseIdStr + ": fields:" + params.toString();
		LogUtil.logInfo(m_Logger,message);

		String time = DateUtil.getCurrentTime();
		params.put(LOCALUPDATETIMESTAMP, time);

		try {
			FmsRow ocustomerFields = getCfsEJB().getCaseFolderFields(caseId);
			FmsRow fmsRow = getCfsEJB().getCaseFolderFields(caseId);

			Iterator<Map.Entry<String, String>> it = params.entrySet().iterator();
			while (it.hasNext()) {

				Map.Entry<String, String> entry = it.next();
				LogUtil.logInfo(m_Logger,"111111" + entry.getKey() + "22222 " + entry.getValue());
				if (fmsRow.getField(entry.getKey()) == null) {
					continue;
				}

				updateCasefolderAssist(fmsRow, entry);
			}
			FmsRowConflict resultObj = getCfsEJB().setCaseFolderFields(caseId, ocustomerFields, fmsRow, true);
			if (resultObj == null) {
				LogUtil.logInfo(m_Logger,message + " is levaing");
				return true;
			}
			LogUtil.logError(m_Logger,message + "  there are " + resultObj.conflictCount + " conflicts!");
			return resultObj.conflictCount <= 0;
		} catch (RemoteException e) {
			 
			throw LogUtil.logException(m_Logger, "",new RemoteException(message));
		} catch (FinderException e) {
			 
			throw LogUtil.logException(m_Logger, "",new RemoteException(message));
		} catch (SonoraException e) {
			 
			throw LogUtil.logException(m_Logger, "",new RemoteException(message));
		}

	}

  private void updateCasefolderAssist(FmsRow fmsRow, Map.Entry<String, String> entry)
      throws RemoteException, SonoraException {
    if (FieldCache.getFieldType(entry.getKey()).equalsIgnoreCase("Decimal")&&!"".equals(valueIsNull(entry.getValue()))) {
    		LogUtil.logInfo(m_Logger,entry.getKey() + " : " + entry.getValue());
    		fmsRow.setValue(entry.getKey(), new BigDecimal(entry.getValue().toString()));
    } else if (FieldCache.getFieldType(entry.getKey()).equalsIgnoreCase("Integer")&&!"".equals(valueIsNull(entry.getValue()))) {
    		LogUtil.logInfo(m_Logger,entry.getKey() + " : " + entry.getValue());
    		fmsRow.setValue(entry.getKey(), new Integer(entry.getValue()));
    } else if (FieldCache.getFieldType(entry.getKey()).equalsIgnoreCase("Boolean")&&!"".equals(valueIsNull(entry.getValue()))) {
    		LogUtil.logInfo(m_Logger,entry.getKey() + " : " + entry.getValue());
    		fmsRow.setValue(entry.getKey(), new Boolean(entry.getValue()));
    } else if (FieldCache.getFieldType(entry.getKey()).equalsIgnoreCase("Timestamp")&&!"".equals(valueIsNull(entry.getValue()))) {
    		LogUtil.logInfo(m_Logger,entry.getKey() + " : " + entry.getValue());
    		fmsRow.setValue(entry.getKey(), DateUtil.getTimestamp(entry.getValue()));
    } else {
    	LogUtil.logInfo(m_Logger,entry.getKey() + " : " + entry.getValue());
    	fmsRow.setValue(entry.getKey(), valueIsNull(entry.getValue()));
    }
  }

	/**
	 * get casefolderId
	 * 
	 * @param caseIdStr casefolder id text string
	 * @return BigDecimal value of the casefolder Id
	 * @throws RemoteException
	 */
	private BigDecimal getCaseId(String caseIdStr) throws RemoteException {

		LogUtil.logInfo(m_Logger,"FunciontName getCaseId start with caseIdStr:" + caseIdStr);
		if (caseIdStr == null || caseIdStr.trim().length() == 0) {
			throw new RemoteException("No Integer caseId input!");
		}
		BigDecimal caseId = new BigDecimal(0);
		try {
			caseId = new BigDecimal(caseIdStr);
			return caseId;
		} catch (Exception e) {
			throw LogUtil.logException(m_Logger, caseIdStr,e);
		}

	}

	@Override
	public void createCasefolderFromXml(String cfXml) throws RemoteException {
		LogUtil.logInfo(m_Logger,"FunciontName createCasefolderFromXml start with cfXml:" + cfXml);
		try {
			getCfsEJB().createElementFromXml(cfXml);
		} catch (CreateException e) {

			throw LogUtil.logException(m_Logger, cfXml,e);

		}
	}

	@Override
	public Map<String, Object> getCasefolderDetail(BigDecimal caseId) throws RemoteException {

		LogUtil.logInfo(m_Logger,"FunciontName getCasefolderDetail start with caseId:" + caseId);
		LogUtil.logInfo(m_Logger,caseId.toString());
		Map<String, Object> result = new HashMap<String, Object>();
		try {
			FmsRow fr = getCfsEJB().getCaseFolderFields(caseId);
			CaseFolderElement ce = getCfsEJB().getElement(caseId);
			if (ce != null) {
				String KEY_GENERIC = ce.getElementType() + "." + ce.getTemplateID() + "." + caseId.toString();
				result.put("KEY_GENERIC", KEY_GENERIC);
			}
			for (FmsField ff : fr.getFieldList()) {
				result.put(ff.fieldMetaData.fieldDefinition.fieldName, ff.getValue());
			}
		} catch (RemoteException e) {
			throw LogUtil.logException(m_Logger, caseId.toString(),e);
			 
			
		} catch (FinderException e) {
			 
			throw LogUtil.logException(m_Logger, caseId.toString(),e);
		}
		return result;
	}

	@Override
	public BigDecimal createCaseFolder(String templateName, Map<String, String> parameters) throws RemoteException {

		LogUtil.logInfo(m_Logger,"FunciontName createCaseFolder start ");
		StringBuilder sb = new StringBuilder();
		BigDecimal caseFolderID = null;
		BigDecimal fmsRowID = null;
		BigDecimal caseId;
		sb.append("Case Folder name is ").append(templateName);
		ArrayList templateList = getCfsEJB().getTemplates();
		CaseFolderElement template;
		for (int i = 0; i < templateList.size(); i++) {
			template = (CaseFolderElement) templateList.get(i);
			if (template.getDisplayName().equalsIgnoreCase(templateName)) {
				fmsRowID = template.getFmsID();
				caseFolderID = template.getCaseFolderID();
				break;
			}

		}

		String time = DateUtil.getCurrentTime();
		parameters.put(LOCALUPDATETIMESTAMP, time);
		parameters.put("CREATE_TIMESTAMP", time);

		if (fmsRowID != null) {
			LogUtil.logInfo(m_Logger,"case folder row id: " + fmsRowID.toString() + "  ,case folder id : " + caseFolderID);
		}
		if (fmsRowID != null && caseFolderID != null) {
			FmsRow fmsRow = getFmsRow(fmsRowID, parameters);
			LogUtil.logInfo(m_Logger,fmsRow.toString());
			caseId = getCfsEJB().createInstance(caseFolderID, fmsRow);
			sb.append(". Case id").append(caseId);
			LogUtil.logInfo(m_Logger,sb.toString());
			return caseId;
		}
		sb.append("case id is null");
		LogUtil.logInfo(m_Logger,sb.toString());
		return null;
	}

	@Override
	public FmsRow getFmsRow(BigDecimal fmsRowID, Map<String, String> parameters) throws RemoteException {

		LogUtil.logInfo(m_Logger,"FunciontName getFmsRow start ");
		FmsRow fmsRow = null;
		FmsRowNative frn;
		String message = "get Fms Row";
		try {
			frn = getFmsEJB().getNewRow(fmsRowID);
			fmsRow = (FmsRow) frn.clone();
			dtHelper.updateTableRow(parameters, fmsRow);

		} catch (CreateException e) {
			 
			throw LogUtil.logException(m_Logger, message,e);
		} catch (SonoraException e) {
			 
			throw LogUtil.logException(m_Logger, message,e);
		}
		return fmsRow;
	}

	@Override
	public boolean deleteCaseFolder(BigDecimal casefolderId) throws RemoteException {
		LogUtil.logInfo(m_Logger,"FunciontName deleteCaseFolder start ");
		try {
			getCfsEJB().remove(casefolderId);
			return true;
		} catch (RemoveException e) {
			String message = LOCALCASEFOLDERID + casefolderId + "delete fail.";
			LogUtil.logError(m_Logger, message + " " + e.getMessage());
		}
		return false;
	}

	@Override
	public String getCasefolderAsXml(BigDecimal caseid) throws RemoteException {

		LogUtil.logInfo(m_Logger,"FunciontName getCasefolderAsXml start ");
		String message = LOCALCASEFOLDERID + caseid;
		try {
			return getCfsEJB().getElementAsXml(caseid, true);
		} catch (RemoteException e) {
			LogUtil.logError(m_Logger, message + " " + e.getMessage());
			throw e;
		} catch (FinderException e) {

			throw LogUtil.logException(m_Logger, message,e);
		}

	}

	/**
	 * create case By requestType and main casefolder id.
	 * 
	 * @param mainCaseId
	 * @param requestType
	 * @return new caseId
	 * @throws RemoteException
	 */
	@Override
	public String createChildCase(String mainCaseId, String requestType) throws RemoteException {

		String message = "FunctionName : cretaeCaseByReqType, mainCaseId:" + mainCaseId + " ,requestType:"
				+ requestType;
		LogUtil.logInfo(m_Logger,message + "is enter");

		HashMap<String, String> params = new HashMap<String, String>();
		params.put("REQ_TYPE", requestType);
		params.put("mfCaseId", mainCaseId);
		params.put("noticeMainCase", "true");
		Map<String, Object> result = ScriptUtil.doScript(
				PropertyUtil.getScriptAndQueryProperty("SCRIPT_CREATE_CASEBYREQTYPE"), params, Locale.CHINA,
				getSysSEJB());
		String caseId = result.get("caseid").toString();
		message = message + caseId;
		LogUtil.logInfo(m_Logger,message + "is leave");
		return caseId;
	}

	/**
	 * create master folder used in data migration
	 * 
	 * @param masterFolderName
	 * @param createAmount
	 * @return
	 * @throws RemoteException
	 */
	@Override
	public String dataMigrationCreateMasterFolder(String masterFolderName, String createAmount) throws RemoteException {
		String message = "FunctionName : [ dataMigrationCreateMasterFolder ] , masterFolderName : [" + masterFolderName
				+ " ] . createAmount : [ " + createAmount + " ] .";
		LogUtil.logInfo(m_Logger,message + "is entery");
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		BigDecimal caseFolderID = null;
		try {
			Date date1 = new Date();
			ArrayList templateList = getCfsEJB().getTemplates();
			CaseFolderElement template;
			for (int i = 0; i < templateList.size(); i++) {
				template = (CaseFolderElement) templateList.get(i);
				if (template.getDisplayName().equalsIgnoreCase(masterFolderName)) {
					caseFolderID = template.getCaseFolderID();
					break;
				}
			}
			for (int i = 0; i < Integer.parseInt(createAmount); i++) {
				LogUtil.logInfo(m_Logger,"caseid:" + caseFolderID);
				getCfsEJB().createInstance(caseFolderID, null);
			}
			message = "create masterFolderName: [" + masterFolderName + " ],Start time: [" + df.format(date1)
					+ "] . End time: [" + df.format(new Date()) + "].";
			LogUtil.logInfo(m_Logger,message);
			return message;
		} catch (RemoteException e) {
			throw LogUtil.logException(m_Logger, message,e);
		}

	}

	/**
	 * create case By requestType
	 * 
	 * @param mainCaseId
	 * @param requestType
	 * @return new caseId
	 * @throws RemoteException
	 */
	@Override
	public String cretaeWorkFolderByReqType(String mfCaseId, String requestType, String policyNum)
			throws RemoteException {
		String message = "FunctionName : cretaeWorkFolderByReqType, mainCaseId:" + mfCaseId + " ,requestType:"
				+ requestType + ",policyNum:" + policyNum;
		LogUtil.logInfo(m_Logger,message + "is enter");

		HashMap<String, String> params = new HashMap<String, String>();
		params.put("policyNum", policyNum);
		params.put("reqType", requestType);
		params.put("mfCaseId", mfCaseId);
		Map<String, Object> result = ScriptUtil.doScript(
				PropertyUtil.getScriptAndQueryProperty("SCRIPT_CREATE_WORKFORLDERBYREQTYPE"), params, Locale.CHINA,
				getSysSEJB());
		String caseId = result.get("caseId").toString();
		LogUtil.logInfo(m_Logger,"caseId is " + caseId);
		message = message + caseId;
		LogUtil.logInfo(m_Logger,message + "is leave");
		return caseId;
	}

	@Override
	public String generateReqNo(String lob, String isChild, String parentReqNo) throws RemoteException {
		HashMap<String, String> params = new HashMap<String, String>();
		params.put("lob", lob);
		params.put("isChild", isChild);// true or false
		params.put("parentReqNo", parentReqNo);
		params.put("java", "test");
		Map<String, Object> result = ScriptUtil.doScript("PSO.Util.generateReqNo", params, Locale.CHINA, getSysSEJB());
		return result.get(LOCALREQUESTNUM) == null ? "" : result.get(LOCALREQUESTNUM).toString();
	}

	@Override
	public String checkPolicyFormat(String policyNum) throws RemoteException {
		HashMap<String, String> params = new HashMap<String, String>();
		params.put("policyNum", policyNum);
		Map<String, Object> result = ScriptUtil.doScript("PSO.Util.doPolicyFormat", params, Locale.CHINA, getSysSEJB());
		return result.get("result") == null ? "" : result.get("result").toString();
	}

	@Override
	public String generateDumyPolicy() throws RemoteException {
		HashMap<String, String> params = new HashMap<String, String>();
		params.put("java", "test");
		Map<String, Object> result = ScriptUtil.doScript("PSO.Util.generateDumyPolicy", params, Locale.CHINA,
				getSysSEJB());
		return result.get("POLICY_NUM") == null ? "" : result.get("POLICY_NUM").toString();
	}

	@Override
	public String getProStartActByReqType(String reqType) throws RemoteException {
		HashMap<String, String> params = new HashMap<String, String>();
		params.put("reqType", reqType);
		params.put("java", "test");
		Map<String, Object> result = ScriptUtil.doScript("PSO.Util.getProcessStartActivity", params, Locale.CHINA,
				getSysSEJB());
		return result.get(LOCALREQUESTNUM) == null ? "" : result.get(LOCALREQUESTNUM).toString();
	}

	@Override
	public String convertRequestNo(String requestNo) throws RemoteException {
		HashMap<String, String> params = new HashMap<String, String>();
		params.put("requestNo", requestNo);
		Map<String, Object> result = ScriptUtil.doScript("PSO.Util.convertRequestNo", params, Locale.CHINA,
				getSysSEJB());
		return result.get(LOCALREQUESTNUM) == null ? "" : result.get(LOCALREQUESTNUM).toString();
	}
	
	private String valueIsNull(String value){
      
      if(value==null){
        return "";
      }else if("".equals(value.trim())){
        return "";
      }else if(value.trim().length()==0){
        return "";
      }else{
        return value;
      }

   }
}
