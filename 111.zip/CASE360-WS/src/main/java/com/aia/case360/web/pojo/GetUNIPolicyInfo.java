package com.aia.case360.web.pojo;

import com.aia.case360.web.common.CommonUtil;

public class GetUNIPolicyInfo {
	private String companyCode;
	private String policyNo;
	private String planName;
	private String sumAssured;
	private String currency;
	private String status;
	private String campaignCode;
	private String campaginDescription;
	private String value_UWID;
	private String medCode;
	private String billingChannel;
	private String mode;
	private String modalPremium;
	private String value_CWA;
	private String cWADatelatestdate;
	private String pendingReason;
	private String pendingType;
	private String code_FSC;
	private String name_FSC;
	private String location;
	private String maturityPolicyNo;
	private String maturityDate;
	private String maturityRelationship;
	private String followUpCode;
	private String value_ANP;
	private String value_TSAR;
	private String agencyCode;
	private String agencyName;
	private String code2_FSC;
	private String name2_FSC;
	private String location2;
	private String agencyCode2;
	private String agencyName2;
	private String agencyLeaderEndorsement;
	private String agencyLeaderEndorsementDate;
	private String submissionChannel;
	private String physicalFileReceiptDate;
	private String indicator_CCASE;
	private String indicator_MDRT;

	public String getValue_UWID() {
		return value_UWID;
	}

	public void setValue_UWID(String value_UWID) {
		this.value_UWID = value_UWID;
	}

	public String getValue_CWA() {
		return value_CWA;
	}

	public void setValue_CWA(String value_CWA) {
		this.value_CWA = value_CWA;
	}

	public String getAgencyCode() {
		return agencyCode;
	}

	public void setAgencyCode(String agencyCode) {
		this.agencyCode = agencyCode;
	}

	public String getAgencyName() {
		return agencyName;
	}

	public void setAgencyName(String agencyName) {
		this.agencyName = agencyName;
	}

	public String getCode2_FSC() {
		return code2_FSC;
	}

	public void setCode2_FSC(String code2_FSC) {
		this.code2_FSC = code2_FSC;
	}

	public String getName2_FSC() {
		return name2_FSC;
	}

	public void setName2_FSC(String name2_FSC) {
		this.name2_FSC = name2_FSC;
	}

	public String getLocation2() {
		return location2;
	}

	public void setLocation2(String location2) {
		this.location2 = location2;
	}

	public String getAgencyCode2() {
		return agencyCode2;
	}

	public void setAgencyCode2(String agencyCode2) {
		this.agencyCode2 = agencyCode2;
	}

	public String getAgencyName2() {
		return agencyName2;
	}

	public void setAgencyName2(String agencyName2) {
		this.agencyName2 = agencyName2;
	}

	public String getAgencyLeaderEndorsement() {
		return agencyLeaderEndorsement;
	}

	public void setAgencyLeaderEndorsement(String agencyLeaderEndorsement) {
		this.agencyLeaderEndorsement = agencyLeaderEndorsement;
	}

	public String getAgencyLeaderEndorsementDate() {
		return agencyLeaderEndorsementDate;
	}

	public void setAgencyLeaderEndorsementDate(String agencyLeaderEndorsementDate) {
		this.agencyLeaderEndorsementDate = agencyLeaderEndorsementDate;
	}

	public String getSubmissionChannel() {
		return submissionChannel;
	}

	public void setSubmissionChannel(String submissionChannel) {
		this.submissionChannel = submissionChannel;
	}

	public String getPhysicalFileReceiptDate() {
		return physicalFileReceiptDate;
	}

	public void setPhysicalFileReceiptDate(String physicalFileReceiptDate) {
		this.physicalFileReceiptDate = physicalFileReceiptDate;
	}

	public String getIndicator_CCASE() {
		return indicator_CCASE;
	}

	public void setIndicator_CCASE(String indicator_CCASE) {
		this.indicator_CCASE = indicator_CCASE;
	}

	public String getIndicator_MDRT() {
		return indicator_MDRT;
	}

	public void setIndicator_MDRT(String indicator_MDRT) {
		this.indicator_MDRT = indicator_MDRT;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public String getSumAssured() {
		return sumAssured;
	}

	public void setSumAssured(String sumAssured) {
		this.sumAssured = sumAssured;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCampaignCode() {
		return campaignCode;
	}

	public void setCampaignCode(String campaignCode) {
		this.campaignCode = campaignCode;
	}

	public String getCampaginDescription() {
		return campaginDescription;
	}

	public void setCampaginDescription(String campaginDescription) {
		this.campaginDescription = campaginDescription;
	}

	public String getMedCode() {
		return medCode;
	}

	public void setMedCode(String medCode) {
		this.medCode = medCode;
	}

	public String getBillingChannel() {
		return billingChannel;
	}

	public void setBillingChannel(String billingChannel) {
		this.billingChannel = billingChannel;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public String getModalPremium() {
		return modalPremium;
	}

	public void setModalPremium(String modalPremium) {
		this.modalPremium = modalPremium;
	}

	public String getCWA() {
		return CommonUtil.getString(value_CWA);
	}

	public void setCWA(String cWA) {
		value_CWA = cWA;
	}

	public String getcWADatelatestdate() {
		return cWADatelatestdate;
	}

	public void setcWADatelatestdate(String cWADatelatestdate) {
		this.cWADatelatestdate = cWADatelatestdate;
	}

	public String getPendingReason() {
		return pendingReason;
	}

	public void setPendingReason(String pendingReason) {
		this.pendingReason = pendingReason;
	}

	public String getPendingType() {
		return pendingType;
	}

	public void setPendingType(String pendingType) {
		this.pendingType = pendingType;
	}

	public String getCode_FSC() {
		return code_FSC;
	}

	public void setCode_FSC(String code_FSC) {
		this.code_FSC = code_FSC;
	}

	public String getName_FSC() {
		return name_FSC;
	}

	public void setName_FSC(String name_FSC) {
		this.name_FSC = name_FSC;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getMaturityPolicyNo() {
		return maturityPolicyNo;
	}

	public void setMaturityPolicyNo(String maturityPolicyNo) {
		this.maturityPolicyNo = maturityPolicyNo;
	}

	public String getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(String maturityDate) {
		this.maturityDate = maturityDate;
	}

	public String getMaturityRelationship() {
		return maturityRelationship;
	}

	public void setMaturityRelationship(String maturityRelationship) {
		this.maturityRelationship = maturityRelationship;
	}

	public String getFollowUpCode() {
		return followUpCode;
	}

	public void setFollowUpCode(String followUpCode) {
		this.followUpCode = followUpCode;
	}

	public String getValue_ANP() {
		return value_ANP;
	}

	public void setValue_ANP(String value_ANP) {
		this.value_ANP = value_ANP;
	}

	public String getValue_TSAR() {
		return value_TSAR;
	}

	public void setValue_TSAR(String value_TSAR) {
		this.value_TSAR = value_TSAR;
	}

}
