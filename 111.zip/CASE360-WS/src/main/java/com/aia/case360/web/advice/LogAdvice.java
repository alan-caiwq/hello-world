package com.aia.case360.web.advice;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.commons.lang.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.common.PropertyUtil;
import com.aia.case360.platform.process.WorkItemHelper;
import com.aia.case360.platform.query.QueryHelper;
import com.aia.case360.platform.security.RoleHelper;
import com.aia.case360.platform.security.UserHelper;
import com.aia.case360.web.exception.CustomException;
import com.aia.case360.web.exception.Error;
import com.aia.case360.web.exception.ObjectNotFoundException;
import com.aia.case360.web.pojo.OutputVO;
import com.aia.case360.web.service.CaseSubmissionService;

import net.sf.json.JSONObject;

/**
 * 
 * 2018/09/10 CASEPP-8933 Select a main logical document on the customer tree to
 * copy,copy from list displays incorrectly. mod by bsnpc1n 2018/09/10
 * CASEPP-8934 Select a main logical document on the customer tree to reindex,
 * reindex from list displays incorrectly. mod by bsnpc1n
 */
@Aspect
public class LogAdvice {

	private static final String LOCALUNPEND_WORK_ITEM = "unpendWorkItem";

	@Autowired
	public RoleHelper roleHelper;
	
	@Autowired
	public UserHelper userHelper;

	@Autowired
	public WorkItemHelper workItemHelper;

	@Autowired
	public QueryHelper queryHelper;

	@Autowired
	private CaseSubmissionService caseSubmissionService;

	private Logger m_Logger = LoggerFactory.getLogger(getClass());


	@Pointcut("execution(public org.springframework.http.ResponseEntity com.aia.case360.web.webservice..*.*(..))")
	public void process() {
		// NOSONAR
	}

	@Around("process()")
	public Object beforeProcess(ProceedingJoinPoint jp)  throws RemoteException {

		// ***********************Albert update start.**************
		// Added by Albert on 20180806.
		// Description:controller Aspect to validate the case owner against button click
		// action.
		//

		org.aspectj.lang.Signature signature = jp.getSignature();
		MethodSignature methodSignature = (MethodSignature) signature;
		String methodName = signature.getName();

		// init button list
		init();

		try {
				Object obj = doValidateOwnerButton(jp, methodSignature, methodName);
				if(obj != null){
					return obj;
				}
		} catch (RemoteException e) {

			LogUtil.logException(m_Logger, "WorkItemControllerAspect", e);
			 LogUtil.logInfo(m_Logger, methodName + ":" + e.getMessage());
			return new ResponseEntity<JSONObject>(JSONObject.fromObject(new Error(e.getMessage())),
					HttpStatus.INTERNAL_SERVER_ERROR);

		} catch (Exception e) {

			LogUtil.logException(m_Logger,String.format("%s-WorkItemControllerAspect{}",methodName), e);
			return new ResponseEntity<JSONObject>(JSONObject.fromObject(new Error(e.getMessage())),
					HttpStatus.INTERNAL_SERVER_ERROR);

		}

		// ***********************Albert update end.**************

		Object result = null;
		// get UUID
		String uuidStr = getReqUUID();

		// get service name
		String className = jp.getTarget().getClass().getName();
		String serviceName = uuidStr + ":" + className + "#" + methodName;

		// arguments
		Object[] args = jp.getArgs();
		StringBuilder arguments = new StringBuilder("Input arguments:");
		for (Object arg : args) {
			arguments.append(arg + " ");
		}

		try {
			 result = doSearchLogic(jp, methodName, serviceName, args, arguments);
		} catch (ObjectNotFoundException e) {
			LogUtil.logException(m_Logger,serviceName + " : " + arguments, e);
			return new ResponseEntity<JSONObject>(JSONObject.fromObject(e.getError()), e.getStatus());
		} catch (CustomException e) {
			LogUtil.logException(m_Logger,serviceName + " : " + arguments, e);
			return new ResponseEntity<JSONObject>(JSONObject.fromObject(e.getError()), e.getStatus());
		} catch (RemoteException e) {
			LogUtil.logException(m_Logger,serviceName + " : " + arguments, e);
			return new ResponseEntity<JSONObject>(JSONObject.fromObject(new Error(e.getMessage())),
					HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (Exception e) {
			LogUtil.logException(m_Logger,serviceName + " : " + arguments, e);
			return new ResponseEntity<JSONObject>(JSONObject.fromObject(new Error(e.getMessage())),
					HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (Throwable e) {
			LogUtil.logException(m_Logger,serviceName + " : " + arguments, e);
			return new ResponseEntity<JSONObject>(JSONObject.fromObject(new Error(e.getMessage())),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return result;
	}

	@SuppressWarnings("unchecked")
	private Object doSearchLogic(ProceedingJoinPoint jp, String methodName,
			String serviceName, Object[] args, StringBuilder arguments)
			throws Throwable {
		Object result;
		LogUtil.logInfo(m_Logger, serviceName + " arguments: " + arguments.toString() + " start");
		// 2018/09/10 CASEPP-8933 Select a main logical document on the customer tree to
		// copy,copy from list displays incorrectly. mod by bsnpc1n
		// 2018/09/10 CASEPP-8934 Select a main logical document on the customer tree to
		// reindex, reindex from list displays incorrectly. mod by bsnpc1n
		// nric encode
		if ("doSearch".equals(methodName)) {
		  Object queryName = "";
			if (args.length > 0) {
		    queryName = args[0];
		  }
			 LogUtil.logInfo(m_Logger, "logAdvice queryName:" + queryName);
			if ("getDocClient".equals(queryName)) {
				 result = queryNameEqGetDocClient(jp, args);
			} else {
		    result = jp.proceed();
		  }
		} else {
		  result = jp.proceed();
		}

		if(result instanceof OutputVO) {
		  if("1".equals(((OutputVO) result).getCode())) {
		    LogUtil.logInfo(m_Logger, serviceName + " end with result:" +result);
		  }
		  else {
		    LogUtil.logInfo(m_Logger, serviceName + " end");
		  }
		}
		else {
		  LogUtil.logInfo(m_Logger, serviceName + " end");
		}
		return result;
	}

	private Object queryNameEqGetDocClient(ProceedingJoinPoint jp, Object[] args)
			throws Throwable {
		Object result;
		LogUtil.logInfo(m_Logger, "logAdvice getDocClient");
		for (Object argsItem : args) {
			if (argsItem instanceof Map) {
				Object nricStr = ((Map<String, Object>) argsItem).get("NRIC");
				 LogUtil.logInfo(m_Logger, "JSONObject nricStr:" + nricStr);
				 LogUtil.logInfo(m_Logger, "JSONObject nricStr:" + nricStr);
				if (nricStr != null) {
					 LogUtil.logInfo(m_Logger, "before doEncrypt");
		      String hashStr = doEncrypt(String.valueOf(nricStr)).get("hashStr");
					if (hashStr == null) {
		        hashStr = "";
		      }
					 LogUtil.logInfo(m_Logger, "JSONObject hashStr:" + hashStr);
					((Map<String, Object>) argsItem).put("NRIC", hashStr);
		    }
		}
     }
   result = jp.proceed(args);
		return result;
	}

	private Object doValidateOwnerButton(ProceedingJoinPoint jp,
			MethodSignature methodSignature, String methodName)
			throws RemoteException {
		String auto;
		boolean hasAuto = false;
		// only click action of button list will be validate processor
		if (methodList.contains(methodName)) {
			String userId = userHelper.getCurrentUser();
			String caseId = null;
			String repositorykey = null;
			 LogUtil.logInfo(m_Logger , "methodName:" + methodName + " matched.");
			for (Object argsItem : jp.getArgs()) {
				if (argsItem instanceof JSONObject) {
					JSONObject args = (JSONObject) argsItem;

					repositorykey = (String) getValueByKeyFromJsonObj(args,
							PropertyUtil.getCommonProperty("REPOSITORYKEY"));

					caseId = getCaseId(caseId, repositorykey, args);

					auto = (String) getValueByKeyFromJsonObj(args, "AUTO");
					if ("AUTO".equals(auto)) {
						hasAuto = true;
					}

				}

			}

			String[] strings = methodSignature.getParameterNames();
			int paramIndex = 0;
			caseId = doGetCaseId(jp, caseId, strings, paramIndex);

			OutputVO output = new OutputVO();
			output.setCode("1");
			output.setMessage("Access Denied");

		     LogUtil.logInfo(m_Logger,"repositorykey:" + repositorykey + ";CaseID:" + caseId);
			ResponseEntity responseEntity = validateProcess(methodName, hasAuto, userId, caseId, repositorykey,
					output);
			if(responseEntity != null){
				return responseEntity;
			}
			
		}
		return null;
	}

	private ResponseEntity validateProcess(String methodName, boolean hasAuto,
			String userId, String caseId, String repositorykey, OutputVO output) throws RemoteException {
		if ((caseId == null || "".equals(caseId)) && repositorykey != null && "".equals(repositorykey)) {

			if (!(methodName.equals(LOCALUNPEND_WORK_ITEM) && hasAuto)
					&& !validateProcessorByRepositorykey(repositorykey, userId)) {
				return new ResponseEntity<JSONObject>(JSONObject.fromObject(new Error("Access Denied.")),
						HttpStatus.OK);

			}
		} else if (caseId != null && !"".equals(caseId)) {
			 LogUtil.logInfo(m_Logger, "validateProcessorByCaseID:Start.");
			if (!(methodName.equals(LOCALUNPEND_WORK_ITEM) && hasAuto)
					&& !validateProcessorByCaseID(caseId, userId)) {
				 LogUtil.logInfo(m_Logger, "validateProcessorByCaseID:failed.");
				return new ResponseEntity<Map<String, Object>>(output.toMap(), HttpStatus.OK);

			}
		}

		 LogUtil.logInfo(m_Logger, methodName + ":" + methodName);
		return null;
	}

	private String doGetCaseId(ProceedingJoinPoint jp, String caseId,
			String[] strings, int paramIndex) {
		if (strings != null && caseId == null) {
			for (String paramName : strings) {

				if ("linkcaseId".equals(paramName)) {
					caseId = (String) jp.getArgs()[paramIndex];
					break;
				}
				paramIndex++;
			}
		    LogUtil.logInfo(m_Logger,"paramName caseId:" + caseId);
		}
		return caseId;
	}

	private String getCaseId(String caseId, String repositorykey, JSONObject args) {
		if (repositorykey == null) {
			caseId = (String) getValueByKeyFromJsonObj(args, "LINKCASEID");
		}

		if (caseId == null || "".equals(caseId)) {
			caseId = (String) getValueByKeyFromJsonObj(args, "CASE_ID");
		}

		if (caseId == null || "".equals(caseId)) {
			caseId = (String) getValueByKeyFromJsonObj(args, "CASEFOLDERID");
		}
		 LogUtil.logInfo(m_Logger, "JSONObject caseId:" + caseId);
		return caseId;
	}

	public synchronized String getReqUUID() {
		return UUID.randomUUID().toString().replaceAll("-", "");
	}

	/**
	 * processor validation. Albert 20180803
	 * 
	 * 
	 */
	private List<String> methodList = null;
	//
	private ReentrantLock lock = new ReentrantLock();

	/**
	 * init buttion action list that need to validate processor.
	 *
	 */
	private void init() {

			lock.lock();
			try {
				if (methodList == null) {
					methodList = new ArrayList<String>();

					// checked REPOSITORYKEY
					methodList.add("touchcase");



					// checked LINKCASEID
					methodList.add("closeWorkItem");

					// checked CASEFOLDERID
					methodList.add("reClassify");

					// checked LINKCASEID
					methodList.add("forwardWorkitem");

					// checked REPOSITORYKEY
					methodList.add("reverseWorkItem");

					// checked LINKCASEID
					methodList.add("SendEmail");

					// checked LINKCASEID
					methodList.add("resolvePendingReason");

					// checked LINKCASEID
					methodList.add("resolveAll");

					// checked LINKCASEID
					methodList.add(LOCALUNPEND_WORK_ITEM);

					// checked LINKCASEID
					methodList.add("pendWorkItem");


					// checked LINKCASEID
					methodList.add("savePendingReasons");

					// checked LINKCASEID
					methodList.add("referWorkitem");


					// checked LINKCASEID
					methodList.add("saveWorkitem");

					// checked REPOSITORYKEY
					methodList.add("submitWorkitem");


					// checked CASE_ID
					methodList.add("sendApprovalEmail");


				}

			} finally {
				lock.unlock();
			}

		}

	private boolean validateProcessorByRepositorykey(String repositorykey, String user) throws RemoteException {

		if (user == null) {
			return false;
		}

		Map<String, Object> wiDetail = null;
		try {
			wiDetail = workItemHelper.getWorkItemDetail(repositorykey);
		} catch (RemoteException e) {
			 LogUtil.logException(m_Logger, repositorykey, e);
		}
		String currentOwner = "";
		if (wiDetail != null) {
			currentOwner = (String) wiDetail.get("PROCESSOR");
		}
		return (validateUserAdminRole(user) || user.equalsIgnoreCase(currentOwner));
	}

	public boolean validateProcessorByCaseID(String linkcaseid, String user) throws RemoteException {
		Map<Integer, Object> map = new HashMap<Integer, Object>();
		map.put(1, linkcaseid);
		String res = queryHelper.callProcedureGetSingleValue(map, "{call sp_getProcessor(?)}");
		 LogUtil.logInfo(m_Logger, "validateProcessor result:" + res);
		if ((user != null && user.equalsIgnoreCase(res)) || validateUserAdminRole(user)) {

			return true;
		}
		return false;
	}
	public boolean validateUserAdminRole(String user) throws RemoteException {
		List<String> roleList = roleHelper.getMyOwnRoles(user);
		for(String role : roleList){
			if("Admin".equalsIgnoreCase(role)){
				return true;
			}
		}
		return false;
	}
	private Object getValueByKeyFromJsonObj(JSONObject args, String Key) {
		if (args.containsKey(Key)) {
			return args.get(Key);
		}
		return null;
	}

	private Map<String, String> doEncrypt(String nric) {
	     Map<String, String> encryptResult = new HashMap<>();
	     String[] encryptValue = null;
	     try {
			 LogUtil.logInfo(m_Logger, "before encryptValue");
	         encryptValue = StringUtils.isNotEmpty(nric) ? caseSubmissionService.encryptValue(nric) : null;
			 LogUtil.logInfo(m_Logger, "encryptValue:" + encryptValue);
	         encryptResult.put("nric", encryptValue != null && encryptValue.length == 3 ? encryptValue[1] : null);
	         encryptResult.put("hashStr", encryptValue != null && encryptValue.length == 3 ? encryptValue[2] : null);
	     } catch (Exception e) {
			LogUtil.logException(m_Logger,"in doEncrypt method:", e);
	     }
		return encryptResult;
	 }

}
