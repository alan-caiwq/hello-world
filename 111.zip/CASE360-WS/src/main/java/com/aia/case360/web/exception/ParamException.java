package com.aia.case360.web.exception;

import org.springframework.http.HttpStatus;

public class ParamException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	private String id;

	private Error error;

	private HttpStatus status;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Error getError() {
		return error;
	}

	public void setError(Error error) {
		this.error = error;
	}

	public HttpStatus getStatus() {
		return status;
	}

	public void setStatus(HttpStatus status) {
		this.status = status;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public ParamException(String id) {
		super("the parameter [" + id +"] is null");
		this.id = id;
		this.error = new Error("the parameter [" + id +"] is null");
		this.status = HttpStatus.NOT_FOUND;
	}
	
	public ParamException(String message, HttpStatus status) {
		super(message);
		this.error = new Error(message);
		this.status = status;
	}

	
}
