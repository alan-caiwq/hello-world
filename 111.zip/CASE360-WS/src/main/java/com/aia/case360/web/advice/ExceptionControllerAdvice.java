package com.aia.case360.web.advice;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.servlet.NoHandlerFoundException;

@ControllerAdvice
@ResponseBody
public class ExceptionControllerAdvice {

	private static final String LOCALERROR = "error";
	private Logger m_Log = LoggerFactory.getLogger(getClass());

	@ExceptionHandler(NoHandlerFoundException.class)
	public ResponseEntity<Map<String, String>> handleResourceNotFoundException(NoHandlerFoundException e,
			HttpServletRequest request) {
		m_Log.error(request.getRequestURL().toString(), e);
		Map<String, String> errorMap = new HashMap<String, String>();
		errorMap.put(LOCALERROR, "URL Not Found(" + request.getRequestURL().toString() + ")");
		return new ResponseEntity<Map<String, String>>(errorMap, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<Map<String, String>>RemoteExceptionHandler(Exception e, HttpServletRequest request) {
		Map<String, String> errorMap = new HashMap<String, String>();
		errorMap.put(LOCALERROR, String.valueOf(e.getMessage()));
		logException(e, request);
		return new ResponseEntity<Map<String, String>>(errorMap, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(MaxUploadSizeExceededException.class)
	public ResponseEntity<Map<String, String>> handleException(MaxUploadSizeExceededException e,
			HttpServletRequest request) {
		Map<String, String> errorMap = new HashMap<String, String>();
		errorMap.put(LOCALERROR, "Document size exceeds the limitation(10M)");
		logException(e, request);
		return new ResponseEntity<Map<String, String>>(errorMap, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	private void logException(Throwable e, HttpServletRequest request) {
		String uuidStr = String.valueOf(request.getAttribute("uuidStr"));
		String serviceName = String.valueOf(request.getAttribute("serviceName"));
		m_Log.error(uuidStr + " " + serviceName + ":", e);
	}

}
