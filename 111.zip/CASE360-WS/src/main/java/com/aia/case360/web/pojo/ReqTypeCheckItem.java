package com.aia.case360.web.pojo;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import com.aia.case360.web.auditTrail.AuditEntityIgnoreCondition;
import com.aia.case360.web.auditTrail.AuditFieldSpecialAction;
import com.aia.case360.web.auditTrail.AuditFileTypeEnum;
import com.aia.case360.web.auditTrail.AuditTrail;
import com.aia.case360.web.auditTrail.annotation.AuditEntity;
import com.aia.case360.web.auditTrail.annotation.AuditField;
import com.aia.case360.web.common.CommonUtil;
import com.fasterxml.jackson.annotation.JsonFormat;

@AuditEntity(entityName = "Check Item", formDataName = "Request type audit trail", tableName = "FD_REQTYPE_AUDITTRAIL")
public class ReqTypeCheckItem implements AuditTrail {
	private String acl;
	private BigDecimal sRowid;

	@AuditField(fieldName = "Work Step Name", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private String workstepname;
	private String createdBy;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	private Date effectiveDate;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	private Date createdTimestamp;
	private String lastUpdatedBy;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	private Date lastUpdatedTimestamp;

	@AuditField(fieldName = "Sequence", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private int sequenceNum;
	@AuditField(fieldName = "Check Item Name", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private String checkItemNm;

	@AuditField(fieldName = "Help Text", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private String helpText;

	@AuditField(fieldName = "Is Mandatory", fieldType = AuditFileTypeEnum.KEY_FIELD)
	private short isMandatory;
	private String reqType;
	private int versionNum;

	public ReqTypeCheckItem(String reqType, int versionNum) {
		super();
		this.reqType = reqType;
		this.versionNum = versionNum;
	}

	public ReqTypeCheckItem() {
		super();
	}

	public String getAcl() {
		return acl;
	}

	public void setAcl(String acl) {
		this.acl = acl;
	}

	public BigDecimal getsRowid() {
		return sRowid;
	}

	public void setsRowid(BigDecimal sRowid) {
		this.sRowid = sRowid;
	}

	public String getWorkstepname() {
		return workstepname;
	}

	public void setWorkstepname(String workstepname) {
		this.workstepname = workstepname;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Date lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public int getSequenceNum() {
		return sequenceNum;
	}

	public void setSequenceNum(int sequenceNum) {
		this.sequenceNum = sequenceNum;
	}

	public String getCheckItemNm() {
		return checkItemNm;
	}

	public void setCheckItemNm(String checkItemNm) {
		this.checkItemNm = checkItemNm;
	}

	public String getHelpText() {
		return helpText;
	}

	public void setHelpText(String helpText) {
		this.helpText = helpText;
	}

	public short getIsMandatory() {
		return isMandatory;
	}

	public void setIsMandatory(short isMandatory) {
		this.isMandatory = isMandatory;
	}

	public String getReqType() {
		return reqType;
	}

	public void setReqType(String reqType) {
		this.reqType = reqType;
	}

	public int getVersionNum() {
		return versionNum;
	}

	public void setVersionNum(int versionNum) {
		this.versionNum = versionNum;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	@Override
	public String toString() {
		return "ReqTypeCheckItem [acl=" + acl + ", sRowid=" + sRowid + ", workstepname=" + workstepname + ", createdBy="
				+ createdBy + ", createdTimestamp=" + createdTimestamp + ", lastUpdatedBy=" + lastUpdatedBy
				+ ", lastUpdatedTimestamp=" + lastUpdatedTimestamp + ", sequenceNum=" + sequenceNum + ", checkItemNm="
				+ checkItemNm + ", helpText=" + helpText + ", isMandatory=" + isMandatory + ", reqType=" + reqType
				+ ", effectiveDate=" + effectiveDate + ", versionNum=" + versionNum + "]";
	}

	@Override
	public List<AuditFieldSpecialAction> registFieldSpecialActionlist() {
		List<AuditFieldSpecialAction> rs = null;
		return rs;
	}

	@Override
	public BigDecimal getRowID() {
		if(sRowid != null && sRowid.intValue() > 0){
			return sRowid;
		}
		return null;
	}

	@Override
	public String getKeyDisplayName() {
		// TODO Auto-generated method stub
		return getCheckItemNm();
	}

	@Override
	public String getKey() {
		return CommonUtil.getString(reqType);
	}

	@Override
	public List<AuditEntityIgnoreCondition> registIgnoreEntitylist() {
		// TODO Auto-generated method stub
		List<AuditEntityIgnoreCondition> rs = null;
		return rs;
	}

}
