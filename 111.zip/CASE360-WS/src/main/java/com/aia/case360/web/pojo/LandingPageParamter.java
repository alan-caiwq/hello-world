package com.aia.case360.web.pojo;

public class LandingPageParamter {
	// secuityNo
	private String secuityNo;
	// policyNo
	private String policyNo;
	// mClaimNo
	private String mClaimNo;

	public String getSecuityNo() {
		return secuityNo;
	}

	public void setSecuityNo(String secuityNo) {
		this.secuityNo = secuityNo;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getmClaimNo() {
		return mClaimNo;
	}

	public void setmClaimNo(String mClaimNo) {
		this.mClaimNo = mClaimNo;
	}

}
