package com.aia.case360.web.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.aia.case360.web.pojo.CaseAuditTrailVO;

@Repository
public interface CaseAuditDao {
	public void batchCreateCaseAudit(List<CaseAuditTrailVO> caseAuditTrailList);

	public void createCaseAudit(CaseAuditTrailVO caseAuditTrail);

	public List<String> getTL(String userId);

	public List<String> getLevelPesonnel(Map<String, String> param);
}
