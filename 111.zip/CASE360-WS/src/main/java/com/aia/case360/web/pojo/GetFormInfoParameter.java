package com.aia.case360.web.pojo;

import java.io.Serializable;

public class GetFormInfoParameter implements Serializable {
	// callingSystem
	private String callingSystem;
	private String formCategory;

	public String getFormCategory() {
		return formCategory;
	}

	public void setFormCategory(String formCategory) {
		this.formCategory = formCategory;
	}

	public String getCallingSystem() {
		return callingSystem;
	}

	public void setCallingSystem(String callingSystem) {
		this.callingSystem = callingSystem;
	}

}
