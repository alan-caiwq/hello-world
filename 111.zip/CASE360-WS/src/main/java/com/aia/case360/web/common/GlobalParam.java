package com.aia.case360.web.common;
/**
 * 
 * @author bsnpc37 (Leo Li)
 *
 */
public class GlobalParam {
	private GlobalParam() {
		
	}
	//for uploadDocument cache limit size
	private static String FILE_SIZE_CHANGE_DATE = "";
	private static  float LIMIT_FILE_SIZE = 0F;
	public static String getFILE_SIZE_CHANGE_DATE() {
		return FILE_SIZE_CHANGE_DATE;
	}
	public static void setFILE_SIZE_CHANGE_DATE(String fILE_SIZE_CHANGE_DATE) {
		FILE_SIZE_CHANGE_DATE = fILE_SIZE_CHANGE_DATE;
	}
	public static float getLIMIT_FILE_SIZE() {
		return LIMIT_FILE_SIZE;
	}
	public static void setLIMIT_FILE_SIZE(float lIMIT_FILE_SIZE) {
		LIMIT_FILE_SIZE = lIMIT_FILE_SIZE;
	}
	
}
