package com.aia.case360.JalDocsInterfacesEx.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.xml.sax.SAXException;

import com.aia.case360.platform.common.LogUtil;

public class ImportXmlUtil {

	private ImportXmlUtil() {}
	private static Logger m_Logger = LoggerFactory.getLogger(ImportXmlUtil.class.getClass());

	private static final String SPEC_CHAR = "%SPACE%";

	/**
	 * Decode the field require with value "Y" to true
	 * 
	 * @param strRequire
	 * @return
	 */
	public static boolean decodeRequire(String strRequire) {

		boolean bRequire = false;

		if (strRequire != null && strRequire.equals("Y")) {
			bRequire = true;
		}

		return bRequire;
	}

	/**
	 * Replace the special charactor with a " ".
	 * 
	 * @param inputStr
	 * @return
	 */
	public static String decodeXMLSpecChr(String inputStr) {

		String modifiedStr = "";

		if (inputStr != null) {
			modifiedStr = inputStr.replaceAll(SPEC_CHAR, " ").trim();
		}

		return modifiedStr;
	}

	/**
	 * Get the first node by xpath from the input starting node
	 * 
	 * @param startNode
	 * @param xpathStr
	 * @return
	 * @throws FwException
	 */
	public static Node getNodeByXpath(Node startNode, String xpathStr) throws RemoteException {

		Node node = null;

		try {
			XPathFactory factory = XPathFactory.newInstance();
			XPath xpath = factory.newXPath();

			XPathExpression expr = xpath.compile(xpathStr);

			node = (Node) expr.evaluate(startNode, XPathConstants.NODE);

		} catch (XPathExpressionException e) {
			 LogUtil.logException(m_Logger, xpathStr, e);
		}

		return node;
	}

	/**
	 * Get the node list by xpath from the input starting node
	 * 
	 * @param startNode
	 * @param xpathStr
	 * @return
	 * @throws FwException
	 */
	public static NodeList getNodeListByXpath(Node startNode, String xpathStr) throws RemoteException {

		NodeList nodeList = null;

		try {
			XPathFactory factory = XPathFactory.newInstance();
			XPath xpath = factory.newXPath();

			XPathExpression expr = xpath.compile(xpathStr);

			nodeList = (NodeList) expr.evaluate(startNode, XPathConstants.NODESET);

		} catch (XPathExpressionException e) {
			 LogUtil.logException(m_Logger, xpathStr, e);
		}

		return nodeList;
	}

	/**
	 * Get List by Xpath from the starting node
	 * 
	 * @param startNode
	 * @param xpathStr
	 * @param attribute
	 * @return
	 * @throws FwException
	 */
	public static List getListByXpath(Node startNode, String xpathStr, String attribute) throws RemoteException {

		List nodeTextValList = new ArrayList();

		try {
			NodeList nodeList = getNodeListByXpath(startNode, xpathStr);

			if (nodeList != null) {
				for (int i = 0; i < nodeList.getLength(); i++) {
					Node node = nodeList.item(i);

					if (node != null) {
						String nodeTextVal = node.getAttributes().getNamedItem(attribute).getNodeValue();
						nodeTextValList.add(nodeTextVal);
					}
				}
			}
		} catch (Exception e) {
			 LogUtil.logException(m_Logger, xpathStr, e);
		}

		return nodeTextValList;
	}

	/**
	 * Get the node text value List by xpath from the starting node
	 * 
	 * @param startNode
	 * @param xpathStr
	 * @return
	 * @throws FwException
	 */
	public static List getNodeTextValListByXpath(Node startNode, String xpathStr) throws RemoteException {

		List nodeTextValList = new ArrayList();

		try {
			XPathFactory factory = XPathFactory.newInstance();
			XPath xpath = factory.newXPath();

			XPathExpression expr = xpath.compile(xpathStr);

			NodeList nodeList = (NodeList) expr.evaluate(startNode, XPathConstants.NODESET);

			if (nodeList != null) {
				for (int i = 0; i < nodeList.getLength(); i++) {
					Node node = nodeList.item(i);

					if (node != null) {
						String nodeTextVal = getNodeTextVal(node);

						nodeTextValList.add(nodeTextVal);
					}
				}
			}

		} catch (XPathExpressionException e) {
			 LogUtil.logException(m_Logger, xpathStr, e);
		}

		return nodeTextValList;
	}

	/**
	 * Get the index node text value list under the doc of the input folder node.
	 * Only index with the input index name will be returned.
	 * 
	 * @param startNode
	 * @param indexName
	 * @return
	 * @throws FwException
	 */
	public static List getNodeTextValListByDocIndexName(Node startNode, String indexName) throws RemoteException {

		List nodeTextValList = getNodeTextValListByXpath(startNode, "DOC/INDEX[@NAME='" + indexName + "']");

		return nodeTextValList;
	}

	/**
	 * Get the node text value by xpath from the starting node
	 * 
	 * @param startNode
	 * @param xpathStr
	 * @return
	 * @throws FwException
	 */
	public static String getNodeTextValByXpath(Node startNode, String xpathStr) throws RemoteException {

		String textVal = "";

		if (startNode != null) {
			Node resultNode = getNodeByXpath(startNode, xpathStr);
			textVal = getNodeTextVal(resultNode).trim();
		}
		return textVal;
	}

	/**
	 * Get the index node test value by the input index name. Starting form the
	 * start node.
	 * 
	 * @param startNode
	 * @param indexName
	 * @return
	 * @throws FwException
	 */
	public static String getNodeTextValByIndexName(Node startNode, String indexName) throws RemoteException {

		String textVal = ImportXmlUtil.getNodeTextValByXpath(startNode, "INDEX[@NAME='" + indexName + "']");

		return textVal;
	}

	/**
	 * Get the node text value of the input element node
	 * 
	 * @param elemNode
	 * @return
	 * @throws FwException
	 */
	public static String getNodeTextVal(Node elemNode) throws RemoteException {

		String textVal = "";

		if (elemNode != null && elemNode instanceof Element) {
			Node elemTextNode = elemNode.getFirstChild();
			if (elemTextNode != null && elemTextNode.getNodeType() == Node.TEXT_NODE) {
				textVal = decodeXMLSpecChr(((Text) elemTextNode).getNodeValue());
			}
		}
		return textVal;
	}

	/**
	 * append the a new element node with input element name and the input text
	 * value
	 * 
	 * @param doc
	 * @param parentNode
	 * @param newElemName
	 * @param textVal
	 * @throws FwException
	 */
	public static void appendNodeWithTextVal(Document doc, Node parentNode, String newElemName, String textVal)
			throws RemoteException {

		Element elem = doc.createElement(newElemName);

		elem.appendChild(doc.createTextNode(textVal));

		parentNode.appendChild(elem);
	}

	/**
	 * Append the input element node with input test value
	 * 
	 * @param doc
	 * @param elemNode
	 * @param textVal
	 * @throws FwException
	 */
	public static void appendNodeTextVal(Document doc, Node elemNode, String textVal) throws RemoteException {

		if (elemNode != null && elemNode instanceof Element) {
			elemNode.appendChild(doc.createTextNode(textVal));
		}
	}

	/**
	 * Copy the text value from the original node to the destination node
	 * 
	 * @param originNode
	 * @param destinationNode
	 * @param doc
	 * @throws FwException
	 */
	public static void copyNewNodeTextVal(Node originNode, Node destinationNode, Document doc) throws RemoteException {

		String originText = getNodeTextVal(originNode);

		appendNodeTextVal(doc, destinationNode, originText);
	}

	/**
	 * Get all the text value from the child node of the input node
	 * 
	 * @param startNode
	 * @return
	 * @throws FwException
	 */
	public static String getAllChildTextVal(Node startNode) throws RemoteException {

		String textVal = "";

		if (startNode != null) {
			Node childNode = startNode.getFirstChild();
			while (childNode != null) {
				if (childNode.getNodeType() == Node.TEXT_NODE) {
					textVal += decodeXMLSpecChr(((Text) childNode).getNodeValue().trim()).replaceAll("\n", "");
				} else {
					textVal += getAllChildTextVal(childNode);
				}
				childNode = childNode.getNextSibling();
			}
		}
		return textVal;
	}

	/**
	 * Set the node with the input text value
	 * 
	 * @param elemNode
	 * @param textVal
	 * @throws FwException
	 */
	public static void setNodeTextVal(Node elemNode, String textVal) throws RemoteException {

		if (elemNode != null && elemNode instanceof Element) {
			Node elemTextNode = elemNode.getFirstChild();
			if (elemTextNode.getNodeType() == Node.TEXT_NODE) {
				((Text) elemTextNode).setNodeValue(textVal.trim());
			}
		}
	}

	/**
	 * Load the xml from the input stream to the buffer
	 * 
	 * @param is
	 * @return
	 * @throws FwException
	 */
	public static Document loadXML(InputStream is) throws RemoteException {

		Document doc = null;
		try {
			DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
			domFactory.setNamespaceAware(true);
			DocumentBuilder builder = domFactory.newDocumentBuilder();
			doc = builder.parse(is);

		} catch (FileNotFoundException e) {
			 LogUtil.logException(m_Logger, "", e);
		} catch (ParserConfigurationException e) {
			LogUtil.logException(m_Logger, "", e);
		} catch (SAXException e) {
			LogUtil.logException(m_Logger, "", e);
		} catch (IOException e) {
			LogUtil.logException(m_Logger, "", e);
		}
		return doc;
	}

	/**
	 * Create a new xml document
	 * 
	 * @return
	 * @throws FwException
	 */
	public static Document createDoc() throws RemoteException {

		Document doc = null;
		try {
			DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
			domFactory.setNamespaceAware(true);
			DocumentBuilder builder = domFactory.newDocumentBuilder();
			doc = builder.newDocument();

		} catch (ParserConfigurationException e) {
			 LogUtil.logException(m_Logger, "", e);
		}
		return doc;
	}

	/**
	 * Get the value of the input tag element from the input xml document
	 * 
	 * @param doc
	 * @param tagname
	 * @return
	 * @throws FwException
	 */
	public static String getTagElementValue(Document doc, String tagname) throws RemoteException {

		String elementVal = ((Element) doc.getElementsByTagName(tagname).item(0)).getAttribute("name");

		return elementVal;
	}

	/**
	 * Print the node for debuging purpose.
	 * 
	 * @param startNode
	 * @return
	 * @throws FwException
	 */
	public static String print(Node startNode) throws RemoteException {

		String textVal = "";
		String name = "";
		if (startNode != null) {
			Node childNode = startNode.getFirstChild();

			while (childNode != null) {
				if (childNode.getNodeType() == Node.TEXT_NODE) {

					textVal += decodeXMLSpecChr(((Text) childNode).getNodeValue().trim()) + "\n";
				} else {
					if (childNode.getAttributes().getNamedItem("NAME") != null)
						name = childNode.getAttributes().getNamedItem("NAME").getNodeValue();
					if (name == null)
						name = "";
					textVal += "<" + childNode.getNodeName() + " NAME=" + name + ">";
					textVal += print(childNode);
				}
				childNode = childNode.getNextSibling();
			}
		}
		return textVal;
	}

}
