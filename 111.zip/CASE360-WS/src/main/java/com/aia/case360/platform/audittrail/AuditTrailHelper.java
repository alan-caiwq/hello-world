package com.aia.case360.platform.audittrail;

import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;

/**
 * 
 * 
 * Audit Trail have ActivityName:userId pairs to trace
 * 
 * @author bsnpbdu
 *
 */
public interface AuditTrailHelper {

	public boolean appendToAuditTrail(Map<String, String> fldPairs) throws RemoteException, SQLException;

	public Map<String, String> getUserIdTrace(String caseId) throws RemoteException;

	public boolean createAuditTrail(String caseId, String auditTrailReason, String userId, String rpKeyStr)
			throws RemoteException, SQLException;

	public boolean createAuditTrail(String caseId, String auditTrailReason, String userId, String rpKeyStr,
			String flpUserName) throws RemoteException, SQLException;

	public ArrayList<Map<String, Object>> getBackLogReport(String reportType) throws RemoteException;
}