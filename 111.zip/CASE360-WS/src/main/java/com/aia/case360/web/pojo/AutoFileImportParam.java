package com.aia.case360.web.pojo;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;


public class AutoFileImportParam {
  
  @NotNull(message="filePath is invalid.")
  private String filePath;
  
  private Integer pageNum;
  
  private String submitChannel;
  
  @NotNull(message="txtID is invalid.")
  private String txtID;
  
  @NotNull(message="printFlag is invalid.")
  private String printFlag;

  private String objectName;
  
  @NotNull(message="omsRequestNo is invalid.")
  private String omsRequestNo;
  
  @NotNull(message="cycleDate is invalid.")
  private String cycleDate;

  @Pattern(regexp = "^01[1|4]$", message = "compNo is invalid.")
  private String compNo;

  @NotNull(message="policyNo is invalid.")
  private String policyNo;
  
  @NotNull(message="sourceSys is invalid.")
  private String sourceSys;
  
  @NotNull(message="processType is invalid.")
  private String processType;
  
  @NotNull(message="formId is invalid.")
  private String formId;
  
  @NotNull(message="logicalLinkFormId is invalid.")
  private String logicalLinkFormId;
  
  @Pattern(regexp = "^[Y|N|y|n]$", message = "matchReq is invalid.")
  private String matchReq;

  @NotNull(message="ilCode is invalid.")
  private String ilCode;

  @NotNull(message="docType is invalid.")
  private String docType;
  /**
   * @return the filePath
   */
  public String getFilePath() {
    return filePath;
  }

  /**
   * @return the pageNum
   */
  public Integer getPageNum() {
    return pageNum;
  }

  /**
   * @return the submitChannel
   */
  public String getSubmitChannel() {
    return submitChannel;
  }

  /**
   * @return the txtID
   */
  public String getTxtID() {
    return txtID;
  }

  /**
   * @return the printFlag
   */
  public String getPrintFlag() {
    return printFlag;
  }

  /**
   * @return the objectName
   */
  public String getObjectName() {
    return objectName;
  }

  /**
   * @return the omsRequestNo
   */
  public String getOmsRequestNo() {
    return omsRequestNo;
  }

  /**
   * @return the cycleDate
   */
  public String getCycleDate() {
    return cycleDate;
  }

  /**
   * @return the compNo
   */
  public String getCompNo() {
    return compNo;
  }

  /**
   * @return the policyNo
   */
  public String getPolicyNo() {
    return policyNo;
  }

  /**
   * @return the sourceSys
   */
  public String getSourceSys() {
    return sourceSys;
  }

  /**
   * @return the processType
   */
  public String getProcessType() {
    return processType;
  }

  /**
   * @return the formId
   */
  public String getFormId() {
    return formId;
  }

  /**
   * @return the logicalLinkFormId
   */
  public String getLogicalLinkFormId() {
    return logicalLinkFormId;
  }

  /**
   * @return the matchReq
   */
  public String getMatchReq() {
    return matchReq;
  }

  /**
   * @return the ilCode
   */
  public String getIlCode() {
    return ilCode;
  }

  /**
   * @param filePath the filePath to set
   */
  public void setFilePath(String filePath) {
    this.filePath = filePath;
  }

  /**
   * @param pageNum the pageNum to set
   */
  public void setPageNum(Integer pageNum) {
    this.pageNum = pageNum;
  }

  /**
   * @param submitChannel the submitChannel to set
   */
  public void setSubmitChannel(String submitChannel) {
    this.submitChannel = submitChannel;
  }

  /**
   * @param txtID the txtID to set
   */
  public void setTxtID(String txtID) {
    this.txtID = txtID;
  }

  /**
   * @param printFlag the printFlag to set
   */
  public void setPrintFlag(String printFlag) {
    this.printFlag = printFlag;
  }

  /**
   * @param objectName the objectName to set
   */
  public void setObjectName(String objectName) {
    this.objectName = objectName;
  }

  /**
   * @param omsRequestNo the omsRequestNo to set
   */
  public void setOmsRequestNo(String omsRequestNo) {
    this.omsRequestNo = omsRequestNo;
  }

  /**
   * @param cycleDate the cycleDate to set
   */
  public void setCycleDate(String cycleDate) {
    this.cycleDate = cycleDate;
  }

  /**
   * @param compNo the compNo to set
   */
  public void setCompNo(String compNo) {
    this.compNo = compNo;
  }

  /**
   * @param policyNo the policyNo to set
   */
  public void setPolicyNo(String policyNo) {
    this.policyNo = policyNo;
  }

  /**
   * @param sourceSys the sourceSys to set
   */
  public void setSourceSys(String sourceSys) {
    this.sourceSys = sourceSys;
  }

  /**
   * @param processType the processType to set
   */
  public void setProcessType(String processType) {
    this.processType = processType;
  }

  /**
   * @param formId the formId to set
   */
  public void setFormId(String formId) {
    this.formId = formId;
  }

  /**
   * @param logicalLinkFormId the logicalLinkFormId to set
   */
  public void setLogicalLinkFormId(String logicalLinkFormId) {
    this.logicalLinkFormId = logicalLinkFormId;
  }

  /**
   * @param matchReq the matchReq to set
   */
  public void setMatchReq(String matchReq) {
    this.matchReq = matchReq;
  }

  /**
   * @param ilCode the ilCode to set
   */
  public void setIlCode(String ilCode) {
    this.ilCode = ilCode;
  }

  /**
   * @return the docType
   */
  public String getDocType() {
    return docType;
  }

  /**
   * @param docType the docType to set
   */
  public void setDocType(String docType) {
    this.docType = docType;
  }

  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "AutoFileImportParam [filePath=" + filePath + ", pageNum=" + pageNum
        + ", submitChannel=" + submitChannel + ", txtID=" + txtID + ", printFlag=" + printFlag
        + ", objectName=" + objectName + ", omsRequestNo=" + omsRequestNo + ", cycleDate="
        + cycleDate + ", compNo=" + compNo + ", policyNo=" + policyNo + ", sourceSys=" + sourceSys
        + ", processType=" + processType + ", formId=" + formId + ", logicalLinkFormId="
        + logicalLinkFormId + ", matchReq=" + matchReq + ", ilCode=" + ilCode + ", docType="
        + docType + "]";
  }
  
}
