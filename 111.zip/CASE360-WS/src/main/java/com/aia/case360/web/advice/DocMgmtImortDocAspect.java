package com.aia.case360.web.advice;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.common.PropertyUtil;
import com.aia.case360.web.dao.DocumentsRelatedDataDao;
import com.aia.case360.web.pojo.CasePara;
import com.aia.case360.web.pojo.ImportPara;
import com.aia.case360.web.service.DocumentService;
import com.aia.case360.web.service.impl.AbstractServiceImpl;

@Component
@Aspect
public class DocMgmtImortDocAspect extends AbstractServiceImpl {
	private String doInsertDocMigCtrl = PropertyUtil.getCommonProperty("MIGRATION_COMPLETED");

	@Autowired
	private DocumentsRelatedDataDao drdd;
	@Autowired
	private DocumentService ds;


	@Pointcut("execution( * com.aia.case360.web.service.DocumentService.importCasesDoc(..))")
	public void pointCutImportCasesDoc() {
		// NOSONAR
	}

	@Pointcut("execution( * com.aia.case360.web.service.DocumentService.importPolsDoc(..))")
	public void pointCutImportPolsDoc() {
		// NOSONAR
	}

	@Pointcut("execution( * com.aia.case360.web.service.DocMgmtService.importCustDoc(..))")
    public void pointCutImportCustDoc() {
		// NOSONAR
    }

	@After("pointCutImportCasesDoc()")
	public void afterImportCasesDoc(JoinPoint jp) {
		if (doInsertDocMigCtrl.equals("0")) {
			CasePara param = (CasePara) jp.getArgs()[0];
			String docId = param.getDocId();
			String objectId = drdd.getObjectIdByDocId(docId);
			try {
				 ds.insertMigCtrl(objectId);
			} catch (Exception e) {
				 
				LogUtil.logException(m_Logger, "afterImportCasesDoc :" ,e);
			}
		}
	}

	@After("pointCutImportPolsDoc()")
	public void ImportPolsDoc(JoinPoint jp) {
		if (doInsertDocMigCtrl.equals("0")) {
		        ImportPara param = (ImportPara) jp.getArgs()[0];
				String docId = param.getDocId();
				String objectId = drdd.getObjectIdByDocId(docId);
				try {
				 ds.insertMigCtrl(objectId);
                } catch (Exception e) {
				 
				LogUtil.logError(m_Logger, "ImportPolsDoc :" + e.getMessage());
                }
		}
	}
}
