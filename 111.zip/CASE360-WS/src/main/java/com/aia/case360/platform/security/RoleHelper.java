package com.aia.case360.platform.security;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

public interface RoleHelper {

	/**
	 * query rolesName
	 * 
	 * @param searchType
	 *            allRolesName: all defined role name list availableRolesName:
	 *            these roles are not in the current user's role attribute
	 *            ownRolesName: current user's role list
	 * @param loginID
	 *            If searchType is availableRolesName,the parameter loginID is
	 *            necessary
	 * @param applicationName
	 *            check role Whether to belong to this applicationName
	 * @return
	 * @throws RemoteException
	 */
	public List<String> getAvailableRoles(String loginID, String applicationName) throws RemoteException;

	public List<String> getMyOwnRoles(String loginId) throws RemoteException;

	public List<String> getAllRoles(String applicationName) throws RemoteException;

	/**
	 * Get All Roles
	 * 
	 * @return a list of RolesElement
	 * @throws RemoteException
	 */

	/**
	 * Get All RolesName
	 * 
	 * @return
	 * @throws RemoteException
	 */

	/**
	 * Get LoginId by query roleName
	 * 
	 * @param roleName
	 * @return
	 * @throws RemoteException
	 */
	public List<String> getLoginIdList(String roleName) throws RemoteException;

	/**
	 * Create Role
	 * 
	 * @param params
	 * @return
	 * @throws RemoteException
	 */
	public boolean createRoleDef(Map<String, String> params) throws RemoteException;

	/**
	 * Update Role
	 * 
	 * @param params
	 * @return
	 * @throws RemoteException
	 */
	public boolean updateRoleDef(Map<String, String> params) throws RemoteException;

	/**
	 * Associate the user with the role
	 * 
	 * @param Role
	 * @param loginId
	 * @return
	 * @throws RemoteException
	 */
	public boolean indexRole(String Role, String loginId) throws RemoteException;

	/**
	 * 
	 * @param Roles
	 * @param loginID
	 * @return
	 * @throws RemoteException
	 */
	public boolean updateRoles(String[] Roles, String loginID) throws RemoteException;

	/**
	 * 
	 * @param Roles
	 * @param loginId
	 * @return
	 * @throws RemoteException
	 */
	/**
	 * Remove role
	 * 
	 * @param roleName
	 * @param loginId
	 * @throws RemoteException
	 */
	public void removeRole(String roleName, String loginId) throws RemoteException;
}
