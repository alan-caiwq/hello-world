package com.aia.case360.web.dao;

import java.rmi.RemoteException;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.aia.case360.web.pojo.NonAIACustomerAuditTrail;
import com.aia.case360.web.pojo.NonAIACustomerInfo;

public interface NonAIACustomerDao { 
	
	public List<NonAIACustomerInfo> queryNonAIACustomerList(NonAIACustomerInfo nric) throws RemoteException;
	
	public int addNonAIACustomer(NonAIACustomerInfo customer) throws RemoteException;
	
	public int updateNonAIACustomer(NonAIACustomerInfo customer) throws RemoteException;
	
	public int addNonAIACustomerAuditTrail(NonAIACustomerAuditTrail auditTrail) throws RemoteException;
	
	public List<NonAIACustomerAuditTrail> queryNonAIACustomerAuditTrail(NonAIACustomerAuditTrail auditTrail) throws RemoteException;
	
	public int doesNonAIACustomerExists(@Param(value="nric") String nric) throws RemoteException;
}