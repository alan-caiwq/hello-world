package com.aia.case360.web.dao;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.aia.case360.web.pojo.ReportDetail;
import com.aia.case360.web.pojo.ReportSummaryInfo;


public interface ReportDao {

	List<ReportSummaryInfo> queryReportSummary(ReportSummaryInfo param);

	List<ReportDetail> queryReportDetail(ReportDetail param);

	void insertReport(@Param("createdBy")String createdBy,@Param("createdTimestamp")String createdTimestamp,@Param("reportName")String reportName,@Param("reportParam")String reportParam,@Param("reportSpName")String reportSpName,@Param("reportStatus")String reportStatus);

	String selectRptBySrowid(Integer sRowid);

	void updateRptStatus(@Param("sRowid")int sRowid,@Param("reportStatus")String reportStatus);

	List<Map<String, Object>> getSrowidTop(@Param("srowid")Integer srowid);

	List<String> selectParam(@Param("createdTimestamp")String createdTimestamp,@Param("createdBy")String createdBy);
	
	public List<Map<String, Object>> getStaffPrdReportData (@Param("teamId")String teamId, @Param("startDT")String startDT, @Param("endDT")String endDT, @Param("mYear")String mYear, @Param("userId")String userId) throws RemoteException;

	public List<Map<String, Object>> getPersonalDashboardReport(@Param("userId") String user) throws RemoteException;
	
	public List<Map<String, Object>> executeSp(@Param("spsql") String spsql);

}
