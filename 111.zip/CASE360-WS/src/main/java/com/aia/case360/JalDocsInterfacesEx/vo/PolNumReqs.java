package com.aia.case360.JalDocsInterfacesEx.vo;

import java.io.Serializable;
import java.math.BigDecimal;

public class PolNumReqs implements Serializable {

	private String company;

	private String polNum;

	private String requestNo;

	private String receivedDate;

	private String processType;

	private String formId;

	private short isLogical;

	private String logicalLinkId;

	private BigDecimal sRowId;

	private short isDeleted;

	private short isVoid;

	private String createdby;

	private String objectId;
	private String lastUpdatedDate;

	private int status;

	public String getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(String lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getObjectId() {
		return objectId;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getPolNum() {
		return polNum;
	}

	public void setPolNum(String polNum) {
		this.polNum = polNum;
	}

	public String getRequestNo() {
		return requestNo;
	}

	public void setRequestNo(String requestNo) {
		this.requestNo = requestNo;
	}

	public String getReceivedDate() {
		return receivedDate;
	}

	public void setReceivedDate(String receivedDate) {
		this.receivedDate = receivedDate;
	}

	public String getProcessType() {
		return processType;
	}

	public void setProcessType(String processType) {
		this.processType = processType;
	}

	public String getFormId() {
		return formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}

	public short getIsLogical() {
		return isLogical;
	}

	public void setIsLogical(short isLogical) {
		this.isLogical = isLogical;
	}

	public String getLogicalLinkId() {
		return logicalLinkId;
	}

	public void setLogicalLinkId(String logicalLinkId) {
		this.logicalLinkId = logicalLinkId;
	}

	public BigDecimal getsRowId() {
		return sRowId;
	}

	public void setsRowId(BigDecimal sRowId) {
		this.sRowId = sRowId;
	}

	public short getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(short isDeleted) {
		this.isDeleted = isDeleted;
	}

	public short getIsVoid() {
		return isVoid;
	}

	public void setIsVoid(short isVoid) {
		this.isVoid = isVoid;
	}

	public String getCreatedby() {
		return createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}

	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}

	@Override
	public String toString() {
		return "PolNum [company=" + company + ", polNum=" + polNum + ", requestNo=" + requestNo + ", receivedDate="
				+ receivedDate + ", processType=" + processType + ", formId=" + formId + ", isLogical=" + isLogical
				+ ", logicalLinkId=" + logicalLinkId + ", sRowId=" + sRowId + ", isDeleted=" + isDeleted + "]";
	}

}
