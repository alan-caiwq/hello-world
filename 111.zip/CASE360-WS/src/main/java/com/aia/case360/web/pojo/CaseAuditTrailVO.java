package com.aia.case360.web.pojo;

import java.util.Date;

public class CaseAuditTrailVO {

	private Integer sRowId;

	private String action_desc;

	private String created_by;

	private Date created_timestamp;

	private String linkCaseId;

	private String category;

	private boolean is_lifecycle;

	public CaseAuditTrailVO() {
		super();
	}

	public CaseAuditTrailVO(String action_desc, String created_by, Date created_timestamp, String linkCaseId,
			String category, boolean is_lifecycle) {
		super();
		this.action_desc = action_desc;
		this.created_by = created_by.equalsIgnoreCase("SONORA")?"system":created_by;
		this.created_timestamp = created_timestamp;
		this.linkCaseId = linkCaseId;

		this.category = category;
		this.is_lifecycle = is_lifecycle;
	}

	public Integer getsRowId() {
		return sRowId;
	}

	public void setsRowId(Integer sRowId) {
		this.sRowId = sRowId;
	}

	public String getAction_desc() {
		return action_desc;
	}

	public void setAction_desc(String action_desc) {
		this.action_desc = action_desc;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public Date getCreated_timestamp() {
		return created_timestamp;
	}

	public void setCreated_timestamp(Date created_timestamp) {
		this.created_timestamp = created_timestamp;
	}

	public String getLinkCaseId() {
		return linkCaseId;
	}

	public void setLinkCaseId(String linkCaseId) {
		this.linkCaseId = linkCaseId;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public boolean isIs_lifecycle() {
		return is_lifecycle;
	}

	public void setIs_lifecycle(boolean is_lifecycle) {
		this.is_lifecycle = is_lifecycle;
	}

}
