package com.aia.case360.web.pojo;

import java.math.BigDecimal;

public class FormDef {

	private String acl;
	private String categoryCode;
	private String classNm;
	private String clmCategory;
	private String clmType;
	private BigDecimal closeToBestRequest; // decimal
	private String contractFormType;
	private String formCategory;
	private String formId;
	private String formLevel;
	private String formNm;
	private short isA3Cutting; // smallint
	private short isA3Group;// smallint
	private String isClmForm;
	private short isCoverSheet;// smallint
	private short isDocIntegrity;// smallint
	private String isMajorClaim;
	private String isPosForm;
	private String isPosIlpForm;
	private short isSheetIntegrity;// smallint
	private short isSignature;// smallint
	private String isUniForm;
	private String isValid;
	private String mainlinkFormId;
	private String posRequestCategory;
	private int printPage; // int
	private String reqType;
	private int retainType; // int
	private BigDecimal sRowid; // decimal
	private String signConfig; // ntext
	private BigDecimal totalPages;// decimal
	private String zoneConfig;// ntext
	private String isTriggerForm;// smallint
	private String isEdocCust;// smallint
	private String isEdocFsc;// smallint
	private String isVisible;// smallint
	private String edocDocId;
	private short isDeleted;// smallint
	private String department;

	private CustFormDef custFormDef;
	private FscFormDef fscFormDef;

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getAcl() {
		return acl;
	}

	public void setAcl(String acl) {
		this.acl = acl;
	}

	public String getCategoryCode() {
		return categoryCode;
	}

	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}

	public String getClassNm() {
		return classNm;
	}

	public void setClassNm(String classNm) {
		this.classNm = classNm;
	}

	public String getClmCategory() {
		return clmCategory;
	}

	public void setClmCategory(String clmCategory) {
		this.clmCategory = clmCategory;
	}

	public String getClmType() {
		return clmType;
	}

	public void setClmType(String clmType) {
		this.clmType = clmType;
	}

	public BigDecimal getCloseToBestRequest() {
		return closeToBestRequest;
	}

	public void setCloseToBestRequest(BigDecimal closeToBestRequest) {
		this.closeToBestRequest = closeToBestRequest;
	}

	public String getContractFormType() {
		return contractFormType;
	}

	public void setContractFormType(String contractFormType) {
		this.contractFormType = contractFormType;
	}

	public String getFormCategory() {
		return formCategory;
	}

	public void setFormCategory(String formCategory) {
		this.formCategory = formCategory;
	}

	public String getFormId() {
		return formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}

	public String getFormLevel() {
		return formLevel;
	}

	public void setFormLevel(String formLevel) {
		this.formLevel = formLevel;
	}

	public String getFormNm() {
		return formNm;
	}

	public void setFormNm(String formNm) {
		this.formNm = formNm;
	}

	public short getIsA3Cutting() {
		return isA3Cutting;
	}

	public void setIsA3Cutting(short isA3Cutting) {
		this.isA3Cutting = isA3Cutting;
	}

	public short getIsA3Group() {
		return isA3Group;
	}

	public void setIsA3Group(short isA3Group) {
		this.isA3Group = isA3Group;
	}

	public String getIsClmForm() {
		return isClmForm;
	}

	public void setIsClmForm(String isClmForm) {
		this.isClmForm = isClmForm;
	}

	public short getIsCoverSheet() {
		return isCoverSheet;
	}

	public void setIsCoverSheet(short isCoverSheet) {
		this.isCoverSheet = isCoverSheet;
	}

	public short getIsDocIntegrity() {
		return isDocIntegrity;
	}

	public void setIsDocIntegrity(short isDocIntegrity) {
		this.isDocIntegrity = isDocIntegrity;
	}

	public String getIsMajorClaim() {
		return isMajorClaim;
	}

	public void setIsMajorClaim(String isMajorClaim) {
		this.isMajorClaim = isMajorClaim;
	}

	public String getIsPosForm() {
		return isPosForm;
	}

	public void setIsPosForm(String isPosForm) {
		this.isPosForm = isPosForm;
	}

	public String getIsPosIlpForm() {
		return isPosIlpForm;
	}

	public void setIsPosIlpForm(String isPosIlpForm) {
		this.isPosIlpForm = isPosIlpForm;
	}

	public short getIsSheetIntegrity() {
		return isSheetIntegrity;
	}

	public void setIsSheetIntegrity(short isSheetIntegrity) {
		this.isSheetIntegrity = isSheetIntegrity;
	}

	public short getIsSignature() {
		return isSignature;
	}

	public void setIsSignature(short isSignature) {
		this.isSignature = isSignature;
	}

	public String getIsUniForm() {
		return isUniForm;
	}

	public void setIsUniForm(String isUniForm) {
		this.isUniForm = isUniForm;
	}

	public String getIsValid() {
		return isValid;
	}

	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}

	public String getMainlinkFormId() {
		return mainlinkFormId;
	}

	public void setMainlinkFormId(String mainlinkFormId) {
		this.mainlinkFormId = mainlinkFormId;
	}

	public String getPosRequestCategory() {
		return posRequestCategory;
	}

	public void setPosRequestCategory(String posRequestCategory) {
		this.posRequestCategory = posRequestCategory;
	}

	public int getPrintPage() {
		return printPage;
	}

	public void setPrintPage(int printPage) {
		this.printPage = printPage;
	}

	public String getReqType() {
		return reqType;
	}

	public void setReqType(String reqType) {
		this.reqType = reqType;
	}

	public int getRetainType() {
		return retainType;
	}

	public void setRetainType(int retainType) {
		this.retainType = retainType;
	}

	public BigDecimal getsRowid() {
		return sRowid;
	}

	public void setsRowid(BigDecimal sRowid) {
		this.sRowid = sRowid;
	}

	public String getSignConfig() {
		return signConfig;
	}

	public void setSignConfig(String signConfig) {
		this.signConfig = signConfig;
	}

	public BigDecimal getTotalPages() {
		return totalPages;
	}

	public void setTotalPages(BigDecimal totalPages) {
		this.totalPages = totalPages;
	}

	public String getZoneConfig() {
		return zoneConfig;
	}

	public void setZoneConfig(String zoneConfig) {
		this.zoneConfig = zoneConfig;
	}

	public String getIsTriggerForm() {
		return isTriggerForm;
	}

	public void setIsTriggerForm(String isTriggerForm) {
		this.isTriggerForm = isTriggerForm;
	}

	public String getIsEdocCust() {
		return isEdocCust;
	}

	public void setIsEdocCust(String isEdocCust) {
		this.isEdocCust = isEdocCust;
	}

	public String getIsEdocFsc() {
		return isEdocFsc;
	}

	public void setIsEdocFsc(String isEdocFsc) {
		this.isEdocFsc = isEdocFsc;
	}

	public String getIsVisible() {
		return isVisible;
	}

	public void setIsVisible(String isVisible) {
		this.isVisible = isVisible;
	}

	public String getEdocDocId() {
		return edocDocId;
	}

	public void setEdocDocId(String edocDocId) {
		this.edocDocId = edocDocId;
	}

	public CustFormDef getCustFormDef() {
		return custFormDef;
	}

	public void setCustFormDef(CustFormDef custFormDef) {
		this.custFormDef = custFormDef;
	}

	public FscFormDef getFscFormDef() {
		return fscFormDef;
	}

	public void setFscFormDef(FscFormDef fscFormDef) {
		this.fscFormDef = fscFormDef;
	}

	public short getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(short isDeleted) {
		this.isDeleted = isDeleted;
	}

	@Override
	public String toString() {
		return "FormDef [acl=" + acl + ", categoryCode=" + categoryCode + ", classNm=" + classNm + ", clmCategory="
				+ clmCategory + ", clmType=" + clmType + ", closeToBestRequest=" + closeToBestRequest
				+ ", contractFormType=" + contractFormType + ", formCategory=" + formCategory + ", formId=" + formId
				+ ", formLevel=" + formLevel + ", formNm=" + formNm + ", isA3Cutting=" + isA3Cutting + ", isA3Group="
				+ isA3Group + ", isClmForm=" + isClmForm + ", isCoverSheet=" + isCoverSheet + ", isDocIntegrity="
				+ isDocIntegrity + ", isMajorClaim=" + isMajorClaim + ", isPosForm=" + isPosForm + ", isPosIlpForm="
				+ isPosIlpForm + ", isSheetIntegrity=" + isSheetIntegrity + ", isSignature=" + isSignature
				+ ", isUniForm=" + isUniForm + ", isValid=" + isValid + ", mainlinkFormId=" + mainlinkFormId
				+ ", posRequestCategory=" + posRequestCategory + ", printPage=" + printPage + ", reqType=" + reqType
				+ ", retainType=" + retainType + ", sRowid=" + sRowid + ", signConfig=" + signConfig + ", totalPages="
				+ totalPages + ", zoneConfig=" + zoneConfig + ", isTriggerForm=" + isTriggerForm + ", isEdocCust="
				+ isEdocCust + ", isEdocFsc=" + isEdocFsc + ", isVisible=" + isVisible + ", edocDocId=" + edocDocId
				+ ", isDeleted=" + isDeleted + ", custFormDef=" + custFormDef + ", fscFormDef=" + fscFormDef + "]";
	}

}
