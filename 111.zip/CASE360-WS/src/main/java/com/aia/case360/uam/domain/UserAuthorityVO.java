package com.aia.case360.uam.domain;

public class UserAuthorityVO {

	private String userId;

	private String roleId;

	private String reqId;

	private String actId;

	private String reqName;

	private String actName;

	private String trainerName;

	private String isTrainee;

	private String bakRrainerName;

	private String rangeMax;

	private String rangeMin;

	private String authType;

	private String amountField;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public String getReqId() {
		return reqId;
	}

	public void setReqId(String reqId) {
		this.reqId = reqId;
	}

	public String getActId() {
		return actId;
	}

	public void setActId(String actId) {
		this.actId = actId;
	}

	public String getReqName() {
		return reqName;
	}

	public void setReqName(String reqName) {
		this.reqName = reqName;
	}

	public String getActName() {
		return actName;
	}

	public void setActName(String actName) {
		this.actName = actName;
	}

	public String getTrainerName() {
		return trainerName;
	}

	public void setTrainerName(String trainerName) {
		this.trainerName = trainerName;
	}

	public String getIsTrainee() {
		return isTrainee;
	}

	public void setIsTrainee(String isTrainee) {
		this.isTrainee = isTrainee;
	}

	public String getBakRrainerName() {
		return bakRrainerName;
	}

	public void setBakRrainerName(String bakRrainerName) {
		this.bakRrainerName = bakRrainerName;
	}

	public String getRangeMax() {
		return rangeMax;
	}

	public void setRangeMax(String rangeMax) {
		this.rangeMax = rangeMax;
	}

	public String getRangeMin() {
		return rangeMin;
	}

	public void setRangeMin(String rangeMin) {
		this.rangeMin = rangeMin;
	}

	public String getAuthType() {
		return authType;
	}

	public void setAuthType(String authType) {
		this.authType = authType;
	}

	public String getAmountField() {
		return amountField;
	}

	public void setAmountField(String amountField) {
		this.amountField = amountField;
	}

}
