package com.aia.case360.web.pojo;

public class GetSuppressPendingDetailsInfo {
	// suppressFollowCode
	private String suppressFollowCode;

	public String getSuppressFollowCode() {
		return suppressFollowCode;
	}

	public void setSuppressFollowCode(String suppressFollowCode) {
		this.suppressFollowCode = suppressFollowCode;
	}

}
