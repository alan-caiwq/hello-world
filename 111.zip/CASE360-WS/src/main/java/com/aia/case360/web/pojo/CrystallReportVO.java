package com.aia.case360.web.pojo;

import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import com.crystaldecisions.sdk.occa.report.application.ReportClientDocument;
import com.crystaldecisions.sdk.occa.report.exportoptions.ExportOptions;

public class CrystallReportVO {

	private String rptSourcePath;
	private String filePath;
	private String fileName;
	private String loginId;
	private ReportClientDocument reportClientDocument;
	private HttpServletResponse response;
	private boolean attachment;
	private ExportOptions exportOptions;
	private String extension;
	private Map<String, String> spParamMap;

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public Map<String, String> getSpParamMap() {
		return spParamMap;
	}

	public void setSpParamMap(Map<String, String> spParamMap) {
		this.spParamMap = spParamMap;
	}

	public String getRptSourcePath() {
		return rptSourcePath;
	}

	public void setRptSourcePath(String rptSourcePath) {
		this.rptSourcePath = rptSourcePath;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public ReportClientDocument getReportClientDocument() {
		return reportClientDocument;
	}

	public void setReportClientDocument(ReportClientDocument reportClientDocument) {
		this.reportClientDocument = reportClientDocument;
	}

	public HttpServletResponse getResponse() {
		return response;
	}

	public void setResponse(HttpServletResponse response) {
		this.response = response;
	}

	public boolean isAttachment() {
		return attachment;
	}

	public void setAttachment(boolean attachment) {
		this.attachment = attachment;
	}

	public ExportOptions getExportOptions() {
		return exportOptions;
	}

	public void setExportOptions(ExportOptions exportOptions) {
		this.exportOptions = exportOptions;
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}
}
