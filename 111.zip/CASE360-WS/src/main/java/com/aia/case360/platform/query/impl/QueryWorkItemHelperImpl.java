package com.aia.case360.platform.query.impl;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.stereotype.Component;

import com.aia.case360.platform.common.CaseUtilities;
import com.aia.case360.platform.common.DataFieldUtil;
import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.common.PropertyUtil;
import com.aia.case360.platform.common.QueryResultsHandler;
import com.aia.case360.platform.process.impl.RepositoryKey;
import com.aia.case360.platform.query.QueryWorkItemHelper;
import com.aia.case360.web.service.impl.AbstractHelperImpl;
import com.eistream.sonora.fields.FieldPropertiesTO;
import com.eistream.sonora.fields.FmsRowSetTO;

@Component
public class QueryWorkItemHelperImpl extends AbstractHelperImpl implements QueryWorkItemHelper {

	private static final String LOCALQUERYWORKITEM = "QUERY_WORKITEM";
	private static final String LOCALLINKCASEID = "LINKCASEID";
	private static final String LOCALPOSREQNO = "POS_REQ_NO";
	private static final String LOCALCURRENTUSER = "CURRENT_USER";

	/**
	 * 
	 * Get userId's own job list by workstep
	 * 
	 * @param userId   login userId should be registered in Case360 side.
	 * @param workstep activity name indicates which activity queue for finding
	 *                 workitems of the current user
	 * @return queryResults
	 * @throws RemoteException
	 */
	@Override
	public ArrayList<Map<String, Object>> getJobs(String userId, String workstep) throws RemoteException {

		Map<String, String> queryParams = new HashMap<String, String>();
		LogUtil.logInfo(m_Logger,userId + ":" + workstep);
		queryParams.put(PropertyUtil.getCommonProperty(LOCALCURRENTUSER), userId);
		queryParams.put(PropertyUtil.getCommonProperty("WFWORKSTEPNAME"), workstep);
		String query = PropertyUtil.getScriptAndQueryProperty("QUERY_MYWORKLIST_GETBYWORKSTEP");
		return doQuery(queryParams, query);
	}


	@Override
	public ArrayList<Map<String, Object>> getNextJobList(String userId, String workstep) throws RemoteException {
		LogUtil.logInfo(m_Logger,userId + ":" + workstep);
		Map<String, String> queryParams = new HashMap<String, String>();
		LogUtil.logInfo(m_Logger,userId + ":" + workstep);
		queryParams.put(PropertyUtil.getCommonProperty(LOCALCURRENTUSER), userId);
		queryParams.put(PropertyUtil.getCommonProperty("WFWORKSTEPNAME"), workstep);
		String query = PropertyUtil.getScriptAndQueryProperty("QUERY_NEXTWORKLIST");
		return doQuery(queryParams, query);
	}

	public ArrayList<Map<String, Object>> doQuery(Map<String, String> queryParams, String queryName)
			throws RemoteException {

		String message = "queryName:" + queryName;

		String paramStr = DataFieldUtil.getInMapStr(queryParams);

		if (paramStr != null && paramStr.length() > 0) {
			message += "," + paramStr;
		} else {
			message += ", no query parameters input!";
		}

		ArrayList<Map<String, Object>> queryResults;

		try {
			FmsRowSetTO[] queryResultsSet = doQuery4RowSet(queryParams, queryName);

			queryResults = QueryResultsHandler.convertQueryResultsAsObject(queryResultsSet);
			LogUtil.logInfo(m_Logger,message);
			return queryResults;
		} catch (RemoteException e) {
			
			throw LogUtil.logException(m_Logger, message, e);
		}
	}

	private FmsRowSetTO[] doQuery4RowSet(Map<String, String> queryParams, String queryName) throws RemoteException {
		String message = "doQuery4RowSet--queryName:" + queryName;

		String paramStr = DataFieldUtil.getInMapStr(queryParams);

		if (paramStr != null && paramStr.length() > 0) {
			message += "," + paramStr;
		} else {
			message += ", no query parameters input!";
		}
		LogUtil.logInfo(m_Logger,"queryName=" + queryName);
		LogUtil.logInfo(m_Logger,"queryParams=" + queryParams + "queryName");
		// Get the list of contents
		FieldPropertiesTO[] queryFields = null;
		if (queryParams != null) {
			queryFields = new FieldPropertiesTO[queryParams.size()];

			setQueryFields(queryParams, queryFields, 0);
		}
		try {
			FmsRowSetTO[] queryResultsSet = getWsEJB().doQueryByScriptName(queryName, queryFields);

			LogUtil.logInfo(m_Logger,message);
			return queryResultsSet;
		} catch (RemoteException e) {
			 
			throw LogUtil.logException(m_Logger, message, e);
		}
	}

	private int setQueryFields(Map<String, String> queryParams, FieldPropertiesTO[] queryFields, int fieldsNum) {
		for (Entry<String, String> paramName : queryParams.entrySet()) {
			queryFields[fieldsNum++] = CaseUtilities.createFieldPropertyTO(paramName.getKey(), paramName.getValue());
		}
		return fieldsNum;
	}

	@Override
	public ArrayList<Map<String, Object>> getCaseByPOSReqNo(String posReqNo) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(LOCALPOSREQNO, posReqNo);
		ArrayList<Map<String, Object>> queryResult =  doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_GETCASEDATA_BY_POSREQNO"));

		return queryResult;
	}

	@Override
	public ArrayList<Map<String, Object>> getSonoraValues(Map<String, String> queryParams) throws RemoteException {
		return doQuery(queryParams, PropertyUtil.getScriptAndQueryProperty("QUERY_GETSONORAVALUES"));

	}

	@Override
	public String getEffectiveRpKeyStrWorkItem(String linkCaseId) throws RemoteException {
		String rpKeyStr = "";
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(LOCALLINKCASEID, linkCaseId);
		ArrayList<Map<String, Object>> result = doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty(LOCALQUERYWORKITEM));

		if (result.size() == 1) {
			rpKeyStr = result.get(0).get(PropertyUtil.getCommonProperty("REPOSITORYKEY")).toString();
		}
		return rpKeyStr;

	}

	/**
	 * add by charley
	 */
	@Override
	public Map<String, Object> getWorkItemByLinkCaseId(String linkCaseId) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(LOCALLINKCASEID, linkCaseId);
		ArrayList<Map<String, Object>> result = doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty(LOCALQUERYWORKITEM));
		if (result == null || result.isEmpty()) {
			return null;
		}
		return result.get(0);
	}

	@Override
	public Map<String, Object> searchWorkItem(String workflowid, String wfworkitemid) throws RemoteException {

		Map<String, String> queryParams = new HashMap<String, String>();

		queryParams.put("WORKFLOWID", workflowid);
		queryParams.put("WFWORKITEMID", wfworkitemid);
		ArrayList<Map<String, Object>> result = doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty(LOCALQUERYWORKITEM));
		return result.get(0);
	}

	@Override
	public Map<String, Object> searchWorkItem(String rekeyStr) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		RepositoryKey rpKey = RepositoryKey.getInstance(rekeyStr);
		int workflowid = rpKey.getWorkflowId();
		String wfworkitemid = rpKey.getWorkItemId().toString();
		queryParams.put("WORKFLOWID", String.valueOf(workflowid));
		queryParams.put("WFWORKITEMID", wfworkitemid);
		ArrayList<Map<String, Object>> queryResult = doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty(LOCALQUERYWORKITEM));
		Map<String, Object> result = queryResult.get(0);
		return result;
	}

	@Override
	public ArrayList<Map<String, Object>> searchAllWorkItem(String requestNo) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(LOCALPOSREQNO, requestNo);
		ArrayList<Map<String, Object>> result = doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_GETAllWORKITEMBYREQNO"));
		return result;
	}

	@Override
	public ArrayList<Map<String, Object>> getWiByPOSReqNo(String posReqNo) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();

		queryParams.put(LOCALPOSREQNO, posReqNo);
		ArrayList<Map<String, Object>> result = doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_GETAllWORKITEMBYREQNO"));
		return result;
	}

	@Override
	public ArrayList<Map<String, Object>> getAllJobs(String userId, String workstep) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		LogUtil.logInfo(m_Logger,userId + ":" + workstep);
		queryParams.put(PropertyUtil.getCommonProperty(LOCALCURRENTUSER), userId);
		String query = PropertyUtil.getScriptAndQueryProperty("QUERY_ALLWORK");
		return doQuery(queryParams, query);
	}

	@Override
	public ArrayList<Map<String, Object>> getAllPendingWorks(String userId, String workstep) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		LogUtil.logInfo(m_Logger,userId + ":" + workstep);
		queryParams.put(PropertyUtil.getCommonProperty(LOCALCURRENTUSER), userId);
		String query = PropertyUtil.getScriptAndQueryProperty("QUERY_ALLPENDINGS");
		return doQuery(queryParams, query);
	}

	@Override
	public ArrayList<Map<String, Object>> getReferedWorks(String userId, String workstep) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		LogUtil.logInfo(m_Logger,userId + ":" + workstep);
		queryParams.put(PropertyUtil.getCommonProperty(LOCALCURRENTUSER), userId);
		String query = PropertyUtil.getScriptAndQueryProperty("QUERY_REFEREDWORK");
		return doQuery(queryParams, query);
	}

	@Override
	public ArrayList<Map<String, Object>> getWaitDocWorks(String userId, String workstep) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		LogUtil.logInfo(m_Logger,userId + ":" + workstep);
		queryParams.put(PropertyUtil.getCommonProperty(LOCALCURRENTUSER), userId);
		String query = PropertyUtil.getScriptAndQueryProperty("QUERY_WAITDOCWORKS");
		return doQuery(queryParams, query);
	}

	@Override
	public ArrayList<Map<String, Object>> getWorkItemByPolNum(String policyNum, String department, String processName)
			throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(PropertyUtil.getCommonProperty("POL_NUM"), policyNum);
		queryParams.put(PropertyUtil.getCommonProperty("DEPARTMENT"), department);
		queryParams.put(PropertyUtil.getCommonProperty("PROCESS_NAME"), processName);
		String query = PropertyUtil.getScriptAndQueryProperty(LOCALQUERYWORKITEM);
		return doQuery(queryParams, query);
	}

	@Override
	public String getWorkItems(String linkCaseId) throws RemoteException {
		String rpKeyStr = "";
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(LOCALLINKCASEID, linkCaseId);
		ArrayList<Map<String, Object>> result = doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_GETALLWORKITEM"));

		if (result.size() == 1) {
			rpKeyStr = result.get(0).get(PropertyUtil.getCommonProperty("REPOSITORYKEY")).toString();
		}
		return rpKeyStr;
	}

}
