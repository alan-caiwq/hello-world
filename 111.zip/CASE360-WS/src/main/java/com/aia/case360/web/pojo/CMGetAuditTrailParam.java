package com.aia.case360.web.pojo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CMGetAuditTrailParam {
  
  @JsonProperty("CM_OBJECT_ID")
  private String cmObjectId;
  
  /**
   * 0:request type;1:form id
   */
  private Integer cmType;

  /**
   * @return the cmObjectId
   */
  public String getCmObjectId() {
    return cmObjectId;
  }

  /**
   * @return the cmType
   */
  public Integer getCmType() {
    return cmType == null ? 0 : cmType;
  }

  /**
   * @param cmObjectId the cmObjectId to set
   */
  public void setCmObjectId(String cmObjectId) {
    this.cmObjectId = cmObjectId;
  }

  /**
   * @param cmType the cmType to set
   */
  public void setCmType(Integer cmType) {
    this.cmType = cmType;
  }

  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "CMGetAuditTrailParam [cmObjectId=" + cmObjectId + ", cmType=" + cmType + "]";
  }
}
