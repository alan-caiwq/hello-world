package com.aia.case360.platform.process;

import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;

/**
 * get workitem data field value from data base and format as map
 * 
 * @author bsnpbdu
 *
 */

public final class WorkItemDetail {
	
	private WorkItemDetail() {}

	public final static String REPOSITORYKEY = "REPOSITORYKEY";

	public final static String LINKCASEID = "LINKCASEID";
	public final static String WFWORKSTEPNAME = "WFWORKSTEPNAME";
	public final static String POL_NUM = "POL_NUM";
	public final static String CLIENT_NM = "CLIENT_NM";

	public final static String PO_REQ_DT = "PO_REQ_DT";
	public final static String CS_RECEIVE_DT = "CS_RECEIVE_DT";
	public final static String CS_REMARK = "CS_REMARK";
	public final static String USER_GROUP = "USER_GROUP";

	public final static String REQ_IND = "REQ_IND";
	public final static String REQ_STATUS = "REQ_STATUS";
	public final static String WFWORKITEMID = "WFWORKITEMID";
	public final static String WFROUTINGTICKETID = "WFROUTINGTICKETID";

	public final static String REL_REQ_NO = "REL_REQ_NO";
	public final static String SLASTATUS = "SLASTATUS";
	public final static String SLA_DUE_DT = "SLA_DUE_DT";
	public final static String ATSTATUS = "ATSTATUS";
	public final static String DEPARTMENT = "DEPARTMENT";

	public final static String REQ_TYPE = "REQ_TYPE";
	public final static String REQ_IND_NM = "REQ_IND_NM";
	public final static String USER_GROUP_NM = "USER_GROUP_NM";

	public final static String POS_REQ_NO = "POS_REQ_NO";
	public final static String REQ_STATUS_NM = "REQ_STATUS_NM";

	public final static String PROCESS_NAME = "PROCESS_NAME";

	public final static String OFFICE_CODE = "OFFICE_CODE";
	public final static String FLP_USER_ID = "FLP_USER_ID";
	public final static String FLP_USER_NM = "FLP_USER_NM";

	public final static String CLM_REQ_NO = "CLM_REQ_NO";// for CLM by charley 2017/4/21
	public final static String MAINCASEID = "MAINCASEID";// for CLM ASS charley 2017/4/25
	public final static String CLM_OFFICE_CODE = "CLM_OFFICE_CODE";// for CLM ASS charley 2017/4/25
	public final static String LA_NM = "LA_NM";// for CLM ASS Henry 2017/05/10
	public final static String CLAIMANT_NM = "CLAIMANT_NM";// for CLM ASS Henry 2017/05/10
	public final static String CLM_OCCUR_NO = "CLM_OCCUR_NO";// for CLM ASS Henry 2017/05/10
	public final static String OCCUR_STATUS = "OCCUR_STATUS";// for CLM ASS Henry 2017/05/10
	public final static String OCCUR_SUB_STATUS = "OCCUR_SUB_STATUS";// for CLM ASS Henry 2017/05/10
	public final static String PRODUCT_CD = "PRODUCT_CD";// for CLM ASS Henry 2017/05/10
	public final static String PRODUCT_ST = "PRODUCT_ST";// for CLM ASS Henry 2017/05/10
	public final static String EMAIL_ADDRESS = "EMAIL_ADDRESS";// for CLM ASS Henry 2017/05/10
	public final static String PHONE_NUM = "PHONE_NUM";// for CLM ASS Henry 2017/05/10
	public final static String REGISTER_USER = "REGISTER_USER";// for CLM ASS Henry 2017/05/10
	public final static String REGISTER_DT = "REGISTER_DT";// for CLM ASS Henry 2017/05/10
	public final static String SCHEDULE_ID = "SCHEDULE_ID";// for CLM CPY Lucas 2017/06/07
	public final static String SCHEDULE_STATUS = "SCSCHEDULE_STATUSHEDULE_ID";// for CLM CPY Lucas 2017/06/07
	public final static String PAY_V_AMOUNT = "PAY_V_AMOUNT";// for CLM CPY Lucas 2017/06/07
	public final static String PAYEE_NM = "PAYEE_NM";// for CLM CPY Lucas 2017/06/07
	public final static String PAYEE_ID = "PAYEE_ID";// for CLM CPY Lucas 2017/06/07
	public final static String PAY_TYPE = "PAY_TYPE";// for CLM CPY Lucas 2017/06/07
	public final static String PAY_PURPOSE = "PAY_PURPOSE";// for CLM CPY Lucas 2017/06/07
	public final static String PAY_LV = "PAY_LV";// for CLM CPY Lucas 2017/06/07

	public static Map<String, String> getWorkItemData(String rpKey, WorkItemHelper wiHelper) throws RemoteException {

		final Map<String, String> wiDataMap = wiHelper.getWorkItemData(rpKey);
		Map<String, String> result = new HashMap<String, String>();

		result.put(LINKCASEID, wiDataMap.get(LINKCASEID));
		result.put(WFWORKSTEPNAME, wiDataMap.get(WFWORKSTEPNAME));
		result.put(POL_NUM, wiDataMap.get(POL_NUM));
		result.put(CLIENT_NM, wiDataMap.get(CLIENT_NM));
		result.put(PO_REQ_DT, wiDataMap.get(PO_REQ_DT));
		result.put(CS_RECEIVE_DT, wiDataMap.get(CS_RECEIVE_DT));

		result.put(CS_REMARK, wiDataMap.get(CS_REMARK));
		result.put(USER_GROUP, wiDataMap.get(USER_GROUP));
		result.put(REQ_IND, wiDataMap.get(REQ_IND));
		result.put(REQ_STATUS, wiDataMap.get(REQ_STATUS));
		result.put(REPOSITORYKEY, rpKey);
		result.put(WFWORKITEMID, wiDataMap.get(WFWORKITEMID));
		result.put(WFROUTINGTICKETID, wiDataMap.get(WFROUTINGTICKETID));

		result.put(REL_REQ_NO, wiDataMap.get(REL_REQ_NO));
		result.put(SLASTATUS, wiDataMap.get(SLASTATUS));
		result.put(SLA_DUE_DT, wiDataMap.get(SLA_DUE_DT));
		result.put(ATSTATUS, wiDataMap.get(ATSTATUS));

		result.put(DEPARTMENT, wiDataMap.get(DEPARTMENT));
		result.put(REQ_TYPE, wiDataMap.get(REQ_TYPE));
		result.put(REQ_IND_NM, wiDataMap.get(REQ_IND_NM));
		result.put(USER_GROUP_NM, wiDataMap.get(USER_GROUP_NM));
		result.put(POS_REQ_NO, wiDataMap.get(POS_REQ_NO));
		result.put(REQ_STATUS_NM, wiDataMap.get(REQ_STATUS_NM));
		result.put(OFFICE_CODE, wiDataMap.get(OFFICE_CODE));
		result.put(FLP_USER_ID, wiDataMap.get(FLP_USER_ID));
		result.put(FLP_USER_NM, wiDataMap.get(FLP_USER_NM));
		result.put(PROCESS_NAME, wiDataMap.get(PROCESS_NAME));

		result.put(CLM_REQ_NO, wiDataMap.get(CLM_REQ_NO));
		result.put(MAINCASEID, wiDataMap.get(MAINCASEID));
		result.put(CLM_OFFICE_CODE, wiDataMap.get(CLM_OFFICE_CODE));
		result.put(LA_NM, wiDataMap.get(LA_NM));
		result.put(CLAIMANT_NM, wiDataMap.get(CLAIMANT_NM));
		result.put(CLM_OCCUR_NO, wiDataMap.get(CLM_OCCUR_NO));
		result.put(OCCUR_STATUS, wiDataMap.get(OCCUR_STATUS));
		result.put(OCCUR_SUB_STATUS, wiDataMap.get(OCCUR_SUB_STATUS));
		result.put(PRODUCT_CD, wiDataMap.get(PRODUCT_CD));
		result.put(PRODUCT_ST, wiDataMap.get(PRODUCT_ST));
		result.put(EMAIL_ADDRESS, wiDataMap.get(EMAIL_ADDRESS));
		result.put(PHONE_NUM, wiDataMap.get(PHONE_NUM));
		result.put(REGISTER_USER, wiDataMap.get(REGISTER_USER));

		return result;
	}

	/**
	 * copy workitem data from query result for creating new workitem
	 * 
	 * @param queryResult
	 * @author bsnpbt9
	 * @date 2017/05/10
	 * @return
	 */
	public static Map<String, Object> copyWorkItemData(Map<String, Object> queryResult) {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Map<String, Object> result = new HashMap<String, Object>();

		result.put(LINKCASEID, queryResult.get(LINKCASEID));
		result.put(POL_NUM, queryResult.get(POL_NUM));
		result.put(CLIENT_NM, queryResult.get(CLIENT_NM));
		Object poReqDtObj = queryResult.get(WorkItemDetail.PO_REQ_DT);
		String poReqDtStr = poReqDtObj == null || "".equals(poReqDtObj.toString().trim()) ? ""
				: sdf.format(((GregorianCalendar) poReqDtObj).getTime());
		result.put(PO_REQ_DT, poReqDtStr);
		Object csReceiveDtObj = queryResult.get(WorkItemDetail.CS_RECEIVE_DT);
		String csReceiveDtStr = csReceiveDtObj == null || "".equals(csReceiveDtObj.toString().trim()) ? ""
				: sdf.format(((GregorianCalendar) csReceiveDtObj).getTime());
		result.put(CS_RECEIVE_DT, csReceiveDtStr);
		result.put(CS_REMARK, queryResult.get(CS_REMARK));
		result.put(USER_GROUP, queryResult.get(USER_GROUP));
		result.put(REQ_IND, queryResult.get(REQ_IND));
		result.put(REQ_STATUS, queryResult.get(REQ_STATUS));
		result.put(REL_REQ_NO, queryResult.get(REL_REQ_NO));
		result.put(SLASTATUS, queryResult.get(SLASTATUS));
		result.put(ATSTATUS, queryResult.get(ATSTATUS));
		result.put(DEPARTMENT, queryResult.get(DEPARTMENT));
		result.put(REQ_TYPE, queryResult.get(REQ_TYPE));
		result.put(REQ_IND_NM, queryResult.get(REQ_IND_NM));
		result.put(USER_GROUP_NM, queryResult.get(USER_GROUP_NM));
		result.put(POS_REQ_NO, queryResult.get(POS_REQ_NO));
		result.put(REQ_STATUS_NM, queryResult.get(REQ_STATUS_NM));
		result.put(OFFICE_CODE, queryResult.get(OFFICE_CODE));
		result.put(FLP_USER_ID, queryResult.get(FLP_USER_ID));
		result.put(FLP_USER_NM, queryResult.get(FLP_USER_NM));
		result.put(CLM_REQ_NO, queryResult.get(CLM_REQ_NO));
		result.put(MAINCASEID, queryResult.get(MAINCASEID));
		result.put(CLM_OFFICE_CODE, queryResult.get(CLM_OFFICE_CODE));
		result.put(LA_NM, queryResult.get(LA_NM));
		result.put(CLAIMANT_NM, queryResult.get(CLAIMANT_NM));
		result.put(CLM_OCCUR_NO, queryResult.get(CLM_OCCUR_NO));
		result.put(OCCUR_STATUS, queryResult.get(OCCUR_STATUS));
		result.put(OCCUR_SUB_STATUS, queryResult.get(OCCUR_SUB_STATUS));
		result.put(PRODUCT_CD, queryResult.get(PRODUCT_CD));
		result.put(PRODUCT_ST, queryResult.get(PRODUCT_ST));
		result.put(EMAIL_ADDRESS, queryResult.get(EMAIL_ADDRESS));
		result.put(PHONE_NUM, queryResult.get(PHONE_NUM));
		result.put(REGISTER_USER, queryResult.get(REGISTER_USER));
		Object regDtObj = queryResult.get(REGISTER_DT);
		String reqDtStr = regDtObj == null || "".equals(regDtObj.toString().trim()) ? ""
				: sdf.format(((GregorianCalendar) regDtObj).getTime());
		result.put(REGISTER_DT, reqDtStr);

		return result;
	}
}