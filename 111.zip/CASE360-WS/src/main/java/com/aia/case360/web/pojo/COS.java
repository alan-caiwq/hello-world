package com.aia.case360.web.pojo;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "COS")
public class COS {

	// following fields for excel

	private static final String EMPTYSTRING = "";

	private String letterctl;

	private String c2letgrp;

	private int c2letseq;

	private String c2reqdte;
	
	private String c2ChdNuM;


	private String c2ReqCoy;// C2REQCOY

	private String c2OwnName; // C2OWNAME

	
	private String c2TrName1; // c2TrName1

	private String c2TrName2; // c2TrName2
	
	private String c2TrName3; // c2TrName3

	private String c2TrName4; // c2TrName4

	private String c20Addr1;// C2OADDR1, NRIC

	private String c20Addr2;// C2OADDR2, address --Road db_pa..tpa_mst.addr1

	private String c20Addr3;// C2OADDR3, address --building db_pa..tpa_mst.addr2

	private String c20Addr4;// C2OADDR4, address --Unit

	private String c20Addr5;// C2OADDR5, address --Country db_pa..tpa_mst.addr3

	private String c2Owctry;// C2OWCTRY

	private String c2OpCode;// C2OPCODE, address --Country db_pa..tpa_mst.addr4

	private String building;// <C2SAGTBR> FSC Location (Agency Location) A82

	private String agencyName;// <C2SAGTBD> Agency Name SP-DAVESOH

	private String agentName;// <C2SAGTNM> Agent Name (FSC Name) Ali Agent 1

	private String agentCode;// <C2SAGNTN> Agent Code (FSC Code) 22618

	private List<String> policyNumberList;
	
	private String trusteeIndicator;
	
	private String userDesk;

	private String userId;

	private String agencyCode;
	
	
	private String printIndicator;
	private String printPolicyNo;
	private String ecopyIndicator;
	private String ecopyPolicyNo;

	public COS() {
		this.letterctl = EMPTYSTRING;
		this.c2letgrp = EMPTYSTRING;
		this.c2reqdte = EMPTYSTRING;
		this.c2ReqCoy = EMPTYSTRING;
		this.c2OwnName = EMPTYSTRING;
		this.c2TrName1 = EMPTYSTRING;
		this.c2TrName2 = EMPTYSTRING;
		this.c2TrName3 = EMPTYSTRING;
		this.c2TrName4 = EMPTYSTRING;
//		this.c2NeName = EMPTYSTRING;
		this.c20Addr1 = EMPTYSTRING;
		this.c20Addr2 = EMPTYSTRING;
		this.c20Addr3 = EMPTYSTRING;
		this.c20Addr4 = EMPTYSTRING;
		this.c20Addr5 = EMPTYSTRING;
		this.c2Owctry = EMPTYSTRING;
		this.c2OpCode = EMPTYSTRING;
		this.building = EMPTYSTRING;
		this.agencyName = EMPTYSTRING;
		this.agentName = EMPTYSTRING;
		this.agentCode = EMPTYSTRING;
		this.userDesk = EMPTYSTRING;
		this.userId = EMPTYSTRING;
		this.agencyCode = EMPTYSTRING;
		this.trusteeIndicator= EMPTYSTRING;
		this.ecopyIndicator="N";
		this.ecopyPolicyNo=EMPTYSTRING;
		this.printIndicator=EMPTYSTRING;
		this.printPolicyNo=EMPTYSTRING;
	}

	public String getLetterctl() {
		return letterctl;
	}

	@XmlElement(name = "LETTERCTL")
	public void setLetterctl(String letterctl) {
		this.letterctl = letterctl == null ? EMPTYSTRING : letterctl.trim();
	}

	public String getC2letgrp() {
		return c2letgrp;
	}

	@XmlElement(name = "C2LETGRP")
	public void setC2letgrp(String c2letgrp) {
		this.c2letgrp = c2letgrp == null ? EMPTYSTRING : c2letgrp.trim();
	}

	public int getC2letseq() {
		return c2letseq;
	}

	@XmlElement(name = "C2LETSEQ")
	public void setC2letseq(int c2letseq) {
		this.c2letseq = c2letseq;
	}

	public String getC2reqdte() {
		return c2reqdte;
	}

	@XmlElement(name = "C2REQDTE")
	public void setC2reqdte(String c2reqdte) {
		this.c2reqdte = c2reqdte == null ? EMPTYSTRING : c2reqdte.trim();
	}

	public String getC2ReqCoy() {
		return c2ReqCoy;
	}
	public String getC2ChdNuM() {
		return c2ChdNuM;
	}
	public void setC2ChdNuM(String c2ChdNuM) {
		this.c2ChdNuM = c2ChdNuM;
	}
	@XmlElement(name = "C2REQCOY")
	public void setC2ReqCoy(String c2ReqCoy) {
		this.c2ReqCoy = c2ReqCoy == null ? EMPTYSTRING : c2ReqCoy.trim();
	}

	public String getC2OwnName() {
		return c2OwnName;
	}

	@XmlElement(name = "C2OWNAME")
	public void setC2OwnName(String c2OwnName) {
		this.c2OwnName = c2OwnName == null ? EMPTYSTRING : c2OwnName.trim();
	}

	public String getC2TrName1() {
		return c2TrName1;
	}

	@XmlElement(name = "ZSTRASS1")
	public void setC2TrName1(String c2TrName1) {
		this.c2TrName1 = c2TrName1 == null ? EMPTYSTRING : c2TrName1.trim();
	}

	public String getC2TrName2() {
		return c2TrName2;
	}

	@XmlElement(name = "ZSTRASS2")
	public void setC2TrName2(String c2TrName2) {
		this.c2TrName2 = c2TrName2 == null ? EMPTYSTRING : c2TrName2.trim();
	}

	public String getC2TrName3() {
		return c2TrName3;
	}

	@XmlElement(name = "ZSTRASS3")
	public void setC2TrName3(String c2TrName3) {
		this.c2TrName3 = c2TrName3 == null ? EMPTYSTRING : c2TrName3.trim();
	}

	public String getC2TrName4() {
		return c2TrName4;
	}

	@XmlElement(name = "ZSTRASS4")
	public void setC2TrName4(String c2TrName4) {
		this.c2TrName4 = c2TrName4 == null ? EMPTYSTRING : c2TrName4.trim();
	}


	public String getC20Addr1() {
		return c20Addr1;
	}

	@XmlElement(name = "C2OADDR1")
	public void setC20Addr1(String c20Addr1) {
		this.c20Addr1 = c20Addr1 == null ? EMPTYSTRING : c20Addr1.trim();
	}

	public String getC20Addr2() {
		return c20Addr2;
	}

	@XmlElement(name = "C2OADDR2")
	public void setC20Addr2(String c20Addr2) {
		this.c20Addr2 = c20Addr2 == null ? EMPTYSTRING : c20Addr2.trim();
	}

	public String getC20Addr3() {
		return c20Addr3;
	}

	@XmlElement(name = "C2OADDR3")
	public void setC20Addr3(String c20Addr3) {
		this.c20Addr3 = c20Addr3 == null ? EMPTYSTRING : c20Addr3.trim();
	}

	public String getC20Addr4() {
		return c20Addr4;
	}

	@XmlElement(name = "C2OADDR4")
	public void setC20Addr4(String c20Addr4) {
		this.c20Addr4 = c20Addr4 == null ? EMPTYSTRING : c20Addr4.trim();
	}

	public String getC20Addr5() {
		return c20Addr5;
	}

	@XmlElement(name = "C2OADDR5")
	public void setC20Addr5(String c20Addr5) {
		this.c20Addr5 = c20Addr5 == null ? EMPTYSTRING : c20Addr5.trim();
	}

	public String getC2Owctry() {
		return c2Owctry;
	}

	@XmlElement(name = "C2OWCTRY")
	public void setC2Owctry(String c2Owctry) {
		this.c2Owctry = c2Owctry == null ? EMPTYSTRING : c2Owctry.trim();
	}

	public String getC2OpCode() {
		return c2OpCode;
	}

	@XmlElement(name = "C2OPCODE")
	public void setC2OpCode(String c2OpCode) {
		this.c2OpCode = c2OpCode == null ? EMPTYSTRING : c2OpCode.trim();
	}

	public List<String> getPolicyNumberList() {
		return policyNumberList;
	}

	@XmlElements(value = { @XmlElement(name = "PolicyNo") })
	public void setPolicyNumberList(List<String> policyNumberList) {
		this.policyNumberList = policyNumberList;
	}

	public String getBuilding() {
		return building;
	}

	@XmlElement(name = "C2SAGTBR")
	public void setBuilding(String building) {
		this.building = building == null ? EMPTYSTRING : building.trim();
	}

	public String getAgencyName() {
		return agencyName;
	}

	@XmlElement(name = "C2SAGTBD")
	public void setAgencyName(String agencyName) {
		this.agencyName = agencyName == null ? EMPTYSTRING : agencyName.trim();
	}

	public String getAgentName() {
		return agentName;
	}

	@XmlElement(name = "C2SAGTNM")
	public void setAgentName(String agentName) {
		this.agentName = agentName == null ? EMPTYSTRING : agentName.trim();
	}

	public String getAgentCode() {
		return agentCode;
	}

	@XmlElement(name = "C2SAGNTN")
	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode == null ? EMPTYSTRING : agentCode.trim();
	}

	public String getUserDesk() {
		return userDesk;
	}

	@XmlElement(name = "C2LUSRGP")
	public void setUserDesk(String userDesk) {
		this.userDesk = userDesk == null ? EMPTYSTRING : userDesk.trim();
	}

	public String getUserId() {
		return userId;
	}

	@XmlElement(name = "C2LUSRID")
	public void setUserId(String userId) {
		this.userId = userId == null ? EMPTYSTRING : userId.trim();
	}

	public String getAgencyCode() {
		return agencyCode;
	}

	@XmlElement(name = "C2SAGTSU")
	public void setAgencyCode(String agencyCode) {
		this.agencyCode = agencyCode == null ? EMPTYSTRING : agencyCode.trim();
	}

	public String getTrusteeIndicator() {
		return trusteeIndicator;
	}
	
	@XmlElement(name = "Trustee_Indicator")
	public void setTrusteeIndicator(String trusteeIndicator) {
		this.trusteeIndicator = trusteeIndicator;
	}
	
	public String getEcopyIndicator() {
		return ecopyIndicator;
	}
	@XmlElement(name="ECopy_Ind")
	public void setEcopyIndicator(String ecopyIndicator) {
		this.ecopyIndicator = ecopyIndicator;
	}

	public String getEcopyPolicyNo() {
		return ecopyPolicyNo;
	}
	@XmlElement(name="ECopy_PolNo")
	public void setEcopyPolicyNo(String ecopyPolicyNo) {
		this.ecopyPolicyNo = ecopyPolicyNo;
	}

	public String getPrintIndicator() {
		return printIndicator;
	}
	@XmlElement(name="PrintCopy_Ind")
	public void setPrintIndicator(String printIndicator) {
		this.printIndicator = printIndicator;
	}

	public String getPrintPolicyNo() {
		return printPolicyNo;
	}
	@XmlElement(name="PrintCopy_PolNo")
	public void setPrintPolicyNo(String printPolicyNo) {
		this.printPolicyNo = printPolicyNo;
	}
	

	

	@Override
	public String toString() {
		return "COS [letterctl=" + letterctl + ", c2letgrp=" + c2letgrp + ", c2letseq=" + c2letseq + ", c2reqdte="
				+ c2reqdte + ", c2ChdNuM=" + c2ChdNuM + ", c2ReqCoy=" + c2ReqCoy + ", c2OwnName=" + c2OwnName
				+ ", c2TrName1=" + c2TrName1 + ", c2TrName2=" + c2TrName2 + ", c2TrName3=" + c2TrName3 + ", c2TrName4="
				+ c2TrName4 + ", c20Addr1=" + c20Addr1 + ", c20Addr2=" + c20Addr2 + ", c20Addr3=" + c20Addr3
				+ ", c20Addr4=" + c20Addr4 + ", c20Addr5=" + c20Addr5 + ", c2Owctry=" + c2Owctry + ", c2OpCode="
				+ c2OpCode + ", building=" + building + ", agencyName=" + agencyName + ", agentName=" + agentName
				+ ", agentCode=" + agentCode + ", policyNumberList=" + policyNumberList + ", trusteeIndicator="
				+ trusteeIndicator + ", userDesk=" + userDesk + ", userId=" + userId + ", agencyCode=" + agencyCode
				+ ", printIndicator=" + printIndicator + ", printPolicyNo=" + printPolicyNo + ", ecopyIndicator="
				+ ecopyIndicator + ", ecopyPolicyNo=" + ecopyPolicyNo + "]";
	}




	static public class PolIndicator  {
		private String printIndicator;
		private String printPolicyNo;
		private String ecopyIndicator;
		private String ecopyPolicyNo;
		
		public PolIndicator(){
			ecopyIndicator="N";
			ecopyPolicyNo=EMPTYSTRING;
			printIndicator=EMPTYSTRING;
			printPolicyNo=EMPTYSTRING;
		}
		
		public String getEcopyIndicator() {
			return ecopyIndicator;
		}
		
	

		public void setEcopyIndicator(String ecopyIndicator) {
			this.ecopyIndicator = ecopyIndicator;
		}

		public String getEcopyPolicyNo() {
			return ecopyPolicyNo;
		}
		
		public void setEcopyPolicyNo(String ecopyPolicyNo) {
			this.ecopyPolicyNo = ecopyPolicyNo;
		}

		public String getPrintIndicator() {
			return printIndicator;
		}
		
		public void setPrintIndicator(String printIndicator) {
			this.printIndicator = printIndicator;
		}

		public String getPrintPolicyNo() {
			return printPolicyNo;
		}
		
		public void setPrintPolicyNo(String printPolicyNo) {
			this.printPolicyNo = printPolicyNo;
		}
		
		@Override
		public String toString() {
			return "PolIndicator [printIndicator=" + printIndicator + ", printPolicyNo=" + printPolicyNo
					+ ", ecopyIndicator=" + ecopyIndicator + ", ecopyPolicyNo=" + ecopyPolicyNo + "]";
		}
	}
}

