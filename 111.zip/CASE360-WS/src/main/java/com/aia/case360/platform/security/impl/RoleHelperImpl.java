package com.aia.case360.platform.security.impl;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.security.RoleHelper;
import com.aia.case360.web.service.impl.AbstractHelperImpl;
import com.eistream.sonora.security.RoleDefTO;
import com.eistream.sonora.security.RolesElement;

@Component
public class RoleHelperImpl extends AbstractHelperImpl implements RoleHelper {
	private static final String LOCALEXCEPTIONSTR = "Exception:";
	private static final String LOCALLOGINID = "loginId:";
	private static final String LOCALTABLEID = "TableID";
	private static final String LOCALROLE_NAME = "roleName:";
	private static final String LOCALROLENAME = ",roleName:";
	private static final String LOCALISLEAVING = " is Leaving";
	private static final String LOCALISENTERING = " is Entering";
	private static final String LOCALFUNCTIONNAME = "FunctionName: ";
	public final static String COMM_APP_NAME = "common";

	@Override
	public List<String> getAvailableRoles(String loginId, String applicationName) throws RemoteException {
		String message = LOCALFUNCTIONNAME + "getAvailableRoles" + " loginId:" + loginId + " applicationName:"
				+ applicationName;
		LogUtil.logInfo(m_Logger,message + LOCALISENTERING);
		List<String> resultList = getAllRoles(applicationName);
		List<String> myOwnRoles = getMyOwnRoles(loginId);
		resultList.removeAll(myOwnRoles);
		LogUtil.logInfo(m_Logger,"get the role list:" + resultList);
		LogUtil.logInfo(m_Logger,message + LOCALISLEAVING);
		return resultList;

	}

	@Override
	public List<String> getMyOwnRoles(String loginId) throws RemoteException {

		String message = LOCALFUNCTIONNAME + "getMyOwnRoles" + " loginId:" + loginId;
		LogUtil.logInfo(m_Logger,message + LOCALISENTERING);

		if (loginId == null || "".equals(loginId)) {

			return new ArrayList<String>();
		}
		List<RolesElement> roles =  getAllRoleElements();
		List<String> resultList = new ArrayList<String>();
		for (RolesElement role : roles) {
			if (role.getLoginID().equals(loginId)) {
				resultList.add(role.getRole());
			}
		}

		LogUtil.logInfo(m_Logger,"get the role list:" + resultList);
		LogUtil.logInfo(m_Logger,message + LOCALISLEAVING);
		return resultList;
	}

	@Override
	public List<String> getAllRoles(String applicationName) throws RemoteException {
		String message = LOCALFUNCTIONNAME + "getAllRoles,applicationName:" + applicationName;
		LogUtil.logInfo(m_Logger,message + LOCALISENTERING);
		List<String> resultList =  getAllRolesName();
		resultList = getAppRoleList(applicationName, resultList);
		LogUtil.logInfo(m_Logger,message + LOCALISLEAVING);
		return resultList;
	}

	private List<String> getAppRoleList(final String applicationName, final List<String> resultList)
			throws RemoteException {
		String message = LOCALFUNCTIONNAME + "getAppRoleList";
		LogUtil.logInfo(m_Logger,message + LOCALISENTERING);
		if (applicationName == null || "".equals(applicationName)) {
			LogUtil.logError(m_Logger, "input application name is null!");
			return new ArrayList<String>();
		}

		List<String> deleteSystem = new ArrayList<String>();
		for (String roleName : resultList) {
			String appName = "";
			try {
				appName =  getRoleApplicationName(roleName);
			} catch (Exception e) {
				continue;
			}
			if (appName == null) {
				continue;
			}
			if (!(appName.equals(applicationName) || appName.equals(COMM_APP_NAME))) {
				deleteSystem.add(roleName);
				LogUtil.logInfo(m_Logger,deleteSystem.toString());
			}
		}
		if (!deleteSystem.isEmpty()) {
			LogUtil.logInfo(m_Logger,deleteSystem.toString());
			resultList.removeAll(deleteSystem);
		}
		LogUtil.logInfo(m_Logger,message + LOCALISLEAVING);
		return resultList;
	}

	private List<RolesElement> getAllRoleElements() throws RemoteException {
		String message = LOCALFUNCTIONNAME + "getAllRoles";
		LogUtil.logInfo(m_Logger,message + LOCALISENTERING);
		try {
			List<RolesElement> roleList = getRoleEJB().getAllRoles();
			LogUtil.logInfo(m_Logger,message + LOCALISLEAVING);
			return roleList;
		} catch (RemoteException e) {
			
			 
			throw LogUtil.logException(m_Logger, LOCALEXCEPTIONSTR, e);
		}
	}

	private List<String> getAllRolesName() throws RemoteException {
		String message = LOCALFUNCTIONNAME + "getAllRolesName";
		LogUtil.logInfo(m_Logger,message + LOCALISENTERING);
		try {
			List<String> roleList = getRoleEJB().getRolesList();
			LogUtil.logInfo(m_Logger,message + LOCALISLEAVING);
			return roleList;
		} catch (RemoteException e) {
			throw LogUtil.logException(m_Logger, LOCALEXCEPTIONSTR, e);
			 
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> getLoginIdList(String roleName) throws RemoteException {
		String message = LOCALFUNCTIONNAME + "getLoginIdList" + LOCALROLENAME + roleName;
		LogUtil.logInfo(m_Logger,message + LOCALISENTERING);
		try {
			List<String> userList = getRoleEJB().getUserList(roleName);
			LogUtil.logInfo(m_Logger,message + LOCALISLEAVING);
			return userList;
		} catch (RemoteException e) {
			
			 
			throw LogUtil.logException(m_Logger, LOCALROLE_NAME + roleName + LOCALEXCEPTIONSTR, e);
		}
	}

	@Override
	public boolean updateRoleDef(Map<String, String> params) throws RemoteException {
		String message = LOCALFUNCTIONNAME + "updateRoleDef";
		LogUtil.logInfo(m_Logger,message + LOCALISENTERING);
		LogUtil.logInfo(m_Logger,params.toString());
		RoleDefTO rd =  getRoleDef(params);
		try {
			getRoleEJB().updateRoleDef(rd);
			LogUtil.logInfo(m_Logger,message + LOCALISLEAVING);
			return true;
		} catch (RemoteException e) {
			
			 
			throw LogUtil.logException(m_Logger, LOCALEXCEPTIONSTR, e);
		}
	}

	@Override
	public boolean createRoleDef(Map<String, String> params) throws RemoteException {
		String message = LOCALFUNCTIONNAME + "createRoleDef";
		LogUtil.logInfo(m_Logger,message + LOCALISENTERING);
		LogUtil.logInfo(m_Logger,params.toString());
		RoleDefTO rd =  getRoleDef(params);
		getRoleEJB().createRoleDef(rd);
		LogUtil.logInfo(m_Logger,message + LOCALISLEAVING);
		return true;
	}

	public RoleDefTO getRoleDef(Map<String, String> params) {
		RoleDefTO roleDefTO = new RoleDefTO();
		roleDefTO.setRole(params.get("Role"));
		roleDefTO.setScriptName(params.get("ScriptName"));
		roleDefTO.setACL(params.get("ACL"));

		if (params.get(LOCALTABLEID) == null && "".equals(params.get(LOCALTABLEID))) {
			roleDefTO.setTableID(new BigDecimal(params.get(LOCALTABLEID)));
		}

		roleDefTO.setApplicationName(params.get("applicationName"));
		roleDefTO.setModifiedDateTime(new Timestamp(System.currentTimeMillis()));
		return roleDefTO;
	}

	@Override
	public boolean indexRole(String roleName, String loginId) throws RemoteException {
		String message = LOCALFUNCTIONNAME + "indexRole" + LOCALROLENAME + roleName + ",loginId:" + loginId;
		LogUtil.logInfo(m_Logger,message + LOCALISENTERING);

		RolesElement element = new RolesElement();
		element.setRole(roleName);
		try {
			element.setLoginID(loginId);
			getRoleEJB().createRole(element);
			LogUtil.logInfo(m_Logger,message + LOCALISLEAVING);
		} catch (RemoteException e) {
			
			 
			throw LogUtil.logException(m_Logger, LOCALROLE_NAME + roleName + LOCALLOGINID + loginId + LOCALEXCEPTIONSTR, e);
		}
		return true;
	}

	@Override
	public void removeRole(String roleName, String loginId) throws RemoteException {
		String message = LOCALFUNCTIONNAME + "removeRole" + " ,Role:" + roleName + " ,loginId:" + loginId;
		LogUtil.logInfo(m_Logger,message + LOCALISENTERING);
		try {
			getRoleEJB().removeRole(roleName, loginId);
			LogUtil.logInfo(m_Logger,message + LOCALISLEAVING);
		} catch (RemoteException e) {
			
			 
			throw LogUtil.logException(m_Logger, "Role:" + roleName + LOCALLOGINID + loginId + LOCALEXCEPTIONSTR, e);
		}
	}

	@Override
	public boolean updateRoles(String[] roles, String loginID) throws RemoteException {
		String message = LOCALFUNCTIONNAME + "updateRoles" + ",roleSize:" + roles.length + ",loginId:" + loginID;
		LogUtil.logInfo(m_Logger,message + LOCALISENTERING);
		LogUtil.logInfo(m_Logger,Arrays.toString(roles));
		try {
			getRoleEJB().UpdateRoles(roles, loginID);
			LogUtil.logInfo(m_Logger,message + LOCALISLEAVING);
		} catch (RemoteException e) {
			
			 
			throw LogUtil.logException(m_Logger, "roleSize:" + roles.length + LOCALLOGINID + loginID + LOCALEXCEPTIONSTR, e);
		}
		return true;
	}

	private String getRoleApplicationName(String roleName) throws RemoteException {
		String message = LOCALFUNCTIONNAME + "getRoleApplicationName" + LOCALROLENAME + roleName;
		LogUtil.logInfo(m_Logger,message + LOCALISENTERING);
		String applicationName = "";
		try {
			RoleDefTO rd = getRoleEJB().getRoleDef(roleName);
			applicationName = rd.getApplicationName();
			LogUtil.logInfo(m_Logger,message + LOCALISLEAVING);
			return applicationName;
		} catch (RemoteException e) {
			LogUtil.logException(m_Logger, LOCALROLE_NAME + roleName + LOCALEXCEPTIONSTR, e);

			return "";
		}
	}
}
