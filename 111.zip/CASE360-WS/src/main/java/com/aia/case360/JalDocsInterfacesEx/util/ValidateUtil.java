package com.aia.case360.JalDocsInterfacesEx.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.aia.case360.platform.common.PropertyUtil;

public class ValidateUtil {
	
	private static final String REQUESTNUMSTR = "requestNum";
	private static final String LOWERCASEISCORRECTSTR= "isCorrect";

	private ValidateUtil() {
	}

	public static Map checkFirstKeyInfo(String companyNo, String polNum, String formId, String processType,
			String requestNum, String claimNo) {

		String currentEnv = PropertyUtil.getCommonProperty("CURRENT_ENV");
		SimpleDateFormat out = new SimpleDateFormat("yyyyMMdd");
		Map<String, Comparable> keyInfoMap = new HashMap<String, Comparable>();
		boolean isCorrect = true;
		keyInfoMap.put(LOWERCASEISCORRECTSTR, isCorrect);
		if ("SIT".equals(currentEnv) || "DEV".equals(currentEnv)) {
			if (companyNo.isEmpty() || companyNo.length() != 3) {
				companyNo = "011";
			}
			if (validPolNum(polNum)) {
				polNum = "ERRR999999";
			}
			if (formId.isEmpty() || formId.length() != 7) {
				formId = "ERR9999";
			}
			if (processType.isEmpty() || processType.length() != 4) {
				processType = "POSX";
			}
		} else {
			isCorrect = checkKeyFldsValue(companyNo, polNum, formId, processType);
		}
		if(!isCorrect) {
			keyInfoMap.put(LOWERCASEISCORRECTSTR, isCorrect);
			return keyInfoMap;
		}
		keyInfoMap.put("requestNum", requestNum); 
		furthCheck(processType, requestNum, claimNo, out, keyInfoMap);
		
		keyInfoMap.put("companyNo", companyNo);
		keyInfoMap.put("polNum", polNum);
		keyInfoMap.put("formId", formId);
		
		keyInfoMap.put("processType", processType);
		return keyInfoMap;

	}

	private static boolean validPolNum(String polNum) {
		return polNum.isEmpty() || (polNum.length() != 9 && polNum.length() != 10);
	}

	private static void furthCheck(String processType, String requestNum, String claimNo, SimpleDateFormat out,
			Map<String, Comparable> keyInfoMap) {
		if (processType.startsWith("POS")) {
			validPos(requestNum, out, keyInfoMap);
		} else if (processType.startsWith("CLM")) {
			validClm(claimNo, out, keyInfoMap);
		} else if (processType.startsWith("UNI") && (!requestNum.isEmpty())) {
			requestNum = "";
			keyInfoMap.put(REQUESTNUMSTR, requestNum);
		}

	}

	private static void validClm(String claimNo, SimpleDateFormat out, Map<String, Comparable> keyInfoMap) {
		String requestNum;
		if (claimNo.isEmpty()) {
			requestNum = "DC" + out.format(new Date());
			claimNo = requestNum;
			keyInfoMap.put(REQUESTNUMSTR, requestNum);
		} 
		if (claimNo.length() != 10) {
			keyInfoMap.put(LOWERCASEISCORRECTSTR, false);
		} else {
			requestNum = claimNo;
			keyInfoMap.put(REQUESTNUMSTR, requestNum);
		}
	}

	private static void validPos(String requestNum, SimpleDateFormat out, Map<String, Comparable> keyInfoMap) {
		if (requestNum.isEmpty()) {
			requestNum = "DUMYPOS" + out.format(new Date());
			keyInfoMap.put(REQUESTNUMSTR, requestNum);
		} else if (requestNum.length() != 15) {
			keyInfoMap.put(LOWERCASEISCORRECTSTR, false);
		}
	}

	private static boolean checkKeyFldsValue(String companyNo, String polNum, String formId, String processType) {
		boolean isCorrect = true;
		if (companyNo.isEmpty() || companyNo.length() != 3) {
			isCorrect = false;
		}
		if (validPolNum(polNum)) {
			isCorrect = false;
		}
		if (formId.isEmpty() || formId.length() != 7) {
			isCorrect = false;
		}
		if (processType.isEmpty() || processType.length() != 4) {
			isCorrect = false;
		}
		return isCorrect;
	}

}
