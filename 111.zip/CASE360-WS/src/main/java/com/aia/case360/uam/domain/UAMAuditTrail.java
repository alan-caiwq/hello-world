package com.aia.case360.uam.domain;

import com.aia.case360.web.vo.DatetimeFieldSerializer;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

public class UAMAuditTrail {

	private Long sRowid;

	private String actionDesc;

	private String category;

	@JsonSerialize(using = DatetimeFieldSerializer.class, nullsUsing = DatetimeFieldSerializer.class)
	private String createTimestamp;

	private String uamComponentName;

	private String uamUserId;

	private String uamUserName;

	/**
	 * @return the sRowid
	 */
	public Long getsRowid() {
		return sRowid;
	}

	/**
	 * @return the actionDesc
	 */
	public String getActionDesc() {
		return actionDesc;
	}

	/**
	 * @return the category
	 */
	public String getCategory() {
		return category;
	}

	/**
	 * @return the createTimestamp
	 */
	public String getCreateTimestamp() {
		return createTimestamp;
	}

	/**
	 * @return the uamComponentName
	 */
	public String getUamComponentName() {
		return uamComponentName;
	}

	/**
	 * @return the uamUserId
	 */
	public String getUamUserId() {
		return uamUserId;
	}

	/**
	 * @param sRowid the sRowid to set
	 */
	public void setsRowid(Long sRowid) {
		this.sRowid = sRowid;
	}

	/**
	 * @param actionDesc the actionDesc to set
	 */
	public void setActionDesc(String actionDesc) {
		this.actionDesc = actionDesc;
	}

	/**
	 * @param category the category to set
	 */
	public void setCategory(String category) {
		this.category = category;
	}

	/**
	 * @param createTimestamp the createTimestamp to set
	 */
	public void setCreateTimestamp(String createTimestamp) {
		this.createTimestamp = createTimestamp;
	}

	/**
	 * @param uamComponentName the uamComponentName to set
	 */
	public void setUamComponentName(String uamComponentName) {
		this.uamComponentName = uamComponentName;
	}

	/**
	 * @param uamUserId the uamUserId to set
	 */
	public void setUamUserId(String uamUserId) {
		this.uamUserId = uamUserId;
	}

	/**
	 * @return the uamUserName
	 */
	public String getUamUserName() {
		return uamUserName;
	}

	/**
	 * @param uamUserName the uamUserName to set
	 */
	public void setUamUserName(String uamUserName) {
		this.uamUserName = uamUserName;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "UAMAuditTrail [sRowid=" + sRowid + ", actionDesc=" + actionDesc + ", category=" + category
				+ ", createTimestamp=" + createTimestamp + ", uamComponentName=" + uamComponentName + ", uamUserId="
				+ uamUserId + ", uamUserName=" + uamUserName + "]";
	}
}
