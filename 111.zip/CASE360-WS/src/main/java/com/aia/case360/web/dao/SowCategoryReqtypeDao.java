package com.aia.case360.web.dao;

import java.util.List;
import java.util.Map;

import com.aia.case360.web.pojo.SowCategory;
import com.aia.case360.web.pojo.SowCategoryAuditTrail;

public interface SowCategoryReqtypeDao {

	public List<SowCategory> querySowCategory(SowCategory sowCategory);

	public List<SowCategory> querySowCategoryReqType(SowCategory sowReqType);

	public int addSowCategory(SowCategory sowCategory);

	public int addSowReqType(List<SowCategory> sowReqType);

	public int updateSowCategory(SowCategory sowCategory);

	public int delSowReqType(List<SowCategory> sowReqType);

	public List<Map<String, Object>> queryChoosedReqTypeList(Map<String, String> params);

	public int delSowReqTypeByCategory(SowCategory sowCategory);

	public int addAuditTrail(SowCategoryAuditTrail sowCategoryAuditTrail);

	public List<Map<String, Object>> querySowCategoryAuditTrail(String sowCategory);

	public SowCategory querySowCategoryByCategory(SowCategory sowCategory);
}
