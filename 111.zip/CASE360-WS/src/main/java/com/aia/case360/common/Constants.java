/**
 * -------------------------------------------------
 * Copyright (c) 2017-2019 AIA . All Rights Reserved.  
 *-------------------------------------------------
 * Project Name: Pulse
 * @author: Fred Yang
 * @version: 1.0
 * @Date: 2018-03-06
 * Description: 
 * Revised Records:
 */
package com.aia.case360.common;

import com.aia.case360.platform.common.PropertyUtil;

/**
 * @author bsnpbdu
 *
 */
public final class Constants {
	//Leo Yang 20181119  add final
	public final static String UNI_REOPEN = "UI_REOPEN";
	public final static String ALLORGS = "-1";
	public final static String ALLROLESNAME = "allRolesName";
	public final static String AVAILABLEROLESNAME = "availableRolesName";
	public final static String OWNROLESNAME = "ownRolesName";
	public final static String DATE_TIME_FORMAT = "dd/MM/yyyy hh:mm:ss";
	public final static String DATE_FORMAT = "dd/MM/yyyy";
	public final static String SONORA = "SONORA";
	public final static int MIGRATION_COMPLETED = Integer
			.parseInt(PropertyUtil.getCommonProperty("MIGRATION_COMPLETED") == null ? "0"
					: PropertyUtil.getCommonProperty("MIGRATION_COMPLETED"));

	public static enum PAS {
		IL, PLAS, HIAS
	};

	public static enum SUBMISSION_CHANNEL {
		TH, IPOS, IDES, ECOMMERCE, POS_STP, ECARE, OUTLOOK_PLUGIN, EMAIL, MANNUALLY
	};

	public static enum BUSINESS_CHANNEL {
		AGENCY, BANKBROKER
	};

	public static enum DEPARTMENT {
		POS, UNI, CLM, CSV, HNW, SOS, COMMON
	};

	public static enum COMPANY {
		SGP, BRUNEI
	};

	public final static String S_ROWID = "S_ROWID";
	/*
	 * 
	 * a) Edit category b) Delete category c) Edit template d) Delete template e)
	 * Link policy f) Delink policy g) Void comment h) Unvoid comment i) Print
	 */
	public final static String ACTION_EDIT_CATEGORY = "Edit category";
	public final static String ACTION_DELETE_CATEGORY = "Delete category";
	public final static String ACTION_EDIT_TEMPLATE = "Edit template";
	public final static String ACTION_DELETE_TEMPLATE = "Delete template";
	public final static String ACTION_LINK = "Link";
	public final static String ACTION_DELINK = "Delink";
	public final static String ACTION_VOID_COMMENT = "Void comment";
	public final static String ACTION_UNVOID_COMMENT = "Unvoid comment";
	public final static String ACTION_PRINT = "Print comment";

	public final static String OWS_POLICY_NUMBER = "OWS_POLICY_NUMBER";
	public final static String OWS_REQUEST_NUMBER = "OWS_REQUEST_NUMBER";
	public final static String OWS_CLAIM_NUMBER = "OWS_CLAIM_NUMBER";
	public final String OWS_LINKED_POLICY_NUMBER = "OWS_LINKED_POLICY_NUMBER";
	public final static String OWS_LINKED_REQUEST_NUMBER = "OWS_LINKED_REQUEST_NUMBER";
	public final static String OWS_AUDITTRAIL_TYPE = "OWS_AUDITTRAIL_TYPE";
	public final static String OWS_AUDITTRAIL_CREATE_USER = "OWS_AUDITTRAIL_CREATE_USER";
	public final static String OWS_AUDITTRAIL_CREATE_DATE = "OWS_AUDITTRAIL_CREATE_DATE";
	public final static String OWS_ACTION = "OWS_ACTION";

	public final static String OWS_QUERY_TYPE_CASE = "case";
	public final static String OWS_QUERY_TYPE_POLICY = "policyAndClaim";
	public final static String OWS_QUERY_TYPE_TIMESTAMP = "timestamp";

	/**
	 * Field name
	 */
	public static final String UAM_COMPONENT_ID = "UAM_COMPONENT_ID";
	public static final String UAM_COMPONENT_PARENTID = "UAM_COMPONENT_PARENTID";
	public static final String UAM_COMPONENT_PARENTNAME = "UAM_COMPONENT_PARENTNAME";
	public static final String UAM_COMPONENT_NAME = "UAM_COMPONENT_NAME";
	public static final String UAM_COMPONENT_TYPE = "UAM_COMPONENT_TYPE";
}
