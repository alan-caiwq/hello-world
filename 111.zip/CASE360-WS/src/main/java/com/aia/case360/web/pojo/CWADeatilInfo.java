/**
 * 
 */
package com.aia.case360.web.pojo;

/**
 * @author bsnpc55
 *
 */
public class CWADeatilInfo {
	private String cwa;
	private String policyStateCode;
	private String policyNo;
	private String companyNo;
	private String SACSTYP;

	public String getCwa() {
		return cwa;
	}

	public void setCwa(String cwa) {
		this.cwa = cwa;
	}

	public String getPolicyStateCode() {
		return policyStateCode;
	}

	public void setPolicyStateCode(String policyStateCode) {
		this.policyStateCode = policyStateCode;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getCompanyNo() {
		return companyNo;
	}

	public void setCompanyNo(String companyNo) {
		this.companyNo = companyNo;
	}

	public String getSACSTYP() {
		return SACSTYP;
	}

	public void setSACSTYP(String sACSTYP) {
		SACSTYP = sACSTYP;
	}

}
