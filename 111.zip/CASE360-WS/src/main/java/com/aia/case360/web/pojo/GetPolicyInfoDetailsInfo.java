package com.aia.case360.web.pojo;

import java.util.Objects;

import org.apache.commons.lang.StringUtils;

import com.google.gson.annotations.SerializedName;

public class GetPolicyInfoDetailsInfo {
	// companyCode
	@SerializedName(value="companyNo",alternate="companyCode")
	String companyCode;
	
	String companyNo;
	public String getCompanyNo() {
		return companyNo;
	}

	public void setCompanyNo(String companyNo) {
		this.companyNo = companyNo;
	}

	// contractNo
	String contractNo;
	// policyNo
	String policyNo;
	// policyStatus
	String policyStatus;
	// policyStatus
	String policyStatusDesc;
	// inceptionDate
	String inceptionDate;
	// PTD
	String PTD;
	// contractCode
	String contractCode;
	// contractName
	String contractName;
	// source
	String source;
	// payMethod
	String payMethod;
	// product
	String product;
	// policyCurrency
	String policyCurrency;
	String fscCode;
	
	private static final String LAST_DATE = "99/99/9999";
	private static final String OTHER_DATE = "/  /0";
	public String getFscCode() {
		return fscCode;
	}

	public void setFscCode(String fscCode) {
		this.fscCode = fscCode;
	}

	public String getPolicyStatusDesc() {
		return policyStatusDesc;
	}

	public void setPolicyStatusDesc(String policyStatusDesc) {
		this.policyStatusDesc = policyStatusDesc;
	}

	// firstIssueDate
	String firstIssueDate;

	String nric;

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
		this.companyNo=companyCode;
	}

	public String getContractNo() {
		return contractNo;
	}

	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getPolicyStatus() {
		return policyStatus;
	}

	public void setPolicyStatus(String policyStatus) {
		this.policyStatus = policyStatus;
	}

	public String getContractCode() {
		return contractCode;
	}

	public void setContractCode(String contractCode) {
		this.contractCode = contractCode;
	}

	public String getContractName() {
		return contractName;
	}

	public void setContractName(String contractName) {
		this.contractName = contractName;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getPayMethod() {
		return payMethod;
	}

	public void setPayMethod(String payMethod) {
		this.payMethod = payMethod;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getInceptionDate() {
		return inceptionDate;
	}

	public void setInceptionDate(String inceptionDate) {
		if (inceptionDate == null || (inceptionDate.contains(LAST_DATE) || inceptionDate.contains(OTHER_DATE))) {
			this.inceptionDate = null;
		} else {
			this.inceptionDate = inceptionDate;
		}
	}

	public String getPTD() {
		return PTD;
	}

	public void setPTD(String pTD) {
		if (pTD == null || (pTD.contains(LAST_DATE) || pTD.contains(OTHER_DATE))) {
			this.PTD = null;
		} else {
			this.PTD = pTD;
		}
	}

	public String getPolicyCurrency() {
		return policyCurrency;
	}

	public void setPolicyCurrency(String policyCurrency) {
		this.policyCurrency = policyCurrency;
	}

	public String getFirstIssueDate() {
		return firstIssueDate;
	}

	public void setFirstIssueDate(String firstIssueDate) {
		if (firstIssueDate == null || (firstIssueDate.contains(LAST_DATE) || firstIssueDate.contains(OTHER_DATE))) {
			this.firstIssueDate = null;
		} else {
			this.firstIssueDate = firstIssueDate;
		}
	}

	/**
	 * @return the nric
	 */
	public String getNric() {
		return nric;
	}

	/**
	 * @param nric the nric to set
	 */
	public void setNric(String nric) {
		this.nric = nric;
	}


	@Override
	public int hashCode() {
		return Objects.hash(companyCode, contractNo, policyNo, policyStatus, policyStatusDesc, inceptionDate, PTD,
				contractCode, contractName, source, payMethod, product, policyCurrency, firstIssueDate, nric);
	}

	@Override
	public boolean equals(Object o) {
		if (null == o) {
			return false;
		}
		if (o == this)
			return true;

		if (!(o.getClass() == this.getClass())) {
			return false;
		}
		GetPolicyInfoDetailsInfo getPolicyInfoDetailsInfo = (GetPolicyInfoDetailsInfo) o;
		boolean isEqual= Objects.equals(companyCode, getPolicyInfoDetailsInfo.companyCode)
				&& Objects.equals(contractNo, getPolicyInfoDetailsInfo.contractNo)
				&& Objects.equals(policyNo, getPolicyInfoDetailsInfo.policyNo)
				&& Objects.equals(policyStatus, getPolicyInfoDetailsInfo.policyStatus)
				&& Objects.equals(inceptionDate, getPolicyInfoDetailsInfo.inceptionDate)
				&& Objects.equals(PTD, getPolicyInfoDetailsInfo.PTD)
				&& Objects.equals(contractCode, getPolicyInfoDetailsInfo.contractCode)
				&& Objects.equals(contractName, getPolicyInfoDetailsInfo.contractName)
				&& Objects.equals(source, getPolicyInfoDetailsInfo.source)
				&& Objects.equals(payMethod, getPolicyInfoDetailsInfo.payMethod)
				&& Objects.equals(product, getPolicyInfoDetailsInfo.product)
				&& Objects.equals(policyCurrency, getPolicyInfoDetailsInfo.policyCurrency)
				&& Objects.equals(firstIssueDate, getPolicyInfoDetailsInfo.firstIssueDate)
				&& Objects.equals(nric, getPolicyInfoDetailsInfo.nric)
//				&& Objects.equals(fscCode, getPolicyInfoDetailsInfo.fscCode)
				&& Objects.equals(policyStatusDesc, getPolicyInfoDetailsInfo.policyStatusDesc);
		if (isEqual) {
			fscCode=StringUtils.trimToEmpty(fscCode)+","+StringUtils.trimToEmpty(getPolicyInfoDetailsInfo.fscCode);
			getPolicyInfoDetailsInfo.setFscCode(fscCode);
		}
		return isEqual;
	}

}
