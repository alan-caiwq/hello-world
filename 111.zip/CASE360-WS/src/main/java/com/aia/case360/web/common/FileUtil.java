package com.aia.case360.web.common;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import net.sf.json.JSONObject;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.tika.config.TikaConfig;
import org.apache.tika.exception.TikaException;
import org.apache.tika.io.TikaInputStream;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.mime.MediaType;
import org.drools.rule.constraint.ConditionAnalyzer.ThisInvocation;
import org.slf4j.LoggerFactory;

import com.aia.case360.JalDocsInterfacesEx.util.StrUtil;
import com.aia.case360.common.OpCase360CustomProperties;
import com.aia.case360.platform.common.PropertyUtil;
import com.aia.case360.platform.common.LogUtil;
public class FileUtil {
	private static org.slf4j.Logger m_Logger = LoggerFactory.getLogger(FileUtil.class.getName());

	private static String defDocTypes = PropertyUtil.getCommonProperty("DEF_DOC_TYPE");
	private static final String CURRENTDATEFORMAT = "yyyyMMddHHmmss";
	/**
	 * 
	 * @param file
	 * @return
	 */
	public static String readFile(File file) {
		String sTotal = "";
		String read = "";
		String message="Function : readFile ";
		try (BufferedReader bufread = new BufferedReader(new FileReader(file))) {

			
			while ((read = bufread.readLine()) != null) {
				sTotal += read + "\r\n";
			}

		} catch (FileNotFoundException ex) {
			LogUtil.logException(m_Logger, message, ex);
		} catch (IOException ex) {
			LogUtil.logException(m_Logger, message, ex);
		} 
		return sTotal;
	}

	/**
	 * 
	 * @param fileName
	 * @return
	 */
	public static String readFile(String fileName) {

		File file = new File(fileName);
		return readFile(file);
	}

	public static String receiveImages(byte[] imageBytes) {
		long iStart = System.currentTimeMillis();
		LogUtil.logInfo(m_Logger,"FileUtil: receiveImagesType start ========== " + iStart);
		String imageType = "";
		int imageSize = getLenFromByte(imageBytes);
		LogUtil.logInfo(m_Logger,"FileUtil: file length ======= " + imageSize);
		if (imageSize > 0) {

			/************** get file type start ******************/
			imageType = getTypeByStream(imageBytes);
			/************** get file type end ******************/

		}

		long iEnd = System.currentTimeMillis();
		LogUtil.logInfo(m_Logger,"FileUtil: receiveImagesType end ========== " + iEnd);

		return imageType;

	}

	
	/**
	 * get file true type based on file stream
	 * 
	 * @param is
	 * @return
	 */
	public static String getTypeByStream(byte[] fileTypeByte) {
		String imageType = "";
		MediaType mimetype = null;
		InputStream s = new ByteArrayInputStream(fileTypeByte);
		String message ="Function : getTypeByStream";
		// default tika configuration can detect a lot of different file types				
			try {
					TikaConfig tika = new TikaConfig();
					// meta data collected about the source file
					Metadata metadata = new Metadata();
					metadata.set(Metadata.RESOURCE_NAME_KEY, "");
					// determine mime type from file contents   
					mimetype = tika.getDetector().detect(TikaInputStream.get(s), metadata);
					
						
					return getImageType(mimetype);
					
			} catch (IOException e) {
				LogUtil.logException(m_Logger, message, e);
			} catch (TikaException e) {
				LogUtil.logException(m_Logger, message, e);
			}
				
			return imageType;
	}
	
	private static String getImageType(MediaType mimetype) {
		String imageType = "";
		try {
			String strSubType = mimetype.getSubtype();
			imageType = getDocType(strSubType);
			return imageType;
		} catch (Exception e) {
			LogUtil.logException(m_Logger, "getImageType", e);
		}
		return imageType;
	}
	
	/**
	 * get file true type based on file stream
	 * 
	 * @param is
	 * @return
	 */
	public static String getTypeByStreamObsolete(byte[] fileTypeByte) {
		String typeByStreamObsolete1 = getTypeByStreamObsolete1(fileTypeByte);
		String typeByStreamObsolete2 = getTypeByStreamObsolete2(fileTypeByte);
		String typeByStreamObsolete3 = getTypeByStreamObsolete3(fileTypeByte);
		if(!typeByStreamObsolete1.equals("")){
			return typeByStreamObsolete1;
		}else if(!typeByStreamObsolete2.equals("")){
			return typeByStreamObsolete2;
		}else{
			return typeByStreamObsolete3;
		}
		
	}
	public static String getTypeByStreamObsolete1(byte[] fileTypeByte) {

		String type = bytesToHexString(fileTypeByte);
		if (type != null) {
			type = type.toUpperCase();
			// 49492A00/4D4D002A/4D4D002B
			if (type.contains("49492A00") || type.contains("4D4D002A") || type.contains("4D4D002B")) {
				return "tif";
			} else if (type.contains("89504E47")) {
				return "png"; // PNG (png)
			} else if (type.contains("FFD8FF")) {
				return "jpg"; // JPEG (jpg)
			} else if (type.contains("47494638")) {
				return "gif"; // GIF (gif)
			} else if (type.contains("424D")) {
				return "bmp"; // Windows Bitmap (bmp)
			} else if (type.contains("25504446")) {
				return "pdf"; // Adobe Acrobat (pdf)
			} else if (type.contains("D0CF11E0")) { // need confirm
				return "doc"; // MS Word
			} else if (type.contains("504B0304")) {
				return "zip";
			} else if (type.contains("3C3F786D")) {
				return "xml";
			} else if (type.contains("52617221")) { // need confirm
				return "rar";
			}  else {
				return "";
			}
		} else {
			return "";
		}
	}
	public static String getTypeByStreamObsolete2(byte[] fileTypeByte) {

		String type = bytesToHexString(fileTypeByte);
		if (type != null) {
			type = type.toUpperCase();
			// 49492A00/4D4D002A/4D4D002B
			
			 if (type.contains("3C68746D")) { // need confirm
				return "html";
			} else if (type.contains("41433130")) { // need confirm
				return "dwg"; // CAD (dwg)
			} else if (type.contains("38425053")) { // need confirm
				return "PSD"; // photoshop (psd)
			} else if (type.contains("44656C69766572792D646174653A")) { // need
																		// confirm
				return "eml"; // Email [thorough only] (eml)
			} else if (type.contains("CFAD12FEC5FD746F")) { // need confirm
				return "dbx"; // Outlook Express (dbx)
			} else if (type.contains("2142444E")) { // need confirm
				return "pst"; // Outlook (pst)
			} else if (type.contains("5374616E64617264204A")) { // need confirm
				return "mdb"; // MS access (mdb)
			} else if (type.contains("FF575043")) { // need confirm
				return "wpd"; // WordPerfect (wpd)
			} else if (type.contains("252150532D41646F6265")) { // need confirm
				return "eps";
			} else if (type.contains("AC9EBD8F")) { // need confirm
				return "qdf"; // Quicken (qdf)
			} else {
				return "";
			}
		} else {
			return "";
		}
	}
	
	public static String getTypeByStreamObsolete3(byte[] fileTypeByte) {

		String type = bytesToHexString(fileTypeByte);
		if (type != null) {
			type = type.toUpperCase();
			// 49492A00/4D4D002A/4D4D002B
			if (type.contains("E3828596")) { // need confirm
				return "pwl"; // Windows Password (pwl)
			} else if (type.contains("57415645")) { // need confirm
				return "wav"; // Wave (wav)
			} else if (type.contains("41564920")) { // need confirm
				return "avi";
			} else if (type.contains("2E7261FD")) { // need confirm
				return "ram"; // Real Audio (ram)
			} else if (type.contains("2E524D46")) { // need confirm
				return "rm"; // Real Media (rm)
			} else if (type.contains("000001BA")) { // need confirm
				return "mpg";
			} else if (type.contains("6D6F6F76")) { // need confirm
				return "mov"; // Quicktime (mov)
			} else if (type.contains("3026B2758E66CF11")) { // need confirm
				return "asf"; // Windows Media (asf)
			} else if (type.contains("4D546864")) { // need confirm
				return "mid"; // MIDI (mid)
			} else if (type.contains("7B5C7274")) { // need confirm
				return "rtf";
			} else {
				return "";
			}
		} else {
			return "";
		}
	}
	/**
	 * the traditional io way
	 * 
	 * @param filename
	 * @return
	 * @throws IOException
	 */
	public static byte[] toByteArray(String filename) throws IOException {

		File f = new File(filename);
		if (!f.exists()) {
			throw new FileNotFoundException(filename);
		}
		
		try(ByteArrayOutputStream bos = new ByteArrayOutputStream((int) f.length());
				BufferedInputStream in = new BufferedInputStream(new FileInputStream(f));) {
			
			int buf_size = 1024;
			byte[] buffer = new byte[buf_size];
			int len = 0;
			while (-1 != (len = in.read(buffer, 0, buf_size))) {
				bos.write(buffer, 0, len);
			}
			return bos.toByteArray();
		} catch (IOException e) {
			throw LogUtil.logException(m_Logger, "", e);
		} 
	}

	/**
	 * get file length based on byte array
	 * 
	 * @param b
	 * @return
	 */
	public static int getLenFromByte(byte[] b) {
		InputStream in = null;
		in = new ByteArrayInputStream(b);
		int len = 0;
		try {
			len = in.available();
		} catch (IOException e) {
			LogUtil.logException(m_Logger, "", e);
		} finally {
			try {
				in.close();
			} catch (IOException e) {
				 
				len = -1;
			}
		}
		return len;
	}

	/**
	 * generate Failed object Txt file
	 * 
	 */
	public static int genFailedObjTxtFile(String txtFilePath, String objectId) {

		int iReturn = 0;
		File txtFile = new File(txtFilePath);
		String message="Function : genFailedObjTxtFile";
		try (FileWriter writer = new FileWriter(txtFilePath, true);) {
			if (!txtFile.exists()) {
				boolean createFile =txtFile.createNewFile();
				if(createFile){
					LogUtil.logInfo(m_Logger, message+"create file success");
				}else{
					LogUtil.logInfo(m_Logger, message+"create file failed");	
				}
			}
			
             writer.write(objectId + "\r\n");

		} catch (IOException ex) {
			iReturn = -1;
			LogUtil.logError(m_Logger, ex.toString());
		} catch (Exception e) {
			iReturn = -1;
			 
			LogUtil.logError(m_Logger, e.toString());
		}
		return iReturn;
	}

	/**
	 * byte array convert to 16 band string
	 * 
	 * @param src add by feng
	 * @return
	 */
	public static String bytesToHexString(byte[] src) {
		StringBuilder stringBuilder = new StringBuilder();
		if (src == null || src.length <= 0) {
			return null;
		}
		for (int i = 0; i < src.length; i++) {
			int v = src[i] & 0xFF;
			String hv = Integer.toHexString(v);
			if (hv.length() < 2) {
				stringBuilder.append(0);
			}
			stringBuilder.append(hv);
		}
		return stringBuilder.toString();
	}

	public String getRandomRequestNo() {
		List<String> list = new ArrayList<String>();
		for (int i = 0; i < 100; i++) {
			String randomReqNoStartStr = "$P";
			String randomReqNo = null;
			randomReqNo = String.valueOf(System.nanoTime());
			randomReqNo = randomReqNoStartStr + randomReqNo.substring(randomReqNo.length() - 13, randomReqNo.length());
			list.add(randomReqNo);
		}
		for (String s : list) {
			LogUtil.logInfo(m_Logger,s);
		}
		return null;
	}
	
	public static String getDocType(String fileType)   {
		
		Set defDocTypeSet;
		String docType = "";
		
		defDocTypeSet = StrUtil.strToSet(defDocTypes);
	    Iterator it = defDocTypeSet.iterator();

	    while (it.hasNext()) {
	        String docTypeMap = (String) it.next();

	        if (fileType.equalsIgnoreCase(docTypeMap.split(":")[0])) {
	            docType = docTypeMap.split(":")[1];
	            break;
	        }
	    }

	    m_Logger.info(" FileUtil : default docType=" + docType);

	    return docType;
	    
	}
	
	/**
	 * generate a excel file 
	 * @param fileName file's name and path
	 * @param datas
	 * @throws IOException 
	 */
	public static void generateExcel(String fileName, List<Map<String, Object>> datas, String sheetName, String[] keys, String[] colKey_display) throws IOException{
		File f = new File(fileName);
		if(!f.exists()){
			if(!new File(f.getParent()).exists()){
				new File(f.getParent()).mkdirs();
			}
			f.createNewFile();
		}
		 m_Logger.error("generateExcel : file created");
		SXSSFWorkbook workbook = new SXSSFWorkbook(1000);
		sheetName = CommonUtil.getString(sheetName, "sheet1");
		Sheet sheet = workbook.createSheet(sheetName);
		if(colKey_display == null || colKey_display.length == 0){
			colKey_display = keys;
		}
		createHead(workbook, sheet, datas, colKey_display);
		m_Logger.error("generateExcel : head created");
		OutputStream outputStream = new FileOutputStream(fileName);
		if(datas == null || datas.size() == 0){
			workbook.write(outputStream);
			m_Logger.error("generateExcel : write head only");
			return;
		}
		createBody(workbook, sheet, datas, keys);
		m_Logger.error("generateExcel : body created");
		workbook.write(outputStream);
		m_Logger.error("generateExcel : write body end");
	}

	private static void createBody(SXSSFWorkbook workbook, Sheet sheet,
			List<Map<String, Object>> datas, String[] keys) {
		CellStyle columnStyle = getBodyStyle(workbook);
		Map<String, Object> map = datas.get(0);
		Set<String> headSet = map.keySet();
		String[] headArray = getSetStringArray(headSet);
		if(keys != null && keys.length > 0){
			headArray = keys;
		}
		int rowCount = 1;
		for (Map<String, Object> dataMap : datas) {
			int rowColunmCount = 0;
			Row row = sheet.createRow(rowCount);
			for (String key : headArray) {
				Cell cell = row.createCell(rowColunmCount);
				cell.setCellType(1);
				String currentValue = String.valueOf(dataMap.get(key));
				XSSFRichTextString text = new XSSFRichTextString(currentValue);
				if (String.valueOf(text).trim().equals("null".trim())) {
					text = new XSSFRichTextString("");
				}
				cell.setCellValue(text);
				cell.setCellStyle(columnStyle);
//				sheet.autoSizeColumn(rowColunmCount);
				rowColunmCount++;
			}
			rowCount++;
		}
	}
	
	private static String[] getSetStringArray(Set<String> headSet) {
		String[] res = new String[headSet.size()];
		int i = 0;
		for(String s : headSet){
			res[i]= s;
			i++;
		}
		return res;
	}

	private static CellStyle getBodyStyle(SXSSFWorkbook workbook) {
		Font font = workbook.createFont();
		font.setFontName("Courier New");
		CellStyle style = workbook.createCellStyle();
		style.setBorderBottom((short) 1);
		style.setBottomBorderColor((short) 8);
		style.setBorderLeft((short) 1);
		style.setLeftBorderColor((short) 1);
		style.setBorderRight((short) 1);
		style.setRightBorderColor((short) 8);
		style.setBorderTop((short) 1);
		style.setTopBorderColor((short) 8);
		style.setFont(font);
		style.setWrapText(false);
		style.setAlignment(CellStyle.ALIGN_CENTER);
		style.setVerticalAlignment((short) 1);
		return style;
	}

	/**
	 * create excel head
	 * @param workbook
	 * @param sheet
	 * @param datas
	 */
	private static void createHead(SXSSFWorkbook workbook, Sheet sheet, List<Map<String, Object>> datas, String[] keys) {
		String[] headArray = null;
		if(datas != null && datas.size() > 0){
			Map<String, Object> map = datas.get(0);
			Set<String> headSet = map.keySet();
			headArray = getSetStringArray(headSet);
		}
		if(keys != null && keys.length > 0){
			headArray = keys;
		}
		if(headArray == null){
			return;
		}
		CellStyle columnTopStyle = getColumnTopStyle(workbook);
		Row rowRowName = sheet.createRow(0);
		int columnTemp = 0;
		for (String head : headArray) {
			Cell cellRowName = rowRowName.createCell(columnTemp);
			cellRowName.setCellType(1);
			XSSFRichTextString text = new XSSFRichTextString(head);
			cellRowName.setCellValue(text);
			cellRowName.setCellStyle(columnTopStyle);
//			sheet.autoSizeColumn(columnTemp);
			columnTemp++;
		}
	}

	/**
	 * get head style
	 * @param workbook
	 * @return
	 */
	private static CellStyle getColumnTopStyle(SXSSFWorkbook workbook) {
		Font font = workbook.createFont();
		font.setFontHeightInPoints((short) 11);
		font.setBoldweight((short) 700);
		font.setFontName("Courier New");
		CellStyle style = workbook.createCellStyle();
		style.setBorderBottom((short) 1);
		style.setBottomBorderColor((short) 10);
		style.setBorderLeft((short) 1);
		style.setLeftBorderColor((short) 8);
		style.setBorderRight((short) 1);
		style.setRightBorderColor((short) 8);
		style.setBorderTop((short) 1);
		style.setTopBorderColor((short) 8);
		style.setFont(font);
		style.setWrapText(false);
		style.setAlignment(CellStyle.ALIGN_CENTER);
		style.setVerticalAlignment((short) 1);
		style.setFillForegroundColor((short) 10);
		style.setFillPattern((short) 1);
		return style;
	}
	
	// Harry updated 20190228
	private void writeExcel(SXSSFWorkbook workbook, JSONObject params) {
		if (workbook != null) {
			try(OutputStream outputStream = new FileOutputStream(assertFile(params))){
				workbook.write(outputStream);
			} catch (IOException e) {
				m_Logger.error("Write Excel error" + e);
			}finally{
				workbook = null;
			}
		}
	}
	
	/**
     * 
     * @param directory 
     * @param fileName 
     * @return file
     * @throws IOException
     */
    private File assertFile(JSONObject params) throws IOException {
    	String filePath = null;
    	File tmpFile = null;
		try {
			String currentUser = getJsonByString("loginId", params);
			String setupPath = OpCase360CustomProperties.getCase360CustomProperty("Report_Share_Folder_URL");
			String fileName = getJsonByString("fileName", params);
			SimpleDateFormat sdf = new SimpleDateFormat(CURRENTDATEFORMAT);
			String createdTimestamp = sdf.format(new Date());
			filePath = setupPath + File.separator + currentUser + File.separator + fileName + "_" + currentUser + "_" + createdTimestamp + "xls";
			tmpFile = new File(filePath);
			if (tmpFile.exists()) {
				throw new IOException("File '" + tmpFile + "' exists but is a directory, or cannot be written to");
	        } else {
	            File parent = tmpFile.getParentFile();
	            if (parent != null && !parent.mkdirs() && !parent.isDirectory()) {
	            	throw new IOException("Directory ' " + parent + "' could not be created");
	            }
	        }
		} catch (Exception e) {
			m_Logger.error("Create File Path error " + e);
		}  
        return tmpFile;
    }
	private String getJsonByString(String key,JSONObject params){
		if(params.has(key)){
			return params.getString(key);
		}
		return null;
	}
	
}
