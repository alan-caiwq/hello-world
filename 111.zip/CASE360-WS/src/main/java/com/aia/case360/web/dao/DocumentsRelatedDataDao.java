package com.aia.case360.web.dao;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.ibatis.annotations.Param;

import com.aia.case360.web.pojo.ConvertAttributesToAttrDocLinkResult;
import com.aia.case360.web.pojo.DocLinkInfo;
import com.aia.case360.web.pojo.DocLinkParam;
import com.aia.case360.web.pojo.FdDocAttr;
import com.aia.case360.web.pojo.FdDocAuditTrail;
import com.aia.case360.web.pojo.FdDocLink;
import com.aia.case360.web.pojo.FdDocNotes;
import com.aia.case360.web.pojo.FsDocumentsVo;
import com.aia.case360.web.pojo.LinkParam;
import com.aia.case360.web.pojo.PolNum;
import com.aia.case360.web.pojo.PolicyInfoParameter;
import com.aia.case360.web.pojo.TreeDocInfo;
import com.aia.case360.web.vo.CaseDocInfo;
import com.aia.case360.web.vo.ClientDocHierarchy;
import com.aia.case360.web.vo.PolicyDocHierarchy;
import com.aia.case360.web.vo.PolicyDocumentHierarchy;
import com.aia.case360.web.vo.RenameDocFormClientParam;
import com.aia.case360.web.vo.RenameDocFormLinkParam;
import com.aia.case360.web.vo.SLAParam;

import net.sf.json.JSONObject;

public interface DocumentsRelatedDataDao {

	public int updateFsDocuments(FsDocumentsVo fsDocumentsVo);

	public List<PolNum> queryPolicyListByCaseId(String caseId);

	public int insertFdDocAttrs(List<FdDocAttr> fdDocAttrs);

	public String queryFormLevelByFormId(String formId);

	public int insertFdDocClints(List<FdDocLink> fdDocClints);

	public int insertFdDocLinks(List<FdDocLink> fdDocLinks);

	public int insertFdDocLinksForImportDoc(List<FdDocLink> fdDocLinks);

	public int insertFdDocLinksNoAspect(List<FdDocLink> fdDocLinks);

	public List<String> queryNric(String policyNo);

	public boolean renameDocFormLinks(List<RenameDocFormLinkParam> dfLinks) throws RemoteException;

	public boolean renameDocFormClient(RenameDocFormClientParam dfClient) throws RemoteException;

	public String getSerialNo(String funcCode) throws RemoteException;

	public String getSLADueDate(SLAParam param);

	public int addReadDoc(Map<String, String> param);

	public String checkPermission(String userId);

	public List<Map<String, Object>> listCaseDocs(Map<String, String> param) throws RemoteException;

	public void voidDocLinks(@Param("linkIdList") List<BigDecimal> linkIdList, @Param("voidFlag") String voidFlag)
			throws RemoteException;

	public void voidAllDocLinks(@Param("docId") long docId, @Param("voidFlag") String voidFlag) throws RemoteException;

	public Integer IsDocRead(Map<String, String> readerIdAndObjIdMap);

	/**
	 * 
	 * @param fdDocAuditTrail
	 */
	public void insertOneFdDocAuditTrail(FdDocAuditTrail fdDocAuditTrail) throws RemoteException;

	public void insertFdDocAuditTrails(List<FdDocAuditTrail> fdDocAuditTrails) throws RemoteException;

	public List<Map<String, Object>> listDocAuditTrail(Map<String, Object> param) throws RemoteException;

	public List<Map<String, Object>> getDocLinkByID(List<String> param) throws RemoteException;

	// added by bsnpc1g: to get the form information by form category
	public List<Map<String, Object>> queryFormInfoByFormCategory(@Param("category") String category) throws RemoteException;

	public Integer isDocIntegrity(Map<String, String> param) throws RemoteException;

	public TreeDocInfo getMigratedDocInfo(@Param("objectId") String objectId, @Param("userId") String userId);

	public String getObjectIdByDocId(String paramString);

	public void insertDocMigDemandTable(@Param("policySet") Set<String> policySet) throws RemoteException;

	public List<Map<String, Object>> getDocLink(Map<String, Object> docLink);

	public int deleteDocLink(Map<String, Object> docLink);

	public int deleteDocLinkNoAspect(Map<String, Object> docLink);

	public Integer saveDocLink(Map<String, Object> insertParam);

	public List<Map<String, Object>> documentAuditTrail(JSONObject params) throws RemoteException;

	public List<ConvertAttributesToAttrDocLinkResult> convertAttributesToAttrDocLink(
			@Param("objectIds") String objectIds, @Param("deleteFlag") Integer deleteFlag) throws RemoteException;

	public Integer updateDocLinkToDeleted(@Param("rowId") String rowId) throws RemoteException;

	public List<Map<String, Object>> getDocNotes(FdDocNotes fdDocNotes) throws RemoteException;

	public int addDocNotes(FdDocNotes fdDocNotes) throws RemoteException;

	public List<Map<String, String>> getDocProperties(Map<String, String> param) throws RemoteException;

	public int insertDocClient(@Param("NRIC") String NRIC, @Param("polNum") String polNum,
			@Param("formId") String formId, @Param("objectId") String objectId, @Param("newObjID") String newObjID,
			@Param("hashNric") String hashNric, @Param("requestNum") String requestNum) throws RemoteException;


    public List<PolicyDocumentHierarchy> getPolicyHierarchyByPolList(@Param("userId")String userId, @Param("companyNo")String companyNo, @Param("polList")String polList) throws RemoteException;

    public List<PolicyInfoParameter> getPolicySourceInfo(@Param("policyNums")List<String> policyNums) throws RemoteException;

	public int deleteDocClient(@Param("NRIC") String NRIC, @Param("objectId") String objectId);


	public List<PolicyDocHierarchy> getPolicyDocHierarchy(@Param("userId") String userId,
			@Param("companyNo") String companyNo, @Param("policyNo") String policyNo, @Param("isTree") int isTree)
			throws RemoteException;

	public List<PolicyDocumentHierarchy> getPolicyHierarchy(@Param("userId") String userId,
			@Param("companyNo") String companyNo, @Param("policyNo") String policyNo, @Param("isTree") int isTree)
			throws RemoteException;

	public List<ClientDocHierarchy> getClientDocHierarchy(@Param("userId") String userId, @Param("nric") String nric)
			throws RemoteException;

	public List<CaseDocInfo> getCaseDocList(@Param("userId") String userId, @Param("caseId") String caseId)
			throws RemoteException;

	public int addDocLinkAuditTrail(@Param("docAudit") FdDocAuditTrail docAudit) throws RemoteException;

	public List<Map<String, Object>> searchByDocId(String docId) throws RemoteException;

	public String searchLogicLinkId(@Param("objectIdBy") String objectIdBy, @Param("reqNumBy") String reqNumBy,
			@Param("polNumBy") String polNumBy, @Param("formIdBy") String formIdBy) throws RemoteException;

	public String getEncryptNricInfo(@Param("nric") String nric) throws RemoteException;

	public List<Map<String, Object>> getDocLinkByRequestNum(@Param("reqNum") String reqNum) throws RemoteException;

    public List<Map<String, Object>> getMulitObjectDocLinks(@Param("params") List<LinkParam> params) throws RemoteException;
    
    public void updateLinkLogicalFlag(@Param("objectId") String objectId) throws RemoteException;

    public String getChangedObjectId(@Param("objectId") String objectId) throws RemoteException;

    public Integer getLogicObjectId(@Param("funcCode") String funcCode) throws RemoteException;

    public List<DocLinkInfo> getLinkInfoById(@Param("rowIds")List<BigDecimal> rowIdList) throws RemoteException;

    public void batchAddDocLinkWithNoAspect(@Param("list") List<DocLinkParam> list) throws RemoteException;
    //PBR-4468
    void deleteDocLinkForRB(List<BigDecimal> docids);
    //PBR-4468
    void deleteCaseDoc(List<BigDecimal> docids);
}