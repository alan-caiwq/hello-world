package com.aia.case360.web.dao;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

@Repository
public interface POSErrorReportDao {

	public List<String> getDepReqType(Map<String, String> params)  throws RemoteException;

	public List<Map<String, String>> getErrorReport(Map<String, String> params)  throws RemoteException;

	public List<Map<String, String>> getErrorReportDropdownList(Map<String, String> params)  throws RemoteException;

	public int insertErrorReport(Map<String, String> params)  throws RemoteException;

	public int updateErrorReport(Map<String, String> params)  throws RemoteException;

}
