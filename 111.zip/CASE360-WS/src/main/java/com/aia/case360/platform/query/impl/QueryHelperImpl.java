package com.aia.case360.platform.query.impl;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.enterprise.inject.New;

import org.apache.commons.lang.StringEscapeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.CallableStatementCallback;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.aia.case360.platform.common.CaseUtilities;
import com.aia.case360.platform.common.DataFieldUtil;
import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.common.PropertyUtil;
import com.aia.case360.platform.common.QueryResultsHandler;
import com.aia.case360.platform.query.QueryHelper;
import com.aia.case360.web.common.CommonUtil;
import com.aia.case360.web.service.impl.AbstractHelperImpl;
import com.eistream.sonora.fields.FieldPropertiesTO;
import com.eistream.sonora.fields.FmsRowSetTO;

@Component
public class QueryHelperImpl extends AbstractHelperImpl implements QueryHelper {

	private static final String WORKSTEPNAMESTR = "WORKSTEPNAME";
	private static final String USERNAMESTR = "USER_NAME";
	private static final String LINKCASEIDSTR = "LINKCASEID";
	private static final String CURRENTUSERSTR = "CURRENT_USER";
	private static final String CASEIDSTR = "CASEID";
	private static final String REQTYPESTR = "REQ_TYPE";
	private static final String DOCFORMIDSTR = "DOC_FORM_ID";
	private static final String POLICYNUMSTR = "POLICY_NUM";
	private static final String CLIENTIDSTR = "CLIENT_ID";
	private static final String POLNUMSTR = "POL_NUM";
	private static final String ISSTARTSTR = " is start .";
	private static final String QRESULTSTR = "queryResult:";
	private static final String ISLEAVESTR = " is leaving .";
	private static final String COMNOSTR = "COMPANY_NO";
	private static final String LOWERCOMNOSTR = "companyNo";
	private static final String LOWERPOLNOSTR = "policyNo";
	private static final String QGETDOCLISTSTR = "QUERY_Get_DocList";
	private static final String LOWERPRONMSTR = "processName";
	private static final String CREATEDBYSTR = "CREATED_BY";
	private static final String EEXCEPTIONSTR = "E_EXCEPTION";
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	/**
	 * Get user list by workstep
	 * 
	 * @param workstep
	 * @return
	 * @throws RemoteException
	 * 
	 */
	public ArrayList<Map<String, Object>> getUserListByWorkstep(String workstep) throws RemoteException {

		Map<String, String> queryParams = new HashMap<String, String>();

		queryParams.put(PropertyUtil.getCommonProperty(WORKSTEPNAMESTR), workstep);

		ArrayList<Map<String, Object>> queryResult = doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_USERLIST_GETBYWORKSTEP"));
		return queryResult;

	}

	/**
	 * Get Role List by workstep name
	 * 
	 * @param workstep
	 * @return
	 * @throws RemoteException
	 */
	public ArrayList<Map<String, Object>> getRoleListByWorkstep(String workstep) throws RemoteException {

		Map<String, String> queryParams = new HashMap<String, String>();

		queryParams.put(PropertyUtil.getCommonProperty(WORKSTEPNAMESTR), workstep);

		ArrayList<Map<String, Object>> queryResult =  doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_ROLELIST_GETBYWORKSTEP"));

		return queryResult;

	}

	/**
	 * Get queue names by userId
	 * 
	 * @param userId
	 * @return
	 * @throws RemoteException
	 */
	public ArrayList<Map<String, Object>> getMyQueueNames(String userId) throws RemoteException {

		Map<String, String> queryParams = new HashMap<String, String>();

		queryParams.put(PropertyUtil.getCommonProperty(USERNAMESTR), userId);

		ArrayList<Map<String, Object>> queryResult =  doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_QUEUENAME_GETBYUSERID"));

		return queryResult;

	}

	/**
	 * Get document information by caseId
	 * 
	 * @param caseId
	 * @return
	 * @throws RemoteException
	 */
	public ArrayList<Map<String, Object>> getDocumentInfo(String caseId, String userId) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(PropertyUtil.getCommonProperty(LINKCASEIDSTR), caseId);
		queryParams.put(CURRENTUSERSTR, userId);
		ArrayList<Map<String, Object>> queryResult =  doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_DOCUMENTS_GETBYCASEID"));

		return queryResult;

	}

	/**
	 * Get QueueHeader Queue Name WorkItem Num by userId
	 * 
	 * @param userId Login userId
	 * @return
	 * @throws RemoteException
	 */
	public ArrayList<Map<String, Object>> getMyQueueHeaders(String userId) throws RemoteException {

		Map<String, String> queryParams = new HashMap<String, String>();

		queryParams.put(PropertyUtil.getCommonProperty(USERNAMESTR), userId);

		ArrayList<Map<String, Object>> queryResult =  doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_QUEUEHEADER_GETBYUSER"));

		return queryResult;
	}

	/**
	 * Get QueueHeader Queue Name WorkItem Num by userId,workstep,workflowId
	 * 
	 * @param userId
	 * @param workstep
	 * @param workflowId
	 * @return
	 * @throws RemoteException
	 */
	public ArrayList<Map<String, Object>> getMyQueueHeaders(String userId, String workstep, String workflowId)
			throws RemoteException {

		Map<String, String> queryParams = new HashMap<String, String>();

		queryParams.put(PropertyUtil.getCommonProperty(USERNAMESTR), userId);
		queryParams.put(PropertyUtil.getCommonProperty(WORKSTEPNAMESTR), workstep);
		queryParams.put(PropertyUtil.getCommonProperty("WORKFLOWID"), workflowId);
		ArrayList<Map<String, Object>> queryResult =  doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_QUEUEHEADER_GETBYUSER"));

		return queryResult;
	}

	@Override
	public String getUserId(String caseId, String workstep) throws RemoteException {
		String userId = null;
		Map<String, String> queryParams = new HashMap<String, String>();

		queryParams.put(PropertyUtil.getCommonProperty(LINKCASEIDSTR), caseId);
		queryParams.put(PropertyUtil.getCommonProperty("WFWORKSTEPNAME"), workstep);
		ArrayList<Map<String, Object>> queryResult =  doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_GETUSERIDBYAUDITTRAIL"));
		Iterator<Map<String, Object>> iterator = queryResult.iterator();
		if (iterator.hasNext()) {
			userId = (String) iterator.next().get(PropertyUtil.getCommonProperty("LOGIN_ID"));
		}
		return userId;
	}

	/**
	 * get query's form fields by script name.
	 * 
	 * @author bsnpbrs
	 */
	@Override
	public ArrayList<String> getFormFields(String scriptName) throws RemoteException {
		ArrayList<String> arrayList = new ArrayList<String>();
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(PropertyUtil.getCommonProperty("SCRIPTNAME"), scriptName);
		ArrayList<Map<String, Object>> queryResult =  doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_FORMFIELDSBYSCRIPTNAME"));
		Iterator<Map<String, Object>> iterator = queryResult.iterator();
		while (iterator.hasNext()) {
			arrayList.add((String) iterator.next().get(PropertyUtil.getCommonProperty("FIELD_NAME")));
		}
		return arrayList;
	}

	/**
	 * 
	 * Get userId's own job list by workstep
	 * 
	 * @param userId   login userId should be registered in Case360 side.
	 * @param workstep activity name indicates which activity queue for finding
	 *                 workitems of the current user
	 * @return queryResults
	 * @throws RemoteException
	 */
	public ArrayList<Map<String, Object>> getJobs(String userId, String workstep, String pndWait)
			throws RemoteException {

		Map<String, String> queryParams = new HashMap<String, String>();
		LogUtil.logInfo(m_Logger,userId + ":" + workstep + ":" + pndWait);
		queryParams.put(PropertyUtil.getCommonProperty(USERNAMESTR), userId);
		queryParams.put(PropertyUtil.getCommonProperty(WORKSTEPNAMESTR), workstep);
		queryParams.put("f_riorStepName", pndWait);

		return doQuery(queryParams, PropertyUtil.getScriptAndQueryProperty("QUERY_MYWORKLIST_GETBYWORKSTEP"));
	}

	private FmsRowSetTO[] doQuery4RowSet(Map<String, String> queryParams, String queryName) throws RemoteException {
		String message = "queryName:" + queryName;

		String paramStr = DataFieldUtil.getInMapStr(queryParams);

		if (paramStr != null && paramStr.length() > 0) {
			message += "," + paramStr;
		} else {
			message += ", no query parameters input!";
		}

		// Get the list of contents
		FieldPropertiesTO[] queryFields = null;
		if (queryParams != null) {
			queryFields = new FieldPropertiesTO[queryParams.size()];

			int fieldsNum = 0;
			
			for (Entry<String, String> paramName : queryParams.entrySet()) {
				queryFields[fieldsNum++] = CaseUtilities.createFieldPropertyTO(paramName.getKey(), paramName.getValue());
			}
		}
		try {

			FmsRowSetTO[] queryResultsSet = null;
			if (queryFields == null || queryFields.length == 0) {
				queryResultsSet = getWsEJB().doQueryByNameNoFormFields(queryName);
			} else {
				queryResultsSet = getWsEJB().doQueryByScriptName(queryName, queryFields);
			}

			LogUtil.logInfo(m_Logger,"wsEJB queryResultsSet:" + queryResultsSet[0].getRowCount());
			LogUtil.logInfo(m_Logger,message);
			return queryResultsSet;
		} catch (RemoteException e) {
			 
			LogUtil.logError(m_Logger, message + " " + e.getMessage());
			e = new RemoteException(message, e);
			throw e;
		}
	}

	public ArrayList<Map<String, Object>> doQuery(Map<String, String> queryParams, String queryName)
			throws RemoteException {

		String message = "queryName:" + queryName;

		String paramStr = DataFieldUtil.getInMapStr(queryParams);

		if (paramStr != null && paramStr.length() > 0) {
			message += "," + paramStr;
		} else {
			message += ", no query parameters input!";
		}

		ArrayList<Map<String, Object>> queryResults;
		try {
			FmsRowSetTO[] queryResultsSet = doQuery4RowSet(queryParams, queryName);
			LogUtil.logInfo(m_Logger,"queryResultsSet.length:" + queryResultsSet.length);
			queryResults = QueryResultsHandler.convertQueryResultsAsObject(queryResultsSet);
			LogUtil.logInfo(m_Logger,message);
			return queryResults;
		} catch (RemoteException e) {
			 
			LogUtil.logError(m_Logger, message + " " + e.getMessage());
			e = new RemoteException(message, e);
			throw e;
		}
	}

	@Override
	public ArrayList<Map<String, Object>> getPendingReasons(String WORKSTEPNAME) throws RemoteException {

		Map<String, String> queryParams = new HashMap<String, String>();

		queryParams.put(PropertyUtil.getCommonProperty(WORKSTEPNAMESTR), WORKSTEPNAME);

		return doQuery(queryParams, PropertyUtil.getScriptAndQueryProperty("QUERY_PENDREASONLIST_GETBYREQTYPE"));
	}

	@Override
	public ArrayList<Map<String, Object>> getMyPendings(String userId) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();

		queryParams.put(PropertyUtil.getCommonProperty(CURRENTUSERSTR), userId);

		return doQuery(queryParams, PropertyUtil.getScriptAndQueryProperty("QUERY_MYPENDCASELIST"));
	}

	@Override
	public ArrayList<Map<String, Object>> getMyPendingCount(String userId) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();

		queryParams.put(PropertyUtil.getCommonProperty(USERNAMESTR), userId);

		return doQuery(queryParams, PropertyUtil.getScriptAndQueryProperty("QUERY_MYPENDINGCOUNT"));
	}

	@Override
	public ArrayList<Map<String, Object>> getUnreceivedPendingReasons(String caseIdStr) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();

		queryParams.put(PropertyUtil.getCommonProperty(CASEIDSTR), caseIdStr);

		return doQuery(queryParams, PropertyUtil.getScriptAndQueryProperty("QUERY_UNRECEIVEDREASONS"));
	}

	@Override
	public ArrayList<Map<String, Object>> getAllPendingHistory(String caseId) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();

		queryParams.put(PropertyUtil.getCommonProperty(LINKCASEIDSTR), caseId);

		return doQuery(queryParams, PropertyUtil.getScriptAndQueryProperty("QUERY_PENDINGHISTBYCID"));
	}

	@Override
	public ArrayList<Map<String, Object>> getAllAuditTrail(String caseId) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();

		queryParams.put(PropertyUtil.getCommonProperty(CASEIDSTR), caseId);

		return doQuery(queryParams, PropertyUtil.getScriptAndQueryProperty("QUERY_AUDITTRAIL"));
	}

	@Override
	public ArrayList<Map<String, Object>> getUnknownDocList(Map<String, String> parameters) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		// fred, don't use branch.
		queryParams.put(PropertyUtil.getCommonProperty("BRANCH"), "026");

		return doQuery(queryParams, PropertyUtil.getScriptAndQueryProperty("QUERY_VALIDINDEXING"));
	}

	@Override
	public FmsRowSetTO[] getUnreceivedPendHistory(String caseId) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();

		queryParams.put(PropertyUtil.getCommonProperty(CASEIDSTR), caseId);

		return  doQuery4RowSet(queryParams, PropertyUtil.getScriptAndQueryProperty("QUERY_UNRECEIVEDREASONS"));
	}

	@Override
	public ArrayList<Map<String, Object>> getReqTypeAndCategory(String requestType, String category)
			throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(REQTYPESTR, requestType);
		queryParams.put("CATEGORY_CODE", category);
		ArrayList<Map<String, Object>> result = doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_REQTYPEANDCATEGORY"));
		return result;
	}

	@Override
	public ArrayList<Map<String, Object>> getReqTypeAndFormId(String requestType, String formId)
			throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(REQTYPESTR, requestType);
		queryParams.put(DOCFORMIDSTR, formId);
		ArrayList<Map<String, Object>> result = doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_DOCUMENTFORMID_BY_REQTYPE"));
		return result;
	}

	/**
	 * 
	 * get policy by policyNum
	 * 
	 * @return have one item return caseID
	 */
	@Override
	public ArrayList<Map<String, Object>> getPolicyTable(String policyNum) throws RemoteException {

		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(PropertyUtil.getCommonProperty(POLICYNUMSTR), policyNum);
		return doQuery(queryParams, PropertyUtil.getScriptAndQueryProperty("QUERY_POLICY"));
	}

	/**
	 * 
	 * get policy coverage by policyNum and certNum
	 */
	@Override
	public ArrayList<Map<String, Object>> getInsuredCoverageTable(String policyNum, String certNum)
			throws RemoteException {

		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(PropertyUtil.getCommonProperty(POLICYNUMSTR), policyNum);
		queryParams.put(PropertyUtil.getCommonProperty("CERT_NUM"), certNum);

		return doQuery(queryParams, PropertyUtil.getScriptAndQueryProperty("QUERY_INSURED_COVERAGE"));
	}

	/**
	 * 
	 * get Document type table by formID
	 */
	@Override
	public ArrayList<Map<String, Object>> getDocumentTypeTable(String formID) throws RemoteException {

		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(PropertyUtil.getCommonProperty(DOCFORMIDSTR), formID);
		return doQuery(queryParams, PropertyUtil.getScriptAndQueryProperty("QUERY_GETREQTYPEBYFORMID"));
	}

	/**
	 * 
	 * get reqTypeConfig Table by formID
	 */
	@Override
	public ArrayList<Map<String, Object>> getReqTypeConfigTable(String formID) throws RemoteException {

		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(PropertyUtil.getCommonProperty(DOCFORMIDSTR), formID);
		return doQuery(queryParams, PropertyUtil.getScriptAndQueryProperty("QUERY_GETPROCESSNAMEBYFORMID"));
	}

	/**
	 * 
	 * get workFolder table by policyNum,certNum,batchNo,submitDateTime,reqType
	 */
	@Override
	public ArrayList<Map<String, Object>> getWorkFolderTable(Map<String, String> parameters) throws RemoteException {

		return doQuery(parameters, PropertyUtil.getScriptAndQueryProperty("QUERY_WORKFOLDER"));
	}

	/**
	 * 
	 * get workItem table by policyNum,reqType,linkcaseid
	 */
	@Override
	public ArrayList<Map<String, Object>> getWorkItemTable(Map<String, String> parameters) throws RemoteException {

		return doQuery(parameters, PropertyUtil.getScriptAndQueryProperty("QUERY_WORKITEM"));
	}

	@Override
	public ArrayList<Map<String, Object>> getDocIdByMasterId(Map<String, String> parameters) throws RemoteException {
		return doQuery(parameters, PropertyUtil.getScriptAndQueryProperty("QUERY_GETDOCIDBYMSTERID"));
	}

	@Override
	public ArrayList<Map<String, Object>> getworkfolderByOrganiza(Map<String, String> parameters)
			throws RemoteException {
		return doQuery(parameters, PropertyUtil.getScriptAndQueryProperty("QUERY_WORKFOLDERBYORGANIZA"));
	}

	@Override
	public ArrayList<Map<String, Object>> getUnKnowDoc(Map<String, String> parameters) throws RemoteException {
		return doQuery(parameters, PropertyUtil.getScriptAndQueryProperty("QUERY_INVALIDINDEXING"));
	}

	@Override
	public ArrayList<Map<String, Object>> getCaseFolderByInsuredCode(Map<String, String> parameters)
			throws RemoteException {
		return doQuery(parameters, PropertyUtil.getScriptAndQueryProperty("QUERY_WORKFOLDERBYINSUREDCODE"));
	}

	@Override
	public ArrayList<Map<String, Object>> getDocumentInfo(Map<String, String> queryParams) throws RemoteException {

		ArrayList<Map<String, Object>> queryResult =  doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_MASTERFOLDER_DOCUMENT"));

		return queryResult;

	}

	@Override
	public ArrayList<Map<String, Object>> getFormIdAndDocType() throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put("", "");
		ArrayList<Map<String, Object>> queryResult =  doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_DOCUMENTTYPE"));

		return queryResult;
	}

	@Override
	public ArrayList<Map<String, Object>> getPolicyByPolicyNum(String policyNum) throws RemoteException {

		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(POLICYNUMSTR, policyNum);
		return doQuery(queryParams, PropertyUtil.getScriptAndQueryProperty("QUERY_POLICY"));
	}

	@Override
	public ArrayList<Map<String, Object>> getProcessByReqType(String requestType) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(REQTYPESTR, requestType);

		return doQuery(queryParams, PropertyUtil.getScriptAndQueryProperty("QUERY_PROCESSNAME_BY_REQTYPE"));
	}

	@Override
	public ArrayList<Map<String, Object>> getMasterFolder(String orgCode) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put("ORG_CODE", orgCode);
		ArrayList<Map<String, Object>> queryResult =  doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_ORGANIZATION"));

		return queryResult;
	}

	@Override
	public ArrayList<Map<String, Object>> getMyTeamWorkList(String users) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put("LOGINID_USER", users);
		ArrayList<Map<String, Object>> queryResult =  doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_MYTEAMWORK"));

		return queryResult;
	}

	@Override
	public ArrayList<Map<String, Object>> getUnassignedWorkList(String user, String workStepName)
			throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put("LOGINID_USER", user);
		queryParams.put("WFWORKSTEPNAME", workStepName);
		ArrayList<Map<String, Object>> queryResult =  doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_UNASSIGNED_WORKLIST"));

		return queryResult;
	}

	@Override
	public ArrayList<Map<String, Object>> getMemberNum(String masterId, String policyNum) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put("CASEFOLDERID", masterId);
		queryParams.put(POLICYNUMSTR, policyNum);
		ArrayList<Map<String, Object>> queryResult =  doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_INSUREDPOLICY_BY_CASEID"));

		return queryResult;
	}

	@Override
	public ArrayList<Map<String, Object>> getWorkFolder(Map<String, String> parameters) throws RemoteException {

		Map<String, String> queryParams = new HashMap<String, String>();
		// fred, don't use branch.
		queryParams.put(PropertyUtil.getCommonProperty("POS_REQ_NO"), parameters.get("POS_REQ_NO"));

		return doQuery(queryParams, PropertyUtil.getScriptAndQueryProperty("QUERY_WORKFOLDER"));
	}

	@Override
	public ArrayList<Map<String, Object>> getChangeItems(Map<String, String> parameters) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		// fred, don't use branch.
		queryParams.put(PropertyUtil.getCommonProperty(LINKCASEIDSTR), parameters.get(LINKCASEIDSTR));

		return doQuery(queryParams, PropertyUtil.getScriptAndQueryProperty("QUERY_CHANGEITEMS"));
	}

	@Override
	public ArrayList<Map<String, Object>> getWorkItem(Map<String, String> parameters) throws RemoteException {

		Map<String, String> queryParams = new HashMap<String, String>();
		// fred, don't use branch.
		queryParams.put(PropertyUtil.getCommonProperty(LINKCASEIDSTR), parameters.get(LINKCASEIDSTR));

		return doQuery(queryParams, PropertyUtil.getScriptAndQueryProperty("QUERY_WORKITEM"));
	}

	public ArrayList<Map<String, Object>> getPendingReason(String id) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put("PENDING_SEQ", id);
		ArrayList<Map<String, Object>> queryResult =  doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_GETPENDREASON_BY_ID"));

		return queryResult;
	}

	public ArrayList<Map<String, Object>> getCustomerInfo(String clientId) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(CLIENTIDSTR, clientId);
		ArrayList<Map<String, Object>> queryResult =  doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_GETCUSTOMER_BY_CLIENTID"));

		return queryResult;
	}

	public ArrayList<Map<String, Object>> getPolicyInfoByClient(String clientId) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(CLIENTIDSTR, clientId);
		ArrayList<Map<String, Object>> queryResult =  doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_GETPOLICY_BY_CLIENTID"));

		return queryResult;
	}

	public ArrayList<Map<String, Object>> getDocsListByClient(String clientId, String userId) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(CLIENTIDSTR, clientId);
		queryParams.put(CURRENTUSERSTR, userId);
		ArrayList<Map<String, Object>> queryResult =  doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_GETDOCSLIST_BY_CLIENTID"));

		return queryResult;
	}

	public ArrayList<Map<String, Object>> getWorkitemByRepKey(String repositoryKey) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put("REPOSITORY_KEY", repositoryKey);
		ArrayList<Map<String, Object>> queryResult =  doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_GETCASEDATA_BY_REPKEY"));

		return queryResult;
	}

	public ArrayList<Map<String, Object>> getCustomersByPolNo(String polNum) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(POLNUMSTR, polNum);
		ArrayList<Map<String, Object>> queryResult =  doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_GETCUSTOMERS_BY_POLNO"));

		return queryResult;
	}

	public ArrayList<Map<String, Object>> getPendingWiRepKey(Map<String, String> queryParams) throws RemoteException {
		ArrayList<Map<String, Object>> queryResult =  doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_GET_WIREPKEY_POSREQNO"));

		return queryResult;
	}

	@Override
	public ArrayList<Map<String, Object>> getAclByUser(String currentUser) throws RemoteException {

		String message = "query function name : getAclByUser";
		LogUtil.logInfo(m_Logger,message + ISSTARTSTR);
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(PropertyUtil.getCommonProperty(CURRENTUSERSTR), currentUser);
		ArrayList<Map<String, Object>> queryResult =  doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_GET_ACL_BY_USERID")); // QUERY_WORKFOLDER
		LogUtil.logInfo(m_Logger,QRESULTSTR + queryResult);
		LogUtil.logInfo(m_Logger,message + ISLEAVESTR);
		return queryResult;
	}

	@Override
	public ArrayList<Map<String, Object>> getUnKnowDocList(Map<String, String> params) throws RemoteException {
		ArrayList<Map<String, Object>> queryResult =  doQuery(params,
				PropertyUtil.getScriptAndQueryProperty("QUERY_GET_UNKNOW_DOC"));
		if (queryResult == null || queryResult.isEmpty()) {
			return new ArrayList<Map<String, Object>>();
		} else if (queryResult.size() == 1) {
			String docList = queryResult.get(0).get("DOC_LIST").toString();
			String[] ids = docList.split(";");
			String listIds = "";
			for (String id : ids) {
				listIds += "'" + id + "',";
			}
			if (listIds.length() > 0) {
				listIds = listIds.substring(0, listIds.length() - 1);
				LogUtil.logInfo(m_Logger,"LISTIDS =" + listIds);
				Map<String, String> queryParams = new HashMap<String, String>();
				queryParams.put("LISTIDS", listIds);
				LogUtil.logInfo(m_Logger,"getUnKnowDocList QUERY_SEARCH_DOCS queryParams" + queryParams.toString());
				return  doQuery(queryParams, PropertyUtil.getScriptAndQueryProperty("QUERY_SEARCH_DOCS"));
			}
		}
		return new ArrayList<Map<String, Object>>();
	}

	// added by Leo Li
	/**
	 * @param params String objectID
	 * @return String OBJECT_ID--objectID String FILENAM--ImageFile(PDF) String
	 *         requestDateTime String responseDateTime
	 */
	@Override
	public Map<String, Object> getDocumentByID(Map<String, String> parameters) throws RemoteException {
		// for log
		String message = "query function name : getDocumentByID";
		LogUtil.logInfo(m_Logger,message + ISSTARTSTR);
		Map<String, String> queryParams = new HashMap<String, String>();
		// get objectID only
		queryParams.put("OBJECT_ID", parameters.get("objectID"));
		LogUtil.logInfo(m_Logger,"QUERY_Get_Document" + queryParams.toString());
		// doQuery
		ArrayList<Map<String, Object>> queryResult = doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_Get_Document"));
		LogUtil.logInfo(m_Logger,QRESULTSTR + queryResult);
		LogUtil.logInfo(m_Logger,message + ISLEAVESTR);
		return queryResult.get(0);
	}

	/**
	 * @param params String companyNo --required String policyNo --required String
	 *               dateFrom String dateTo
	 * @return policyno String imageDate String recieveDate String documentObject ID
	 *         String formID String formName String waterMarkText String actionFlag
	 *         String notificationType String eCabinetCategory --if callingSystem is
	 *         eCabinet
	 */
	@Override
	public ArrayList<Map<String, Object>> getDocumentList(Map<String, String> parameters) throws RemoteException {
		// for log
		String message = "query function name : getDocumentList";
		LogUtil.logInfo(m_Logger,message + ISSTARTSTR);
		Map<String, String> queryParams = new HashMap<String, String>();
		// get companyNo,policyNo,dateFrom,dateTo
		queryParams.put(COMNOSTR, parameters.get(LOWERCOMNOSTR));
		queryParams.put(POLNUMSTR, parameters.get(LOWERPOLNOSTR));
		queryParams.put("DATEFROM", parameters.get("dateFrom"));
		queryParams.put("DATETO", parameters.get("dateTo"));
		ArrayList<Map<String, Object>> queryResult = null;
		// if callingSystem is eCabinet
		if ("eCabinet".equals(parameters.get("callingSystem"))) {
			LogUtil.logInfo(m_Logger,"QUERY_Get_Document_List" + queryParams.toString());
			queryResult = doQuery(queryParams, PropertyUtil.getScriptAndQueryProperty("QUERY_Get_DocumentList"));
			// if callingSystem is not eCabinet
		} else {
			LogUtil.logInfo(m_Logger,QGETDOCLISTSTR + queryParams.toString());
			queryResult = doQuery(queryParams, PropertyUtil.getScriptAndQueryProperty(QGETDOCLISTSTR));
		}
		LogUtil.logInfo(m_Logger,QRESULTSTR + queryResult);
		LogUtil.logInfo(m_Logger,message + ISLEAVESTR);
		return queryResult;
	}

	@Override
	public Map<String, Object> getDocumentByIDOMS(Map<String, String> parameters) throws RemoteException {
		String message = "query function name : getDocumentByIDOMS";
		LogUtil.logInfo(m_Logger,message + ISSTARTSTR);
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put("OBJECT_ID", parameters.get("objectID"));
		LogUtil.logInfo(m_Logger,"QUERY_Get_Document_By_ID" + queryParams.toString());
		ArrayList<Map<String, Object>> queryResult = doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_Get_Document_By_ID"));
		LogUtil.logInfo(m_Logger,QRESULTSTR + queryResult);
		LogUtil.logInfo(m_Logger,message + ISLEAVESTR);
		return queryResult.get(0);
	}

	@Override
	public ArrayList<Map<String, Object>> getDocumentListOMS(Map<String, String> parameters) throws RemoteException {
		String message = "query function name : getDocumentListOMS";
		LogUtil.logInfo(m_Logger,message + ISSTARTSTR);
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(COMNOSTR, parameters.get(LOWERCOMNOSTR));
		queryParams.put(POLNUMSTR, parameters.get(LOWERPOLNOSTR));
		queryParams.put("DATEFROM", parameters.get("dateFrom"));
		queryParams.put("DATETO", parameters.get("dateTo"));
		ArrayList<Map<String, Object>> queryResult = null;
		// if callingSystem is eCabinet
		if ("eCabinet".equals(parameters.get("callingSystem"))) {
			LogUtil.logInfo(m_Logger,"QUERY_Get_Document_List" + queryParams.toString());
			queryResult = doQuery(queryParams, PropertyUtil.getScriptAndQueryProperty("QUERY_Get_DocumentList"));
		} else {
			LogUtil.logInfo(m_Logger,QGETDOCLISTSTR + queryParams.toString());
			queryResult = doQuery(queryParams, PropertyUtil.getScriptAndQueryProperty(QGETDOCLISTSTR));
		}
		LogUtil.logInfo(m_Logger,QRESULTSTR + queryResult);
		LogUtil.logInfo(m_Logger,message + ISLEAVESTR);
		return queryResult;
	}

	// get Case By Request No
	@Override
	public Map<String, Object> getCaseByRequestNo(Map<String, String> parameters) throws RemoteException {
		// for log
		String message = "query function name : getCaseByRequestNo";
		LogUtil.logInfo(m_Logger,message + ISSTARTSTR);
		Map<String, String> queryParams = new HashMap<String, String>();
		// get only
		queryParams.put("REQUEST_NUM", parameters.get("requestNo"));
		LogUtil.logInfo(m_Logger,"QUERY_Get_Case" + queryParams.toString());
		// doQuery
		ArrayList<Map<String, Object>> queryResult = doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_Get_Case"));
		LogUtil.logInfo(m_Logger,QRESULTSTR + queryResult);
		LogUtil.logInfo(m_Logger,message + ISLEAVESTR);
		return queryResult.get(0);
	}

	@Override
	public ArrayList<Map<String, Object>> getRequestType(Map<String, String> parameters) throws RemoteException {
		String message = "query function name : getRequestType";
		LogUtil.logInfo(m_Logger,message + ISSTARTSTR);
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put("PROCESS_NM", parameters.get(LOWERPRONMSTR));
		LogUtil.logInfo(m_Logger,"QUERY_Get_RequestType" + queryParams.toString());
		ArrayList<Map<String, Object>> queryResult = doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_Get_RequestType"));
		LogUtil.logInfo(m_Logger,QRESULTSTR + queryResult);
		LogUtil.logInfo(m_Logger,message + ISLEAVESTR);
		return queryResult;
	}

	@Override
	public ArrayList<Map<String, Object>> getParentRequestNoByPolicyNo(Map<String, Object> parameters)
			throws RemoteException {
		String message = "query function name : getParentRequestNoByPolicyNo";
		LogUtil.logInfo(m_Logger,message + ISSTARTSTR);
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(COMNOSTR, parameters.get(LOWERCOMNOSTR).toString());
		queryParams.put(POLNUMSTR, parameters.get(LOWERPOLNOSTR).toString());
		// processName is a list
		List<String> processNames = (List<String>) parameters.get(LOWERPRONMSTR);
		String processName = CommonUtil.listToString(processNames);
		queryParams.put("PROCESSOR", processName);
		LogUtil.logInfo(m_Logger,"QUERY_Get_ParentRequestNo" + queryParams.toString());
		ArrayList<Map<String, Object>> queryResult = doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_Get_ParentRequestNo"));
		LogUtil.logInfo(m_Logger,QRESULTSTR + queryResult);
		LogUtil.logInfo(m_Logger,message + ISLEAVESTR);
		return queryResult;
	}

	@Override
	public ArrayList<Map<String, Object>> getRequestNoByPolicyNo(Map<String, Object> parameters)
			throws RemoteException {
		String message = "query function name : getRequestNoByPolicyNo";
		LogUtil.logInfo(m_Logger,message + ISSTARTSTR);
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put("COMPANY", (String) parameters.get(LOWERCOMNOSTR));
		queryParams.put(POLNUMSTR, (String) parameters.get(LOWERPOLNOSTR));
		// caseStatus is a list
		List<String> caseStatuses = (List<String>) parameters.get("caseStatus");
		String caseStatus = CommonUtil.listToString(caseStatuses);
		queryParams.put("CASESTATUS", caseStatus);
		// processName is a list
		List<String> processNames = (List<String>) parameters.get(LOWERPRONMSTR);
		String processName = CommonUtil.listToString(processNames);
		queryParams.put("PROCESSOR", processName);
		LogUtil.logInfo(m_Logger,"QUERY_Get_RequestNo" + queryParams.toString());
		ArrayList<Map<String, Object>> queryResult = doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_Get_RequestNo"));
		LogUtil.logInfo(m_Logger,QRESULTSTR + queryResult);
		LogUtil.logInfo(m_Logger,message + ISLEAVESTR);
		return queryResult;
	}

	@Override
	public ArrayList<Map<String, Object>> getFormInfo() throws RemoteException {
		String message = "query function name : getRequestNoByPolicyNo";
		LogUtil.logInfo(m_Logger,message + ISSTARTSTR);
		LogUtil.logInfo(m_Logger,"QUERY_Get_FormInfo no parameter is needed ");
		// do query
		ArrayList<Map<String, Object>> queryResult = doQuery(null,
				PropertyUtil.getScriptAndQueryProperty("QUERY_Get_FormInfo"));
		LogUtil.logInfo(m_Logger,QRESULTSTR + queryResult);
		LogUtil.logInfo(m_Logger,message + ISLEAVESTR);
		return queryResult;
	}

	@Override
	public ArrayList<Map<String, Object>> getRequestStatusByRequestNo(Map<String, Object> parameters)
			throws RemoteException {
		String message = "query function name : getRequestStatusByRequestNo";
		LogUtil.logInfo(m_Logger,message + ISSTARTSTR);
		Map<String, String> queryParams = new HashMap<String, String>();
		// requestNo is a list
		List<String> requestNos = (List<String>) parameters.get("requestNo");
		String requestNo = CommonUtil.listToString(requestNos);
		queryParams.put("REQUEST_NUM", requestNo);
		LogUtil.logInfo(m_Logger," " + queryParams.toString());
		ArrayList<Map<String, Object>> queryResult = doQuery(queryParams, PropertyUtil.getScriptAndQueryProperty(" "));
		LogUtil.logInfo(m_Logger,QRESULTSTR + queryResult);
		LogUtil.logInfo(m_Logger,message + ISLEAVESTR);
		return queryResult;
	}

	@Override
	public ArrayList<Map<String, Object>> pendingCase(Map<String, Object> parameters) throws RemoteException {
		
		return getRequestStatusByRequestNo(parameters);
	}

	@Override
	public ArrayList<Map<String, Object>> getSytemConfigByConfigNameAndValue(Map<String, String> params)
			throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put("CONFIG_NAME", params.get("CONFIG_NAME"));
		queryParams.put("CONFIG_VALUE", params.get("CONFIG_VALUE"));
		queryParams.put("DATA_TYPE", params.get("DATA_TYPE"));
		queryParams.put("DISPLAY_FORMAT", params.get("DISPLAY_FORMAT"));
		queryParams.put("DISPLAY_NAME", params.get("DISPLAY_NAME"));
		queryParams.put("VALUE_LIST", params.get("VALUE_LIST"));
		queryParams.put("DEFAULT_VALUE", params.get("DEFAULT_VALUE"));
		queryParams.put("REFERENCE_KEY1", params.get("REFERENCE_KEY1"));
		ArrayList<Map<String, Object>> queryResult =  doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_GET_SYSTEM_CONFIG"));

		return queryResult;
	}

	@Override
	public ArrayList<Map<String, Object>> getReqtypeAvalibleSteps(Map<String, String> params) throws RemoteException {

		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(REQTYPESTR, params.get(REQTYPESTR));
		queryParams.put("DISPLAY_CONDITION", params.get("DISPLAY_CONDITION"));
		queryParams.put("DISPLAY_SEQUENCE", params.get("DISPLAY_SEQUENCE"));
		queryParams.put(WORKSTEPNAMESTR, params.get(WORKSTEPNAMESTR));
		queryParams.put("AVAILABLE_STEP", params.get("AVAILABLE_STEP"));
		ArrayList<Map<String, Object>> queryResult =  doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_GET_REQTYPE_STEPS"));

		return queryResult;
	}

	@Override
	public ArrayList<Map<String, Object>> getReqtypeCustomInfo(Map<String, String> params) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(REQTYPESTR, params.get(REQTYPESTR));
		queryParams.put("CATEGORY", params.get("CATEGORY"));
		queryParams.put("REQTYPE_INFO", params.get("REQTYPE_INFO"));
		queryParams.put("IS_READONLY", params.get("IS_READONLY"));
		queryParams.put(CREATEDBYSTR, params.get(CREATEDBYSTR));
		ArrayList<Map<String, Object>> queryResult =  doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_GET_REQTYPE_CUSTOM_INFO"));

		return queryResult;
	}

	@Override
	public ArrayList<Map<String, Object>> getReqTypeFunctions(Map<String, String> params) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(REQTYPESTR, params.get(REQTYPESTR));
		queryParams.put("DISPATCH_BUTTON", params.get("DISPATCH_BUTTON"));
		queryParams.put(WORKSTEPNAMESTR, params.get(WORKSTEPNAMESTR));
		queryParams.put(CREATEDBYSTR, params.get(CREATEDBYSTR));
		ArrayList<Map<String, Object>> queryResult =  doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_GET_REQTYPE_FUNCTIONS"));

		return queryResult;
	}

	@Override
	public ArrayList<Map<String, Object>> getPendingReasonByInputValue(Map<String, String> params)
			throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put("PENDING_DURATION", params.get("PENDING_DURATION"));
		queryParams.put("PENDING_REASON", params.get("PENDING_REASON"));
		queryParams.put("OBJID", params.get("OBJID"));
		queryParams.put("DEPARTMENT", params.get("DEPARTMENT"));
		queryParams.put("IS_CLEANOWNER", params.get("IS_CLEANOWNER"));
		queryParams.put("PEND_TYPE", params.get("PEND_TYPE"));
		ArrayList<Map<String, Object>> queryResult =  doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_GET_PENDING_REASON"));

		return queryResult;
	}

	@Override
	public ArrayList<Map<String, Object>> getFormIDAndNM(Map<String, String> params) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put("FORM_ID", params.get("FORM_ID"));
		ArrayList<Map<String, Object>> queryResult =  doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty("QUERY_GET_FORMID_FORMNM"));

		return queryResult;
	}

	@Override
	public List<Map<String, Object>> callProcedureAsQuery(final Map<Integer, Object> map, final String procedureName) {

		LogUtil.logInfo(m_Logger,"callProcedureAsQuery start.");

		@SuppressWarnings("unchecked")
		List<Map<String, Object>> queryResult = (List<Map<String, Object>>) jdbcTemplate
				.execute(new CallableStatementCreator() {
					public CallableStatement createCallableStatement(Connection con) throws SQLException {

						CallableStatement cstmt = con.prepareCall(procedureName); // NOSONAR

						setSQLParameters(map, cstmt);

						return cstmt;
					}
				}, new CallableStatementCallback() {
					public Object doInCallableStatement(CallableStatement cs) throws SQLException, DataAccessException {
						List resultsMap = new ArrayList();
						ResultSet rs = null;
						try {
							rs = cs.executeQuery(); // NOSONAR

							ResultSetMetaData md = rs.getMetaData();
							int columnCount = md.getColumnCount();

							while (rs.next()) {
								Map<String, Object> rowData = new HashMap<String, Object>();
								for (int i = 1; i <= columnCount; i++) {
									rowData.put(md.getColumnName(i), rs.getObject(i));
								}
								resultsMap.add(rowData);
							}

						} catch (Exception e) {
							 
							LogUtil.logException(m_Logger, EEXCEPTIONSTR, e);
						}
						return resultsMap;
					}
				});

		return queryResult;
	}

	@Override
	public boolean callProcedureForUpdate(final Map<Integer, Object> map, final String procedureName) {
		LogUtil.logInfo(m_Logger," ProcedureName: " + procedureName);

		@SuppressWarnings("unchecked")
		int updatedCount = (Integer) jdbcTemplate.execute(new CallableStatementCreator() {
			public CallableStatement createCallableStatement(Connection con) throws SQLException {

				CallableStatement cstmt = con.prepareCall(procedureName); // NOSONAR

				setSQLParameters(map, cstmt);
				return cstmt;
			}
		}, new CallableStatementCallback<Object>() {
			public Object doInCallableStatement(CallableStatement cs) throws SQLException, DataAccessException {
				Integer result = 0;
				try {
					result = Integer.valueOf(cs.executeUpdate());
				} catch (Exception e) {
					LogUtil.logException(m_Logger, EEXCEPTIONSTR, e);
					 
				}
				return result;

			}
		});

		return updatedCount > 0 ? true : false;
	}

	@Override
	public boolean doUpdate(final Map<Integer, Object> map, final String sql) throws RemoteException, SQLException {

		int updatedCount = (Integer) jdbcTemplate.execute(new CallableStatementCreator() {
			public CallableStatement createCallableStatement(Connection con) throws SQLException {

				CallableStatement cstmt = con.prepareCall(sql); // NOSONAR

				setSQLParameters(map, cstmt);

				return cstmt;
			}
		}, new CallableStatementCallback<Object>() {
			public Object doInCallableStatement(CallableStatement cs) throws SQLException, DataAccessException {
				Integer result = 0;
				try {
					result = Integer.valueOf(cs.executeUpdate());
				} catch (Exception e) {
					 
					LogUtil.logException(m_Logger, EEXCEPTIONSTR, e);
				}
				return result;

			}
		});

		return updatedCount > 0 ? true : false;

	}

	@SuppressWarnings("unchecked")
	@Override
	public String callProcedureGetSingleValue(final Map<Integer, Object> map, final String procedureName) {

		LogUtil.logInfo(m_Logger," callProcedureGetSingleValue start: " + procedureName);

		return (String) jdbcTemplate.execute(new CallableStatementCreator() {
			public CallableStatement createCallableStatement(Connection con) throws SQLException {

				CallableStatement cstmt = con.prepareCall(procedureName); // NOSONAR

				setSQLParameters(map, cstmt);

				return cstmt;
			}
		}, new CallableStatementCallback<Object>() {
			public Object doInCallableStatement(CallableStatement cs) throws SQLException, DataAccessException {
				ResultSet rs = null;
				try {
					rs = cs.executeQuery(); // NOSONAR

					while (rs.next()) {

						Object value = rs.getObject(1);
						LogUtil.logInfo(m_Logger,"callProcedureGetSingleValue Procedure Res: " + value);
						if (value != null) {
							return gengerateRes(value);
						}
					}
				} catch (Exception e) {
					 
					LogUtil.logException(m_Logger, EEXCEPTIONSTR, e);
				}
				return "";
			}

		});

	}
	
	private Object gengerateRes(Object value) {
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String str1;
		if ((value instanceof String)) {
			str1 = (String) value;
			return str1;
		}

		if ((value instanceof Boolean)) {
			str1 = value.toString();
			return str1;
		}

		if ((value instanceof Integer)) {
			str1 = value.toString();
			return str1;
		}

		if ((value instanceof java.sql.Date)) {
			str1 = sf.format(value);
			return str1;
		}

		if ((value instanceof Timestamp)) {
			str1 = sf.format((Timestamp) value);
			return str1;
		}

		if ((value instanceof java.util.Date)) {
			str1 = sf.format((java.util.Date) value);
			return str1;
		}

		if ((value instanceof BigDecimal)) {
			str1 = ((BigDecimal) value).toString();
			return str1;
		}

		if ((value instanceof Long)) {
			str1 = ((Long) value).toString();
			return str1;
		}

		if ((value instanceof Short)) {
			str1 = ((Short) value).toString();
			return str1;
		}

		if ((value instanceof Double)) {
			str1 = ((Double) value).toString();
			return str1;
		}

		if ((value instanceof Float)) {
			str1 = ((Float) value).toString();
			return str1;
		}

		str1 = value.toString();
		return str1;
	}

	private void setSQLParameters(final Map<Integer, Object> map, CallableStatement cstmt) throws SQLException {
		if (map != null && map.size() > 0) {
			for (Entry<Integer, Object> item : map.entrySet()) {
				int key = item.getKey();
				Object value = item.getValue();
				if (value == null) {
					cstmt.setString(key, null);
				}
				setValueForStatement(cstmt, value, key);
			}
		}
	}

	private void setValueForStatement(CallableStatement cstmt, Object value, int key) throws SQLException {
		if (value instanceof String) {
			String tmp = (String) value;
			tmp = StringEscapeUtils.escapeSql(tmp);
			cstmt.setString(key, tmp);
		} else if (value instanceof Boolean) {
			cstmt.setBoolean(key, (Boolean) value);
		} else if (value instanceof Integer) {
			cstmt.setInt(key, (int) value);
		} else if (value instanceof java.sql.Date) {
			cstmt.setDate(key, (Date) value);
		} else if (value instanceof BigDecimal) {
			cstmt.setBigDecimal(key, (BigDecimal) value);
		} else if (value instanceof Long) {
			cstmt.setLong(key, (Long) value);
		} else if (value instanceof Short) {
			cstmt.setShort(key, (Short) value);
		} else if (value instanceof Double) {
			cstmt.setDouble(key, (Double) value);
		} else if (value instanceof Float) {
			cstmt.setFloat(key, (Float) value);
		}
		
	}
}