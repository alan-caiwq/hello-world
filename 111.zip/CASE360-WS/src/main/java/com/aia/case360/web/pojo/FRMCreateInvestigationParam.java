package com.aia.case360.web.pojo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class FRMCreateInvestigationParam {
  
  @JsonProperty("POLICY_NO")
  private String policyNo;
  
  @JsonProperty("COMPANY_NO")
  private String companyNo;

  /**
   * @return the policyNo
   */
  public String getPolicyNo() {
    return policyNo;
  }

  /**
   * @return the companyNo
   */
  public String getCompanyNo() {
    return companyNo;
  }

  /**
   * @param policyNo the policyNo to set
   */
  public void setPolicyNo(String policyNo) {
    this.policyNo = policyNo;
  }

  /**
   * @param companyNo the companyNo to set
   */
  public void setCompanyNo(String companyNo) {
    this.companyNo = companyNo;
  }

  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "FRMCreateInvestigationParam [policyNo=" + policyNo + ", companyNo=" + companyNo + "]";
  }
 
}
