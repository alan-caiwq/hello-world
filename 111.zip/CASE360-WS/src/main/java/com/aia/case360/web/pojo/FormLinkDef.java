package com.aia.case360.web.pojo;

public class FormLinkDef {

	private String formCategory;
	private String formId;
	private String formNm;
	private String isVisible;// smallint
	private String contractFormType;
	private String mainLinkFormId;
	private short isDocIntegrity;

	public short getIsDocIntegrity() {
		return isDocIntegrity;
	}

	public void setIsDocIntegrity(short isDocIntegrity) {
		this.isDocIntegrity = isDocIntegrity;
	}

	public String getMainLinkFormId() {
		return mainLinkFormId;
	}

	public void setMainLinkFormId(String mainLinkFormId) {
		this.mainLinkFormId = mainLinkFormId;
	}

	public String getContractFormType() {
		return contractFormType;
	}

	public void setContractFormType(String contractFormType) {
		this.contractFormType = contractFormType;
	}

	public String getFormCategory() {
		return formCategory;
	}

	public void setFormCategory(String formCategory) {
		this.formCategory = formCategory;
	}

	public String getFormId() {
		return formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}

	public String getFormNm() {
		return formNm;
	}

	public void setFormNm(String formNm) {
		this.formNm = formNm;
	}

	public String getIsVisible() {
		return isVisible;
	}

	public void setIsVisible(String isVisible) {
		this.isVisible = isVisible;
	}

	@Override
	public String toString() {
		return "FormLinkDef [formCategory=" + formCategory + ", formId=" + formId + ", formNm=" + formNm
				+ ", isVisible=" + isVisible + ", contractFormType=" + contractFormType + ", mainLinkFormId="
				+ mainLinkFormId + ", isDocIntegrity=" + isDocIntegrity + "]";
	}

}
