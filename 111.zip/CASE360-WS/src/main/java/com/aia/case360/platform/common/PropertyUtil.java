package com.aia.case360.platform.common;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PropertyUtil {
	
	private PropertyUtil() {}
	
	private static Logger m_Logger = LoggerFactory.getLogger(PropertyUtil.class.getClass());
	static ResourceBundle scriptProp = null;

	static ResourceBundle commProp = null;

	static ResourceBundle errorMsgProp = null;

	static ResourceBundle standCodeProp = null;

	static ResourceBundle tableProp = null;

	static ResourceBundle logProp = null;

	static ResourceBundle CaptureProp = null; // add by smart
	//added by Leo Li
	static ResourceBundle esbErrorCodeMappingProp = null; // add by smart
	
	static ResourceBundle reportConfProp = null;
	
	static {

		try {

			scriptProp = ResourceBundle.getBundle("scriptquery");

			commProp = ResourceBundle.getBundle("common");

			errorMsgProp = ResourceBundle.getBundle("errorMsg");

			standCodeProp = ResourceBundle.getBundle("standCode");

			tableProp = ResourceBundle.getBundle("tableName");
			
			esbErrorCodeMappingProp = ResourceBundle.getBundle("esbErrorCodeMapping");
			
			reportConfProp = ResourceBundle.getBundle("report");

		} catch (MissingResourceException e) {

			LogUtil.logException(m_Logger, "Initialize properties files failed:", e);

		}

	}

	public static String getReportProperty(String key) {
		try {
			if (reportConfProp != null)
				
				return reportConfProp.getString(key);
		} catch (Exception e) {
			LogUtil.logException(m_Logger, "getReportProperty failed:" + key, e);
		}

		return "";

	}
	
	public static String getScriptAndQueryProperty(String key) {

		if (scriptProp != null)

			return scriptProp.getString(key);

		return "";

	}

	public static String getCommonProperty(String key) {

		if (commProp != null)

			return commProp.getString(key);

		return "";

	}

	public static String getErrorMsgProperty(String key) {

		if (errorMsgProp != null)

			return errorMsgProp.getString(key);

		return "";

	}

	public static String getStandCodeProperty(String key) {

		if (standCodeProp != null)

			return standCodeProp.getString(key);

		return "";

	}

	public static String getTableIDProperty(String key) {

		if (tableProp != null)

			return tableProp.getString(key);

		return "";

	}

	public static String getLogInfo(String key) {
		if (logProp != null)

			return logProp.getString(key);

		return "";
	}

	// add by smart
	public static String getCaptureProperty(String key) {

		if (CaptureProp != null)

			return CaptureProp.getString(key);

		return "";

	}
	public static String getEsbECMProperty(String key) {
		
		if (esbErrorCodeMappingProp != null)
			
			return esbErrorCodeMappingProp.getString(key);
		
		return "";
		
	}

}
