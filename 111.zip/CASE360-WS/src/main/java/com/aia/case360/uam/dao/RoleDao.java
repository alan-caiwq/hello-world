package com.aia.case360.uam.dao;

import java.util.List;
import java.util.Map;

import com.aia.case360.uam.domain.RoleInfo;
import com.aia.case360.uam.domain.RoleMenuPara;
import com.aia.case360.uam.domain.RoleMenuVo;
import com.aia.case360.uam.domain.RoleQueryPara;
import com.aia.case360.uam.domain.RoleReqPara;

public interface RoleDao {

	public List<Map<String, Object>> getRoleBaseInfoByRoleId(String roleId);

	public List<Map<String, Object>> getRoleActivity();

	public List<Map<String, Object>> getRoleActivityMapping(String roleId);

	public boolean deleteRoleReq(String roleId);

	public boolean deleteRoleMenu(String roleId, Integer roleType);

	public boolean insertRoleReq(List<RoleReqPara> roleReqParas);

	public boolean insertRoleMenuReq(List<RoleMenuPara> roleMenuParas);

	public boolean updateRoleInfo(RoleInfo roleInof);

	public List<Map<String, Object>> getroleMenuByRoleId(String roleId);

	public List<Map<String, Object>> getRoleByUserIdAndRoleType(String userId, String roleType);

	public int insertRoleInfo(RoleInfo roleinfo);

	public boolean insertRoleMenu(RoleMenuVo roleMenuVo, int roleId);

	public List<Map<String, Object>> getRolebyPara(RoleQueryPara roleQueryPara);

	public List<Map<String, Object>> getMeun();

}
