package com.aia.case360.web.common;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.List;

import com.aia.case360.platform.common.DateUtil;

public class PFHConstants {

	private PFHConstants() {}
	public static final String ROOT_NAME = "Policy Number";
	public static final String ROOT_ID = "ROOT";

	public static final String POLICY = "P";// Policy level
	public static final String FOLDER = "F";// Folder level
	public static final String DOCUMENT = "D";// Document level
	
	public static final String APPEND = "A";// Append

	public static final String CLIENT = "C";// Client level

	public static final String COS_LETTER_CONTROL = "CHGSG";

	public static final String COS_LETTER_GRP = "CHGSG";

	public static final String REQ_DATE_FORMAT = "dd MMMMM yyyy";

	public static final String START_SVS_LETTER_NAME_SG = "CHGSG_";
	//public static final String START_SVS_LETTER_NAME_BR = "CHGBR_";
	public static final String START_SVS_LETTER_NAME_BR = "CHGSG_BR";

	public static final String IL_COY_SG = "2";

	public static final String IL_COY_BR = "4";

    public static final String SGP_CTRY_NAME = "Singapore";

	public static final String BRU_CTRY_NAME = "Brunei";

	public static final String CYCLE_DATE_FORMAT = "yyyyMMdd";

	public static final String UNI_REOPEN = "UNI_REOPEN";// UNI_REOPEN

	public static final String CASE_UNPEND_NOTE = "Policy expire in IL, un-pend case";// Client level
	public static final String CASE_UNPEND_NOTE_CPF = "Get CFPADV flag from IL and un-pend case";// Client level
	public static final String CASE_INPROGRESS_NOTE = "Policy expire in IL";// Client level

	// pending reason -->find case when uploadDocument
	public static final String UPLOAD_DOCUMENT_PENDING_REASSON  = "pending assessor,pending review team,pending LA";
	// unPend action signal when create case
	public static final String POLICY_NO_NOT_IN_PAS_ACTION_SINGAL  = "Policy Number is not existed in PAS";
	public static final String ACTION_SIGNAL_PENDING  = "Pending";

	public static final String CASE_STATUS_DRAFT = "Draft";
	public static final String CASE_STATUS_WIP = "WIP";
	public static final String CASE_STATUS_CLOSE = "Closed";
	public static final String CASE_STATUS_CANCEL = "Cancel";

	public static final String PENDING = "Pending";

	// External system In-Progress -->DB WIP
	public static final String CASE_STATUS_IN_PROGRESS = "In-Progress";
	// External system ReadyForProcessing -->DB Draft , flag 1
	public static final String CASE_STATUS_READY_FOR_PROCESSING = "ReadyForProcessing";
	// processName--->LOB
	public static final String LOB_POS = "POS";
	public static final String LOB_UNI = "UNI";
	public static final String LOB_CLM = "CLM";
	// unpend pending payment case
	public static final String PAYMENT_ACTION_SINGAL = "Payment Received";
	public static final String REQUESTTYPE_NEW_TPD_CASE = "UNKNOWN_DOCUMENT";

	// CASE360USER to pass POSSTP userType in API notifyCaseStatus
	public static final String C360_USER = "CASE360";

	// define for get TSAR start
	public static final String COUNTRY_FOR_TSAR = "SG";
	public static final String LANGUAGE_FOR_TSAR = "en";
	public static final String SOURCE_APPLICATION_FOR_TSAR = "Case360";
	public static final String TARGET_APPLICATION_FOR_TSAR = "IL";
	// define for get TSAR end

	// External W/S notifyCaseStatus scenario
	public static final String SCENARIO_CASE_CLOSED = "1";
	public static final String SCENARIO_SIGNATURE = "2";
	public static final String SOURCE_APPLICATION = "Case360";
	public static final String TARGET_APPLICATION_ESB = "ESB";

	// External web service url
	public static final String EXT_WS_NOTIFY_CASE_STAT = "/rest/AIACase360/services/notifyCaseStatus";
	// for uploadDocument
	public static final String PROCESS_TYPE_UNIP = "UNIP";
	public static final String PROCESS_TYPE_UNIX = "UNIX";
	public static final String PROCESS_TYPE_POSP = "POSP";
	public static final String PROCESS_TYPE_POSX = "POSX";
	public static final String PROCESS_TYPE_CLMP = "CLMP";
	public static final String PROCESS_TYPE_CLMX = "CLMX";
	// POLICY ROLE
	public static final String POLICY_ROLE_A = "A";
	public static final String POLICY_ROLE_B = "B";
	public static final String POLICY_ROLE_C = "C";
	public static final String POLICY_ROLE_D = "D";
	public static final String POLICY_ROLE_E = "E";
	public static final String POLICY_ROLE_F = "F";
	public static final String POLICY_ROLE_G = "G";
	public static final String POLICY_ROLE_H = "H";
	// callingSystem
	public static final String CALLING_SYSTEM_IL = "IL";
	public static final String CALLING_SYSTEM_IPOS = "iPoS";
	public static final String CALLING_SYSTEM_IDES = "iDES";
	public static final String CALLING_SYSTEM_ECARE = "ECare";
	public static final String CALLING_SYSTEM_STP_PORTAL = "STP-PORTAL";
	public static final String CALLING_SYSTEM_CASE360 = "Case360";
	public static final String CALLING_SYSTEM_EDOC = "eDoc";
	public static final String CALLING_SYSTEM_ECABINET = "eCabinet";
	// close reason
	public static final String CLOSE_REASON_DECLINE = "Decline";
	public static final String CLOSE_REASON_DECLINED = "Declined";
	// close note
	public static final String CLOSE_NOTE_DEFAULT = "close case";
	// submissionChannel
	public static final String SUBMISSION_CHANNEL_IDES = "iDES";
	public static final String SUBMISSION_CHANNEL_SYSTEM = "system";
	// requestType
	public static final String REQUEST_TYPE_HS_ATTAINMENT = "HS_ATTAINMENT";
	public static final String REQUEST_TYPE_UNKNOWN_DOCUMENT = "UNKNOWN_DOCUMENT";
	public static final String REQUEST_TYPE_CRS_SKIPPED_TO_FOLLOWUP = "CRS_SKIPPED_TO_FOLLOWUP";
	public static final String REQUEST_TYPE_NO_DATA = "NB_PEND_DATA";
	// departMent
	public static final String DEPARTMENT_TMP = "TMP";
	// WORKSTEP
	public static final String WORKSTEP_DESTINATION = "DESTINATION";
	public static final String WORKSTEP_COM_START = "COM_Start";
	public static final String REOPEN_COM_001 = "COM_001";
	// singleTrusteeFlag
	public static final String SINGLE_TRUSTEE_FLAG_Y = "Y";
	public static final String SINGLE_TRUSTEE_FLAG_N = "N";
	// pasName
	public static final String PASNAME_IL = "IL";
	public static final String PASNAME_PLAS = "PLAS";
	public static final String PASNAME_HIAS = "HIAS";
	// caseFlag
	public static final String UPDATE_CASE_FLAG_CREATE = "create";
	public static final String UPDATE_CASE_FLAG_UPDATE = "update";
	
	//UWID AVAILABLESTEP
	public static final String AVAILABLESTEP_UWID = "UWID";
	public static final String CHECK_UW_DC_RESULT = "CHECK_UW_DC_RESULT";
	
	// current time
	private static String CURRENT_TIME = "";

	public static String getCURRENT_TIME() {
		return CURRENT_TIME;
	}

	public static void setCURRENT_TIME(String cURRENT_TIME) {
		CURRENT_TIME = cURRENT_TIME;
	}

	public static final String VERSION_NUM  = "VERSION_NUM";
	public static final String LINKCASEID  = "LINKCASEID";
	public static final String AVAILABLE_STEP  = "AVAILABLE_STEP";
	public static final String DATA_VALUE  = "DATA_VALUE";
	public static final String S_ROWID  = "S_ROWID";
	public static final String AVAILABLE_STEPS_INFO  = "AVAILABLE_STEPS_INFO";
	public static final String DATA  = "data";
	public static final String QUERY_GET_CASE_AVAILABLESTEP  = "getCaseAvailableStep";
	public static final String SCRIPT_TRIGGER_SUBMIT  = "triggerSubmit";
	
	
	// companyCode
	public static final String COMPANY_CODE_011 = "011";
	public static final String COMPANY_CODE_014 = "014";

	// OBJID='0034' , PENDING_REASON is â€œPending for Premier
	public static final String PENDING_FOR_PREM_OBJID = "0034";
	// job run time name
	public static final String JOB_RUN_TIME_NAME_CITI_BANK_REPORT_TIME = "CITI_BANK_REPORT_TIME";
	public static final String JOB_RUN_TIME_NAME_CITI_BANK_REPORT_PRE_TIME = "CITI_BANK_REPORT_PRE_TIME";
	// batch no
	public static final String BATCH_NO_SUFFIX_CT = "%CT";
	// citi bank report headLine
	public static final String CITI_BANK_REPORT_HEAD_LINE = "HparamIR FILE";
	// citi bank report policy no prefix
	public static final String CITI_BANK_REPORT_POLICY_NO_PREFIX = "Z";
	// citi bank report Footer line prefix
	public static final String CITI_BANK_REPORT_FOOTER_LINE_PREFIX = "T";
	public static final String CITI_BANK_REPORT_FOOTER_LINE_MIDDLE = "0";
	// citi bank report location
	public static final String CITI_BANK_REPORT_LOCATION = "D:" + File.separator + "Test File" + File.separator
			+ "INSURER_RPT_" + DateUtil.getCurrentTime1() + ".txt";

	public static final String FLAG_FALSE = "0";
	public static final String FLAG_TRUE = "1";
	public static final String UPDATE_REQUEST_MAX_NUM = "20";
	public static final int UPDATE_REQUEST_MAX_NUM_ONE_TIME = 20;

	public static final String ROOTKEY = "\\";
	// default job timestamp
	public static final String DEFAULT_JOB_TIMESTAMP = "2016-01-01";
	// job name of syncBatchUploadFileDetails
	public static final String JOB_NAME_SYNC_BATCH_UPLOAD_FILE_DETAIL = "syncBatchUploadFileDetails";

	// For STP-PORTAL notify param after close case success param
	public static final String CASE360_USER = "CASE360_USER";
	public static final String STP_NOTIFY_STATUS = "Closed";
	public static final String STP_NOTIFY_STATUS_REASON = "Completed";

	// pending reason
	public static final String PENDING_REASON_WFDFE = "Waiting for Deduction File Extraction";
	public static final String PENDING_REASON_DFE = "Deduction File Extracted";
	public static final String PENDING_REASON_IL_TRANSCATION = "pending for IL transcation";
	public static final String PENDING_REASON_SHORT_PAYMENT_AMOUNT = "pend for short payment";
	// childCaseIndicator
	public static final String CHILD_CASE_INDICATOR_CRS = "CRS";
	public static final String CHILD_CASE_INDICATOR_PMSP = "PMSP";

	// getClaimForDocumentView
	private static final List<String> HIAS = Arrays.asList("G", "V");
	public static final String PLAS = "C";
	public static final String ILMM = "P";
	public static final String ILHSG = "H";
	public static final String ILHSG_E = "E";
	public static final String FORMAT_MINOR = "------";
	public static final String FORMAT_MAJOR = "MAJOR-";
	public static final String CLAIM_TYPE = "AH";
	public static final String CLAIM = "CLAIM";
	public static final String CHILD_CLAIM_TYPE = "CHILD_CLAIM_TYPE";

	// processType suffix
	public static final String PROCESS_TYPE_SUFFIX_P = "P";
	public static final String PROCESS_TYPE_SUFFIX_X = "X";
	// common process start
	public static final String COMMON_PROCESS_START = "CSP_Start";
	// document printFlag
	public static final String PRINTEDFLAG_Y = "Y";
	public static final String PRINTEDFLAG_N = "N";
	public static final String PRINTEDFLAG_NA = "NA";
	// policyNo prefix

	public static final String POLICY_NO_PREFIX_P="P";
	public static final String POLICY_NO_PREFIX_H="H";
	public static final String POLICY_NO_PREFIX_G="G";
	public static final String POLICY_NO_PREFIX_V="V";
	public static final String POLICY_NO_PREFIX_C="C";
	public static final String POLICY_NO_PREFIX_E="E";
	//look up code
	public static final String LOOK_UP_CODE_DEDUCTION_OLD_PENDING_ID="DEDUCTION_OLD_PENDING_ID";
	public static final String LOOK_UP_CODE_DEDUCTION_NEW_PENDING_ID="DEDUCTION_NEW_PENDING_ID";
	public static final String LOOK_UP_CODE_PENDING_FOR_IL_TRANSCATION="PENDING_FOR_IL_TRANSCATION";
	public static final String LOOK_UP_CODE_PENDING_SHORT_PAYMENT="PENDING_SHORT_PAYMENT";
	//look up category
	public static final String LOOK_UP_CATEGORY_PENDING_ID="PENDING_ID";
	//look up group
	public static final String LOOK_UP_GROUP_PENDING_ID="PENDING_ID";
	//sonora S_PROPCATEGORY
	public static final String PROPCATEGORY_CUSTOM="Custom";
	//sonora S_PROPNAME
	public static final String PROPNAME_CAPTURE_DIRECTORY_PREFIX="CaptureDirectoryPrefix";
	public static final String PROPNAME_EFILING_FILESIZE="Efiling_fileSize";
	//file sub directory
	public static final String UPLOAD_SUB_DIRECTORY_WEBAPI="webAPI_Cache";
	//pending indicator
	public static final String PENDING_INDICATOR_1="1";
	public static final String PENDING_INDICATOR_2="2";
	public static final String PRE_AUTOFILE_ERR_1="1G";

	public static final String AUTOFILE_TXT_CREATE_BY_OMS = "OMS";
	public static final String AUTOFILE_STATUS_WAIT_RTV_FORM_ID = "01";
	public static final String AUTOFILE_STATUS_WAIT_CHECK_FILE_EXIST = "10";
	public static final String AUTOFILE_STATUS_FILE_NOT_EXIST = "1F";
	public static final String AUTOFILE_STATUS_WAIT_RTV_REQ_NUM = "02";
	public static final String AUTOFILE_STATUS_DONE_RTV_REQ_NUM = "99";

	public static final Integer AUTOFILE_CHK_FILE_EXPIRED_DAY = 10;
	public static final String AUTOFILE_REQ_NUM_EXPIRE_DAY = "3";
	public static final String AUTOFILE_FUN_CODE_POSX = "POSX";
	public static final String AUTOFILE_FUN_CODE_CLMX = "CLMX";
	public static final String AUTOFILE_UPDATE_BY_PRE_AF_GET_FORM = "PAF-F";
	public static final String AUTOFILE_UPDATE_BY_PRE_AF_POS = "PAF-P";
	public static final int UPDATE_TEMP_EDOC_NOTIFICATION_MAX_NUM = 100;

	// notifySignatureCaseStatus
	public static final String SIGNATURE_POS_010 = "POS_010";
	public static final String SIGNATURE_COM_001 = "COM_001";
	public static final String SIGNATURE_CHECK_FAIL = "Decline due to signature checking fail";
	public static final String DUPLICATED_CASE = "Decline due to duplicated case";
	public static final String SIGNATURE_CASE_STATUS_PENDING = "Pending";
    public static final String SIGNATURE_STATUS_APPROVED = "Approved";
  	public static final String SIGNATURE_STATUS_DECLINE_FAIL = "Decline-Fail";
  	public static final String SIGNATURE_STATUS_DECLINE_DUPLICATE = "Decline-Duplicate";
	public static final String SUFFIX_PDF = ".pdf";
	public static final String CATEGORY_PEND = "PEND";
	public static final String ACTION_DESC_RESOLVE_PENDING = "Pending Reason [Waiting for Deduction File Extraction] Resolved";
	public static final String ACTION_DESC_RESOLVE_ILP_TRANSACTION = "Pending Reason [Pending for ILP Transaction Form] Resolved";
	public static final String ACTION_DESC_RESOLVE_TRANSACTION_COMPLETED = "Pending Reason [Pending For Transaction Completed] Resolved";
	// signatureVerifyFlag
	public static final String SIGNATURE_VERIFY_FLAG_2 = "2";
	public static final int REPORT_MAX_NUM_EVERYTIME = 50;
	public static final String SUCCESS = "success";
	public static final String CATEGORY_CLOSE = "CLOSE";
	public static final int WFSTATE_200 = 200;
	public static final int WFSTATE_210 = 210;
	public static final long SLEEP_TIME = 7000;
	public static final String WATER_FLAG="NOWATERMARK";
	//policy No prefix E to H comment
	public static final String E_TO_H_COMMENT="Policy number is wrongly provided from submission channel, system auto rectifies";
	public static final String LOOK_UP_GROUP_POL_STATUS="POL_STATUS";
	//match status
	public static final int MATCH_STATUS_3=3;
	//generateChangeSignatureLetter
	public static final String SEND_LETTER_Y="Y";
	public static final String SEND_LETTER_N="N";
	public static final String WEB_API="WebAPI";
	public static final String ADDITTRAIL_ADD_SIGNATURE="Add singnature";
	public static final String ADDITTRAIL_UPDATE_SIGNATURE="Update singnature";
	public static final int SYNC_FSCDISTRINCT_MAX_NUM=100;
	//close reason
	//Decline
	public static final String CLOSE_REASON_DUPLICATE="Cancel due to duplicate submission";
	public static final String CLOSE_REASON_INCORRECT="Cancel due to incorrect submission";
	public static final String CLOSE_REASON_WRONGLY="Cancel due to wrongly created";
	public static final String CLOSE_REASON_NON_TAKEN="Non Taken";
	//Completed
	public static final String CLOSE_REASON_COMPLETED="Completed";
	//coefficient
	public static final float FILE_COEFFICIENT = 1.4F;

	public static List<String> getHias() {
		return HIAS;
	}
	
	public static final int UPDATE_TEMP_SUSPENSE_MAX_NUM = 200;
	public static final int UPDATE_TEMP_CWA_MAX_NUM = 200;
	public static final int UPDATE_TEMP_EXPIRE_MAX_NUM = 200;
	public static final int UPDATE_TEMP_POLICY_MAX = 200;
	//department
	//UNI
	public static final String DEPARTMENT_UNI="UNI";
	public static final String DEPARTMENT_HNW="HNW";
	//POS
	public static final String DEPARTMENT_POS="POS";
	public static final String DEPARTMENT_CS="CS";
	public static final String DEPARTMENT_CNC="CNC";
	
	public static final String EMPTY_STRING="";
	public static final String VERTICAL_LINE="|";
	public static final String DOUBLE_EXCLAMATION="!!";
	//default code and message
	public static final String SUCCESS_DEFAULT_CODE="0";
	public static final String SUCCESS_DEFAULT_MESSAGE="success";
	public static final String FAILED_DEFAULT_CODE="1";
	public static final String FAILED_DEFAULT_MESSAGE="failed";
	
	public static final String ERROR_POLICY_NO_NULL="policyNo can not be null";
	public static final String ERROR_CLAIMNO_NULL="claimNo can not be null";
	public static final String ERROR_SECUITYNO_NULL="secuityNo is null";
	public static final String ERROR_LIFEAN_NULL="LifeAssuredNRIC is null";
	
	//act signal
	public static final String ACT_SIGNAL_CLOSE="CLOSE";
	public static final String ACT_SIGNAL_REOPEN="REOPEN";
	public static final String ACT_SIGNAL_REOPEN_DOCRECEIVED="Re-open - Doc received";
	public static final String ACT_SIGNAL_REOPEN_PRMRECEIVED="Re-open - Premium received";
	
	//ESB indicator
	//1 - short payment register
	public static final String ESB_INDICATOR_1="1";
	//3 - mark complete
	public static final String ESB_INDICATOR_3="3";
	public static final int ESB_REGISTER_SUCCESS=10;
	public static final int ESB_REGISTER_FIRST_FAILED=11;
	public static final int ESB_COMPLETED_SUCESS=20;
	public static final int ESB_COMPLETED_FIRST_FAILED=21;
	
	public static final String AVAILABLE_STEP_UW_TYPE="UW_TYPE";
	public static final String UW_TYPE_HNW="HNW";
	public static final String DESTINATION_COM_006="COM_006";
	public static final String DESTINATION_COM_004="COM_004";
	public static final String DESTINATION_COM_009="COM_009";
	
	public static final String REQ_TYPE_GRP_UNI_UW="GRP_UNI_UW";
	
	//CNC followUpCode
	public static final String FOLLOW_UP_CODE_CY2="CY2";
	public static final String FOLLOW_UP_CODE_CY3="CY3";
	//CNC requestType match followUpCode 
	public static final String REQUEST_TYPE_CY2="CNC_CYO_ANNIVERSARY";
	public static final String REQUEST_TYPE_CY3="CNC_CYO_RPU";
	//IL follow up code trigger case(SYSTEM)
	public static final String FOLLOW_UP_CODE_SYSTEM="ODS";
	//IL follow up code trigger case(process)
	public static final String FOLLOW_UP_CODE_PROCESS="CNC";
	
	// default call ESB
	/**
	 * "yyyy/MM/dd hh:mm:ss"
	 */
	public static SimpleDateFormat getyyyyMMddhhmmssDateFormat() {
		return new SimpleDateFormat("yyyy/MM/dd hh:mm:ss");
	}
	/**
	 * "yyyy/MM/dd HH:mm:ss"
	 */
	public static SimpleDateFormat getyyyyMMdd24DateFormat() {
		return new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	}
	/**
	 * "MM-dd-yyyy hh:mm:ss"
	 */
	public static SimpleDateFormat getMMddyyyyhhmmssDateFormat() {
		return new SimpleDateFormat("MM-dd-yyyy hh:mm:ss");
	}
	/**
	 * "MM-dd-yyyy HH:mm:ss"
	 */
	public static SimpleDateFormat getMMddyyyy24DateFormat() {
		return new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
	}

	public static final String ESB_getTASRURL="/rest/AIACase360/party/v1/retrieveCustomerPerLifeInfo";
	public static final String ESB_getTASRReqName="retrieveCustomerPerLifeInfoRequest";
	
	public static final String ESB_checkILURL="/rest/AIASGServicePortal/masterData/v1/retrieveILStatus";
	public static final String ESB_checkILReqName="retrieveILStatusRequest";
	
	public static final String ESB_updateUWIDURL="/rest/AIACase360/party/v1/updateUnderwriter";
	public static final String ESB_updateUWIDReqName="updateUnderwriterRequest";
	
	public static final String ESB_getFSCCodeURL="/rest/AIASCase360.contract.v2.retrievePolicyBasic";
	public static final String ESB_getFSCCodeReqName="retrievePolicyDetailRequest"; 
	public static final String ESB_getFSCCodeResponseName="retrievePolicyDetailResponse";
	
	public static final String ESB_shortPaymentUpdateURL="/rest/AIACase360/shortPayment/v1/updateShortPayment";
	public static final String ESB_shortPaymentUpdateReqName="updateShortPaymentRequest";
}
