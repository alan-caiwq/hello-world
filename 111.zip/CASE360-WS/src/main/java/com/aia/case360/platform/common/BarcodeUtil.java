package com.aia.case360.platform.common;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import org.apache.commons.lang.StringUtils;
import org.krysalis.barcode4j.impl.code39.Code39Bean;
import org.krysalis.barcode4j.output.bitmap.BitmapCanvasProvider;
import org.krysalis.barcode4j.tools.UnitConv;

public class BarcodeUtil {

	private BarcodeUtil() {
		
	}
	public static File generateFile(String msg, String path) throws IOException {
		File file = new File(path);
			generate(msg, new FileOutputStream(file));
		
		return file;
	}

	public static byte[] generate(String msg) throws IOException {
		ByteArrayOutputStream ous = new ByteArrayOutputStream();
		generate(msg, ous);
		return ous.toByteArray();
	}

	public static void generate(String msg, OutputStream ous) throws IOException {
		if (StringUtils.isEmpty(msg) || ous == null) {
			return;
		}

		Code39Bean bean = new Code39Bean();

		final int dpi = 150;

		final double moduleWidth = UnitConv.in2mm((double) ((double) 1.0f / dpi));

		bean.setModuleWidth(moduleWidth);
		bean.setWideFactor(3);
		bean.doQuietZone(false);

		String format = "image/png";

			BitmapCanvasProvider canvas = new BitmapCanvasProvider(ous, format, dpi, BufferedImage.TYPE_BYTE_BINARY,
					false, 0);

			bean.generateBarcode(canvas, msg);

			canvas.finish();
		
	}

}