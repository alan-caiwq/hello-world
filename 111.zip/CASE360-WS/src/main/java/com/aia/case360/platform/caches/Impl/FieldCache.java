package com.aia.case360.platform.caches.Impl;

import java.rmi.RemoteException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedDeque;

import javax.ejb.FinderException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.web.service.impl.AbstractHelperImpl;
import com.eistream.sonora.fields.FieldDataType;
import com.eistream.sonora.fields.FmsFieldDefinition;

/**
 * 
 * @author bsnpbjd
 *
 */
public class FieldCache extends AbstractHelperImpl {
	private static Logger m_Logger_sec = LoggerFactory.getLogger(FieldCache.class.getClass());
	private static Map<String, String> fieldTypeCache = new ConcurrentHashMap<String, String>();
	private static ConcurrentLinkedDeque<String> fieldTypeMruList = new ConcurrentLinkedDeque<String>();

	// Cache pool size.
	private static int cachesize = 1024;

	public static String getFieldType(String filedName) throws RemoteException {
		String methodName = "getFieldType";
		try {
			LogUtil.logInfo(m_Logger_sec,"FieldCache getFieldType is entering!");
			if (filedName == null || "".equals(filedName)) {
				return null;
			}
			String fieldtype = null;

			fieldtype = (String) fieldTypeCache.get(filedName);
			if (fieldtype != null && !((String) fieldTypeMruList.getFirst()).equals(filedName)
					&& fieldTypeMruList.size() > 0) {
				fieldTypeMruList.remove(filedName);
				fieldTypeMruList.addFirst(filedName);

			}

			if (fieldtype == null) {
				FmsFieldDefinition fmsFile;

				fmsFile = getFmsSchemaSessionEJB().getField(filedName);
				FieldDataType fdType = fmsFile.getDataType();
				fieldtype = fdType.toString();

				if ((fieldTypeCache.size() >= cachesize) && (cachesize != 0)) {
					fieldTypeCache.remove(fieldTypeMruList.getLast());
					fieldTypeMruList.removeLast();

				}
				fieldTypeCache.put(filedName, fieldtype);
				fieldTypeMruList.addFirst(filedName);

			}
			return fieldtype;
		} catch (RemoteException e) {

			throw LogUtil.logException(m_Logger_sec,methodName,e);
		} catch (FinderException e) {

			throw LogUtil.logException(m_Logger_sec,methodName, e);
		}
	}

	public static int getCacheLength() {
		return fieldTypeCache.size();
	}

	public static void clearCache()  throws RemoteException {
		String str = "clearCache";
		LogUtil.logInfo(m_Logger_sec, " clearCache Entering");
		try {
			fieldTypeCache.clear();
			fieldTypeMruList.clear();
		} catch (Exception localException1) {
			
			throw LogUtil.logException(m_Logger_sec, str, localException1);
		} finally {
			LogUtil.logInfo(m_Logger_sec,"clearCache leaving");
		}
	}

}
