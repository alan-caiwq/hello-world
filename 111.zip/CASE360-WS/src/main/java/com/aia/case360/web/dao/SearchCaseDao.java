package com.aia.case360.web.dao;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.aia.case360.web.pojo.CaseDetailsInfo;
import com.aia.case360.web.pojo.CfWork;
import com.aia.case360.web.pojo.FdReqType;
import com.aia.case360.web.pojo.FdWcfClient;
import com.aia.case360.web.pojo.FdWcfLink;
import com.aia.case360.web.pojo.GetFormInfo;
import com.aia.case360.web.pojo.GetFormInfoParameter;
import com.aia.case360.web.pojo.GetParentRequestNoDetailsInfo;
import com.aia.case360.web.pojo.GetParentRequestNoParameter;
import com.aia.case360.web.pojo.GetRequestStatusDetailsInfo;
import com.aia.case360.web.pojo.GetRequestStatusParameter;
import com.aia.case360.web.pojo.GetRequestTypeDetailsInfo;
import com.aia.case360.web.pojo.GetRequestTypeParameter;
import com.aia.case360.web.pojo.GetSuppressPendingDetailsInfo;
import com.aia.case360.web.pojo.GetSuppressPendingParameter;
import com.aia.case360.web.pojo.LinkCaseVO;
import com.aia.case360.web.pojo.PendingComment;
import com.aia.case360.web.pojo.RequestNoByPolicyNoDetailsInfo;
import com.aia.case360.web.pojo.RequestNoByPolicyNoParameter;
import com.aia.case360.web.pojo.SearchCaseDetailsInfo;
import com.aia.case360.web.pojo.StartWorkflowDetailsInfo;
import com.aia.case360.web.pojo.TempCaseInfo;

@Repository
public interface SearchCaseDao {

	// Get case detail by policy no and case status, process name
	public List<SearchCaseDetailsInfo> querySearchCases(Map<String, String> params)  throws RemoteException;

	// Get form into list
	public List<GetFormInfo> queryFormInfo(GetFormInfoParameter params)  throws RemoteException;

	// Get case status by request no(For eCare CRS)
	public List<GetRequestStatusDetailsInfo> queryRequestStatusByRequestNo(GetRequestStatusParameter params)
			 throws RemoteException;

	// Get parent request no by policy no and process name
	public List<GetParentRequestNoDetailsInfo> queryParentRequestNoByPolicyNo(GetParentRequestNoParameter params)
			 throws RemoteException;

	// Get request type
	public List<GetRequestTypeDetailsInfo> queryRequestType(GetRequestTypeParameter params)  throws RemoteException;

	// Get case id/request no by policy no and process name
	public List<RequestNoByPolicyNoDetailsInfo> queryRequestNoByPolicyNo(RequestNoByPolicyNoParameter params)
			 throws RemoteException;

	// Get suppress pending follow code list
	public List<GetSuppressPendingDetailsInfo> querySuppressPendingFollowCode(GetSuppressPendingParameter params)
			 throws RemoteException;

	// Force trigger workflow-only for draft case, ignore the waiting time, need
	// wait for manatory case ID
	public StartWorkflowDetailsInfo startWorkflow(StartWorkflowDetailsInfo params)  throws RemoteException;

	// insert fd_wcf_link
	public void insertWcfLink(List<FdWcfLink> fdWcfLink)  throws RemoteException;

	// update isDELETED=1 with fd_wcf_link
	public void deletedWcfLink(FdWcfLink fdWcfLink)  throws RemoteException;

	// verify fd_wcf_link
	public List verifyWcfLink(FdWcfLink fdWcfLink)  throws RemoteException;

	// Get case informaition by caseId
	public List serachCaseDetail(CaseDetailsInfo params)  throws RemoteException;

	// insert into FD_DOC_LINK
	public void insertDocLink(FdWcfLink fdWcfLink)  throws RemoteException;

	// INSERT INTO FD_WCF_CLINT
	public void insertWcfClient(List<FdWcfClient> fdWcfClient)  throws RemoteException;

	// update isDELETED=1 with fd_wcf_client
	public void delClientLinkList(List<FdWcfClient> fdWcfClient)  throws RemoteException;

	// update isDELETED=1 with fd_wcf_client
	public void delClientLink(FdWcfLink fdWcfLink)  throws RemoteException;

	// update isDELETED=1 with fd_doc_link
	public void delDocLink(FdWcfLink fdWcfLink)  throws RemoteException;

	/**
	 * 
	 * @param params
	 * @return
	 * @ throws RemoteException
	 * @author bsnpc37
	 * @date: 2018-4-11 17:58:43
	 */
	List<PendingComment> getPendingComment(Map<String, String> params)  throws RemoteException;

	// get case policyNo and claimNo Info
	List<TempCaseInfo> getTempCaseInfo(Map<String, String> params)  throws RemoteException;

	// added by bsnpc1g: for the use of search case list of quick search.
	public List<Map<String, String>> getCaseByPolNum(Map<String, String> params)  throws RemoteException;

	public List<FdWcfClient> getClientLink(Map<String, String> params)  throws RemoteException;

	public List<FdWcfClient> getClientLinkSeprateRole(Map<String, String> params)  throws RemoteException;

	public List<FdWcfLink> getWcfLink(Map<String, String> params)  throws RemoteException;

	public List<Integer> varifyDocLink(Map<String, String> param)  throws RemoteException;

	public List<Integer> varifyWcf(Map<String, String> param)  throws RemoteException;

	public List<Map> getCustomerByCase(CaseDetailsInfo params)  throws RemoteException;

	public List<FdReqType> getReqTypeInformation(Map<String, String> params)  throws RemoteException;

	public List<Map> getUserStatus(Map<String, String> params)  throws RemoteException;

	public List<Map> getTrainerStatus(Map<String, String> params)  throws RemoteException;

	public List<Map> verifyIsTrainee(Map<String, String> params)  throws RemoteException;

	public List<Map<String, String>> queryPolicyByNRIC(Map<String, String> params)  throws RemoteException;

	public List<Map<String, String>> queryPolicyByPolNum(Map<String, String> params)  throws RemoteException;

	CfWork existCfWork(String LinkRequestNum)  throws RemoteException;

	LinkCaseVO existLinkCase(@Param(value = "linkRequestNum") String linkRequestNum,
			@Param(value = "requestNum") String requestNum)  throws RemoteException;

    //added by bsnpc1g : for basic case quick search
	public List<Map<String, String>> basicQueryCaseList(
			@Param(value = "requestNo") String requestNo,
			@Param(value = "polNo") String polNo,
			@Param(value = "idNo") String idNo,
			@Param(value = "curUserId") String curUserId
			)  throws RemoteException;
	
	public int isMimoRequest(String requestNo)  throws RemoteException;
	
	// added by bsnpc1g on 2018-12-14 : save the nric into wcf client
	public int addNonAIACusToClientLink(FdWcfClient client)  throws RemoteException;
	// added end on 2018-12-14
	
	public List<Map<String, Object>> validUserFormIdAuth(@Param(value = "userId") String userId, @Param(value = "formId") String formId) throws RemoteException;
}
