package com.aia.case360.web.pojo;

import java.util.List;

public class ConcurrentCaseRuleVO {

	private String sRowId;

	private String department;

	// 0 default rule 1 combination rule
	private String ruleType;

	// if ruleType is 0 default rule, then this field will show default rule
	// 1 same insured 2 same owner 3 same policy number 4 same insured or same owner
	// else it's concurrent case's rule name
	private String ruleName;
	
	private String reqTypeCategory;

	private List<ConcurrentCaseDataVO> datas;

	public String getsRowId() {
		return sRowId;
	}

	public void setsRowId(String sRowId) {
		this.sRowId = sRowId;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getRuleType() {
		return ruleType;
	}

	public void setRuleType(String ruleType) {
		this.ruleType = ruleType;
	}

	public String getRuleName() {
		return ruleName;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	public List<ConcurrentCaseDataVO> getDatas() {
		return datas;
	}

	public void setDatas(List<ConcurrentCaseDataVO> datas) {
		this.datas = datas;
	}

	public String getReqTypeCategory() {
		return reqTypeCategory;
	}

	public void setReqTypeCategory(String reqTypeCategory) {
		this.reqTypeCategory = reqTypeCategory;
	}
	
}
