package com.aia.case360.uam.domain;

import java.util.List;

public class RoleActivityVo extends BaseRoleInfo {

	public RoleActivityVo(List<RequsetTypeInfo> rEQUESTTYPES) {
		super();
		REQUESTTYPES = rEQUESTTYPES;
	}

	public RoleActivityVo() {

	}

	private List<RequsetTypeInfo> REQUESTTYPES;

	public List<RequsetTypeInfo> getREQUESTTYPES() {
		return REQUESTTYPES;
	}

	public void setREQUESTTYPES(List<RequsetTypeInfo> rEQUESTTYPES) {
		REQUESTTYPES = rEQUESTTYPES;
	}

}
