package com.aia.case360.uam.constants;

import com.aia.case360.platform.common.PropertyUtil;

public final class UAMConstants {

	private UAMConstants() {
		
	}
	public static final String ROLE_TYPE_ACT = "RequestType & Activity";
	public static final String ROLE_TYPE_FUC = "Functional";
	public static final String ROLE_TYPE_MU = "Menu";
	public static final String ROLE_TYPE_CATE = "FormCategory";

	public static final String LOGINID = "LOGINID";// primary key
	public static final String DISPLAYNAME = "DISPLAYNAME";
	public static final String DELIVERYSTRING = "DELIVERYSTRING";
	public static final String ACTIVESTATUS = "ACTIVESTATUS";

	public static final String SEARCH_FILTER = PropertyUtil.getCommonProperty("ADGROUP");

	public static final String BASEDN = "DC=AIA,DC=BIZ";
	public static final String LDAP_JNDI_STR = "java:jboss/ldap";
	public static final String UAM_USER_ID = "UAM_USER_ID";
	public static final String UAM_USER_OFFICE_NUMBER = "UAM_USER_OFFICE_NUMBER";
	public static final String USERCOMPANY = "USERCOMPANY";

	// dose not exist data
	public static final String UAM_USER_DEPARTMENT = "UAM_USER_DEPARTMENT";

	public static final String FROMAD = "FROM_AD";

}
