package com.aia.case360.platform.process.impl;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;

import javax.ejb.FinderException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.aia.case360.common.Constants;
import com.aia.case360.platform.common.DateUtil;
import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.common.PropertyUtil;
import com.aia.case360.platform.common.QueryResultsHandler;
import com.aia.case360.platform.common.ScriptUtil;
import com.aia.case360.platform.process.WorkItemHelper;
import com.aia.case360.web.service.impl.AbstractHelperImpl;
import com.eistream.sonora.exceptions.SonoraApplicationException;
import com.eistream.sonora.exceptions.SonoraException;
import com.eistream.sonora.fields.FieldDataType;
import com.eistream.sonora.fields.FmsField;
import com.eistream.sonora.fields.FmsFieldDefinition;
import com.eistream.sonora.fields.FmsRow;
import com.eistream.sonora.workflow.Envelope;
import com.eistream.sonora.workflow.worksteps.WSElement;

/**
 * A <code>WorkItemHelper</code> is the common helper class for the operations
 * on special WorkItem.
 *
 * @author bsnpbdu
 *
 */
@Component
public class WorkItemHelperImpl extends AbstractHelperImpl implements WorkItemHelper {

	private static final String LOCALWFWORKSTEPNAME = "WFWORKSTEPNAME";
	private static final String WFPRIORSTEPNAME = "WFPRIORSTEPNAME";
	private static final String LOCALWORKITEMREPOSITORYKEY = "WorkItem repositoryKey:";
	private static final String LOCALDISPATCHNAME = "dispatchName";

	/**
	 * Update one specified customer field with value.
	 * 
	 * @param fldName  field Name
	 * @param fldValue fields Value
	 * @throws RemoteException
	 */
	public void updateFldVal(String fldName, String fldValue, String rpKeyStr) throws RemoteException {

		updateFldsVals(rpKeyStr, new String[] { fldName, fldValue });

	}

	/**
	 * route On one specified WorkItem which is indicated by repository key
	 * 
	 * @param userId userId
	 * 
	 * @throws RemoteException
	 */

	public void routeOn(String userId, String rpKeyStr) throws RemoteException {
		routeOn("", userId, rpKeyStr);
	}

	/**
	 * route On one specified WorkItem which is ndicated by repository keyi
	 * 
	 * @param dispatchName process's dispatch button's name
	 * @param userId       userId
	 * @throws RemoteException
	 */
	public void routeOn(String dispatchName, String userId, String rpKeyStr) throws RemoteException {
		LogUtil.logInfo(m_Logger,LOCALDISPATCHNAME + dispatchName);
		Envelope wiEvp;
		RepositoryKey rpKey = RepositoryKey.getInstance(rpKeyStr);
		String message = LOCALWORKITEMREPOSITORYKEY + rpKey.toString();

		if (dispatchName != null && dispatchName.trim().length() > 0) {
			message += "dispatch Name:" + dispatchName;
		}

		if (null == userId || userId.trim().length() < 1) {
			userId = Constants.SONORA;
		}
		message += " userId:" + userId + ".";

		try {
			Map<String, String> s_dispatchMap = new HashMap<String, String>();
			s_dispatchMap.put("S_DISPATCH", "");

			Map<String, Object> fieldMap = new HashMap<String, Object>();
			fieldMap.put("UPDATE_TIMESTAMP", DateUtil.getCurrentTime());
			updateCustomFields(fieldMap, rpKeyStr);
			this.updateSysFields1(s_dispatchMap, rpKeyStr);
			wiEvp = getWfEJB().getEnvelope(rpKey.getWorkflowId(), rpKey.getEnvelopeId().toString(), true);

			m_Logger.info(LOCALDISPATCHNAME + dispatchName+"," +rpKeyStr +",state:"+wiEvp.getState());
			
			if(wiEvp.getState() != 200 && wiEvp.getState() != 210){
				throw new RemoteException("dispatchName:" + dispatchName+"," +rpKeyStr +",state:"+wiEvp.getState()+", state error");
			}
			if (wiEvp.getLockType() == 1) {
				getWfEJB().releaseFromLock(rpKey.getWorkflowId(), rpKey.getWorkItemId().toString(),
						rpKey.getEnvelopeId().toString());

			}
			LogUtil.logInfo(m_Logger,LOCALDISPATCHNAME + dispatchName);

			getWfEJB().lockEnvelopeTo(rpKey.getWorkflowId(), rpKey.getWorkItemId().toString(),
					rpKey.getEnvelopeId().toString(), userId,
					com.eistream.sonora.workflow.workprocessor.WorkflowConstants.W_LOCK_SIMPLELOCK);
			if (dispatchName == null || dispatchName.trim().length() == 0) {
				getWfEJB().routeEnvelope(rpKey.getWorkflowId(), rpKey.getWorkItemId().toString(),
						rpKey.getEnvelopeId().toString());
			} else if (dispatchName.trim().length() > 0) {

				// if dispatchName is not null, after routeOn, must clear
				// the dispatchBtn, otherwise, the s_dispatch button will
				// always has the value.

				getWfEJB().routeEnvelope(rpKey.getWorkflowId(), rpKey.getWorkItemId().toString(),
						rpKey.getEnvelopeId().toString(), dispatchName);

			}

		} catch (RemoteException e) {
			 
			throw LogUtil.logException(m_Logger, message, e);
		} catch (SonoraApplicationException e) {
			throw LogUtil.logException(m_Logger, message, e);
		}
		LogUtil.logInfo(m_Logger, message);
	}

	@Override
	public String getCurWorkstep(String rpKeyStr) throws RemoteException {
		RepositoryKey rpKey = RepositoryKey.getInstance(rpKeyStr);
		Envelope wiEvp = getWfEJB().getEnvelope(rpKey.getWorkflowId(), rpKey.getEnvelopeId().toString(), true);

		try {
			return wiEvp.getStepName();
		} catch (SonoraApplicationException e) {

			 
			RemoteException e1 = new RemoteException(e.getMessage(), e);

			throw LogUtil.logException(m_Logger, rpKeyStr, e1);
		}
	}

	private void updateFldsVals(String rpKeyStr, String[]... params) throws RemoteException {

		StringBuilder sb = new StringBuilder();
		RepositoryKey rpKey = RepositoryKey.getInstance(rpKeyStr);
		sb.append(LOCALWORKITEMREPOSITORYKEY + rpKey.toString());
		try {
			FmsRow nfr = getWfEJB().getWorkItemFields(rpKey.getWorkflowId(), rpKey.getEnvelopeId().toString());
			for (String[] paramPair : params) {
				if (null != nfr.getField(paramPair[0])) {
					nfr.setValue(paramPair[0], paramPair[1]);

				}
				sb.append("|FieldName:" + paramPair[0] + " FieldVal:" + paramPair[1]);
			}
			getWfEJB().setWorkItemFields(rpKey.getWorkflowId(), rpKey.getEnvelopeId().toString(), nfr);
			LogUtil.logInfo(m_Logger,sb.toString());
		} catch (RemoteException e) {
			 
			throw LogUtil.logException(m_Logger, sb.toString(), e);
		} catch (FinderException e) {
			 
			throw LogUtil.logException(m_Logger, sb.toString(), e);
		} catch (SonoraException e) {
			 
			throw LogUtil.logException(m_Logger, sb.toString(), e);

		}

	}

	@Override
	public FmsRow getWorkItemRow(String rpKeyStr) throws RemoteException {
		try {
			RepositoryKey rpKey = RepositoryKey.getInstance(rpKeyStr);
			return getWfEJB().getWorkItemFields(rpKey.getWorkflowId(), rpKey.getEnvelopeId().toString());
		} catch (FinderException e) {
			 
			throw LogUtil.logException(m_Logger,rpKeyStr, e);
		}
	}

	@Override
	public FmsRow getWorkItemSysRow(String rpKeyStr) throws RemoteException {

		try {
			RepositoryKey rpKey = RepositoryKey.getInstance(rpKeyStr);
			return getWfEJB().getWorkItemEnvelope(rpKey.getWorkflowId(), rpKey.getEnvelopeId().toString());
		} catch (FinderException e) {
			 
			throw LogUtil.logException(m_Logger,rpKeyStr, e);
		}
	}

	@Override
	public List<String> getDispatchButtons(String workstep, String rpKeyStr) throws RemoteException {
		RepositoryKey rpKey = RepositoryKey.getInstance(rpKeyStr);
		List<String> dispatchBtnNames = new ArrayList<String>();
		try {

			List<WSElement> wsElements = getWssSEJB().getElementList(rpKey.getWorkflowId());
			WSElement actElement = null;
			for (WSElement element : wsElements) {
				if (element.m_WorkStepName.equalsIgnoreCase(workstep)) {
					actElement = element;
					break;
				}

			}
			if (actElement != null) {
				dispatchBtnNames = getDispatchButton(actElement.activityOpts);
			}

		} catch (RemoteException e) {

			 
			throw LogUtil.logException(m_Logger, workstep, e);
		} catch (FinderException e) {
			 
			throw LogUtil.logException(m_Logger, workstep, e);
		} catch (ParserConfigurationException e) {
			 
			throw LogUtil.logException(m_Logger, workstep, e);
		} catch (SAXException e) {
			 
			throw LogUtil.logException(m_Logger, workstep, e);
		} catch (IOException e) {
			 
			throw LogUtil.logException(m_Logger, workstep, e);
		}

		return dispatchBtnNames;
	}

	@Override
	public Map<String, Object> getWorkItemDetail(String rpKeyStr) throws RemoteException {

		FmsRow curr =  getWorkItemRow(rpKeyStr);
		Map<String, Object> workItemRow = new HashMap<String, Object>();
		if (curr == null || curr.fieldCount < 1) {
			return workItemRow;
		}

		Map<String, Object> queryResults = QueryResultsHandler.convertQueryRowAsObject(curr.getFmsRowTO());

		return queryResults;

	}

	private List<String> getDispatchButton(String optString)
			throws SAXException, IOException, ParserConfigurationException {

		List<String> result = new ArrayList<String>();
		if (optString != null) {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.parse(new InputSource(new ByteArrayInputStream(optString.getBytes())));
			NodeList nodeList = doc.getElementsByTagName("Dispatch");
			if (nodeList != null) {
				for (int i = 0; i < nodeList.getLength(); i++) {
					Node node = nodeList.item(i);
					NamedNodeMap attrs = node.getAttributes();
					getDispatchButtonAssist(result, attrs);
				}
			}
		}
		return result;
	}

  private void getDispatchButtonAssist(List<String> result, NamedNodeMap attrs) {
    if (attrs != null) {
    	for (int j = 0; j < attrs.getLength(); j++) {
    		Node nattr = attrs.item(j);
    		if (nattr.getNodeName().equalsIgnoreCase("name"))
    			result.add(nattr.getNodeValue());

    	}
    }
  }

	@Override
	public boolean canPend(String workstep, String rpKeyStr) throws RemoteException {

		List<String> dispatchBtns = getDispatchButtons(workstep, rpKeyStr);

		return null != dispatchBtns && dispatchBtns.contains(PropertyUtil.getCommonProperty("PENDBTNNAME"));
	}

	@Override
	public boolean assign(String userEntity, String... repositoryKeys) throws RemoteException {

		return false;
	}

	/**
	 * It's used to update loginid_user if WorkItem owner want to send it to
	 * another.
	 * 
	 * @param userId userId
	 * 
	 * @throws RemoteException
	 */

	public boolean reassignWork(String userId, String rpKeyStr) throws RemoteException {
		boolean flag = false;
		RepositoryKey rpKey = RepositoryKey.getInstance(rpKeyStr);
		String message = LOCALWORKITEMREPOSITORYKEY + rpKey.toString();
		try {
			message += "Update LOGINID_USER:" + userId;
			FmsRow nfr = getWfEJB().getWorkItemFields(rpKey.getWorkflowId(), rpKey.getEnvelopeId().toString());
			if (null != nfr.getField(PropertyUtil.getCommonProperty("LOGINID_USER"))) {
				nfr.setValue(PropertyUtil.getCommonProperty("LOGINID_USER"), userId);
			}
			getWfEJB().setWorkItemFields(rpKey.getWorkflowId(), rpKey.getEnvelopeId().toString(), nfr);
			LogUtil.logInfo(m_Logger,message);
			flag = true;
		} catch (SonoraException e) {
			 
			throw LogUtil.logException(m_Logger, message, e);
		} catch (FinderException e) {
			 
			throw LogUtil.logException(m_Logger, message, e);
		}
		return flag;
	}

	private String getFieldType(String filedName) throws RemoteException {
		FmsFieldDefinition fmsFile;
		String fieldDataType = null;
		try {
			fmsFile = getFmsSchemaSessionEJB().getField(filedName);
			FieldDataType fdType = fmsFile.getDataType();
			fieldDataType = fdType.toString();
		} catch (FinderException e) {
			 
			throw LogUtil.logException(m_Logger,filedName, e);
		}
		return fieldDataType;
	}

	@Override
	public void updateCustomFields(Map<String, ?> fieldMap, String rpKeyStr) throws RemoteException {
		RepositoryKey rpKey = RepositoryKey.getInstance(rpKeyStr);
		LogUtil.logInfo(m_Logger,fieldMap.toString());
		//20181819 add message
		String message ="Function : updateCustomFields";
		try {
			FmsRow fmsRow = getWfEJB().getFields(rpKey.getWorkflowId(), rpKey.getEnvelopeId().toString());
			LogUtil.logInfo(m_Logger,fmsRow.getFieldCount() + "");

			Iterator<?> it = fieldMap.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry<String, String> entry = (Entry<String, String>) it.next();

				if (fmsRow.getField(entry.getKey()) == null) {
					continue;
				}
				String fieldType = verifyFiledValue(fmsRow, entry);
				LogUtil.logInfo(m_Logger,"fieldType:" + fieldType + " value:" + fmsRow.getValue(entry.getKey()));
			}
			getWfEJB().setWorkItemFields(rpKey.getWorkflowId(), rpKey.getEnvelopeId().toString(), fmsRow);
		} catch (RemoteException e1) {
			LogUtil.logException(m_Logger, message, e1);
			throw LogUtil.logException(m_Logger, fieldMap.toString(), e1);
		} catch (SonoraException e) {
			 
			throw LogUtil.logException(m_Logger, fieldMap.toString(), e);
		}
	}

  private String verifyFiledValue(FmsRow fmsRow, Map.Entry<String, String> entry)
      throws RemoteException, SonoraException {
    String fieldType = getFieldType(entry.getKey());
    if (fieldType.equalsIgnoreCase("Decimal")) {
      if(!"".equals(valueIsNull(entry.getValue()))){

    		fmsRow.setValue(entry.getKey(), new BigDecimal(entry.getValue().toString()));
      }
    } else if (fieldType.equalsIgnoreCase("Integer")) {
      if(!"".equals(valueIsNull(entry.getValue()))){

    		fmsRow.setValue(entry.getKey(), new Integer(entry.getValue()));
      }
    } else if (fieldType.equalsIgnoreCase("Boolean")) {
      if(!"".equals(valueIsNull(entry.getValue()))){

    		fmsRow.setValue(entry.getKey(), getBoolean(entry.getValue()));
      }
    } else if (fieldType.equalsIgnoreCase("Timestamp")) {
      if(!"".equals(valueIsNull(entry.getValue()))){

    		fmsRow.setValue(entry.getKey(), DateUtil.getTimestamp(entry.getValue()));
      }
    } else {
    	fmsRow.setValue(entry.getKey(), valueIsNull(entry.getValue()));
    }
    return fieldType;
  }

	private Boolean getBoolean(String value) {

		if (value == null) {
			return false;
		}
		if (value.equals("1")) {
			return true;
		}
		return new Boolean(value);
	}

	
	@Override
	public boolean updateExpiryType(String rpKeyStr) throws RemoteException {
		RepositoryKey rpKey = RepositoryKey.getInstance(rpKeyStr);
		StringBuilder sb = new StringBuilder();
		int expiryType;
		sb.append(LOCALWORKITEMREPOSITORYKEY + rpKey.toString());
		try {
			FmsRow nfr = getWfEJB().getWorkItemFields(rpKey.getWorkflowId(), rpKey.getEnvelopeId().toString());
			FmsField fs = nfr.getField(PropertyUtil.getCommonProperty("EXPIRY_TYPE"));
			if (fs.getValue() == null) {
				sb.append("ExpiryType can't update. Value is null.");
				LogUtil.logInfo(m_Logger,sb.toString());
				return false;
			}
			expiryType = (Integer) fs.getValue();

			expiryType = (expiryType + 1) % 3;
			nfr.setValue(PropertyUtil.getCommonProperty("EXPIRY_TYPE"), expiryType + "");

			getWfEJB().setWorkItemFields(rpKey.getWorkflowId(), rpKey.getEnvelopeId().toString(), nfr);
			LogUtil.logInfo(m_Logger,sb.toString());
		} catch (RemoteException e) {
			 
			throw LogUtil.logException(m_Logger, sb.toString(), e);
		} catch (FinderException e) {
			 
			throw LogUtil.logException(m_Logger, sb.toString(), e);
		} catch (SonoraException e) {
			 
			throw LogUtil.logException(m_Logger, sb.toString(), e);
		}
		return true;
	}

	@Override
	public boolean reassign(String caseId, String userId, String reAssignUserId, String rpKeyStr)
			throws RemoteException {
		Envelope wiEvp;
		RepositoryKey rpKey = RepositoryKey.getInstance(rpKeyStr);
		StringBuilder sb = new StringBuilder();
		boolean flag = false;
		sb.append(LOCALWORKITEMREPOSITORYKEY).append(rpKey.toString()).append(".");
		if (null == userId || userId.trim().length() < 1) {
			userId = Constants.SONORA;
		}
		sb.append("unlock userId:").append(userId).append(".");
		;
		try {
			wiEvp = getWfEJB().getEnvelope(rpKey.getWorkflowId(), rpKey.getEnvelopeId().toString(), true);
			// if locked by others, first released then delete lock user.
			if (wiEvp.getLockType() == 1) {
				getWfEJB().releaseFromLock(rpKey.getWorkflowId(), rpKey.getWorkItemId().toString(),
						rpKey.getEnvelopeId().toString());
				Map<String, String> lockUserMap = new HashMap<String, String>();
				lockUserMap.put(PropertyUtil.getCommonProperty("WFLOCKUSER"), "");
				updateCustomFields(lockUserMap, rpKeyStr);
			}
			flag = reassignWork(reAssignUserId, rpKeyStr);
			if (!flag) {
				sb.append("sendTask is error");
				LogUtil.logInfo(m_Logger,sb.toString());
				return flag;
			}
			sb.append("Re-assign userId:").append(reAssignUserId).append(".");
			LogUtil.logInfo(m_Logger,sb.toString());
		} catch (SonoraApplicationException e) {
			 
			throw LogUtil.logException(m_Logger, sb.toString(), e);
		}
		return flag;
	}

	@Override
	public void routeOnToSpecifiedWorkstep(String workstepName, String userId, String wfstatu, String rpKeyStr)
			throws RemoteException {

		Envelope wiEvp;
		RepositoryKey rpKey = RepositoryKey.getInstance(rpKeyStr);
		String message = LOCALWORKITEMREPOSITORYKEY + rpKey.toString();

		if (workstepName != null && workstepName.trim().length() > 0) {
			message += "，workstep Name:" + workstepName;
		}

		if (null == userId || userId.trim().length() < 1) {
			userId = Constants.SONORA;
		}
		message += " userId:" + userId + ".";
		Integer status = Integer.parseInt(wfstatu);
		try {
			wiEvp = getWfEJB().getEnvelope(rpKey.getWorkflowId(), rpKey.getEnvelopeId().toString(), true);
			// if locked by others, first released then locked.
			if (wiEvp.getLockType() == 1) {
				getWfEJB().releaseFromLock(rpKey.getWorkflowId(), rpKey.getWorkItemId().toString(),
						rpKey.getEnvelopeId().toString());

			}

			if (wiEvp.checkCanLockEnvelope()) {
				getWfEJB().lockEnvelopeTo(rpKey.getWorkflowId(), rpKey.getWorkItemId().toString(),
						rpKey.getEnvelopeId().toString(), userId,
						com.eistream.sonora.workflow.workprocessor.WorkflowConstants.W_LOCK_SIMPLELOCK);

				if (workstepName == null || workstepName.trim().length() == 0) {
					getWfEJB().routeEnvelope(rpKey.getWorkflowId(), rpKey.getWorkItemId().toString(),
							rpKey.getEnvelopeId().toString());
				} else if (workstepName.trim().length() > 0) {

					getWfEJB().sendToWorkstep(rpKey.getWorkflowId(), rpKey.getWorkItemId().toString(),
							rpKey.getEnvelopeId().toString(), workstepName, status.intValue() == 200);

				}

			} else {
				message += userId + " no permission to do routeOn for " + rpKey.toString();
				RemoteException e = new RemoteException(message);
				LogUtil.logError(m_Logger, message);
				 
				throw e;
			}
		} catch (RemoteException e) {
			 
			throw LogUtil.logException(m_Logger, message, e);
		} catch (SonoraApplicationException e) {
			throw LogUtil.logException(m_Logger, message, e);
		}
		LogUtil.logInfo(m_Logger,message);
	}

	@Override
	public void doReleaseFromErroe(String rpKeyStr) {
		try {
			RepositoryKey rpKey = RepositoryKey.getInstance(rpKeyStr);
			getWfEJB().releaseFromError(rpKey.getWorkflowId(), rpKey.getWorkItemId().toString(),
					rpKey.getEnvelopeId().toString());
			getWfEJB().releaseFromLock(rpKey.getWorkflowId(), rpKey.getWorkItemId().toString(),
					rpKey.getEnvelopeId().toString());
		} catch (RemoteException e) {
			LogUtil.logException(m_Logger, rpKeyStr, e);
		}
	}

	@Override
	public boolean isCurrentWorkStepName(String stepName, String rpKeyStr) throws RemoteException {
		String message = "FunctionName:isCurrentWorkStepName, stepName:" + stepName;
		LogUtil.logInfo(m_Logger,message + " is entering");
		Envelope result;
		boolean flag = true;
		try {

			RepositoryKey rpKey = RepositoryKey.getInstance(rpKeyStr);
			result = getWfEJB().getEnvelope(rpKey.getWorkflowId(), rpKey.getEnvelopeId().toString(), true);
			// get workStepName
			String workStepName = result.getStepName();

			if (!workStepName.equals(stepName)) {
				flag = false;
			}
		} catch (Exception e) {
			throw LogUtil.logException(m_Logger, stepName, e);
		}
		LogUtil.logInfo(m_Logger,message + " is levaing");
		return flag;

	}

	@Override
	public Map<String, String> getWorkItemData(String rpKeyStr) throws RemoteException {

		Map<String, String> result = new HashMap<String, String>();

		RepositoryKey rpKey = RepositoryKey.getInstance(rpKeyStr);
		try {
			FmsRow wiRow = getWfEJB().getWorkItemFields(rpKey.getWorkflowId(), rpKey.getEnvelopeId().toString());
			for (FmsField ff : wiRow.getFieldList()) {
				String fieldName = ff.getFieldMetaData().getColumnDefinition().getFieldName();
				String fieldValue = ff.getValue() == null ? "" : ff.getValue().toString();
				result.put(fieldName, fieldValue);
			}

			Envelope envelope = getWfEJB().getEnvelope(rpKey.getWorkflowId(), rpKey.getEnvelopeId().toString(), true);

			result.put(WFPRIORSTEPNAME, envelope.getPriorStepName());
			result.put("S_DISPATCH", envelope.getDispatch() == null ? "" : envelope.getDispatch());
			result.put(LOCALWFWORKSTEPNAME, envelope.getStepName());

		} catch (Exception e) {
			throw LogUtil.logException(m_Logger, rpKeyStr, e);
		}

		return result;
	}

	private void doTATHistory(String userId, int histType, String rpKeyStr, String scriptName) {
		String message = "doTATHistory, userId:" + userId + " histType:" + histType + " rpKeyStr:" + rpKeyStr
				+ " scriptName:" + scriptName;
		LogUtil.logInfo(m_Logger,message + "is entering!");
		RepositoryKey rpKey = RepositoryKey.getInstance(rpKeyStr);
		Map<String, Object> sysResults = new HashMap<String, Object>();
		Map<String, Object> cusResults = new HashMap<String, Object>();
		FmsRow fr;
		try {
			fr =  getWorkItemSysRow(rpKeyStr);
			sysResults = QueryResultsHandler.convertQueryRowAsObject(fr.getFmsRowTO());
			cusResults =  getWorkItemDetail(rpKeyStr);
		} catch (RemoteException e1) {
			LogUtil.logException(m_Logger, message, e1);

		}

		HashMap<String, String> params = new HashMap<String, String>();
		params.put("userId", userId);
		params.put("histType", histType + "");
		params.put("linkcaseId", cusResults.get("LINKCASEID") == null ? "" : cusResults.get("LINKCASEID").toString());

		params.put("workflowId", rpKey.getWorkflowId() + "");
		params.put("wfWorkItemId", rpKey.getWorkItemId().toString());
		params.put("wfRoutingTicketId", rpKey.getEnvelopeId().toString());

		params.put("WFPriorStepName",
				sysResults.get(WFPRIORSTEPNAME) == null ? "" : sysResults.get(WFPRIORSTEPNAME).toString());
		params.put("WFWorkStepName",
				sysResults.get(LOCALWFWORKSTEPNAME) == null ? "" : sysResults.get(LOCALWFWORKSTEPNAME).toString());
		params.put("callPend", cusResults.get("CALL_PEND") == null ? "" : cusResults.get("CALL_PEND").toString());

		try {
			ScriptUtil.doScript(scriptName, params, Locale.CHINA, getSysSEJB());
			LogUtil.logInfo(m_Logger,message + "is leaving!");
		} catch (RemoteException e) {
			LogUtil.logException(m_Logger, message, e);
			 
		}

	}

	@Override
	public void putUserIdTATHistory(String userId, String rpKeyStr) throws RemoteException {
		doTATHistory(userId, TATHistoryRecordType.USERID.ordinal(), rpKeyStr,
				PropertyUtil.getScriptAndQueryProperty("SCRIPT_END_TATHIS"));

	}

	@Override
	public void putActivityTATHistory(String userId, String rpKeyStr) throws RemoteException {
		doTATHistory(userId, TATHistoryRecordType.WORKSTEP.ordinal(), rpKeyStr,
				PropertyUtil.getScriptAndQueryProperty("SCRIPT_BEGIN_TATHIS"));

	}

	enum TATHistoryRecordType {
		INITIAL, WORKSTEP, USERID
	}

	@Override
	public void updateSysFields1(Map<String, ?> fieldMap, String rpKeyStr) throws RemoteException {
		RepositoryKey rpKey = RepositoryKey.getInstance(rpKeyStr);
		LogUtil.logInfo(m_Logger,fieldMap.toString() + rpKey.toString());
		try {

			FmsRow row = getWfEJB().getWorkItemEnvelope(rpKey.getWorkflowId(), rpKey.getEnvelopeId().toString());
			LogUtil.logInfo(m_Logger,row.getFieldCount() + "");
			for (Entry<String, ?> fieldName : fieldMap.entrySet()) {
				LogUtil.logInfo(m_Logger,fieldName.getKey() + row.getField(fieldName.getKey().trim()));
				if (null != row.getField(fieldName.getKey().trim())) {
					row.setValue(fieldName.getKey(), fieldName.getValue().toString());
					LogUtil.logInfo(m_Logger,  fieldName.getKey()+"|"+fieldName.getValue());
				} 
			}
			getWfEJB().setWorkItemFields(rpKey.getWorkflowId(), rpKey.getEnvelopeId().toString(), row);
		} catch (RemoteException e1) {
			throw LogUtil.logException(m_Logger, fieldMap.toString(), e1);
		} catch (SonoraException e) {
			 
			throw LogUtil.logException(m_Logger, fieldMap.toString(), e);

		} catch (FinderException e) {

			throw LogUtil.logException(m_Logger, fieldMap.toString(), e);
		}
	}

	private String valueIsNull(String value){
      
      if(value==null){
        return "";
      }else if("".equals(value.trim())){
        return "";
      }else if(value.trim().length()==0){
        return "";
      }else{
        return value;
      }
  }
}