package com.aia.case360.web.pojo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ImportPara implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String receivedDate;

	private String processType;

	private String formId;

	private String uuid;

	private String casdId;

	private String docId;

	private String fileName;
	private String companyNo;
	private String submissionChannel;
	private String claimNo;

	public String getSubmissionChannel() {
		return submissionChannel;
	}

	public void setSubmissionChannel(String submissionChannel) {
		this.submissionChannel = submissionChannel;
	}

	private ArrayList<PolNum> polNums;

	public String getCompanyNo() {
		return companyNo;
	}

	public void setCompanyNo(String companyNo) {
		this.companyNo = companyNo;
	}

	public String getDocId() {
		return docId;
	}

	public void setDocId(String docId) {
		this.docId = docId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getReceivedDate() {
		return receivedDate;
	}

	public void setReceivedDate(String receivedDate) {
		this.receivedDate = receivedDate;
	}

	public String getProcessType() {
		return processType;
	}

	public void setProcessType(String processType) {
		this.processType = processType;
	}

	public String getFormId() {
		return formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getCasdId() {
		return casdId;
	}

	public void setCasdId(String casdId) {
		this.casdId = casdId;
	}

	public List<PolNum> getPolNums() {
		return polNums;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public void setPolNums(List<PolNum> polNums) {
		this.polNums = new ArrayList<PolNum>();
		for (PolNum pn : polNums) {
		  this.polNums.add(pn);
		}
	}

	@Override
	public String toString() {
		return "ImportPara [receivedDate=" + receivedDate + ", processType=" + processType + ", formId=" + formId
				+ ", uuid=" + uuid + ", casdId=" + casdId + ", docId=" + docId + ", fileName=" + fileName
				+ ", companyNo=" + companyNo + ", polNums=" + polNums + "]";
	}

}
