package com.aia.case360.web.dao;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.aia.case360.web.pojo.ConcurrentCaseDataVO;
import com.aia.case360.web.pojo.ConcurrentCaseRuleVO;
import com.aia.case360.web.pojo.PriorityRuleVO;

@Repository
public interface GetJobRuleDao {

	public List<PriorityRuleVO> queryPriorityRulesByDepartment(@Param("department")String department) throws RemoteException;
	
	public List<PriorityRuleVO> queryAllPriorityRulesByDepartment(@Param("department")String department) throws RemoteException;

	public Integer insertPriorityRule(List<PriorityRuleVO> rules) throws RemoteException;

	public Integer updatePriorityRule(List<PriorityRuleVO> rules) throws RemoteException;

	/**
	 * query concurrent case data
	 * 
	 * @param department
	 * @return
	 * @throws RemoteException
	 */
	public List<ConcurrentCaseDataVO> queryConcurrentDatasByDepartment(@Param("department")String department) throws RemoteException;

	/**
	 * query concurrent case rule
	 * 
	 * @param department
	 * @return
	 * @throws RemoteException
	 */
	public List<ConcurrentCaseRuleVO> queryConcurrentRulesByDepartment(@Param("department")String department) throws RemoteException;

	public Integer deleteRules(List<String> rules) throws RemoteException;

	public Integer insertConcurrentRule(ConcurrentCaseRuleVO ruleVO) throws RemoteException;

	public Integer insertConcurrentData(List<ConcurrentCaseDataVO> dataVOs) throws RemoteException;

	public Integer updateConcurrentRule(ConcurrentCaseRuleVO ruleVO) throws RemoteException;

	public Integer deleteConcurrentRule(Integer sRowId) throws RemoteException;

	public Integer deleteConcurrentData(Integer parentId) throws RemoteException;

	public List<ConcurrentCaseRuleVO> validateRuleName(@Param("department") String department,
			@Param("ruleName") String ruleName) throws RemoteException;

	public List<Map<String, Object>> queryPriorityDropDownList(@Param("configName") String configName) throws RemoteException;

	public List<Map<String, Object>> validateReqAct(@Param("reqActList") List<String> reqActList,
			@Param("department") String department) throws RemoteException;

	public void updateCaseToDoScoreCase() throws RemoteException;
	
	public List<Map<String, Object>> getDropDownList(@Param("list") List<String> list, @Param("company") String company) throws RemoteException;
}
