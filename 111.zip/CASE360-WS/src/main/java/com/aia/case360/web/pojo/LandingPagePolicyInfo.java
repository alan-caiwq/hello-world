package com.aia.case360.web.pojo;

public class LandingPagePolicyInfo {
	private String policyNo;
	private String contractNo;
	private String lifeAssuredName;
	private String lifeAssuredNumber;
	private String lifeAssuredNRIC;
	private String LAAttainedAge;
	private String LAGender;
	private String LANationality;
	private String FSCName;
	private String FSCNo;

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getContractNo() {
		return contractNo;
	}

	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	public String getLifeAssuredName() {
		return lifeAssuredName;
	}

	public void setLifeAssuredName(String lifeAssuredName) {
		this.lifeAssuredName = lifeAssuredName;
	}

	public String getLifeAssuredNumber() {
		return lifeAssuredNumber;
	}

	public void setLifeAssuredNumber(String lifeAssuredNumber) {
		this.lifeAssuredNumber = lifeAssuredNumber;
	}

	public String getLifeAssuredNRIC() {
		return lifeAssuredNRIC;
	}

	public void setLifeAssuredNRIC(String lifeAssuredNRIC) {
		this.lifeAssuredNRIC = lifeAssuredNRIC;
	}

	public String getLAAttainedAge() {
		return LAAttainedAge;
	}

	public void setLAAttainedAge(String lAAttainedAge) {
		if (lAAttainedAge == null || (lAAttainedAge.contains("99/99/9999") || lAAttainedAge.contains("/  /0"))) {
			this.LAAttainedAge = null;
		} else {
			this.LAAttainedAge = lAAttainedAge;
		}
	}

	public String getLAGender() {
		return LAGender;
	}

	public void setLAGender(String lAGender) {
		LAGender = lAGender;
	}

	public String getLANationality() {
		return LANationality;
	}

	public void setLANationality(String lANationality) {
		LANationality = lANationality;
	}

	public String getFSCName() {
		return FSCName;
	}

	public void setFSCName(String fSCName) {
		FSCName = fSCName;
	}

	public String getFSCNo() {
		return FSCNo;
	}

	public void setFSCNo(String fSCNo) {
		FSCNo = fSCNo;
	}
}
