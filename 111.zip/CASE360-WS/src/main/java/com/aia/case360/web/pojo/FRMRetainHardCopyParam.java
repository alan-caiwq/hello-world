package com.aia.case360.web.pojo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class FRMRetainHardCopyParam {
  @JsonProperty("POLICY_NOS")
  private List<FRMPolicyCompany> polNums;
  
  @JsonProperty("SG_COLLECTOR")
  private String collector;
  
  @JsonProperty("SG_COLLECTOR_OFFICE_CODE")
  private String officeCode;
  
  @JsonProperty("SG_COLLECTOR_OFFICE")
  private String office;
  
  @JsonProperty("COMMENTS")
  private String comments;
  
  @JsonProperty("ASSIGN_TO")
  private String assignTo;

  /**
   * @return the polNums
   */
  public List<FRMPolicyCompany> getPolNums() {
    return polNums;
  }

  /**
   * @return the collector
   */
  public String getCollector() {
    return collector;
  }

  /**
   * @return the officeCode
   */
  public String getOfficeCode() {
    return officeCode;
  }

  /**
   * @return the office
   */
  public String getOffice() {
    return office;
  }

  /**
   * @param polNums the polNums to set
   */
  public void setPolNums(List<FRMPolicyCompany> polNums) {
    this.polNums = polNums;
  }

  /**
   * @param collector the collector to set
   */
  public void setCollector(String collector) {
    this.collector = collector;
  }

  /**
   * @param officeCode the officeCode to set
   */
  public void setOfficeCode(String officeCode) {
    this.officeCode = officeCode;
  }

  /**
   * @param office the office to set
   */
  public void setOffice(String office) {
    this.office = office;
  }

  /**
   * @return the comments
   */
  public String getComments() {
    return comments;
  }

  /**
   * @param comments the comments to set
   */
  public void setComments(String comments) {
    this.comments = comments;
  }

  /**
   * @return the assignTo
   */
  public String getAssignTo() {
    return assignTo;
  }

  /**
   * @param assignTo the assignTo to set
   */
  public void setAssignTo(String assignTo) {
    this.assignTo = assignTo;
  }

  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "FRMRetainHardCopyParam [polNums=" + polNums + ", collector=" + collector
        + ", officeCode=" + officeCode + ", office=" + office + ", comments=" + comments
        + ", assignTo=" + assignTo + "]";
  }
 
}
