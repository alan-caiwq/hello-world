package com.aia.case360.web.pojo;

public class CampaignCodeInfo {

	private String policyNo;

	private String campaignCode;

	private String campaignCodeDesc;

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getCampaignCode() {
		return campaignCode;
	}

	public void setCampaignCode(String campaignCode) {
		this.campaignCode = campaignCode;
	}

	public String getCampaignCodeDesc() {
		return campaignCodeDesc;
	}

	public void setCampaignCodeDesc(String campaignCodeDesc) {
		this.campaignCodeDesc = campaignCodeDesc;
	}

}
