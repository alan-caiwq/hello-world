package com.aia.case360.web.pojo;

/**
 * 
 * @author bsnpc37(Leo Li)
 *
 */
public class DistrictInfo {

	private String fscChannel;
	private String districtCode;
	private String districtName;
	private String fscCode;
	private String fscChannelLevel2;
	private String fscChannelLevel3;

	public String getFscChannel() {
		return fscChannel;
	}

	public void setFscChannel(String fscChannel) {
		this.fscChannel = fscChannel;
	}

	public String getDistrictCode() {
		return districtCode;
	}

	public void setDistrictCode(String districtCode) {
		this.districtCode = districtCode;
	}

	public String getDistrictName() {
		return districtName;
	}

	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}

	public String getFscCode() {
		return fscCode;
	}

	public void setFscCode(String fscCode) {
		this.fscCode = fscCode;
	}

	public String getFscChannelLevel2() {
		return fscChannelLevel2;
	}

	public void setFscChannelLevel2(String fscChannelLevel2) {
		this.fscChannelLevel2 = fscChannelLevel2;
	}

	public String getFscChannelLevel3() {
		return fscChannelLevel3;
	}

	public void setFscChannelLevel3(String fscChannelLevel3) {
		this.fscChannelLevel3 = fscChannelLevel3;
	}

}
