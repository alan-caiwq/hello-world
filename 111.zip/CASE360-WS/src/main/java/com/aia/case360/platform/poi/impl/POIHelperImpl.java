package com.aia.case360.platform.poi.impl;

import org.apache.poi.ss.usermodel.Cell;
import org.springframework.stereotype.Component;

import com.aia.case360.platform.poi.POIHelper;

@Component
public class POIHelperImpl implements POIHelper {
	@Override
	public String getCellValue(Cell cell) {
		String cellValue = "";
		if (cell == null) {

			return "";
		}
		//
		if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
			cell.setCellType(Cell.CELL_TYPE_STRING);
		}
		//
		switch (cell.getCellType()) {
		case Cell.CELL_TYPE_NUMERIC: //
			cellValue = String.valueOf(cell.getNumericCellValue());
			break;
		case Cell.CELL_TYPE_STRING: //
			cellValue = String.valueOf(cell.getStringCellValue());
			break;
		case Cell.CELL_TYPE_BOOLEAN: //
			cellValue = String.valueOf(cell.getBooleanCellValue());
			break;
		case Cell.CELL_TYPE_FORMULA: //
			cellValue = String.valueOf(cell.getCellFormula());
			break;
		case Cell.CELL_TYPE_BLANK: //
			cellValue = "";
			break;
		case Cell.CELL_TYPE_ERROR: //
			cellValue = "error";
			break;

		default:
			cellValue = "unknow";
			break;
		}
		return cellValue;
		
	}
}
