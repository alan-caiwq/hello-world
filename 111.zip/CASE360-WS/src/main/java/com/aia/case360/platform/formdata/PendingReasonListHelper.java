package com.aia.case360.platform.formdata;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.aia.case360.web.vo.PendingParam;
import com.eistream.sonora.fields.FmsRow;
import com.eistream.sonora.fields.FmsRowNative;

public interface PendingReasonListHelper {

	/**
	 * Add one new pending reason for casefolder <br>
	 * Pending Reason table must be a relation table with pi_process table The
	 * relation is :<b>CasePendingHistory</b> <br>
	 * When create a new pending reason, API will create the new row based on
	 * pi_process <br>
	 * 
	 * @param parentRow pi_process row
	 * @param prDefines pendingReason definition row
	 * @param params    fields name/value pairs
	 * @return the operation result
	 * @throws RemoteException
	 * 
	 */
	public boolean addPendingReasonHistory(FmsRow parentRow, List<FmsRowNative> prDefines, Map<String, String> params)
			throws RemoteException;

	public boolean addPendingReasonHistory(FmsRow parentRow, List<PendingParam> params) throws RemoteException;

	public boolean addPendingReasonHistory(FmsRow parentRow, PendingParam params) throws RemoteException;

	/**
	 * Return pending reason definition rows based on the S_ROWID list
	 * 
	 * @param prIdsList
	 * @return
	 * @throws RemoteException
	 * @throws SQLException
	 */
	public List<FmsRowNative> getPendingReasonRow(List<BigDecimal> prIdsList) throws RemoteException, SQLException;

	/**
	 * Return pending reason history rows based on the S_ROWID
	 * 
	 * @param prIdsList
	 * @return
	 * @throws RemoteException
	 * @throws SQLException
	 */
	public List<FmsRowNative> getPendingReasonHistoryRows(List<BigDecimal> prIdsList)
			throws RemoteException, SQLException;

	/**
	 * Return one workitem's all pending reason history rows list
	 * 
	 * @param parentRow
	 * @return
	 * @throws RemoteException
	 */
	public List<FmsRow> getAllPendingReasonHistory(FmsRow parentRow) throws RemoteException;

	/**
	 * Update all pending reason history rows' received date as current time.
	 * 
	 * @param oldpendingReasons
	 * @param resolvePendingHistory
	 * @return
	 * @throws RemoteException
	 */
	public boolean updatePendingReasonHistory(List<FmsRowNative> oldpendingReasons,
			List<FmsRowNative> resolvePendingHistory) throws RemoteException;
}