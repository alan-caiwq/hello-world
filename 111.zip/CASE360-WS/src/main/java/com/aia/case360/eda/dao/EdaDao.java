package com.aia.case360.eda.dao;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.util.Map;

import com.eistream.sonora.webservices.WsSessionEJB;

public interface EdaDao {
	public boolean insertDocAttr(Map<String, Object> docAttr);

	public boolean updateDocAttributesAll(Map<String, Object> docAttr);

	public boolean updateDocFileStore(Map<String, Object> docFs);

	public boolean updateDocMigCtrl(String objectName, String objectId);

	public boolean selectC360DocAttr(String objectId);

	public Map<String, Object> selectE360DocAttr(String objectId);

	public BigDecimal saveToFileStore(WsSessionEJB wsEJB, String fileName, byte[] fileByte, String objectId)
			throws RemoteException;

	public boolean insertEdaReport(Map<String, Object> reportInfo);

	public boolean updateDocAttributes(String objectName, String objectId);

	public boolean updateDocAttr(String objectName, String objectId);

	public boolean updateDocLink(String objectId);

	public boolean updateXFileStore(String objectId);
	public boolean selectMigDemand(String objectId);	
	public boolean insertMigDemand(String objectId, String objectName);	
	public boolean updateMigDemand(String objectId);
}
