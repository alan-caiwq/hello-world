package com.aia.case360.web.pojo;

public class ReportDetail {

	private String sRowid;

	private String createdTimeStamp;

	private String lastUpdateTimeStamp;

	private int parentFdId;

	private String policyNo;

	private String status;

	private String comments;

	private String contractNo;

	private String creationCaseId;

	private String lineIndex;

	private String metaData;

	public String getsRowid() {
		return sRowid;
	}

	public void setsRowid(String sRowid) {
		this.sRowid = sRowid;
	}

	public String getCreatedTimeStamp() {
		return createdTimeStamp;
	}

	public void setCreatedTimeStamp(String createdTimeStamp) {
		this.createdTimeStamp = createdTimeStamp;
	}

	public String getLastUpdateTimeStamp() {
		return lastUpdateTimeStamp;
	}

	public void setLastUpdateTimeStamp(String lastUpdateTimeStamp) {
		this.lastUpdateTimeStamp = lastUpdateTimeStamp;
	}

	public int getParentFdId() {
		return parentFdId;
	}

	public void setParentFdId(int parentFdId) {
		this.parentFdId = parentFdId;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getContractNo() {
		return contractNo;
	}

	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	public String getCreationCaseId() {
		return creationCaseId;
	}

	public void setCreationCaseId(String creationCaseId) {
		this.creationCaseId = creationCaseId;
	}

	public String getLineIndex() {
		return lineIndex;
	}

	public void setLineIndex(String lineIndex) {
		this.lineIndex = lineIndex;
	}

	public String getMetaData() {
		return metaData;
	}

	public void setMetaData(String metaData) {
		this.metaData = metaData;
	}

}
