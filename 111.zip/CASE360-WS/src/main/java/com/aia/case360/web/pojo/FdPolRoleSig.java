package com.aia.case360.web.pojo;

import java.util.Date;

public class FdPolRoleSig {
	private Integer sRowId;
	private String polNum;
	private String polRole;
	private Date createdTimestamp;
	private String objectId;
	private String isDeleted;
	private String isViod;
	private String companyNo;

	public Integer getsRowId() {
		return sRowId;
	}

	public void setsRowId(Integer sRowId) {
		this.sRowId = sRowId;
	}

	public String getPolRole() {
		return polRole;
	}

	public void setPolRole(String polRole) {
		this.polRole = polRole;
	}

	public String getPolNum() {
		return polNum;
	}

	public void setPolNum(String polNum) {
		this.polNum = polNum;
	}

	public Date getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public String getObjectId() {
		return objectId;
	}

	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}

	public String getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(String isDeleted) {
		this.isDeleted = isDeleted;
	}

	public String getIsViod() {
		return isViod;
	}

	public void setIsViod(String isViod) {
		this.isViod = isViod;
	}

	public String getCompanyNo() {
		return companyNo;
	}

	public void setCompanyNo(String companyNo) {
		this.companyNo = companyNo;
	}

}
