package com.aia.case360.web.pojo;

public class FRMReqTypeInfo {

  private String reqType;
  private String category;
  private String department;
  private Integer disable;
  /**
   * @return the reqType
   */
  public String getReqType() {
    return reqType;
  }
  /**
   * @return the category
   */
  public String getCategory() {
    return category;
  }
  /**
   * @return the department
   */
  public String getDepartment() {
    return department;
  }
  /**
   * @return the disable
   */
  public Integer getDisable() {
    return disable;
  }
  /**
   * @param reqType the reqType to set
   */
  public void setReqType(String reqType) {
    this.reqType = reqType;
  }
  /**
   * @param category the category to set
   */
  public void setCategory(String category) {
    this.category = category;
  }
  /**
   * @param department the department to set
   */
  public void setDepartment(String department) {
    this.department = department;
  }
  /**
   * @param disable the disable to set
   */
  public void setDisable(Integer disable) {
    this.disable = disable;
  }
  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "FRMReqTypeInfo [reqType=" + reqType + ", category=" + category + ", department="
        + department + ", disable=" + disable + "]";
  }
  
}
