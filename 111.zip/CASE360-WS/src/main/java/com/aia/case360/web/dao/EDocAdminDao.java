package com.aia.case360.web.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.aia.case360.web.pojo.CustFormDef;
import com.aia.case360.web.pojo.FormDef;
import com.aia.case360.web.pojo.FormDefAuditTrail;
import com.aia.case360.web.pojo.FormLinkDef;
import com.aia.case360.web.pojo.FscFormDef;

@Repository
public interface EDocAdminDao {

	List<Map<String, Object>> findFSCCategoryList();

	List<Map<String, Object>> findCustCategoryList();

	List<FormDef> findFormDefList(FormDef formDef);

	List<FormDef> exportFormDefList(@Param("rowIds") List<Long> rowIds);

	List<Long> getFormDefIdList();

	List<Map<String, Object>> findAllEdocCategory();

	FormDef findFormDef(String formId);

	void addFormDef(FormDef formDef);

	void updateFormDef(FormDef formDef);

	void deleteFormDef(FormDef formDef);

	CustFormDef findCustFormDef(String formId);

	void addCustFormDef(CustFormDef custFormDef);

	void updateCustFormDef(CustFormDef custFormDef);

	void deleteCustFormDef(CustFormDef custFormDef);

	FscFormDef findFscFormDef(String formId);

	void addFscFormDef(FscFormDef fscFormDef);

//	
	void updateFscFormDef(FscFormDef fscFormDef);

	void deleteFscFormDef(FscFormDef fscFormDef);

	String exportForms();

	String getMainLinkFormId(String formId);

	/**
	 * added by cuixin remove condition "AND CONTRACT_FORM_TYPE != 'L'"
	 * 
	 * @param formId
	 * @return
	 */
	String getMainLinkFormIdByFormId(String formId);

	String getMainLinkFormIdById(String s_rowid);

	/**
	 * added by cuixin remove condition "AND CONTRACT_FORM_TYPE != 'L'"
	 * 
	 * @param s_rowid
	 * @return
	 */
	String getMainLinkFormIdByDocLinkId(String s_rowid);

	String generateLinkFormId(String formId);

	int getLinkFormIdCount(String linkFormId);

	int getPFHFormCount(Map<String, Object> params);

	void addFormCategory(@Param("category") String category, @Param("userId") String userId);

	int getMaxCustCatCode();

	void addCustCategory(@Param("category") String category, @Param("code") String code);

	List<Integer> verfyCount(FormDef formDef);

	CustFormDef searchCust(String formId);

	/*
	 * Yang,Loe add method to search form_id
	 */
	FscFormDef searchFsc(String formId);

	void deleteCustForm(String formId);

	void deleteFscForm(String formId);

	List<Map<String, String>> searchFormDef(Map<Object, Object> mapParam);

	void addFormLinkDef(FormLinkDef formLinkDef);

	void addFormDefAuditTrail(FormDefAuditTrail formDefAuditTrail);

	List<FormDefAuditTrail> queryAuditTrail(@Param(value = "formId") String formId);
}