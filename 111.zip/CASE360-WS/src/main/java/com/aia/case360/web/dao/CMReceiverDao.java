package com.aia.case360.web.dao;

import java.sql.SQLException;
import java.util.List;

import com.aia.case360.web.pojo.CMSearchReceiverParam;
import com.aia.case360.web.vo.CMSearchReceiverVo;

public interface CMReceiverDao {

  List<CMSearchReceiverVo> searchReceiver(CMSearchReceiverParam param) throws SQLException;
}
