package com.aia.case360.web.pojo;

/**
 * 
 * 
 * select convert( varchar(15),b.building ) as building , a.s_agency_code as
 * agencyCode, a.s_agency_name as agencyName, c.s_agent_name as agentName ,
 * c.s_agent_code as agentCode from agency a, aia_building b ,agent_particulars
 * c where a.es_agency_building_code = b.es_agency_building_code and status =
 * 'I' and c.s_agency_code = a.s_agency_code and c.s_agent_code = '80302'
 * 
 * 
 * @author SMIS008 (Srinivasan Mahendran)
 *
 */
public class AgentData {


	private String building;

	private String agencyCode;

	private String agencyName;

	private String agentName;

	private String agentCode;

	private String agencyChannel;

	private String locationCode;

	public String getBuilding() {
		return building;
	}

	public void setBuilding(String building) {
		this.building = building;
	}

	public String getAgencyCode() {
		return agencyCode;
	}

	public void setAgencyCode(String agencyCode) {
		this.agencyCode = agencyCode;
	}

	public String getAgencyName() {
		return agencyName;
	}

	public void setAgencyName(String agencyName) {
		this.agencyName = agencyName;
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public String getAgentCode() {
		return agentCode;
	}

	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}

	public String getAgencyChannel() {
		return agencyChannel;
	}

	public void setAgencyChannel(String agencyChannel) {
		this.agencyChannel = agencyChannel;
	}

	public String getLocationCode() {
		return locationCode;
	}

	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	@Override
	public String toString() {
		return "AgentData [building=" + building + ", agencyCode=" + agencyCode + ", agencyName=" + agencyName
				+ ", agentName=" + agentName + ", agentCode=" + agentCode + ", agencyChannel=" + agencyChannel
				+ ", locationCode=" + locationCode + "]";
	}
}
