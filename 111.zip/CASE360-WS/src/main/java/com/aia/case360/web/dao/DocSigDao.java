package com.aia.case360.web.dao;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.aia.case360.web.pojo.FdPolRoleSig;
import com.aia.case360.web.pojo.FdSigAuditTrail;
import com.aia.case360.web.pojo.FdSigComments;
import com.aia.case360.web.pojo.FdSigTab;
import com.aia.case360.web.pojo.FdSvsCustNotif;

@Repository
public interface DocSigDao {

	/**
	 * @param fdPolRoleSigList
	 */
	public void insertFdPolRoleSig(List<FdPolRoleSig> fdPolRoleSigList);

	public FdPolRoleSig findPolRoleSig(Map<String, String> map);

	public List<FdPolRoleSig> findPolRoleSigs(Map<String, String> map);

	/**
	 * @param sRowId
	 */
	public int deleteFdPolRoleSig(String sRowId);

	/**
	 * @param fdPolRoleSig
	 */
	public void insertOneFdPolRoleSig(FdPolRoleSig fdPolRoleSig);

	/**
	 * @param parentId
	 * @return
	 */
	public List<FdSigComments> queryFdSigComments(String parentId);

	/**
	 * @param fdSigComments
	 */
	public void insertFdSigComments(List<FdSigComments> fdSigComments);

	/**
	 * @param fdSigAuditTrail
	 */
	public void insertOneFdSigAuditTrail(FdSigAuditTrail fdSigAuditTrail);

	/**
	 * @param fdSigComments
	 */
	public void insertOneFdSigComments(FdSigComments fdSigComments);

	/**
	 * @param sRowId
	 * @return
	 */
	public FdSigComments queryFdSigCommentsBySRowId(String sRowId);

	/**
	 * @param sRowId
	 * @return
	 */
	public int deleteFdSigComments(String sRowId);

	/**
	 * @param fdPolRoleSig
	 * @return 0:FALSE ; 1:TRUE;
	 */
	public int isFdPolroleSigExist(FdPolRoleSig fdPolRoleSig);

	/**
	 * 
	 * @param fdPolRoleSig
	 * @return
	 */
	public int voidSig(String sRowId);

	/**
	 * 
	 * @param polNum
	 * @return
	 */
	public List<FdSigTab> findSigByPlicy(String polNum);

	public int updateSigFS(Map map);

	public List<Map<String, Object>> listSigAuditTrail(Map<String, String> param)  throws RemoteException;

	public void insertFdSvsCustNotifs(List<FdSvsCustNotif> svsCustNotifList);

	public void copyFdSigComments(@Param("queryFdSigComments") List<FdSigComments> queryFdSigComments,
			@Param("parentId") Integer parentId)  throws RemoteException;

	public List<String> getRowIdbyPolRoleStatus(FdSvsCustNotif fdSvsCustNotif);

	public int updateFdSvsCustNotifs(List<FdSvsCustNotif> svsCustNotifList4update);

	
    public List<FdSigTab> findUSigByPlicy(String polNum);

	public List<Map<String, Object>> getWStatusRecords();
	

}
