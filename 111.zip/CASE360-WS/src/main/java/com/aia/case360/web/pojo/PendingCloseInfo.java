package com.aia.case360.web.pojo;

public class PendingCloseInfo {

	String policyNo;

	String companyNo;

	String processCode;

	String followUpCode;

	String followUpCode_status;

	String createDate;

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getFollowUpCode() {
		return followUpCode;
	}

	public void setFollowUpCode(String followUpCode) {
		this.followUpCode = followUpCode;
	}

	public String getProcessCode() {
		return processCode;
	}

	public void setProcessCode(String processCode) {
		this.processCode = processCode;
	}

	public String getCompanyNo() {
		return companyNo;
	}

	public void setCompanyNo(String companyNo) {
		this.companyNo = companyNo;
	}

	public String getFollowUpCode_status() {
		return followUpCode_status;
	}

	public void setFollowUpCode_status(String followUpCode_status) {
		this.followUpCode_status = followUpCode_status;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

}
