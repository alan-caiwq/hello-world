package com.aia.case360.JalDocsInterfacesEx.manager;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aia.case360.JalDocsInterfacesEx.dao.JalDocDao;
import com.aia.case360.JalDocsInterfacesEx.util.StrUtil;
import com.aia.case360.JalDocsInterfacesEx.vo.InputParamVo;
import com.aia.case360.JalDocsInterfacesEx.vo.PolNumReqs;
import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.common.PropertyUtil;

@Service
public class JalLogicalLinkDocManager {

	private static final String LOGICAL_LINK_ID = "LogicalLinkId";

	private static final String LAST_UPDATE_DATE = "lastUpdateDate";

	private Logger m_Logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private JalDocDao jalDao;

	@Autowired
	private JalObjectDefManager jalObjectDefManager;

	@Autowired
	private JalDocManager jalDocManager;
	
	
	 /**
     * Create logical link
     * 
     * @ throws RemoteException
     */
    public List<Map> procLogicalLinks(InputParamVo params, String objectId) throws RemoteException {
  
    	List<Map> linkInfoList = new ArrayList<Map>();
    	Map linkInfoMap = null;
    	
    	 try {
    	    	final List<PolNumReqs> polNumReqs = params.getPolNumReqs();
    	    	if(polNumReqs!=null && !polNumReqs.isEmpty()){
    	    		
   	    			Map parFormFieldsMap = jalDocManager.getParFormFieldsMap();
    		        
	    		    if(checkIsNullMap(parFormFieldsMap)){
	    		       parFormFieldsMap = jalDocManager.getParentInfo(params);
	    		       jalDocManager.setParFormFieldsMap(parFormFieldsMap);
	    		    }
	    		    int isLogicalLink = -1;
	    		    BigDecimal sParentRowId = new BigDecimal(0);
	    		    String  sParentLastUpdatedTime = null;
	    		    if(checkIsNullMap(parFormFieldsMap)){
	    		    	isLogicalLink = 1; 
	    		    }else{
	    		    	sParentRowId = getParentRowId(parFormFieldsMap);
		    		    sParentLastUpdatedTime = StrUtil.nullToEmptyForObject(parFormFieldsMap.get(LAST_UPDATE_DATE));
		    		    isLogicalLink = setIsLogicalLink(polNumReqs); 
	    		    }
	    		    
    	    		if(isLogicalLink==1){
    	    			createLogicalLinks(params, objectId, linkInfoList, polNumReqs);
    	    		}else if(isLogicalLink==0){
    	    			linkInfoMap = new HashMap();
    	    			linkInfoMap.put("SRowId", sParentRowId);
    	    			linkInfoMap.put("ObjectId", objectId);
    	    			linkInfoMap.put(LOGICAL_LINK_ID, null); 
    	    			linkInfoMap.put(LAST_UPDATE_DATE,sParentLastUpdatedTime);
    	    		
    	    			linkInfoList.add(linkInfoMap);
    	    		}   	        	
    	    	}
         } catch (Exception e) {
			LogUtil.logError(m_Logger, e.toString());
         }
    	 
    	 return linkInfoList;
    	 
    }


	private int setIsLogicalLink(final List<PolNumReqs> polNumReqs) {
		int isLogicalLink=-1;
		if(polNumReqs.size()>1){
			isLogicalLink = 1; 
		}else if(polNumReqs.size()==1){
			isLogicalLink = 0;
		}
		return isLogicalLink;
	}


	private BigDecimal getParentRowId(Map parFormFieldsMap) {
		return parFormFieldsMap.get("sParentRowId")==null?new BigDecimal(0):(BigDecimal) parFormFieldsMap.get("sParentRowId");
	}


	private void createLogicalLinks(InputParamVo params, String objectId, List<Map> linkInfoList,
			final List<PolNumReqs> polNumReqs) {
		Map linkInfoMap;
		m_Logger.info(this.getClass().getName()
		        + " : createLogicalLinks docId=" + objectId);
		
		String parentId = objectId; 
		
		for(PolNumReqs pol: polNumReqs){ 
			linkInfoMap = new HashMap(); 
			String policyNo = StrUtil.nullToEmpty(pol.getPolNum());
			String logicalLinkId = StrUtil.nullToEmpty(pol.getLogicalLinkId());
			BigDecimal sRowId = pol.getsRowId();
			String lastUpdatedTime = StrUtil.nullToEmpty(pol.getLastUpdatedDate());
			
			// add by wanjun
			short isVoid= pol.getIsVoid();
			short isDeleted=pol.getIsDeleted();
			
			linkInfoMap.put("SRowId", sRowId);
			linkInfoMap.put("ObjectId", objectId);
			linkInfoMap.put(LAST_UPDATE_DATE,lastUpdatedTime);
			linkInfoList.add(linkInfoMap);  
			        	    			
			if(pol.getIsLogical() == 0){
				linkInfoMap.put(LOGICAL_LINK_ID, null);       	    				
				continue;
			}else{
				linkInfoMap.put(LOGICAL_LINK_ID, logicalLinkId);   
			}
			 
			processLogicalLink(params, pol, policyNo, logicalLinkId, isVoid, isDeleted);	
			 
		}
		m_Logger.info("Import: Created logical link for document " + parentId);
	}


	private boolean checkIsNullMap(Map parFormFieldsMap) {
		return parFormFieldsMap==null || parFormFieldsMap.isEmpty();
	}


	private void processLogicalLink(InputParamVo params, PolNumReqs pol, String policyNo, String logicalLinkId,
			short isVoid, short isDeleted) {
		try {
			String receivedDate = jalObjectDefManager
					.toCompressedJulianDate(StrUtil.nullToEmpty(pol.getReceivedDate()));
			m_Logger.info("procLogicalLinks receivedDate=" + receivedDate);
			String exStatus = "";
			if (isDeleted == 0) {
				if (isVoid == 1) {
					exStatus = "V";
				} else {
					exStatus = "N";
				}
			} else if (isDeleted == 1) {
				exStatus = "S";
			}
			Map<String, Object> existFlag = jalDao.checkE360LogicalLinkByLinkId(logicalLinkId);
			int num = existFlag.get("NUM") == null ? 0 : (int) (existFlag.get("NUM"));
			if (num > 0) {
				m_Logger.info("update fields in Ex360 tlogical_link table for logical link id: " + logicalLinkId);
				jalDao.updateEx360infoByLinkId(pol, receivedDate, exStatus);
			} else {
				m_Logger.info("insert data in Ex360 tlogical_link table for logical link id: " + logicalLinkId);
				jalDao.insertExLogicalLink(params, pol, receivedDate, exStatus);
			}

		} catch (Exception e) {
			m_Logger.info("Fail to reindex the policy: " + policyNo + "from Case360 to Ex360");
			LogUtil.logError(m_Logger, e.toString());
		}
	} 

}
