package com.aia.case360.ilClaim.service;

import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public interface RegisterService {

	public List<Map<String, String>> getClaimNo(Map<String, String> params)  throws SQLException;

}
