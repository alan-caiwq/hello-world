package com.aia.case360.web.pojo;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import com.aia.case360.web.common.CommonUtil;
import com.ibm.icu.util.CharsTrie.Iterator;

public class DocLinkParam {
  
  private Long sRowId;
  private String formId;
  private String objectId;
  private String receivedDt;
  private String orgRequestNo;
  private String requestNum;
  private String processType;
  private Long linkcaseid;
  private String claimNo;
  private Integer isMigrated;
  private Integer isDeleted;
  private Integer isVoid;
  private Integer isLogical;
  private String logicalLinkId;
  private String c360LogicalLinkId;
  private String companyNo;
  private String polNum;
  private Map<String, String> docFrom;

  public DocLinkParam getClone() {
    DocLinkParam docLinkParamNew = new DocLinkParam();
    docLinkParamNew.setC360LogicalLinkId(c360LogicalLinkId);
    docLinkParamNew.setClaimNo(claimNo);
    docLinkParamNew.setCompanyNo(companyNo);
    docLinkParamNew.setFormId(formId);
    docLinkParamNew.setIsDeleted(isDeleted);
    docLinkParamNew.setIsLogical(isLogical);
    docLinkParamNew.setIsMigrated(isMigrated);
    docLinkParamNew.setIsVoid(isVoid);
    docLinkParamNew.setLinkcaseid(linkcaseid);
    docLinkParamNew.setObjectId(objectId);
    docLinkParamNew.setOrgRequestNo(orgRequestNo);
    docLinkParamNew.setPolNum(polNum);
    docLinkParamNew.setProcessType(processType);
    docLinkParamNew.setReceivedDt(receivedDt);
    docLinkParamNew.setRequestNum(requestNum);
    docLinkParamNew.setLogicalLinkId(logicalLinkId);
    if(docFrom == null) {
      docFrom = new HashMap<String, String>();
    }
    java.util.Iterator<String> keyIterator = docFrom.keySet().iterator();
    Map<String, String> newDocFrom = new HashMap<String, String>();
    String key = "";
    while(keyIterator.hasNext()) {
      key = keyIterator.next();
      newDocFrom.put(key, docFrom.get(key));
    }
    docLinkParamNew.setDocFrom(newDocFrom);
    
    return docLinkParamNew;
  }

  

  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "DocLinkParam [sRowId=" + sRowId + ", formId=" + formId + ", objectId=" + objectId
        + ", receivedDt=" + receivedDt + ", orgRequestNo=" + orgRequestNo + ", requestNum="
        + requestNum + ", processType=" + processType + ", linkcaseid=" + linkcaseid + ", claimNo="
        + claimNo + ", isMigrated=" + isMigrated + ", isDeleted=" + isDeleted + ", isVoid="
        + isVoid + ", isLogical=" + isLogical + ", logicalLinkId=" + logicalLinkId
        + ", c360LogicalLinkId=" + c360LogicalLinkId + ", companyNo=" + companyNo + ", polNum="
        + polNum + ", docFrom=" + docFrom + "]";
  }



  /**
   * @return the sRowId
   */
  public Long getsRowId() {
    return sRowId==null?0:sRowId;
  }

  /**
   * @param sRowId the sRowId to set
   */
  public void setsRowId(Long sRowId) {
    this.sRowId = sRowId;
  }

  /**
   * @return the docFrom
   */
  public Map<String, String> getDocFrom() {
    return docFrom;
  }
  /**
   * @param docFrom the docFrom to set
   */
  public void setDocFrom(Map<String, String> docFrom) {
    this.docFrom = docFrom;
  }
  /**
   * @return the formId
   */
  public String getFormId() {
    return CommonUtil.getString(formId);
  }
  /**
   * @return the objectId
   */
  public String getObjectId() {
    return CommonUtil.getString(objectId);
  }
  /**
   * @return the receivedDt
   */
  public String getReceivedDt() {
    return CommonUtil.getString(receivedDt);
  }
  /**
   * @return the orgRequestNo
   */
  public String getOrgRequestNo() {
    return CommonUtil.getString(orgRequestNo);
  }
  /**
   * @return the requestNum
   */
  public String getRequestNum() {
    return CommonUtil.getString(requestNum);
  }
  /**
   * @return the processType
   */
  public String getProcessType() {
    return CommonUtil.getString(processType);
  }
  /**
   * @return the linkcaseid
   */
  public Long getLinkcaseid() {
    return linkcaseid;
  }
  /**
   * @return the claimNo
   */
  public String getClaimNo() {
    return CommonUtil.getString(claimNo);
  }
  /**
   * @return the isMigrated
   */
  public Integer getIsMigrated() {
    return isMigrated;
  }
  /**
   * @return the isDeleted
   */
  public Integer getIsDeleted() {
    return isDeleted;
  }
  /**
   * @return the isVoid
   */
  public Integer getIsVoid() {
    return isVoid;
  }
  /**
   * @return the isLogical
   */
  public Integer getIsLogical() {
    return isLogical;
  }
  /**
   * @return the logicalLinkId
   */
  public String getLogicalLinkId() {
    return CommonUtil.getString(logicalLinkId);
  }
  /**
   * @return the c360LogicalLinkId
   */
  public String getC360LogicalLinkId() {
    return CommonUtil.getString(c360LogicalLinkId);
  }
  /**
   * @return the companyNo
   */
  public String getCompanyNo() {
    return CommonUtil.getString(companyNo, "011");
  }
  /**
   * @return the polNum
   */
  public String getPolNum() {
    return CommonUtil.getString(polNum);
  }
  /**
   * @param formId the formId to set
   */
  public void setFormId(String formId) {
    this.formId = formId;
  }
  /**
   * @param objectId the objectId to set
   */
  public void setObjectId(String objectId) {
    this.objectId = objectId;
  }
  /**
   * @param receivedDt the receivedDt to set
   */
  public void setReceivedDt(String receivedDt) {
    this.receivedDt = receivedDt;
  }
  /**
   * @param orgRequestNo the orgRequestNo to set
   */
  public void setOrgRequestNo(String orgRequestNo) {
    this.orgRequestNo = orgRequestNo;
  }
  /**
   * @param requestNum the requestNum to set
   */
  public void setRequestNum(String requestNum) {
    this.requestNum = requestNum;
  }
  /**
   * @param processType the processType to set
   */
  public void setProcessType(String processType) {
    this.processType = processType;
  }
  /**
   * @param linkcaseid the linkcaseid to set
   */
  public void setLinkcaseid(Long linkcaseid) {
    this.linkcaseid = linkcaseid;
  }
  /**
   * @param claimNo the claimNo to set
   */
  public void setClaimNo(String claimNo) {
    this.claimNo = claimNo;
  }
  /**
   * @param isMigrated the isMigrated to set
   */
  public void setIsMigrated(Integer isMigrated) {
    this.isMigrated = isMigrated;
  }
  /**
   * @param isDeleted the isDeleted to set
   */
  public void setIsDeleted(Integer isDeleted) {
    this.isDeleted = isDeleted;
  }
  /**
   * @param isVoid the isVoid to set
   */
  public void setIsVoid(Integer isVoid) {
    this.isVoid = isVoid;
  }
  /**
   * @param isLogical the isLogical to set
   */
  public void setIsLogical(Integer isLogical) {
    this.isLogical = isLogical;
  }
  /**
   * @param logicalLinkId the logicalLinkId to set
   */
  public void setLogicalLinkId(String logicalLinkId) {
    this.logicalLinkId = logicalLinkId;
  }
  /**
   * @param c360LogicalLinkId the c360LogicalLinkId to set
   */
  public void setC360LogicalLinkId(String c360LogicalLinkId) {
    this.c360LogicalLinkId = c360LogicalLinkId;
  }
  /**
   * @param companyNo the companyNo to set
   */
  public void setCompanyNo(String companyNo) {
    this.companyNo = companyNo;
  }
  /**
   * @param polNum the polNum to set
   */
  public void setPolNum(String polNum) {
    this.polNum = polNum;
  }
  /* (non-Javadoc)
   * @see java.lang.Object#hashCode()
   */
  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + (StringUtils.isBlank(claimNo) ? 0 : claimNo.hashCode());
    result = prime * result + (StringUtils.isBlank(companyNo) ? 0 : companyNo.hashCode());
    result = prime * result + (StringUtils.isBlank(formId) ? 0 : formId.hashCode());
    result = prime * result + ((isDeleted == null) ? 0 : isDeleted.hashCode());
    result = prime * result + ((isLogical == null) ? 0 : isLogical.hashCode());
    result = prime * result + ((isMigrated == null) ? 0 : isMigrated.hashCode());
    result = prime * result + ((isVoid == null) ? 0 : isVoid.hashCode());
    result = prime * result + ((linkcaseid == null) ? 0 : linkcaseid.hashCode());
    result = prime * result + (StringUtils.isBlank(objectId) ? 0 : objectId.hashCode());
    result = prime * result + (StringUtils.isBlank(orgRequestNo) ? 0 : orgRequestNo.hashCode());
    result = prime * result + (StringUtils.isBlank(polNum) ? 0 : polNum.hashCode());
    result = prime * result + (StringUtils.isBlank(processType) ? 0 : processType.hashCode());
    result = prime * result + (StringUtils.isBlank(receivedDt) ? 0 : receivedDt.hashCode());
    result = prime * result + (StringUtils.isBlank(requestNum) ? 0 : requestNum.hashCode());
    return result;
  }
  /* (non-Javadoc)
   * @see java.lang.Object#equals(java.lang.Object)
   */
  @Override
  public boolean equals(Object obj) {
    if (this == obj) return true;
    if (obj == null) return false;
    if (getClass() != obj.getClass()) return false;
    DocLinkParam other = (DocLinkParam) obj;
    if (StringUtils.isBlank(claimNo)) {
      if (StringUtils.isNotBlank(other.claimNo)) return false;
    } else if (!claimNo.equals(other.claimNo)) return false;
    if (StringUtils.isBlank(companyNo)) {
      if (StringUtils.isNotBlank(other.companyNo)) return false;
    } else if (!companyNo.equals(other.companyNo)) return false;
    if (StringUtils.isBlank(formId)) {
      if (StringUtils.isNotBlank(other.formId)) return false;
    } else if (!formId.equals(other.formId)) return false;
    if (isDeleted == null) {
      if (other.isDeleted != null) return false;
    } else if (!isDeleted.equals(other.isDeleted)) return false;
    if (isLogical == null) {
      if (other.isLogical != null) return false;
    } else if (!isLogical.equals(other.isLogical)) return false;
    if (isMigrated == null) {
      if (other.isMigrated != null) return false;
    } else if (!isMigrated.equals(other.isMigrated)) return false;
    if (isVoid == null) {
      if (other.isVoid != null) return false;
    } else if (!isVoid.equals(other.isVoid)) return false;
    if (linkcaseid == null) {
      if (other.linkcaseid != null) return false;
    } else if (!linkcaseid.equals(other.linkcaseid)) return false;
    if (StringUtils.isBlank(objectId)) {
      if (StringUtils.isNotBlank(other.objectId)) return false;
    } else if (!objectId.equals(other.objectId)) return false;
    if (StringUtils.isBlank(orgRequestNo)) {
      if (StringUtils.isNotBlank(other.orgRequestNo)) return false;
    } else if (!orgRequestNo.equals(other.orgRequestNo)) return false;
    if (StringUtils.isBlank(polNum)) {
      if (StringUtils.isNotBlank(other.polNum)) return false;
    } else if (!polNum.equals(other.polNum)) return false;
    if (StringUtils.isBlank(processType)) {
      if (StringUtils.isNotBlank(other.processType)) return false;
    } else if (!processType.equals(other.processType)) return false;
    if (StringUtils.isBlank(receivedDt)) {
      if (StringUtils.isNotBlank(other.receivedDt)) return false;
    } else if (!receivedDt.equals(other.receivedDt)) return false;
    if (StringUtils.isBlank(requestNum)) {
      if (StringUtils.isNotBlank(other.requestNum)) return false;
    } else if (!requestNum.equals(other.requestNum)) return false;
    return true;
  }
  
  public static void main(String[] args) throws CloneNotSupportedException {
    Set<DocLinkParam> linkSet = new HashSet<>();
    DocLinkParam param = new DocLinkParam();
//    param.setFormId("1");
//    linkSet.add(param);
//    
//    param = new DocLinkParam();
//    param.setFormId("1");
//    param.setClaimNo("1");
//    linkSet.add(param);
//    
//    param = new DocLinkParam();
//    param.setFormId("0");
//    param.setClaimNo("1");
//    linkSet.add(param);
//    
//    param = new DocLinkParam();
//    param.setFormId("0");
//    linkSet.add(param);
//    
//    param = new DocLinkParam();
//    param.setFormId("0");
//    param.setClaimNo("1");
//    linkSet.add(param);
//    
//    param = new DocLinkParam();
//    param.setFormId("0");
//    linkSet.add(param);
//    
//    param = new DocLinkParam();
//    param.setFormId("0");
//    param.setClaimNo("1");
//    param.setLogicalLinkId("1");
//    linkSet.add(param);
    
    param = new DocLinkParam();
    param.setFormId("0");
    param.setLogicalLinkId("1");
    Map<String,String> map = new HashMap<String,String>();
    map.put("1", "1");
    param.setDocFrom(map);
    linkSet.add(param);
    
    param = (DocLinkParam)param.clone();
    param.setFormId("1");
    param.setLogicalLinkId("1");
    param.getDocFrom().put("2", "2");
    linkSet.add(param);
    
    System.out.println(linkSet.size());
    System.out.println(linkSet);
  }

}
