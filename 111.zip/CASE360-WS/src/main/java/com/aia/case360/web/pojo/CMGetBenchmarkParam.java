package com.aia.case360.web.pojo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CMGetBenchmarkParam {

  @JsonProperty("COMPANY_NO")
  private String companyNo;
  
  @JsonProperty("DEPARTMENT")
  private String department;
  
  @JsonProperty("BENCHMARK_NAME")
  private String benchmarkName;
  
  @JsonProperty("STATUS")
  private Integer cmStatus;
  
  @JsonProperty("REQ_TYPE")
  private String reqType;
  
  @JsonProperty("FORM_ID")
  private String formId;
  
  /**
   * 0:request type;1:form id
   */
  private Integer cmType;

  /**
   * @return the companyNo
   */
  public String getCompanyNo() {
    return companyNo;
  }

  /**
   * @return the department
   */
  public String getDepartment() {
    return department;
  }

  /**
   * @return the benchmarkName
   */
  public String getBenchmarkName() {
    return benchmarkName;
  }

  /**
   * @return the cmStatus
   */
  public Integer getCmStatus() {
    return cmStatus;
  }

  /**
   * @return the cmType
   */
  public Integer getCmType() {
    return cmType==null?0:cmType;
  }

  /**
   * @param companyNo the companyNo to set
   */
  public void setCompanyNo(String companyNo) {
    this.companyNo = companyNo;
  }

  /**
   * @param department the department to set
   */
  public void setDepartment(String department) {
    this.department = department;
  }

  /**
   * @param benchmarkName the benchmarkName to set
   */
  public void setBenchmarkName(String benchmarkName) {
    this.benchmarkName = benchmarkName;
  }

  /**
   * @param cmStatus the cmStatus to set
   */
  public void setCmStatus(Integer cmStatus) {
    this.cmStatus = cmStatus;
  }

  /**
   * @param cmType the cmType to set
   */
  public void setCmType(Integer cmType) {
    this.cmType = cmType;
  }

  /**
   * @return the reqType
   */
  public String getReqType() {
    return reqType;
  }

  /**
   * @param reqType the reqType to set
   */
  public void setReqType(String reqType) {
    this.reqType = reqType;
  }

  /**
   * @return the formId
   */
  public String getFormId() {
    return formId;
  }

  /**
   * @param formId the formId to set
   */
  public void setFormId(String formId) {
    this.formId = formId;
  }

  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "CMGetBenchmarkParam [companyNo=" + companyNo + ", department=" + department
        + ", benchmarkName=" + benchmarkName + ", cmStatus=" + cmStatus + ", reqType=" + reqType
        + ", formId=" + formId + ", cmType=" + cmType + "]";
  }
}
