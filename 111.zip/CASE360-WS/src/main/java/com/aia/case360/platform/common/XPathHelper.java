package com.aia.case360.platform.common;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.namespace.NamespaceContext;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;

/**
 * A helper class to deal with XPath, namespaces and prefixes
 * 
 * @author hophvwk
 * 
 */
public class XPathHelper {

	// Namespace aware context
	/**
	 * @uml.property name="nsCtx"
	 * @uml.associationEnd multiplicity="(1 1)"
	 */
	private NamespaceContext nsCtx = new NamespaceContext() {
		public String getNamespaceURI(String prefix) {
			return nsMap.get(prefix);
		}

		@SuppressWarnings("rawtypes")
		public Iterator getPrefixes(String val) {
			return nsMap.keySet().iterator();
		}

		public String getPrefix(String uri) {
			for (Entry<String, String> k : nsMap.entrySet()) {
				if (nsMap.get(k.getKey()).equals(uri))
					return k.getKey();
			}
			return null;
		}
	};

	// Variables
	/**
	 * @uml.property name="nsMap"
	 * @uml.associationEnd qualifier="constant:java.lang.String java.lang.String"
	 */
	private Map<String, String> nsMap = new HashMap<String, String>();
	/**
	 * @uml.property name="xpath"
	 * @uml.associationEnd multiplicity="(1 1)"
	 */
	private XPath xpath = null;

	/**
	 * Default constructor
	 */
	public XPathHelper() {
		nsMap.put("cs", "http://www.aia.com/china/service/casesearch/1");
		nsMap.put("ac", "http://ACORD.org/Standards/Life/2");

		xpath = XPathFactory.newInstance().newXPath();
		xpath.setNamespaceContext(nsCtx);
	}

	/**
	 * Register all namespaces from a document
	 * 
	 * @param doc
	 */
	public void registerNamespaces(String prefix, String namespace) {
		nsMap.put(prefix, namespace);
	}

	/**
	 * Return the prepped XPath object
	 * 
	 * @return
	 */
	public XPath getXPath() {
		return xpath;
	}
}
