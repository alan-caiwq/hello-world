package com.aia.case360.web.advice;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@Configuration
@EnableAspectJAutoProxy
public class LogAdviceConfig {

	@Bean
	public LogAdvice logAdvice() {
		return new LogAdvice();
	}
}
