package com.aia.case360.JalDocsInterfacesEx.manager;

import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aia.case360.JalDocsInterfacesEx.util.ImportXmlUtil;
import com.aia.case360.JalDocsInterfacesEx.util.StrUtil;
import com.aia.case360.JalDocsInterfacesEx.vo.InputParamVo;
import com.aia.case360.JalDocsInterfacesEx.vo.ObjectDefVo;
import com.aia.case360.JalDocsInterfacesEx.vo.ObjectFieldDefVo;
import com.aia.case360.platform.common.LogUtil;
import com.eistream.jal.JalException;
import com.eistream.jal.JalFormField;
import com.eistream.jal.JalFormFields;

@Service
public class JalFormFieldsManager {

	private Logger m_Logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private JalObjectDefManager jalObjectDefManager;

	@Autowired
	private JalDocManager jalDocManager;

	/**
	 * 
	 * @param jalFormFields
	 * @param objClass
	 * @param params
	 * @param workitemType
	 * @ throws RemoteException
	 */
	protected void setJalFormFieldSet(JalFormFields jalFormFields, String objClass, InputParamVo params,
			String workitemType) throws JalException, RemoteException {

		try {
			LogUtil.logInfo(m_Logger, getClass().getSimpleName() + " : jalFormFields count=" + jalFormFields.getCount());

			for (int i = 1; i <= jalFormFields.getCount(); i++) {
				JalFormField jalFormField = jalFormFields.getItem(i);

				LogUtil.logInfo(m_Logger,
						 getClass().getSimpleName() + " : jalFormField name=" + jalFormField.getInfo().getName());

				// Get the object name
				ObjectFieldDefVo objectFieldVo = getObjectField(jalFormField, workitemType, params);

				if (objectFieldVo != null) {

					String xmlFieldName = StrUtil.nullToEmpty(objectFieldVo.getObjectFieldName());

					if (!xmlFieldName.isEmpty()) {

						setFormField(jalFormField, params, xmlFieldName, objectFieldVo);

						validateFormField(jalFormField, objClass, objectFieldVo);
					}
				}

			}
		} catch (JalException e) {
			 LogUtil.logException(m_Logger, objClass, e);
		} catch (Exception e) {
			LogUtil.logException(m_Logger, objClass, e);
		}
	}

	/**
	 * Set the form field value of the object
	 * 
	 * @param jalFormField
	 * @param objClass
	 * @param releaseWorkitemList
	 * @param xmlFieldName
	 * @param objFieldVo
	 * @ throws RemoteException
	 */
	protected void setFormField(JalFormField jalFormField, InputParamVo params, String xmlFieldName,
			ObjectFieldDefVo objFieldVo) throws JalException, RemoteException {

		try {

			String fieldVal;
			if (jalFormField.getInfo().getName().equalsIgnoreCase("PolicyNo")
					|| xmlFieldName.equalsIgnoreCase("Policy_No")) {
				fieldVal = StrUtil.nullToEmptyWithoutTrim(getFieldVal(params, xmlFieldName, objFieldVo));
			} else {
				fieldVal = StrUtil.nullToEmpty(getFieldVal(params, xmlFieldName, objFieldVo));
			}

			if (!fieldVal.isEmpty()) {

				jalFormField.setValue(fieldVal);

				LogUtil.logInfo(m_Logger,
						 getClass().getSimpleName() + " : Set Form Field Value: " + jalFormField.getInfo().getName()
								+ "=" + jalFormField.getValue() + " from XML field '" + xmlFieldName + "'.");
			}
		} catch (JalException e) {
			LogUtil.logException(m_Logger, xmlFieldName, e);
		} catch (Exception e) {
			LogUtil.logException(m_Logger, xmlFieldName, e);
		}
	}

	/**
	 * Get the object field value
	 * 
	 * @param jalFormField
	 * @param objectClass
	 * @param workItemType
	 * @return
	 * @ throws RemoteException
	 */
	protected ObjectFieldDefVo getObjectField(JalFormField jalFormField, String workItemType, InputParamVo params)
			throws JalException, RemoteException {

		ObjectFieldDefVo objectFieldVo = null;

		try {

			ObjectDefVo objectVo = getDefaultObj(workItemType, params);

			objectFieldVo = (ObjectFieldDefVo) objectVo.getObjectFieldDefMap().get(jalFormField.getInfo().getName());

			if (objectFieldVo != null) {
				String xmlFieldName = StrUtil.nullToEmpty(objectFieldVo.getObjectFieldName());

				if (xmlFieldName.isEmpty()) {

					LogUtil.logInfo(m_Logger, getClass().getSimpleName()
							+ " : the object xml field name is empty - field name=" + jalFormField.getInfo().getName());

					// if the defined object does not define the xml field, get
					// the object with default object type
					objectVo = getDefaultObj(workItemType, params);

					objectFieldVo = (ObjectFieldDefVo) objectVo.getObjectFieldDefMap()
							.get(jalFormField.getInfo().getName());
				}
			}
		} catch (JalException e) {
			LogUtil.logException(m_Logger, workItemType, e);
		} catch (Exception e) {
			LogUtil.logException(m_Logger, workItemType, e);
		}
		return objectFieldVo;
	}

	/**
	 * Get the default object definition (object type = workitem type ["FLD_",
	 * "DOC_"] + process type)
	 * 
	 * @param jalFormField
	 * @param workItemType
	 * @return
	 * @ throws RemoteException
	 */
	protected ObjectDefVo getDefaultObj(String workItemType, InputParamVo params) throws RemoteException {

		String procType = getProcType(params);

		LogUtil.logInfo(m_Logger, getClass().getSimpleName() + " : Get default obj with obj class=" + workItemType + procType);

		// if no object name defined, get the default object name
		ObjectDefVo objDefVo = (ObjectDefVo) jalObjectDefManager.getObjectDefMap().get(workItemType + procType);

		return objDefVo;
	}

	/**
	 * Get the xml field value from the xml and do conversion
	 * 
	 * @param objClass
	 * @param params
	 * @param xmlFieldName
	 * @param objFieldVo
	 * @return
	 * @ throws RemoteException
	 */
	protected String getFieldVal(InputParamVo params, String xmlFieldName, ObjectFieldDefVo objFieldVo)
			throws RemoteException {

		String fieldVal = getFieldValBeforeConversion(params, xmlFieldName);
		String updatedFieldVal = getFieldValAfterConversion(xmlFieldName, objFieldVo, fieldVal);
		LogUtil.logInfo(m_Logger, getClass().getSimpleName() + " : Convert XML field '" + xmlFieldName + "' from value '"
				+ fieldVal + "' to '" + updatedFieldVal + "'.");

		return updatedFieldVal;
	}

	/**
	 * Get the xml field value from the xml
	 * 
	 * @param params
	 * @param xmlFieldName
	 * @return
	 * @ throws RemoteException
	 */
	protected String getFieldValBeforeConversion(InputParamVo params, String xmlFieldName) throws RemoteException {

		Map<?, ?> parFormFieldsMap = jalDocManager.getParFormFieldsMap();

		getParFormFldMap(params, parFormFieldsMap);

		String fieldVal = "";
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		String scanDate = df.format(new Date());// need confirm
		String sourceSystemCode = "C360"; // need confirm

		String policyNo = (String) parFormFieldsMap.get("policyNo");
		String companyNo = (String) parFormFieldsMap.get("companyNo");
		String requestNo = (String) parFormFieldsMap.get("requestNo");
		String batchNo = (String) parFormFieldsMap.get("caseObjectId");
		String formId = (String) parFormFieldsMap.get("formId");
		String processType = (String) parFormFieldsMap.get("processType");
		String receivedDate = (String) parFormFieldsMap.get("receivedDate");
		// confirm
		String statusIndicator = (String) parFormFieldsMap.get("statusIndicator");
		String linkIndicator = (String) parFormFieldsMap.get("linkIndicator");
		String pageIndicator = (String) parFormFieldsMap.get("pageIndicator");

		if (xmlFieldName.equalsIgnoreCase("PolicyNo") || xmlFieldName.equalsIgnoreCase("OrgPolicyNo")) {
			fieldVal = StrUtil.nullToEmpty(policyNo);
		} else if (xmlFieldName.equalsIgnoreCase("CompanyNo") || xmlFieldName.equalsIgnoreCase("OrgCompanyNo")) {
			fieldVal = StrUtil.nullToEmpty(companyNo);
		} else if (xmlFieldName.equalsIgnoreCase("RequestNo")) {
			fieldVal = StrUtil.nullToEmpty(requestNo);
		} else if (xmlFieldName.equalsIgnoreCase("BatchNo")) {
			fieldVal = StrUtil.nullToEmpty(batchNo);
		} else if (xmlFieldName.equalsIgnoreCase("FormId")) {
			fieldVal = StrUtil.nullToEmpty(formId);
		} else if (xmlFieldName.equalsIgnoreCase("ProcessType")) {
			fieldVal = StrUtil.nullToEmpty(processType);
		} else if (xmlFieldName.equalsIgnoreCase("SourceSystemCode")) {
			fieldVal = StrUtil.nullToEmpty(sourceSystemCode);
		} else if (xmlFieldName.equalsIgnoreCase("ScanDate")) {
			fieldVal = StrUtil.nullToEmpty(scanDate);
		} else if (xmlFieldName.equalsIgnoreCase("ReceivedDate")) {
			fieldVal = StrUtil.nullToEmpty(receivedDate);
		} else if (xmlFieldName.equalsIgnoreCase("StatusIndicator")) {
			fieldVal = StrUtil.nullToEmpty(statusIndicator);
		} else if (xmlFieldName.equalsIgnoreCase("LinkIndicator")) {
			fieldVal = StrUtil.nullToEmpty(linkIndicator);
		} else if (xmlFieldName.equalsIgnoreCase("PageIndicator")) {
			fieldVal = StrUtil.nullToEmpty(pageIndicator);
		}

		return fieldVal;
	}

	private void getParFormFldMap(InputParamVo params, Map<?, ?> parFormFieldsMap) throws RemoteException {
		if (parFormFieldsMap == null || parFormFieldsMap.isEmpty()) {
			parFormFieldsMap = jalDocManager.getParentInfo(params);
			jalDocManager.setParFormFieldsMap(parFormFieldsMap);
		}
	}

	/**
	 * Get the field value from the workitem map according to the xml field name
	 * Convert the field value with the conversion specified in the objectName.xml
	 * 
	 * @param xmlFieldName
	 * @param objFieldVo
	 * @param fieldVal
	 * @return
	 * @ throws RemoteException
	 */
	protected String getFieldValAfterConversion(String xmlFieldName, ObjectFieldDefVo objectFieldVo, String fieldVal)
			throws RemoteException {

		String updatedFieldVal = "";

		String conversion = objectFieldVo.getConversion();

		updatedFieldVal = jalObjectDefManager.getXmlValAfterConversion(conversion, xmlFieldName, fieldVal);

		return updatedFieldVal;
	}

	/**
	 * Validate the form field in the workitem
	 * 
	 * @param jalFormField
	 * @param objClass
	 * @param objFieldVo
	 * @ throws RemoteException
	 */
	protected void validateFormField(JalFormField jalFormField, String objClass, ObjectFieldDefVo objFieldVo)
			throws JalException, RemoteException {

		try {
			String strRequire = objFieldVo.getRequired();

			boolean bRequire = ImportXmlUtil.decodeRequire(strRequire);

			if (bRequire && (jalFormField.getValue() == null || jalFormField.getValue().trim().isEmpty())) {

				// Check if the field is compulsory (when the value
				// is blank)

				LogUtil.logInfo(m_Logger, getClass().getSimpleName() + " : Compulsory field [" + objClass + "."
						+ jalFormField.getInfo().getName() + "] is blank!");

				throw new RemoteException( getClass().getName() + " : Compulsory field [" + objClass + "."
						+ jalFormField.getInfo().getName() + "] is blank!");
			}

		} catch (JalException e) {
			LogUtil.logException(m_Logger, objClass, e);
		} catch (Exception e) {
			LogUtil.logException(m_Logger, objClass, e);
		}
	}

	/**
	 * Retrieve the process type of the batch
	 * 
	 * @return procType
	 * @ throws RemoteException
	 */
	protected String getProcType(InputParamVo params) throws RemoteException {

		String procType = null;

		Map parFormFieldsMap = jalDocManager.getParFormFieldsMap();

		if (parFormFieldsMap == null || parFormFieldsMap.isEmpty()) {
			parFormFieldsMap = jalDocManager.getParentInfo(params);
			jalDocManager.setParFormFieldsMap(parFormFieldsMap);
		}

		procType = StrUtil.nullToEmpty((String) (parFormFieldsMap.get("processType")));

		return procType;
	}

}
