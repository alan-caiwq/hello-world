package com.aia.case360.platform.formdata.impl;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.ejb.CreateException;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.aia.case360.platform.caches.Impl.FieldCache;
import com.aia.case360.platform.common.DateUtil;
import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.dao.TableIdBean;
import com.aia.case360.platform.formdata.DataTableHelper;
import com.aia.case360.platform.query.QueryHelper;
import com.aia.case360.web.service.impl.AbstractHelperImpl;
import com.eistream.sonora.exceptions.SonoraException;
import com.eistream.sonora.fields.FmsColumnDefinition;
import com.eistream.sonora.fields.FmsRow;
import com.eistream.sonora.fields.FmsRowChange;
import com.eistream.sonora.fields.FmsRowConflict;
import com.eistream.sonora.fields.FmsRowNative;

@Component
public class DataTableHelperImpl extends AbstractHelperImpl implements DataTableHelper {
	private static final String LOCALUPDATE_REL_EXISTING_ROW_COUNT_OF = "updateRel-Existing row count of ";

	private static final String LOCALTABLE_ID_IS = "Table id is ";

	@Autowired
	private QueryHelper queryHelper;

	@Autowired
	private TableIdBean tableIdBean;

	@Override
	public List<FmsColumnDefinition> getTableDefinition(BigDecimal tableId) throws RemoteException {
		try {
			return getFmsSchemaSessionEJB().getColumns(tableId);
		} catch (FinderException e) {

			 
			throw new RemoteException("", e);
		}
	}

	@Override
	public List<String> getTableColumnName(BigDecimal tableId) throws RemoteException {
		LogUtil.logInfo(m_Logger,"FunciontName getTableColumnName is entering!");
		List<FmsColumnDefinition> columns =  getTableDefinition(tableId);
		List<String> result = new ArrayList<String>();
		if (columns != null) {
			for (FmsColumnDefinition col : columns) {
				result.add(col.getFieldName());
			}
		}
		LogUtil.logInfo(m_Logger,"FunciontName getTableColumnName is leaving!");
		return result;
	}

	@Override
	public boolean createTableRow(BigDecimal tableId, Map<String, String> parameters) throws RemoteException {
		LogUtil.logInfo(m_Logger,"FunciontName createTableRow is entering!");
		StringBuilder sb = new StringBuilder();
		LogUtil.logInfo(m_Logger,parameters.toString());
		sb.append(LOCALTABLE_ID_IS).append(tableId).append(".");
		FmsRowNative frn;
		try {
			frn = getFmsEJB().getNewRow(tableId);
			FmsRow fmsRow = (FmsRow) frn.clone();
			FmsRow newfmsRow = (FmsRow) frn.clone();
			updateTableRow(parameters, newfmsRow);
			getFmsEJB().saveChanges(fmsRow, (FmsRowNative) newfmsRow, true);
			sb.append("Create table row success .");
			LogUtil.logInfo(m_Logger,sb.toString());
			LogUtil.logInfo(m_Logger,"FunciontName createTableRow is leaving!");
			return true;
		} catch (CreateException e) {
			 
			LogUtil.logError(m_Logger, e.getMessage());
			throw LogUtil.logException(m_Logger, sb.toString(), e);
		} catch (SonoraException e) {
			LogUtil.logError(m_Logger, e.getMessage());
			 
			throw LogUtil.logException(m_Logger, sb.toString(), e);
		} catch (FinderException e) {
			 
			LogUtil.logError(m_Logger, e.getMessage());
			throw LogUtil.logException(m_Logger, sb.toString(), e);
		}

	}

	@Override
	public void updateTableRow(Map<String, String> parameters, FmsRow fmsRow) throws RemoteException, SonoraException {
		LogUtil.logInfo(m_Logger,"FunciontName updateTableRow is entering!");
		Iterator<Map.Entry<String, String>> it = parameters.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<String, String> entry = it.next();
			if (fmsRow.getField(entry.getKey()) == null) {
				continue;
			}

			updateTableRowAssist(fmsRow, entry);
		}
		LogUtil.logInfo(m_Logger,"FunciontName updateTableRow is ending");

	}

  private void updateTableRowAssist(FmsRow fmsRow, Map.Entry<String, String> entry)
      throws RemoteException, SonoraException {
    if (FieldCache.getFieldType(entry.getKey()).equalsIgnoreCase("Decimal")) {
      if(!"".equals(valueIsNull(entry.getValue()))){
    		LogUtil.logInfo(m_Logger,entry.getKey() + " : " + entry.getValue());
    		fmsRow.setValue(entry.getKey(), new BigDecimal(entry.getValue().toString()));
      }
    } else if (FieldCache.getFieldType(entry.getKey()).equalsIgnoreCase("Integer")) {
      if(!"".equals(valueIsNull(entry.getValue()))){
    		LogUtil.logInfo(m_Logger,entry.getKey() + " : " + entry.getValue());
    		fmsRow.setValue(entry.getKey(), new Integer(entry.getValue()));
      }
    } else if (FieldCache.getFieldType(entry.getKey()).equalsIgnoreCase("Boolean")) {
      if(!"".equals(valueIsNull(entry.getValue()))){
    		LogUtil.logInfo(m_Logger,entry.getKey() + " : " + entry.getValue());
    		String fieldValue = entry.getValue();
    		// Albert wang.On 20180206.Convert "1" and "true" to true value.
    		verifyFiielValue(fmsRow, entry, fieldValue);
      }
    } else if (FieldCache.getFieldType(entry.getKey()).equalsIgnoreCase("Timestamp")) {
      if(!"".equals(valueIsNull(entry.getValue()))){
    		LogUtil.logInfo(m_Logger,entry.getKey() + " : " + entry.getValue());
    		fmsRow.setValue(entry.getKey(), DateUtil.getTimestamp(entry.getValue()));
      }
    } else {
    	LogUtil.logInfo(m_Logger,entry.getKey() + " : " + entry.getValue());
    	String value = entry.getValue();
    	fmsRow.setValue(entry.getKey(),valueIsNull(value));
    }
  }

  private void verifyFiielValue(FmsRow fmsRow, Map.Entry<String, String> entry, String fieldValue)
      throws SonoraException {
    if(StringUtils.isBlank(fieldValue)) {
    	fmsRow.setValue(entry.getKey(), false);
    }
    else if(fieldValue.equals("1")){						
    	fmsRow.setValue(entry.getKey(), true);
    }else {
    	fmsRow.setValue(entry.getKey(), new Boolean(fieldValue));
    }
  }

	@Override
	public FmsRow updateTableRow1(Map<String, String> parameters, FmsRow fmsRow)
			throws RemoteException, SonoraException {
		LogUtil.logInfo(m_Logger,"FunciontName updateTableRow1 is entering!");
		Iterator<Map.Entry<String, String>> it = parameters.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<String, String> entry = it.next();
			if (fmsRow.getField(entry.getKey()) == null) {
				continue;
			}

			if (FieldCache.getFieldType(entry.getKey()).equalsIgnoreCase("Decimal")&&!"".equals(valueIsNull(entry.getValue()))) {
				
					LogUtil.logInfo(m_Logger,entry.getKey() + " : " + entry.getValue());
					fmsRow.setValue(entry.getKey(), new BigDecimal(entry.getValue().toString()));
				
			} else if (FieldCache.getFieldType(entry.getKey()).equalsIgnoreCase("Integer")&&!"".equals(valueIsNull(entry.getValue()))) {
			
					LogUtil.logInfo(m_Logger,entry.getKey() + " : " + entry.getValue());
					fmsRow.setValue(entry.getKey(), new Integer(entry.getValue()));
				
			} else if (FieldCache.getFieldType(entry.getKey()).equalsIgnoreCase("Boolean")&&!"".equals(valueIsNull(entry.getValue()))) {
				
					LogUtil.logInfo(m_Logger,entry.getKey() + " : " + entry.getValue());
					fmsRow.setValue(entry.getKey(), new Boolean(entry.getValue()));
				
			} else if (FieldCache.getFieldType(entry.getKey()).equalsIgnoreCase("Timestamp")&&!"".equals(valueIsNull(entry.getValue()))) {
				
					LogUtil.logInfo(m_Logger,entry.getKey() + " : " + entry.getValue());
					fmsRow.setValue(entry.getKey(), DateUtil.getTimestamp(entry.getValue()));
				
			} else {
				LogUtil.logInfo(m_Logger,entry.getKey() + " : " + entry.getValue());
				fmsRow.setValue(entry.getKey(),valueIsNull(entry.getValue()));
			}
		}
		LogUtil.logInfo(m_Logger,"FunciontName updateTableRow is ending");
		return fmsRow;
	}

	@Override
	public boolean checkTableColumnName(Map<String, String> parameter, BigDecimal tableId) throws RemoteException {
		LogUtil.logInfo(m_Logger,"FunciontName checkTableColumnName is entering!");
		StringBuilder sb = new StringBuilder();
		sb.append("check formData Id is").append(tableId);
		List<String> fmsNameList = getTableColumnName(tableId);
		Iterator<Map.Entry<String, String>> it = parameter.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<String, String> entry = it.next();
			if (!fmsNameList.contains(entry.getKey())) {
				sb.append(entry.getKey()).append("have error");
				LogUtil.logInfo(m_Logger,sb.toString());

				
				return false;
			}
		}
		sb.append(".Check tabler column name success.");
		LogUtil.logInfo(m_Logger,sb.toString());
		LogUtil.logInfo(m_Logger,"FunciontName checkTableColumnName is leaving!");

		return true;
	}

	@Override
	public boolean updateTableRow(BigDecimal tableId, String queryName, Map<String, String> queryParameters,
			Map<String, String> updateParameters) throws RemoteException {
		LogUtil.logInfo(m_Logger,"FunciontName updateTableRowFourPara is entering!");
		StringBuilder sb = new StringBuilder();
		List<String> rowList = new ArrayList<String>();
		boolean flag = false;
		sb.append(LOCALTABLE_ID_IS).append(tableId).append(".");
		try {
			rowList = getRowIdList(queryName, queryParameters);
		} catch (RemoteException e) {

			 
			throw new RemoteException(e.getMessage());
		}
		if (rowList.isEmpty()) {
			sb.append("result is null!");
			LogUtil.logInfo(m_Logger,sb.toString());
			flag = true;
			return flag;
		}
		for (String rowId : rowList) {
			flag = updateRow(tableId, rowId, updateParameters);
			if (!flag) {
				sb.append("update Row have error,rowId is ").append(rowId);
				LogUtil.logInfo(m_Logger,sb.toString());
				return flag;
			}

		}
		sb.append("Update table row success .");
		LogUtil.logInfo(m_Logger,sb.toString());
		LogUtil.logInfo(m_Logger,"FunciontName updateTableRow is leaving!");

		return true;
	}

	@Override
	public boolean updateTableRow(BigDecimal tableId, String queryName, Map<String, String> parameters)
			throws RemoteException {
		LogUtil.logInfo(m_Logger,"FunciontName updateTableRowThreePara is entering!");
		StringBuilder sb = new StringBuilder();
		String rowId = null;
		boolean flag = false;
		sb.append(LOCALTABLE_ID_IS).append(tableId).append(".");
		LogUtil.logInfo(m_Logger,sb.toString());
		rowId = getRowID(queryName, parameters);
		if (rowId == null) {
			sb.append("get rowID have error");
			LogUtil.logInfo(m_Logger,sb.toString());
			return flag;
		}
		try {
			flag = updateRow(tableId, rowId, parameters);
		} catch (Exception e) {
			 
			LogUtil.logError(m_Logger, e.getMessage());
			throw new RemoteException(e.getMessage());
		}
		if (!flag) {
			sb.append("update Row have error,rowId is ").append(rowId);
			LogUtil.logInfo(m_Logger,sb.toString());
			return flag;
		}
		sb.append("Update table row success .");
		LogUtil.logInfo(m_Logger,sb.toString());
		LogUtil.logInfo(m_Logger,"FunciontName updateTableRow is leaving!");

		return true;
	}

	/**
	 * change private to public by bsnpbys 2017/5/2
	 * 
	 * @param tableId
	 * @param rowId
	 * @param parameters
	 * @return
	 * @throws RemoteException
	 */
	public boolean updateRow(BigDecimal tableId, String rowId, Map<String, String> parameters) throws RemoteException {
		LogUtil.logInfo(m_Logger,"FunciontName updateRow is entering!tableId  " + tableId.toString());
		LogUtil.logInfo(m_Logger,parameters.toString());

		FmsRowNative frn;
		try {
			frn = getFmsEJB().fetch(tableId, new BigDecimal(rowId));
			FmsRow originalRo = (FmsRow) frn.clone();
			FmsRowNative newRow = (FmsRowNative) frn.clone();
			updateTableRow(parameters, newRow);
			FmsRowConflict rff = getFmsEJB().saveChanges(originalRo, newRow, true);
			if (rff != null) {
				LogUtil.logInfo(m_Logger,rff.conflictCount + "");

			}
			LogUtil.logInfo(m_Logger,"FunciontName updateRow is leaving!");

			return true;

		} catch (FinderException e) {
			 
			LogUtil.logError(m_Logger, e.getMessage());
			throw LogUtil.logException(m_Logger,parameters.toString(), e);
		} catch (SonoraException e) {
			 
			LogUtil.logError(m_Logger, e.getMessage());
			throw LogUtil.logException(m_Logger,parameters.toString(), e);
		}
	}

	private String getRowID(String queryName, Map<String, String> parameters) throws RemoteException {
		LogUtil.logInfo(m_Logger,"FunciontName getRowID is entering!");
		StringBuilder sb = new StringBuilder();
		String rowId = null;
		ArrayList<Map<String, Object>> list = queryHelper.doQuery(parameters, queryName);
		if (list == null || list.size() < 1) {
			sb.append("Query result is null.");
			throw LogUtil.logException(m_Logger, sb.toString(), null);
		}
		if (list.size() > 1) {
			sb.append("Query result is greater than one.");
			throw LogUtil.logException(m_Logger, sb.toString(), null);
		}
		Map<String, Object> fmsMap = list.get(0);
		rowId = fmsMap.get("S_ROWID").toString();
		LogUtil.logInfo(m_Logger,"FunciontName getRowID is leaving!");

		return rowId;
	}

	private List<String> getRowIdList(String queryName, Map<String, String> parameters) throws RemoteException {
		LogUtil.logInfo(m_Logger,"FunciontName getRowIdList is entering!");
		List<String> rowList = new ArrayList<String>();
		String rowId = null;

		ArrayList<Map<String, Object>> list = queryHelper.doQuery(parameters, queryName);
		if (list.size() >= 1) {
			for (Map<String, Object> map : list) {
				rowId = map.get("S_ROWID").toString();
				rowList.add(rowId);
			}
		}
		LogUtil.logInfo(m_Logger,"FunciontName getRowIdList is leaving!");

		return rowList;
	}

	@Override
	public boolean deleteRow(BigDecimal tableId, String rowId) throws RemoteException {
		LogUtil.logInfo(m_Logger,"FunciontName deleteRow is entering!");
		FmsRowNative frn;
		try {
			frn = getFmsEJB().fetch(tableId, new BigDecimal(rowId));
			FmsRow originalRo = (FmsRow) frn.clone();
			FmsRowNative newRow = (FmsRowNative) frn.clone();
			newRow.setValue("IS_DELETED", "true");
			getFmsEJB().saveChanges(originalRo, newRow, true);
			return true;
		} catch (FinderException e) {
			 
			LogUtil.logError(m_Logger, e.getMessage());
			throw LogUtil.logException(m_Logger,tableId.toString(), e);
		} catch (SonoraException e) {
			 
			LogUtil.logError(m_Logger, e.getMessage());
			throw LogUtil.logException(m_Logger,tableId.toString(), e);
		}
	}

	@Override
	public boolean deletePhysicalRow(BigDecimal templateId, String rowId) throws RemoteException {
		LogUtil.logInfo(m_Logger,"FunciontName deletePhysicalRow is entering!");
		
		try {
			BigDecimal bdRowId = new BigDecimal(rowId);
			LogUtil.logInfo(m_Logger,"deletePhysicalRow templateId :" + templateId);
			LogUtil.logInfo(m_Logger,"deletePhysicalRow bdRowId :" + bdRowId);
			getFdEJB().deleteFormData(templateId, bdRowId);
			return true;
		} catch (RemoveException e) {
			 
			throw LogUtil.logException(m_Logger,rowId, e);
		}
	}

	@Override
	public boolean deletePhysicalRow(BigDecimal tableID, BigDecimal templateId, String rowId, String[] relationList)
			throws RemoteException {
		LogUtil.logInfo(m_Logger,"FunciontName deletePhysicalRow is entering!");
		
		try {
			BigDecimal bdRowId = new BigDecimal(rowId);
			LogUtil.logInfo(m_Logger,"deletePhysicalRow templateId :" + templateId);
			LogUtil.logInfo(m_Logger,"deletePhysicalRow tableID :" + tableID);
			LogUtil.logInfo(m_Logger,"deletePhysicalRow bdRowId :" + bdRowId);

			FmsRowNative tableRow = getFmsEJB().fetch(tableID, new BigDecimal(rowId));

			for (String relnam : relationList) {
				LogUtil.logInfo(m_Logger,"deletePhysicalRow relnams :" + relnam);
				getFmsEJB().removeAllRelatedRows(tableRow, relnam);
			}

			getFdEJB().deleteFormData(templateId, bdRowId);
			return true;
		} catch (RemoveException e) {
			//  
			throw LogUtil.logException(m_Logger,Arrays.toString(relationList), e);
		} catch (FinderException e) {
			throw LogUtil.logException(m_Logger,Arrays.toString(relationList), e);
		}
	}

	@Override
	public boolean batchDeletePhysical(BigDecimal tableId, String queryName, Map<String, String> queryParameters)
			throws RemoteException {
		LogUtil.logInfo(m_Logger,"FunciontName batchDeletePhysical is entering!");
		StringBuilder sb = new StringBuilder();
		boolean flag = false;
		sb.append(LOCALTABLE_ID_IS).append(tableId).append(".");
		List<String> rowList = new ArrayList<String>();
		try {
			rowList = getRowIdList(queryName, queryParameters);
		} catch (RemoteException e) {
			 
			throw new RemoteException(e.getMessage());
		}
		if (rowList.isEmpty()) {
			sb.append("result is null!");
			LogUtil.logInfo(m_Logger,sb.toString());
			flag = true;
			return flag;
		}
		for (String rowId : rowList) {
			flag = deletePhysicalRow(tableId, rowId);
			if (!flag) {
				sb.append("physicaly delete row have error,rowId is ").append(rowId);
				LogUtil.logInfo(m_Logger,sb.toString());
				return flag;
			}
		}
		sb.append("delete table row success .");
		LogUtil.logInfo(m_Logger,sb.toString());
		LogUtil.logInfo(m_Logger,"FunciontName batchDeletePhysical is leaving!");
		return true;
	}

	@Override
	public String dataMigrationCreateFormData(BigDecimal tableId, String createAmount) throws RemoteException {
		String message = "FunctionName : [ dataMigrationCreateFormData ] , tableId : [" + tableId
				+ " ] . createAmount : [ " + createAmount + " ] .";
		LogUtil.logInfo(m_Logger,message + "is entery");

		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date1 = new Date();
		FmsRowNative frn;

		try {
			for (int i = 0; i < Integer.parseInt(createAmount); i++) {
				frn = getFmsEJB().getNewRow(tableId);
				FmsRow fmsRow = (FmsRow) frn.clone();
				getFmsEJB().saveChanges(fmsRow, (FmsRowNative) fmsRow, true);
			}

			message = "create tableId: [" + tableId + " ],Start time: [" + df.format(date1) + "] . End time: ["
					+ df.format(new Date()) + "].";
			LogUtil.logInfo(m_Logger,message);
			return message;
		} catch (CreateException e) {
			throw LogUtil.logException(m_Logger,message, e);
		} catch (FinderException e) {
			throw LogUtil.logException(m_Logger,message, e);
		}
	}

	@Override
	public List<FmsRowNative> getRowsByIdList(List<BigDecimal> idList, BigDecimal tableId) throws RemoteException {
		LogUtil.logInfo(m_Logger,"FunciontName getRowsByIdList is entering!");
		LogUtil.logInfo(m_Logger,"input parameters: " + idList.toString());
		List<FmsRowNative> result = new ArrayList<FmsRowNative>();
		if (idList.isEmpty()) {
			throw LogUtil.logException(m_Logger, "No rowId passed", null);
		}

		for (BigDecimal rowId : idList) {
			try {
				result.add(getFmsEJB().fetch(tableId, rowId));
			} catch (FinderException e) {
				 
				throw LogUtil.logException(m_Logger, idList.toString(), e);
			}
		}
		LogUtil.logInfo(m_Logger,"FunciontName getRowsByIdList is leaving!");

		return result;
	}

	@Override
	public List<FmsRowNative> getNewRows(BigDecimal tableId, int size) throws RemoteException {
		LogUtil.logInfo(m_Logger,"FunciontName getNewRows is entering!");
		LogUtil.logInfo(m_Logger,"input parameters: " + tableId.toString() + "," + size);
		List<FmsRowNative> result = new ArrayList<FmsRowNative>();

		for (int i = 0; i < size; i++) {
			try {
				result.add(getFmsEJB().getNewRow(tableId));
			} catch (CreateException e) {
				 
				throw LogUtil.logException(m_Logger, tableId.toString() + "," + size, e);
			}
		}
		LogUtil.logInfo(m_Logger,"FunciontName getNewRows is leaving!");

		return result;
	}

	@Override
	public boolean batchUpdate(List<FmsRowNative> oldFmsRows, List<FmsRowNative> newFmsRows) throws RemoteException {
		LogUtil.logInfo(m_Logger,"FunciontName batchUpdate is entering!");
		FmsRowChange[] changes = new FmsRowChange[newFmsRows.size()];
		LogUtil.logInfo(m_Logger,"batchUpdate 1");
		for (int i = 0; i < newFmsRows.size(); i++) {
			changes[i] = FmsRowChange.getInstanceSaveChanges(oldFmsRows.get(i), newFmsRows.get(i), false);
		}
		LogUtil.logInfo(m_Logger,"batchUpdate 2");
		StringBuilder sb = new StringBuilder();
		saveAllChanges(sb, changes);
		LogUtil.logInfo(m_Logger,"FunciontName batchUpdate is leaving!");
		return true;

	}

	private void saveAllChanges(StringBuilder sb, FmsRowChange[] changes) throws RemoteException {
		LogUtil.logInfo(m_Logger,"FunciontName saveAllChanges is entering!");
		FmsRowConflict[] moreConflict;
		try {
			moreConflict = getFmsEJB().saveChanges(changes);

			if (moreConflict != null && moreConflict.length > 0) {
				boolean conflictFlag = false;
				conflictFlag = saveAllChangesAssist(sb, moreConflict, conflictFlag);
				if (conflictFlag) {
					throw LogUtil.logException(m_Logger, sb.toString(), new RemoteException());
				}
			}
			LogUtil.logInfo(m_Logger,"FunciontName saveAllChanges is leaving!");

		} catch (FinderException e) {
			 
			throw LogUtil.logException(m_Logger, sb.toString(), e);
		}
	}

  private boolean saveAllChangesAssist(StringBuilder sb, FmsRowConflict[] moreConflict,
      boolean conflictFlag) {
    for (FmsRowConflict frc : moreConflict) {
    	if (frc != null) {
    		conflictFlag = true;
    		sb.append("|conflictRow:");
    		if (frc.getConflictFieldNames() != null) {
    			for (String fldName : frc.getConflictFieldNames()) {
    				sb.append(fldName);
    			}
    		}
    	}
    }
    return conflictFlag;
  }

	@Override
	public void updateRel(BigDecimal tableId, String rowID, String relName, String referenceKeyName,
			List<Map<String, String>> fieldValuesList) {

		FmsRowNative tableRow;

		try {
			tableRow = getFmsEJB().fetch(tableId, new BigDecimal(rowID));
			FmsRow[] relRows = getFmsEJB().fetchRelatedRows(tableRow, relName);
			if (relRows != null) {
				LogUtil.logInfo(m_Logger,LOCALUPDATE_REL_EXISTING_ROW_COUNT_OF + relName + "is " + relRows.length);
			} else {
				LogUtil.logInfo(m_Logger,LOCALUPDATE_REL_EXISTING_ROW_COUNT_OF + relName + "is null.");

			}
			if (relRows != null) {
				updateRelAssist(relName, referenceKeyName, fieldValuesList, tableRow, relRows);
			}
			LogUtil.logInfo(m_Logger,"Check fieldValuesList:" + fieldValuesList);
			for (Map<String, String> fileValues : fieldValuesList) {
				LogUtil.logInfo(m_Logger,"updateRel-insert new rel: " + fileValues);
				FmsRow frn = getFmsEJB().createRelatedRow(tableRow, relName);

				FmsRow originalRo = (FmsRow) frn.clone();
				FmsRowNative newRow = (FmsRowNative) frn.clone();

				updateTableRow(fileValues, newRow);
				getFmsEJB().saveChanges(originalRo, newRow, true);

			}

		} catch (RemoteException e) {
			 LogUtil.logException(m_Logger, LOCALUPDATE_REL_EXISTING_ROW_COUNT_OF + relName , e);
			 
		} catch (FinderException e) {
			 LogUtil.logException(m_Logger, LOCALUPDATE_REL_EXISTING_ROW_COUNT_OF + relName , e);
			 
		} catch (SonoraException e) {
			 LogUtil.logException(m_Logger, LOCALUPDATE_REL_EXISTING_ROW_COUNT_OF + relName , e);
			 
		}

	}

  private void updateRelAssist(String relName, String referenceKeyName,
      List<Map<String, String>> fieldValuesList, FmsRowNative tableRow, FmsRow[] relRows)
      throws RemoteException {
    for (FmsRow rowItem : relRows) {
    	String rowKey = (String) (rowItem.getField(referenceKeyName).getValue());
    	boolean contains = false;
    	LogUtil.logInfo(m_Logger,"fieldValuesList:" + fieldValuesList.size());
    	Iterator<Map<String, String>> it = fieldValuesList.iterator();
    	while (it.hasNext()) {
    		Map<String, String> map = it.next();
    		if (map.get(referenceKeyName).equals(rowKey)) {
    			LogUtil.logInfo(m_Logger,"remove from fieldValuesList:" + map.get(referenceKeyName));
    			contains = true;
    			it.remove();
    		}
    	}

    	if (!contains) {
    		LogUtil.logInfo(m_Logger,"updateRel-remove key " + rowKey);
    		getFmsEJB().removeRelatedRow(tableRow, relName, rowItem);
    	}

    	// rowItem.
    }
  }

	@Override
	public String createTableRowAndGetRepositoryKey(BigDecimal tableId, Map<String, String> parameters)
			throws RemoteException {

		LogUtil.logInfo(m_Logger,"FunciontName createTableRow is entering!");
		StringBuilder sb = new StringBuilder();
		LogUtil.logInfo(m_Logger,parameters.toString());
		sb.append(LOCALTABLE_ID_IS).append(tableId).append(".");
		FmsRowNative frn;
		try {
			frn = getFmsEJB().getNewRow(tableId);
			FmsRow fmsRow = (FmsRow) frn.clone();
			FmsRow newfmsRow = (FmsRow) frn.clone();
			updateTableRow(parameters, newfmsRow);
			String repositoryKey = fmsRow.getRepositoryKey();
			getFmsEJB().saveChanges(fmsRow, (FmsRowNative) newfmsRow, true);
			sb.append("Create table row success .");
			LogUtil.logInfo(m_Logger,sb.toString());
			LogUtil.logInfo(m_Logger,"FunciontName createTableRow is leaving!");
			return repositoryKey;
		} catch (CreateException e) {
			 
			throw LogUtil.logException(m_Logger, sb.toString(), e);
		} catch (SonoraException e) {
			 
			throw LogUtil.logException(m_Logger, sb.toString(), e);
		} catch (FinderException e) {
			 
			throw LogUtil.logException(m_Logger, sb.toString(), e);
		}
	}
	private String valueIsNull(String value){
	      
	      if(value==null){
	        return "";
	      }else if("".equals(value.trim())){
	        return "";
	      }else if(value.trim().length()==0){
	        return "";
	      }else{
	        return value;
	      }
	}
}