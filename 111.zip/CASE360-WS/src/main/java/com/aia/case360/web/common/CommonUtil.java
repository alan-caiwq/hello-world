package com.aia.case360.web.common;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.rmi.RemoteException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.sf.json.JSONArray;
import net.sf.json.JSONException;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;

import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.common.PropertyUtil;
import com.aia.case360.web.pojo.GetPolicyInfoDetailsInfo;
import com.aia.case360.web.pojo.PolicyInfo;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

/**
 * 
 * @author bsnpc1i
 * @author Kevin Song
 *
 */
public class CommonUtil {

	private CommonUtil() {}
	protected static Logger mLogger = LoggerFactory.getLogger(CommonUtil.class);
	
	public static boolean isDynamicFolder(String value) {
		if (value.startsWith("{") && value.endsWith("}")) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * <pre>
	 * convert result to list of entity [{"FOLDER_ID":"1"},{"FOLDER_ID":"2"}] to
	 * [{"folderId":"1"},{"folderId":"2"}]
	 * 
	 * @param queryResult
	 * @param clazz
	 * @return
	 * @ throws RemoteException
	 * 
	 *                   <pre>
	 */
	public static ArrayList<Object> convertToEntityList(ArrayList<Map<String, Object>> queryResult, Class<?> clazz)
			 throws RemoteException {
		ArrayList<Object> list = new ArrayList<Object>();
		for (Map<String, Object> temp : queryResult) {
			Object obj;
			try {
				obj = clazz.newInstance();
				Field[] fields = clazz.getDeclaredFields();
				for (Field field : fields) {
					String fieldName = field.getName();
					Class<?> fieldType = field.getType();
					String fieldNameCamel = CommonUtil.camel2Underline(fieldName);
					String value = temp.get(fieldNameCamel) == null ? null : temp.get(fieldNameCamel).toString().trim();

					String setMethodName = "set" + fieldName.substring(0, 1).toUpperCase()
							+ fieldName.substring(1, fieldName.length());
					Method method = clazz.getMethod(setMethodName, fieldType);
					if (StringUtils.containsIgnoreCase(field.getGenericType().toString(), "String")) {
						method.invoke(obj, value);
					}
				}
				list.add(obj);
			} catch (InstantiationException | IllegalAccessException | NoSuchMethodException | SecurityException | IllegalArgumentException | InvocationTargetException e) {
					throw new RemoteException(e.getMessage());
			}
			
		}
		return list;
	}

	public static Object convertMapToEntity(Map<String, Object> queryResult, Class<?> clazz)  throws RemoteException {
		Iterator<Entry<String, Object>> iterator = queryResult.entrySet().iterator();
		String fieldName = null;
		Object fieldValue = null;
		Entry<String, Object> entry = null;
		Object obj = null;
		try {
			obj = clazz.newInstance();
			Class<?> fieldType = null;

			Field[] fields = clazz.getDeclaredFields();
			List<String> fieldNames = new ArrayList<String>();
			for (Field field : fields) {
				fieldNames.add(field.getName());
			}

			while (iterator.hasNext()) {
				entry = iterator.next();
				fieldName = entry.getKey();
				fieldValue = entry.getValue();
				fieldName = CommonUtil.underline2Camel(fieldName, true);

				if (!fieldNames.contains(fieldName)) {
					continue;
				}

				fieldValue = fieldValue == null ? null : fieldValue;
				fieldType = clazz.getDeclaredField(fieldName).getType();

				String setMethodName = "set" + fieldName.substring(0, 1).toUpperCase()
						+ fieldName.substring(1, fieldName.length());
				Method method = clazz.getMethod(setMethodName, fieldType);
				if (fieldType.getName().equalsIgnoreCase("long")) {
					long newValue = Long.valueOf(String.valueOf(fieldValue));
					method.invoke(obj, newValue);
				} else if (fieldType.getName().equalsIgnoreCase("int")) {
					int newValue = Integer.valueOf(String.valueOf(fieldValue));
					method.invoke(obj, newValue);
				} else {
					method.invoke(obj, fieldValue);
				}
			}
		} catch (InstantiationException | IllegalAccessException | NoSuchMethodException | SecurityException | IllegalArgumentException | InvocationTargetException | NoSuchFieldException e) {
			throw new RemoteException(e.getMessage());
		}
		

		return obj;
	}

	/**
	 * I_HAVE_AN_IPANG3_PIG -> iHaveAnIpang3Pig
	 * 
	 * @param line
	 * @param smallCamel
	 * @return
	 */
	public static String underline2Camel(String line, boolean smallCamel) {
		if (line == null || "".equals(line)) {
			return "";
		}
		StringBuilder sb = new StringBuilder();
		Pattern pattern = Pattern.compile("([A-Za-z\\d]+)(_)?");
		Matcher matcher = pattern.matcher(line);
		while (matcher.find()) {
			String word = matcher.group();
			sb.append(smallCamel && matcher.start() == 0 ? Character.toLowerCase(word.charAt(0))
					: Character.toUpperCase(word.charAt(0)));
			int index = word.lastIndexOf('_');
			if (index > 0) {
				sb.append(word.substring(1, index).toLowerCase());
			} else {
				sb.append(word.substring(1).toLowerCase());
			}
		}
		return sb.toString();
	}

	/**
	 * iHaveAnIpang3Pig -> I_HAVE_AN_IPANG3_PIG
	 * 
	 * @param line
	 * @return
	 */
	public static String camel2Underline(String line) {
		if (line == null || "".equals(line)) {
			return "";
		}
		line = String.valueOf(line.charAt(0)).toUpperCase().concat(line.substring(1));
		StringBuilder sb = new StringBuilder();
		Pattern pattern = Pattern.compile("[A-Z]([a-z\\d]+)?");
		Matcher matcher = pattern.matcher(line);
		while (matcher.find()) {
			String word = matcher.group();
			sb.append(word.toUpperCase());
			sb.append(matcher.end() == line.length() ? "" : "_");
		}
		return sb.toString();
	}

	// added by Leo Li
	// ' ',' '
	public static String listToString(List<String> list) {
		String str = "";
		if (null != list && list.size() > 0) {
			for (String string : list) {
				str += "'" + string + "',";
			}
		}
		if (str.length() > 0) {
			str = str.substring(0, str.length() - 1);
		}
		return str;
	}
	public static String listToString4ODS(List<String> list) {
		String str = "";
		if (null != list && list.size() > 0) {
			for (String string : list) {
				str += string + "','";
			}
		}
		if (str.length() > 0) {
			str = str.substring(0, str.length() - 3);
		}
		return str;
	}

	// get md5 of doc
	public static String getMd5OfDoc(byte[] bytes) throws NoSuchAlgorithmException {
		MessageDigest md5 = MessageDigest.getInstance("MD5");
		md5.update(bytes);
		// md5.digest() hash
		BigInteger bi = new BigInteger(1, md5.digest());
		String value = bi.toString(16);
		return value;
	}

	/**
	 * list to String " "
	 * 
	 * @param list
	 * @param a
	 * @return
	 * @author bsnpc37
	 * @date: 2018-4-10 13:53:55
	 */
	public static String listToString(List<String> list,String split) {
		if (StringUtils.isBlank(split)) {
			//set default value
			split = ",";
		}
		StringBuilder builder = new StringBuilder();
		if (list != null && list.size() > 0) {
			for (int i = 0; i < list.size(); i++) {
				builder.append(list.get(i) + split);
			}
		}
		if (builder.length() > split.length()) {
			builder.delete(builder.length() - split.length(),builder.length());
		}
		return builder.toString();
	}

	public static String fillInVacancies(String str,int lenth){
		if(lenth>100 || lenth<0){
			return null;
		}
		if(str.length()<lenth){
			str = "0" + str;
			return fillInVacancies(str, lenth);
		}
		return str;
	}
	// end

	/**
	 * compare 2 days
	 * 
	 * @param Date
	 * @param Date
	 * @return
	 * @author asnphjq
	 * @date: 2018-7-31
	 */
	public static long compareDays(Date d1, Date d2) {
		return (d2.getTime() - d1.getTime()) / (1000 * 3600 * 24);
	}

	/**
	 * @title: dateCompare
	 * @param date1
	 * @param date2
	 * @return
	 */

	public static int dateCompare(Date date1, Date date2) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		String dateFirst = dateFormat.format(date1);
		String dateLast = dateFormat.format(date2);
		int dateFirstIntVal = Integer.parseInt(dateFirst);
		int dateLastIntVal = Integer.parseInt(dateLast);
		if (dateFirstIntVal > dateLastIntVal) {
			return 1;
		} else if (dateFirstIntVal < dateLastIntVal) {
			return -1;
		}
		return 0;
	}
	 /**
     * 
     * @param split
     * @param suffix
     * @param sb
     * @param Args
     * @return
     * @ throws RemoteException
     * @author bsnpc37(Leo Li)
     * @date: Nov 29, 2018 4:23:29 PM
     */
    public static StringBuilder appendString(String split,StringBuilder sb,String ...Args){
		for (String str:Args){
			sb.append(StringUtils.trimToEmpty(str)+split);
		}
		sb.delete(sb.length()-split.length(), sb.length());
		return sb;	
    }
    
	public static StringBuilder appendString (String split,String suffix,StringBuilder sb,String ...Args) throws NullPointerException{
		if (sb==null) {
			sb=new StringBuilder();
		}
		appendString(split,sb,Args);
		if (!StringUtils.isBlank(suffix)) {
			sb.append(suffix);
		}
		return sb;
	}
    
    /**
     * 
     * @param jsonObject
     * @param key
     * @param nullAsValue
     * @return
     * @ throws RemoteException
     * @author bsnpc37(Leo Li)
     * @date: Dec 4, 2018 4:29:05 PM
     */
    public static String getStringFromJson (JSONObject jsonObject, String key, String nullAsValue){
    	if (jsonObject == null || !jsonObject.containsKey(key)) 
    		return nullAsValue;
    	return jsonObject.get(key) == null ? nullAsValue : jsonObject.get(key).toString();
    }
    public static String getStringFromJson (JSONObject jsonObject, String key){
    	return getStringFromJson(jsonObject, key,PFHConstants.EMPTY_STRING);
    }
    /**
     * 
     * @param jsonObject
     * @param key
     * @param nullAsValue
     * @return
     * @ throws RemoteException
     * @author bsnpc37(Leo Li)
     * @date: Dec 6, 2018 10:59:31 AM
     */
    public static List<String>  getStringListFromJson(JSONObject jsonObject, String key) throws JSONException{
    	List<String> list = new ArrayList<>();
    	if (jsonObject != null && jsonObject.containsKey(key)) {
			JSONArray jsonArray = jsonObject.getJSONArray(key);
			if (jsonArray != null && !jsonArray.isEmpty()) {
				int size = jsonArray.size();
				for (int i = 0; i < size; i++) {
					list.add(jsonArray.getString(i));
				}
			}
		}
    	return list;
    }
    
    /**
     * return a String or blank String by charley 20181212
     * @param object
     * @return
     */
    public static String getString(Object object){
    	return object == null ? "" : String.valueOf(object).trim();
    }
    
   /**
    * return a int or default value by charley 20181219
    * @param object
    * @param defaultValue
    * @return
    */
    public static int getIntValue(String object, int defaultValue){
    	return StringUtils.isBlank(object) ? defaultValue : Integer.parseInt(object);
    }
    
    /**
     * return a long or default value by charley 20181219
     * @param object
     * @param defaultValue
     * @return
     */
     public static long getLongValue(String object, long defaultValue){
     	return StringUtils.isBlank(object) ? defaultValue : Long.parseLong(object);
     }
    
    /**
     * return a boolean or default value by charley 20181219
     * @param object
     * @param defaultValue
     * @return
     */
    public static boolean getBooleanValue(Object object, boolean defaultValue){
    	return object == null ? defaultValue : Boolean.parseBoolean(object.toString());
    }
    
    /**
     * return a String or blank String by charley 20181212
     * @param object
     * @return
     */
    public static String getString(Object object, String defaultValue){
        return object == null || "".equals(object) ? defaultValue : String.valueOf(object);
    }
    
    /**
     * return a Decimal value by charley 20190115
     * @param object
     * @return
     */
    public static BigDecimal getDecimalValue(Object object, BigDecimal defaultValue){
    	try {
    		return object == null || "".equals(object) ? defaultValue : new BigDecimal(object.toString());
		} catch (Exception e) {
			// if convert failed, return default value
			return defaultValue;
		}
    }
    
    public static boolean isListEmpty(List<?> list){
    	return list == null || list.size() == 0;
    }
    
    /**
     * @param list
     * @return
     * not null and not empty -->true
     * null or empty -->false
     * @author bsnpc37(Leo Li)
     * @date: Dec 13, 2018 11:20:00 AM
     */
    public static boolean listIsNotNull(List<?> list){
    	return list != null && !list.isEmpty();
    }
    /**
     * validate 
     * all Strings are not null and not "" -->true
     * exist null or "" --> false
     * @param args
     * @return
     * @author bsnpc37(Leo Li)
     * @date: Dec 13, 2018 3:03:38 PM
     */
    public static boolean stringIsNotNull(String...args){
    	if (args == null) {
			return false;
		}else {
			int size = args.length;
			for (int i = 0; i < size; i++) {
				if (StringUtils.isBlank(args[i])) {
					return false;
				}
			}
		}
    	return true;
    }
  
    /**
     * 
     * @param args
     * @return
     * @author bsnpc37(Leo Li)
     * @date: Dec 18, 2018 3:06:54 PM
     */
    public static boolean allTrue(boolean...args){
		int size = args.length;
		for (int i = 0; i < size; i++) {
			if (!args[i]) {
				return false;
			}
		}
    	return true;
    }
    /**
     * 
     * @param args
     * @return
     * @author bsnpc37(Leo Li)
     * @date: Dec 18, 2018 2:58:47 PM
     */
    public static boolean allFalse(boolean...args){
		int size = args.length;
		for (int i = 0; i < size; i++) {
			if (args[i]) {
				return false;
			}
		}
    	return true;
    }
    
    public static boolean isListNotNull(List list){
    	return list != null && list.size() > 0;
    }
    
    public static boolean isListFirstObjNull(List list){
    	return list == null || list.size() < 1 || list.get(0) == null;
    }
    /**
     * 
     * @param esbCode
     * @return
     * @author bsnpc37(Leo Li)
     * @date: Jan 2, 2019 11:27:56 AM
     */
    public static String getCase360ErrorMsgByEsbCode(String esbCode){
    	String msg = PFHConstants.EMPTY_STRING;
    	if (!StringUtils.isBlank(esbCode)) {
    		msg = PropertyUtil.getErrorMsgProperty(PropertyUtil.getEsbECMProperty(esbCode));
		}
    	return msg;
    }
    public static Map<String, String>  getEsbCodeAndMessage(ResponseEntity<JSONObject> response,String key){
    	Map<String, String> errorMap = new HashMap<>();
    	int rsStatus = response.getStatusCodeValue();
		if (rsStatus == 200) {
			JSONObject responseBody = response.getBody();
			JSONObject realResponse = responseBody.getJSONObject(key);
			JSONObject msgHeader = realResponse.getJSONObject(ParaConstants.HEADER);
			String statusCode = msgHeader.get("statusCode").toString();
			if (!StringUtils.equalsIgnoreCase("200", statusCode)&& realResponse.containsKey(ParaConstants.BODY)) {
				JSONObject msgBody = realResponse.getJSONObject(ParaConstants.BODY);
				JSONArray errorJsonArray = msgBody.getJSONArray("error");
				JSONObject errorJson = errorJsonArray.getJSONObject(0);
				errorMap.put(ParaConstants.ERROR_CODE, errorJson.getString(ParaConstants.ERROR_CODE));
				errorMap.put(ParaConstants.ERROR_MESSAGE, errorJson.getString(ParaConstants.ERROR_MESSAGE));
			}
		}
		return errorMap;
    }
    /**
     * 
     * @param jsonObject
     * @param beanClass
     * @return
     * @throws NullPointerException
     * @author bsnpc37(Leo Li)
     * @date: Jan 2, 2019 4:51:31 PM
     */
    public static <T> T jsonToObject(JSONObject jsonObject,Class<T> beanClass) throws NullPointerException{
    	return jsonToObject(jsonObject.toString(),beanClass);
    }
    /**
     * 
     * @param json
     * @param classOfT
     * @return
     * @author bsnpc37(Leo Li)
     * @date: Jan 2, 2019 4:51:34 PM
     */
    public static <T> T jsonToObject(String json,Class<T> classOfT){
    	Gson gson = new Gson();
    	return gson.fromJson(json, classOfT);
    }
    
    public static <T> List<T> jsonToListObject(JSONArray jsonArray, TypeToken<List<T>> typeToken)  throws NullPointerException{
    	return jsonToListObject(jsonArray.toString(),  typeToken);
    }
    public static <T> List<T> jsonToListObject(String json,TypeToken<List<T>> typeToken){
    	Gson gson = new Gson();
    	return gson.fromJson(json, typeToken.getType());
    }

	public static String getDateStrBySdf(SimpleDateFormat sdf) {
		return sdf.format(new Date());
	}
	@SuppressWarnings("unchecked")
	public static <T> List<T> bindDataToPojo(Map<String, Object> paraMap,Class<T> class1) {
		List<T> lists=new ArrayList<>();
		List<Map<String, Object>> result=(List<Map<String, Object>>) paraMap.get("result");
		if (!isListEmpty(result)) {
			try {
				lists=JSONArray.toList(JSONArray.fromObject(result),class1.newInstance(),new JsonConfig());
			} catch (InstantiationException | IllegalAccessException e) {
				LogUtil.logError(mLogger , e);
			}
		}
		return lists;
	}
	public static <T> List<List<T>> splitListForODS(List<T> list) {
		return splitList(list, 40);
	}

	public static <T> List<List<T>> splitList(List<T> list, int i) {
		List<List<T>> slist = new ArrayList<>();
		if (listIsNotNull(list)) {
			double m = Math.ceil((double) list.size() / i);
			int lastCount = (int) m - 1;
			List<T> subList;
			for (int count = 0; count < lastCount; count++) {
				subList = list.subList(count * i, (count + 1) * i);
				slist.add(subList);

			}
			if (m > 0) {
				subList = list.subList(lastCount * i, list.size());
				slist.add(subList);
			}
		}
		return slist;
	}
	public static <T> boolean distinguishParameterByCompanyCode(String policyNo,String companyNo,T t,List<T> listEq2,List<T> listEq4) {
		if (StringUtils.isNotBlank(policyNo)) {
			if ("011".equals(companyNo)||StringUtils.isEmpty(companyNo)) {
				listEq2.add(t);
			} else if ("014".equals(companyNo)) {
				listEq4.add(t);
			}
		}
		return true;
	}

	public static String replaceCompanyNo4IL(String companyNo) {
		if (StringUtils.isEmpty(companyNo)||companyNo.equals(PFHConstants.COMPANY_CODE_011)) {
			return PFHConstants.IL_COY_SG;
		} else if (companyNo.equals(PFHConstants.COMPANY_CODE_014)) {
			return PFHConstants.IL_COY_BR;
		}
		
		return companyNo;
	}
}
