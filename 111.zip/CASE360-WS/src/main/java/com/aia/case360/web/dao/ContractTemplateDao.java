package com.aia.case360.web.dao;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import com.aia.case360.web.pojo.ContractTemplateAuditTrail;
import com.aia.case360.web.pojo.ContractTemplateInfo;

public interface ContractTemplateDao {
	
	List<ContractTemplateInfo> queryContractTemplate()  throws RemoteException;
	
	void uploadContractTemplate(Map<String, String> params)  throws RemoteException;
	
	void deleteContractTemplate(List<ContractTemplateInfo> params)  throws RemoteException; 
	
	void addContractTemplateAuditTrail(ContractTemplateAuditTrail contractTemplateAuditTrail)  throws RemoteException;
	
	void batchAddContractTemplateAuditTrail(List<ContractTemplateAuditTrail> auditTrailList)  throws RemoteException;
	
	List<ContractTemplateAuditTrail> queryContractTemplateAuditTrail()  throws RemoteException;
	
	public String getObjectId(String docId)   throws RemoteException;

}
