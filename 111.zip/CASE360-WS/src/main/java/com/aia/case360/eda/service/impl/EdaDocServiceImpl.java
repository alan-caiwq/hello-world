package com.aia.case360.eda.service.impl;

import java.io.IOException;
import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.CreateException;
import javax.naming.NamingException;

import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.aia.case360.common.PDFUtil;
import com.aia.case360.eda.EDAQueryHelper;
import com.aia.case360.eda.ImageUtil;
import com.aia.case360.eda.Tif2Pdf;
import com.aia.case360.eda.dao.EdaDao;
import com.aia.case360.eda.service.EdaDocService;
import com.aia.case360.platform.common.PropertyUtil;
import com.aia.case360.platform.system.InitCase360EJB;
import com.aia.case360.web.common.FileUtil;
import com.aia.case360.web.service.impl.AbstractServiceImpl;
import com.eistream.sonora.fields.FieldPropertiesTO;
import com.eistream.sonora.fields.FmsFieldWs;
import com.eistream.sonora.fields.FmsRowSetWs;
import com.eistream.sonora.fields.FmsRowWs;
import com.eistream.sonora.repository.RepositoryContentStreamTO;
import com.eistream.sonora.repository.RepositoryItemTO;
import com.eistream.sonora.repository.RepositoryPropertyDefinitionTO;
import com.eistream.sonora.repository.RepositoryPropertyRowTO;
import com.eistream.sonora.repository.RepositoryPropertyTO;
import com.eistream.sonora.webservices.WsSessionEJB;
import com.rometools.utils.Lists;

/**
 * 
 * @author bsnpbjy
 *
 */

@Service
@Scope("prototype")
public class EdaDocServiceImpl extends AbstractServiceImpl implements EdaDocService {

	private static final String LOCALQUERYCOUNT = "queryCount";
	private static final String LOCALEDADOCSERVICEIMPL = "EdaDocServiceImpl: ";
	private static final String LOCALRETMESSAGE = "RETMESSAGE";
	private static final String LOCALRETCODE = "RETCODE";
	private static final String LOCALPAGEINDICATOR = "PageIndicator";
	private static final String LOCALTIFSIZE = "TIF_SIZE";
	private static final String LOCALISEXIST = "isExist";
	private final String queryName = PropertyUtil.getCommonProperty("EDA_QUERY_NAMES");
	private final String txtFilePath = PropertyUtil.getCommonProperty("EDA_FAILED_TXTFILE_PATH");
	private final String latestObjectId = PropertyUtil.getCommonProperty("OBJID_INIT");

	@Autowired
	private EdaDao edaDao;

	private Map<String, Object> getIndexMap(byte[] fileImage,String paraStr,Map<String, Object> indexMap) throws IOException {
		try {
			return Tif2Pdf.genBytePDFFromTIF(fileImage, indexMap);
		} catch (Exception e) {
			return ImageUtil.convertImageoPDF(fileImage, paraStr, indexMap);
		}
	}
	@Override
	public Map<String, String> getEx360Image(String objectId, String objectName)
			throws NamingException, RemoteException, CreateException {
		String currentUser = userHelper.getCurrentUser();
		Map<String, String> result = new HashMap<>();
		Map<String, Object> indexMap = new HashMap<String, Object>();
		Map<String, Object> fieldMap = new HashMap<String, Object>();
		String initObjectName = objectName;
		try {
			WsSessionEJB wsEJB = InitCase360EJB.getWsEJB();
			
			if(!StringUtils.isBlank(objectName)&&!objectName.trim().equalsIgnoreCase("NULL")){
				List<Map<String, Object>> lstMap = isDocExist(wsEJB, objectId, objectName, indexMap, fieldMap);						
				if (!Lists.isEmpty(lstMap) ) {
					indexMap = lstMap.get(0);
					fieldMap = lstMap.get(1);
					boolean isExist = (Boolean)isExisting(indexMap,LOCALISEXIST,false);
					if (isExist) {
						getEx360Assist(objectId, objectName, result, indexMap, fieldMap, initObjectName, wsEJB);

					} else {
					  getEx360AssistTwo(result, indexMap, fieldMap, wsEJB, lstMap, objectId, objectName, initObjectName);
					}

				} else {
					addToMigDemand(objectId, initObjectName, result);
				}
			}else{
				addToMigDemand(objectId, initObjectName, result);
			}

		} catch (Exception e) {
			m_Logger.error(e.toString());
			addToMigDemand(objectId, initObjectName, result);
			FileUtil.genFailedObjTxtFile(txtFilePath, objectId + "," + currentUser + "," + (new Date()));
		}

		return result;
	}
  private void getEx360AssistTwo(Map<String, String> result,
      Map<String, Object> indexMap, Map<String, Object> fieldMap,
      WsSessionEJB wsEJB, List<Map<String, Object>> lstMap, String... strParams) throws RemoteException {
	  String objectId = strParams[0];
	  String objectName = strParams[1];
	  String initObjectName = strParams[2];
	  //						if can't retrieve document from Ex10, then try using xObjectName, objectName len lessEqual 44
    						// check xName
    						if(objectName.contains("POS")){
    							objectName = ("x" + objectName).substring(0, 44);
    						}else{
    							objectName = "x" + objectName;
    						}					
    						List<Map<String, Object>> lstxMap = isDocExist(wsEJB, objectId, objectName, indexMap, fieldMap);
    						if (lstxMap != null && !lstxMap.isEmpty()) {
    							indexMap = lstMap.get(0);
    							boolean isxExist = (boolean) indexMap.get(LOCALISEXIST);
    							if (isxExist) {
    								// update control ta.78ble FD_DOC_MIG_CTRL 12 is table
    								// id for FD_DOC_MIG_CTRL
    								edaDao.updateDocMigCtrl(objectName, objectId);
    								
    								if (latestObjectId.compareTo(objectId) > 0) {
    									// update objectName,is_deleted in FD_DOC_ATTRIBUTES
    									edaDao.updateDocAttributes(objectName, objectId);
    
    								} else {
    									// update objectName in FD_DOC_ATTR
    									edaDao.updateDocAttr(objectName, objectId);
    									
    								}
    
    								// update is_deleted in FD_DOC_LINK
    								edaDao.updateDocLink(objectId);
    								
    								//update filestore FS_DOCUMENTS
    								edaDao.updateXFileStore(objectId);
    								
    								
    								result.put(LOCALRETCODE, "02");
    								result.put(LOCALRETMESSAGE, "Doc [" + objectId + "_" + objectName + "] has been deleted in Ex360 side! Kindly contact Administrator pls!" );
    							} else {
    								//insert FD_DOC_MIG_DEMAND
    								addToMigDemand(objectId, initObjectName, result);
    							}
    						} else {
    							//insert FD_DOC_MIG_DEMAND
    							addToMigDemand(objectId, initObjectName, result);
    						}
  }
  private void getEx360Assist(String objectId, String objectName, Map<String, String> result,
      Map<String, Object> indexMap, Map<String, Object> fieldMap, String initObjectName,
      WsSessionEJB wsEJB) throws RemoteException, IOException, InvalidPasswordException {
    BigDecimal documentId;
    Map<String, Object> docParam;
    FmsFieldWs[] rowFWs =  (FmsFieldWs[])isExisting(indexMap,"rowFWs",null);
    if (rowFWs != null) {
    	String strRepositoryKey = rowFWs[(int) fieldMap.get("EX_REPOSITORY_KEY")].getStringValue();
    	m_Logger.info(objectId + " : REPOSITORY_KEY ======" + strRepositoryKey);
    	long iStart = System.currentTimeMillis();
    	m_Logger.info(
    			"EdaDocServiceImpl:" + objectId + " wsEJB.rpGetContent start ========== " + iStart);
    	RepositoryItemTO repItemTo = wsEJB.rpGet(strRepositoryKey);
    	final String keyId = repItemTo.getId();
    	byte[] fileImage = null;
    	fileImage = getDocData(wsEJB, keyId, fileImage);

    	indexMap.put("wsEJB.rpGetContent DateTime", new Date());
    	m_Logger.info("EdaDocServiceImpl:" + objectId + " wsEJB.rpGetContent spend time ========== "
    			+ (System.currentTimeMillis() - iStart));
    	indexMap.put("GET_FIEL_SPENDTIME", (System.currentTimeMillis() - iStart));

    	m_Logger.info(objectId + ": file bytes ======" + fileImage);

    	if (fileImage != null) {
    		// judge if byte image is tif
    		String imageType = "";
    		byte[] fileByte = null;
    		String fileName = "";

    		imageType = receiveImages(fileImage, indexMap);
    		m_Logger.info(objectId + " : image Type ======" + imageType);
    		indexMap.put("imageType", imageType);
    		int numPdfPages = 0;
    		String pageIndicator = "";
    		if (imageType.equalsIgnoreCase("tif") || imageType.equalsIgnoreCase("tiff")) {
    			// convert to pdf
    			indexMap = this.getIndexMap(fileImage, "A4", indexMap);

    			byte[] pdffile = (byte[]) indexMap.get("pdfByte");
    			m_Logger.info(objectId + " : pdf bytes ======" + pdffile);
    			int numTifPages = (int) indexMap.get("TIF_PAGES");
    			m_Logger.info(objectId + " : tif pages ======" + numTifPages);
    			numPdfPages = (int) indexMap.get("PDF_PAGES");
    			m_Logger.info(objectId + " : pdf pages ======" + numPdfPages);
    			int tifSize = (int) indexMap.get(LOCALTIFSIZE);
    			m_Logger.info(objectId + " : tif size ======" + tifSize);
    			// need confirm
    			long pdfSize = (long) indexMap.get("PDF_SIZE");
    			m_Logger.info(objectId + " : pdf size ======" + pdfSize);
    			Date convertDateTime = (Date) indexMap.get("convertDateTime");
    			m_Logger.info(objectId + " : convert date time ======" + convertDateTime);
    			long convertTifToPdfSpendTime = (long) indexMap.get("CONVERT_FIEL_SPENDTIME");
    			m_Logger.info(objectId + " : convert tif to pdf spend time ======"
    					+ convertTifToPdfSpendTime);

    			fileByte = pdffile;
    			imageType = "pdf";

    		} else {
    			fileByte = fileImage;
    			//for pdf
    			pageIndicator = setPDFPageIndicators(indexMap, fileImage, imageType, pageIndicator);
    		}

    		// save to filestore 6 is table id for FS_DOCUMENTS

    		long isf = System.currentTimeMillis();
    		m_Logger.info("EdaDaoImpl: " + objectId + " saveToFileStore start ========== " + isf);

    		fileName = setImageFileName(objectId, objectName, imageType);
    		m_Logger.info(objectId + " : fileName=======" + fileName);

    		documentId = edaDao.saveToFileStore(wsEJB, fileName, fileByte, objectId);

    		indexMap.put("saveToFileStoreDateTime", new Date());
    		m_Logger.info("EdaDaoImpl: " + objectId + " saveToFileStore spend time ========== "
    				+ (System.currentTimeMillis() - isf));
    		indexMap.put("SAVE_FIELSTORE_SPENDTIME", (System.currentTimeMillis() - isf));

    		indexMap.put("FILE_EXT", imageType);
    		indexMap.put("OBJECT_ID", objectId);

    		// get ATTRIBUTES info from EX360
    		docParam = edaDao.selectE360DocAttr(objectId);

    		if (docParam == null) {
    			docParam = new HashMap<String, Object>();
    			docParam.put("OBJECT_ID", objectId);
    			docParam.put("OBJECT_NAME", objectName);
    		}

    		// for filestore FS_DOCUMENTS
    		docParam.put("DOCUMENTID", documentId);
    		docParam.put("FILENAME", fileName);
    		docParam.put("IS_DELETED", 0);
    		// docParam.put("OBJECT_ID", objectId); //exist
    		// CREATE_DATE
    		docParam.put("IS_SYS_VOID", 0);
    		docParam.put("IS_VOID", 0);
    		docParam.put("LAST_UPDATE_BY", "EDASystem");
    		// LAST_UPDATE_TIMESTAMP
    		docParam.put("FILE_EXTENSION", imageType);
    		docParam.put("IS_MIGRATED", 1); // need confirm
    		docParam.put("IS_MOVED", 0); // need confirm
    		docParam.put("SUBMIT_CHANNEL", "EDASystem"); // need confirm
    		//add for pdf
    		setPageIndicatorForPDF(docParam, imageType, pageIndicator);
    		
    		// add for output
    		result.put("DOC_ID", "" + documentId);
    		result.put("PAGE_INDICATOR", (String) docParam.get(LOCALPAGEINDICATOR));
    		result.put("FILE_EXT", "" + imageType);

    		m_Logger.info(objectId + " : update db param : " + docParam.toString());

    		// update control ta.78ble FD_DOC_MIG_CTRL 12 is table
    		// id for FD_DOC_MIG_CTRL

    		edaDao.updateDocMigCtrl(objectName, objectId);

    		// judge if objectId is new or old
    		setAttrFileds(objectId, docParam);

    		edaDao.updateDocFileStore(docParam);

    		// write eda report
    		edaDao.insertEdaReport(indexMap);

    	}

    	//add for output
    	result.put(LOCALRETCODE, "01");
    	result.put(LOCALRETMESSAGE, "");
    	
    } else {
    	//insert FD_DOC_MIG_DEMAND
    	addToMigDemand(objectId, initObjectName, result);
    }
  }

	private void setAttrFileds(String objectId, Map<String, Object> docParam) {
		if (latestObjectId.compareTo(objectId) >= 0) {
			// old objectId
			boolean selectAttrRet = edaDao.selectC360DocAttr(objectId);
			if (!selectAttrRet) {
				//insert FD_DOC_ATTRIBUTES
				boolean insertRet = edaDao.insertDocAttr(docParam);
				if (insertRet) {
					m_Logger.info(objectId + " : insert FD_DOC_ATTRIBUTES one record success .");
				} else {
					m_Logger.info(objectId + " : insert FD_DOC_ATTRIBUTES one record fail .");
				}
			} else {
				m_Logger.info(objectId + " is exist in FD_DOC_ATTRIBUTES.");
				//update FD_DOC_ATTRIBUTES
				boolean updRet = edaDao.updateDocAttributesAll(docParam);
				if (updRet) {
					m_Logger.info(objectId + " : update FD_DOC_ATTRIBUTES one record success .");
				} else {
					m_Logger.info(objectId + " : update FD_DOC_ATTRIBUTES one record fail .");
				}
				
			}
		}else{
			m_Logger.info(objectId + " is new generated by Case360.");
		}
	}

	private void setPageIndicatorForPDF(Map<String, Object> docParam, String imageType, String pageIndicator) {
		if((imageType.equalsIgnoreCase("pdf")&&pageIndicator!=null&&!pageIndicator.isEmpty()) 
			||docParam.get(LOCALPAGEINDICATOR)==null||((String) docParam.get(LOCALPAGEINDICATOR)).isEmpty()){
			docParam.put(LOCALPAGEINDICATOR, pageIndicator);
		}
	}

	private String setImageFileName(String objectId, String objectName, String imageType) {
		String fileName;
		if (imageType.isEmpty()) {
			fileName = objectId + "_" + objectName;
		} else {
			fileName = objectId + "_" + objectName + "." + imageType;
		}
		return fileName;
	}

	private String setPDFPageIndicators(Map<String, Object> indexMap, byte[] fileImage, String imageType,
			String pageIndicator) throws InvalidPasswordException, IOException {
		int numPdfPages;
		if(imageType.equalsIgnoreCase("pdf")){
			numPdfPages = PDFUtil.getPageNumber(fileImage);
			indexMap.put("PDF_PAGES", numPdfPages);
			if(numPdfPages>0){
				for(int i=0;i<numPdfPages;i++){
					pageIndicator += "N";
				}							
			}
		}
		return pageIndicator;
	}

	private byte[] getDocData(WsSessionEJB wsEJB, final String keyId, byte[] fileImage) throws RemoteException {
		RepositoryContentStreamTO rcsTo;
		RepositoryItemTO repItemToImport;
		String importItemKeyId;
		try {
			// for tif
			rcsTo = wsEJB.rpGetContent(keyId);
			if (rcsTo != null) {
				fileImage = rcsTo.getData();
			}

		} catch (Exception e) {
			repItemToImport = wsEJB.rpGet(keyId + "/imports");
			// for NON-TIFF like pdf...
			RepositoryPropertyDefinitionTO[] rpdTos = repItemToImport.getPropertyDefinitions();
			int itemIdIndex = 0;
			for (int k = 0; k < rpdTos.length; k++) {
				if ("itemId".equalsIgnoreCase(rpdTos[k].getName())) {
					itemIdIndex = k;
					break;
				}
			}
			RepositoryPropertyRowTO[] rprTos = repItemToImport.getPropertyRows();
			if (rprTos != null && rprTos.length > 0) {
				RepositoryPropertyTO[] rpts = rprTos[0].getProperties();
				importItemKeyId = rpts[itemIdIndex].getStringValue();
				rcsTo = wsEJB.rpGetContent(importItemKeyId);
				if (rcsTo != null) {
					fileImage = rcsTo.getData();
				}
			}

		}
		return fileImage;
	}

	private Object isExisting(Map<String, Object> indexMap,String fldName, Object defaultVal) {
		return indexMap.get(fldName) == null ? defaultVal : indexMap.get(fldName);
	}

	private String receiveImages(byte[] imageBytes, Map indexMap) {
		long iStart = System.currentTimeMillis();
		m_Logger.info("FileUtil: receiveImagesType start ========== " + iStart);
		String imageType = "";

		int imageSize = FileUtil.getLenFromByte(imageBytes);
		m_Logger.info("FileUtil: file length ======= " + imageSize);
		if (imageSize > 0) {

			/************** get file type start ******************/
			
			imageType = FileUtil.getTypeByStream(imageBytes);
			/************** get file type end ******************/

		}
		if (imageType.equalsIgnoreCase("tif") || imageType.equalsIgnoreCase("tiff")) {
			indexMap.put(LOCALTIFSIZE, imageSize);
		} else {
			indexMap.put(LOCALTIFSIZE, imageSize);
			indexMap.put("PDF_SIZE", imageSize);
		}

		indexMap.put("receiveImagesTypeDateTime", new Date());

		long iEnd = System.currentTimeMillis();
		m_Logger.info("FileUtil: receiveImagesType end ========== " + iEnd);
		m_Logger.info("FileUtil: receiveImagesType spend time ========== " + (iEnd - iStart));
		indexMap.put("receiveImagesTypeSpendTime", (iEnd - iStart));

		return imageType;

	}

	@SuppressWarnings("unchecked")
	private List<Map<String, Object>> isDocExist(WsSessionEJB wsEJB, String objectId, String objectName, Map<String, Object> indexMap,
			Map<String, Object> fieldMap) throws RemoteException{
		List<Map<String, Object>> resultList = new ArrayList<Map<String, Object>>();
		boolean isExist = false;
		try {

			Map<String, String> queryParams = new HashMap<String, String>();

			queryParams.put("EX_OBJECT_NAME", objectName);

			FieldPropertiesTO[] queryParamList = EDAQueryHelper.getQueryParamList(queryParams);
			long isq = System.currentTimeMillis();
			m_Logger.info(LOCALEDADOCSERVICEIMPL + objectId + " doQueryByScriptNameEx start ========== " + isq);
			FmsRowSetWs[] resultRS = wsEJB.doQueryByScriptNameEx(queryName, queryParamList);
			indexMap.put("queryDateTime", new Date());
			m_Logger.info(LOCALEDADOCSERVICEIMPL + objectId + " doQueryByScriptNameEx end ========== "
					+ System.currentTimeMillis());
			m_Logger.info(LOCALEDADOCSERVICEIMPL + objectId + " doQueryByScriptNameEx spend time ========== "
					+ (System.currentTimeMillis() - isq));
			indexMap.put("querySpendTime", (System.currentTimeMillis() - isq));
			if (resultRS != null && resultRS.length != 0) {
				for (int i = 0; i < resultRS[0].getResultFields().length; i++) {
					fieldMap.put(resultRS[0].getResultFields()[i].getFieldName(), i);
				}
				Map<String,Object>map=loopResultRS(resultRS,fieldMap,objectId,indexMap);
				isExist=(boolean) map.get(LOCALISEXIST);
				indexMap=(Map<String, Object>) map.get("indexMap");
			}

			indexMap.put(LOCALISEXIST, isExist);
			
			int queryCount = indexMap.get(LOCALQUERYCOUNT)==null?0:(int) indexMap.get(LOCALQUERYCOUNT);
			
			if(queryCount==0||queryCount>2){
				queryCount = 1;
				indexMap.put(LOCALQUERYCOUNT, queryCount);
				
			}
			
			if(!isExist&&queryCount<2){
				indexMap.clear();
				indexMap.put(LOCALQUERYCOUNT, 2);
				objectName=objectNameFormat(objectName);
				
				resultList = isDocExist(wsEJB,objectId,objectName,indexMap,fieldMap);	
			}else{
				indexMap.put(LOCALQUERYCOUNT, 3);
				resultList.add(indexMap);
				resultList.add(fieldMap);
			}

		} catch (Exception e) {
			m_Logger.error(e.toString());
			throw new RemoteException(e.getMessage(),e);			
		}

		return resultList;
	}
	private Map<String,Object>  loopResultRS(FmsRowSetWs[] resultRS,Map<String, Object> fieldMap,String objectId,Map<String, Object> indexMap){
		FmsRowWs[] rowRWs = null;
		FmsFieldWs[] rowFWs = null;
		Map<String,Object> map=new HashMap<String,Object>();
		boolean isExist = false;
		for (FmsRowSetWs r : resultRS) {
			rowRWs = r.getResultRows();
			for (FmsRowWs s : rowRWs) {
				rowFWs = s.getFieldList();
				String strObjectId = rowFWs[(int) fieldMap.get("EX_OBJECT_ID")].getStringValue();
				if (strObjectId.trim().equalsIgnoreCase(objectId.trim())) {
					isExist = true;
					break;
				}

			}

		}
		indexMap.put("rowFWs", rowFWs);
		map.put(LOCALISEXIST,isExist);
		map.put("indexMap",indexMap);
		return map;
	}
	private String objectNameFormat(String objectName){
		String linkIndicator = null;
		if(objectName.startsWith("x")){
			linkIndicator = objectName.substring(26, 27);
			if(linkIndicator.equalsIgnoreCase("E")){
				objectName = objectName.substring(0, 26) + "P" + objectName.substring(27, objectName.length());
			}else if(linkIndicator.equalsIgnoreCase("P")){
				objectName = objectName.substring(0, 26) + "E" + objectName.substring(27, objectName.length());
			}
		}else{
			linkIndicator = objectName.substring(25, 26);
			if(linkIndicator.equalsIgnoreCase("E")){		
				objectName = objectName.substring(0, 25) + "P" + objectName.substring(26, objectName.length());
			}else if(linkIndicator.equalsIgnoreCase("P")){
				objectName = objectName.substring(0, 25) + "E" + objectName.substring(26, objectName.length());
			}				
		}
		return objectName;
	}
	private void addToMigDemand(String objectId, String initObjectName, Map<String, String> result){
		
		//check if objectId exists in FD_DOC_MIG_DEMAND
		boolean setMigRet = edaDao.selectMigDemand(objectId);
		if(setMigRet){
			//update IS_URGENT = 3
			boolean updMigRet = edaDao.updateMigDemand(objectId);
			if(updMigRet){
				m_Logger.info(objectId + " : update FD_DOC_MIG_DEMAND success .");
			}else{
				m_Logger.info(objectId + " : update FD_DOC_MIG_DEMAND fail .");
			}
			
		}else{
			//set IS_URGENT = 3
			boolean intMigRet = edaDao.insertMigDemand(objectId, initObjectName);
			if (intMigRet) {
				m_Logger.info(objectId + " : insert FD_DOC_MIG_DEMAND success .");
			} else {
				m_Logger.info(objectId + " : insert FD_DOC_MIG_DEMAND fail .");
			}
			
		}
		
		result.put(LOCALRETCODE, "03");
		result.put(LOCALRETMESSAGE, "Document data was changed and need more time to be migrated. Please wait for 20 mins.");
				
	}

}