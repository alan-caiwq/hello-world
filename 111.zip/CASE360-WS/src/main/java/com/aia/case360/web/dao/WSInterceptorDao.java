package com.aia.case360.web.dao;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface WSInterceptorDao {

	public List<Map<String, Object>> queryActiveUser(String userId)  throws RemoteException;

	public List<Map<String, Object>> getUserAuthUrl(@Param("userId") String userId);
	
	public List<String> getAvailableUrlList();
}
