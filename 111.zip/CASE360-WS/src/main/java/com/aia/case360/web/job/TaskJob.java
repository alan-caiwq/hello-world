package com.aia.case360.web.job;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;

import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.web.common.SystemInfo;
import com.aia.case360.web.pojo.DBJobParameter;
import com.aia.case360.web.pojo.OutputVO;
import com.aia.case360.web.service.DBJobService;

/**
 * @Author: huiyun ma
 * @Create Date: 03/02/2018
 */

//@Component("taskJob")
public class TaskJob {
	private Logger m_Logger = LoggerFactory.getLogger(getClass());
	
	private static final String DATE_FORMAT= "yyyyMMdd";
	
	@Autowired
	private DBJobService dBJobService;

	// sync lapse policy from IL
	// @Scheduled(cron = "0 0 0 * * ?")
	public void syncLapsePolicy()  throws RemoteException {
		 LogUtil.logInfo(m_Logger, "syncLapsePolicy job start " + System.currentTimeMillis());
		try {
			Date now = new Date();
			SimpleDateFormat df = new SimpleDateFormat(DATE_FORMAT);
			BigDecimal currentDate = new BigDecimal(df.format(now));
			DBJobParameter dbJobParameter = new DBJobParameter();
			dbJobParameter.setCurrentDate(currentDate);
			dBJobService.syncLapsePolicy(dbJobParameter);
		} catch (Exception e) {
			 
			 LogUtil.logInfo(m_Logger, "syncLapsePolicy job failed ");
		} finally {
			 LogUtil.logInfo(m_Logger, "syncLapsePolicy job end " + System.currentTimeMillis());
		}
	}

	// sync TPD Case info from IL
//	@Scheduled(cron = "0 0 0 * * ?")
	public void syncTPDCaseInfo()  throws RemoteException {
		 LogUtil.logInfo(m_Logger, "syncTPDCaseInfo job start " + System.currentTimeMillis());
		try {
			Date now = new Date();
			SimpleDateFormat df = new SimpleDateFormat(DATE_FORMAT);
			String currentDate = df.format(now);
			if (currentDate != null && currentDate.length() >= 4) {
				currentDate = currentDate.substring(4);
			}
			DBJobParameter dbJobParameter = new DBJobParameter();
			dbJobParameter.setDate(currentDate);
			dBJobService.syncLapsePolicy(dbJobParameter);
		} catch (Exception e) {
			 
			 LogUtil.logInfo(m_Logger, "syncTPDCaseInfo job failed ");
		} finally {
			 LogUtil.logInfo(m_Logger, "syncTPDCaseInfo job end " + System.currentTimeMillis());
		}

	}

	// sync deduction file extracted successfully policy from IL
	// @Scheduled(cron = "0 0 0 * * ?")
	public void syncExtractDeductionFilePolicy()  throws RemoteException {
		 LogUtil.logInfo(m_Logger, "syncExtractDeductionFilePolicy job start " + System.currentTimeMillis());
		try {
			Date now = new Date();
			SimpleDateFormat df = new SimpleDateFormat(DATE_FORMAT);
			String currentDate = df.format(now);
			DBJobParameter dbJobParameter = new DBJobParameter();
			dbJobParameter.setCurrentDate(new BigDecimal(currentDate));
			dBJobService.syncExtractDeductionFilePolicy(dbJobParameter);

		} catch (Exception e) {
			 
			 LogUtil.logInfo(m_Logger, "syncExtractDeductionFilePolicy job failed ");
		} finally {
			 LogUtil.logInfo(m_Logger, "syncExtractDeductionFilePolicy job end " + System.currentTimeMillis());
		}
	}

	// checking IL online status
//    @Scheduled(cron = "0 0 0 * * ?")
	public void checkILOnline()  throws RemoteException {
		 LogUtil.logInfo(m_Logger, "checkILOnline job start " + System.currentTimeMillis());
		OutputVO result = new OutputVO();
		try {
			Date now = new Date();
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String currentDate = df.format(now);
			DBJobParameter dbJobParameter = new DBJobParameter();
			dbJobParameter.setDate(currentDate);
			result = dBJobService.syncILOnlineStatus();
			if (result.getDatas() == null) {
				SystemInfo.setIlOnline_status(false);
			}

		} catch (Exception e) {
			 
			 LogUtil.logInfo(m_Logger, "checkILOnline job failed ");
		} finally {
			 LogUtil.logInfo(m_Logger, "checkILOnline job end " + System.currentTimeMillis());
		}
	}

	// insert clientInfo
//	@Scheduled(cron = "0 0/20 * * * ?")
	public void insertClientInfo()  throws RemoteException {
		 LogUtil.logInfo(m_Logger, "insertClientInfo job start " + System.currentTimeMillis());
	}

	// get policyInfo from OMS
//	@Scheduled(cron = "0 0 0 * * ?")
	public void getPolicyInfoFromOMS()  throws RemoteException {
		 LogUtil.logInfo(m_Logger, "getPolicyInfoFromOMS job start " + System.currentTimeMillis());
		try {
			dBJobService.getPolicyInfoFromOMS();
		} catch (Exception e) {
			 
			 LogUtil.logInfo(m_Logger, "getPolicyInfoFromOMS job failed ");
		} finally {
			 LogUtil.logInfo(m_Logger, "getPolicyInfoFromOMS job end " + System.currentTimeMillis());
		}
	}


	/**
	 * call stored procedure to count requestType and update CF_WORK requestType
	 * 
	 * @ throws RemoteException
	 * @author bsnpc37(Leo Li)
	 * @date: May 4, 2018 3:20:21 PM
	 */
//	@Scheduled(cron = "0 0/20 * * * ?")
	public void jobFindRequestType()  throws RemoteException {
		 LogUtil.logInfo(m_Logger, "jobFindRequestType job start " + System.currentTimeMillis());
		try {
			dBJobService.jobFindRequestType();
		} catch (Exception e) {
			 
			 LogUtil.logInfo(m_Logger, "jobFindRequestType job failed ");
		} finally {
			 LogUtil.logInfo(m_Logger, "jobFindRequestType job end " + System.currentTimeMillis());
		}
	}

	// generate svs letter for OMS
//	@Scheduled(cron = "0 0/5 * * * ?")
	public void svsNotification()  throws RemoteException {
		 LogUtil.logInfo(m_Logger, "svsNotification job start " + System.currentTimeMillis());
		try {
			dBJobService.getSVSNotificationLetter();
		} catch (Exception e) {
			 
			 LogUtil.logInfo(m_Logger, "svsNotification job failed ");
		} finally {
			 LogUtil.logInfo(m_Logger, "svsNotification job end " + System.currentTimeMillis());
		}
	}

	// sync UNI policy status in (Inforce/Withdrawn/Non Taken/Decline/Postpone) and
	// closeCase
//	@Scheduled(cron = "0 0 0 * * ?")
	public void syncPolicyStatusAutoClosedCase()  throws RemoteException {
		 LogUtil.logInfo(m_Logger, "syncPolicyStatusAutoClosedCase job start " + System.currentTimeMillis());
		try {
			dBJobService.syncPolicyStatusAutoClosedCase();
		} catch (Exception e) {
			 
			 LogUtil.logInfo(m_Logger, "syncPolicyStatusAutoClosedCase job failed ");
		} finally {
			 LogUtil.logInfo(m_Logger, "syncPolicyStatusAutoClosedCase job end " + System.currentTimeMillis());
		}
	}

	// sync closed Case CWA from IL
	@Scheduled(cron = "0 0 0 * * ?")
	public void syncCWAdetails()  throws RemoteException {
		 LogUtil.logInfo(m_Logger, "syncCWAdetails job start " + System.currentTimeMillis());
		try {
			dBJobService.syncCWAdetails();
		} catch (Exception e) {
			 
			 LogUtil.logInfo(m_Logger, "syncCWAdetails job failed ");
		} finally {
			 LogUtil.logInfo(m_Logger, "syncCWAdetails job end " + System.currentTimeMillis());
		}
	}

//	@Scheduled(cron = "0 0/20 * * * ?")
	public void syncEDocNotification()  throws RemoteException {
		 LogUtil.logInfo(m_Logger, "syncEDocNotification job start " + System.currentTimeMillis());
		try {
			dBJobService.syncEDocNotification();
		} catch (Exception e) {
			 LogUtil.logInfo(m_Logger, "syncEDocNotification job failed ");
		} finally {
			 LogUtil.logInfo(m_Logger, "syncEDocNotification job end " + System.currentTimeMillis());
		}
	}

	// sync Policy Expire
//	@Scheduled(cron = "0 0 0 * * ?")
	public void syncCPFADVFlag()  throws RemoteException {
		 LogUtil.logInfo(m_Logger, "syncCPFADVFlag() job start " + System.currentTimeMillis());
		try {
			dBJobService.syncCPFADVFlag();
		} catch (Exception e) {
			 
			 LogUtil.logInfo(m_Logger, "syncCPFADVFlag() job failed ");
		} finally {
			 LogUtil.logInfo(m_Logger, "syncCPFADVFlag() job end " + System.currentTimeMillis());
		}
	}

	// sync short payment amount from IL
	// @Scheduled(cron = "0 0 0 * * ?")
//	@Scheduled(cron = "0 0/10 * * * ?")
	public void syncSuspense()  throws RemoteException {
		 LogUtil.logInfo(m_Logger, "syncSuspense job start " + System.currentTimeMillis());
		try {
			dBJobService.syncSuspense();
		} catch (Exception e) {
			 
			 LogUtil.logInfo(m_Logger, "syncSuspense job failed ");
		} finally {
			 LogUtil.logInfo(m_Logger, "syncSuspense job end " + System.currentTimeMillis());
		}
	}

}