package com.aia.case360.platform.common;

import java.util.HashMap;
import java.util.Map;

public final class ResultDataUtil {

	private static final String LOCALRESPONSE_DESC = "RESPONSE_DESC";

	enum RESULTCODE {
		INITIAL, SUCCESS, FAILURE
	};

	/**
	 * Convert all return result into 3 parts: ResultCode:1 or 2; return Data;
	 * ResultMessage
	 * 
	 * @param isSuccess : 0 SUCESS, 1 FAILURE
	 * @param rData     :
	 * @param inputMsg
	 * @return
	 */
	public static Map<String, Object> convertResult(boolean isSuccess, Object rData, Object inputMsg) {

		Map<String, Object> result = new HashMap<String, Object>();
		if (isSuccess) {
			result.put("RESPONSE_CD", "0");
		} else {
			result.put("RESPONSE_CD", "1");
		}

		if (null != rData) {
			try {
				result.put("DATA", rData);
			} catch (Exception e) {
				result.put("DATA", rData);
			}
		} else {
			result.put("DATA", "");
		}

		if (null != inputMsg) {
			try {
				result.put(LOCALRESPONSE_DESC, inputMsg);
			} catch (Exception e) {
				result.put(LOCALRESPONSE_DESC, inputMsg);
			}
		} else {
			result.put(LOCALRESPONSE_DESC, "");
		}

		return result;
	}

}