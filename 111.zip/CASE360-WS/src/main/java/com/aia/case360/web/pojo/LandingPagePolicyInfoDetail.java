package com.aia.case360.web.pojo;

public class LandingPagePolicyInfoDetail {
	private String policyNo;
	private String PHName;
	private String PHClientNo;
	private String contractName;
	private String polOrCompRiskStat;
	private String polOrPremiumRiskStat;
	private String role;
	private String lifeAssuredName;
	private String PTD;
	private String coverStartDate;
	private String reinstDate;
	private String excln;
	private String benefitAmount;
	private String proposalDate;
	private String lapsedDate;
	private String terminateDate;
	private String effectDate;
	
	private static final String LAST_DATE = "99/99/9999";
	private static final String OTHER_DATE = "/  /0";

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getPHName() {
		return PHName;
	}

	public void setPHName(String pHName) {
		PHName = pHName;
	}

	public String getPHClientNo() {
		return PHClientNo;
	}

	public void setPHClientNo(String pHClientNo) {
		PHClientNo = pHClientNo;
	}

	public String getContractName() {
		return contractName;
	}

	public void setContractName(String contractName) {
		this.contractName = contractName;
	}

	public String getPolOrCompRiskStat() {
		return polOrCompRiskStat;
	}

	public void setPolOrCompRiskStat(String polOrCompRiskStat) {
		this.polOrCompRiskStat = polOrCompRiskStat;
	}

	public String getPolOrPremiumRiskStat() {
		return polOrPremiumRiskStat;
	}

	public void setPolOrPremiumRiskStat(String polOrPremiumRiskStat) {
		this.polOrPremiumRiskStat = polOrPremiumRiskStat;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getLifeAssuredName() {
		return lifeAssuredName;
	}

	public void setLifeAssuredName(String lifeAssuredName) {
		this.lifeAssuredName = lifeAssuredName;
	}

	public String getPTD() {
		return PTD;
	}

	public void setPTD(String pTD) {
		if (pTD == null || (pTD.contains(LAST_DATE) || pTD.contains(OTHER_DATE))) {
			this.PTD = null;
		} else {
			this.PTD = pTD;
		}

	}

	public String getCoverStartDate() {
		return coverStartDate;
	}

	public void setCoverStartDate(String coverStartDate) {
		if (coverStartDate == null || (coverStartDate.contains(LAST_DATE) || coverStartDate.contains(OTHER_DATE))) {
			this.coverStartDate = null;
		} else {
			this.coverStartDate = coverStartDate;
		}
	}

	public String getReinstDate() {
		return reinstDate;
	}

	public void setReinstDate(String reinstDate) {
		if (reinstDate == null || (reinstDate.contains(LAST_DATE) || reinstDate.contains(OTHER_DATE))) {
			this.reinstDate = null;
		} else {
			this.reinstDate = reinstDate;
		}
	}

	public String getExcln() {
		return excln;
	}

	public void setExcln(String excln) {
		this.excln = excln;
	}

	public String getBenefitAmount() {
		return benefitAmount;
	}

	public void setBenefitAmount(String benefitAmount) {
		this.benefitAmount = benefitAmount;
	}

	public String getProposalDate() {
		return proposalDate;
	}

	public void setProposalDate(String proposalDate) {
		if (proposalDate == null || (proposalDate.contains(LAST_DATE) || proposalDate.contains(OTHER_DATE))) {
			this.proposalDate = null;
		} else {
			this.proposalDate = proposalDate;
		}
	}

	public String getLapsedDate() {
		return lapsedDate;
	}

	public void setLapsedDate(String lapsedDate) {
		if (lapsedDate == null || (lapsedDate.contains(LAST_DATE) || lapsedDate.contains(OTHER_DATE))) {
			this.lapsedDate = null;
		} else {
			this.lapsedDate = lapsedDate;
		}
	}

	public String getTerminateDate() {
		return terminateDate;
	}

	public void setTerminateDate(String terminateDate) {
		if (terminateDate == null || (terminateDate.contains(LAST_DATE) || terminateDate.contains(OTHER_DATE))) {
			this.terminateDate = null;
		} else {
			this.terminateDate = terminateDate;
		}

	}

	public String getEffectDate() {
		return effectDate;
	}

	public void setEffectDate(String effectDate) {
		if (effectDate == null || (effectDate.contains(LAST_DATE) || effectDate.contains(OTHER_DATE))) {
			this.effectDate = null;
		} else {
			this.effectDate = effectDate;
		}

	}

}
