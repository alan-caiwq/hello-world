package com.aia.case360.ilClaim.service.impl;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.aia.case360.ilClaim.dao.AssessBean;
import com.aia.case360.ilClaim.service.AssessService;

@Service
public class AssessServiceImpl implements AssessService {

	private AssessBean assessDao = new AssessBean();

	@Override
	public List<Map<String, String>> getClaimStatus(String policyNo, String matherClaimNo, String childClaimNo)
			 throws SQLException {
		List<Map<String, String>> result = null;
		Map<String, String> params = new HashMap<String, String>();
		String childClaimNos = "";
		if (null != policyNo && policyNo.length() > 0) {

			params.put("policyNo", policyNo);
			params.put("matherClaimNo", matherClaimNo);
			if (null != childClaimNo && childClaimNo.length() > 0) {
				childClaimNos = childClaimNo.replaceAll(",", "','");
			}
			params.put("childClaimNo", "'" + childClaimNos + "'");

			return assessDao.getClaimStatus(params);
		} else {
			return result;
		}
	}

}
