package com.aia.case360.web.common;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.common.PropertyUtil;
import com.aia.case360.platform.common.ScriptUtil;
import com.aia.case360.web.exception.CustomException;
import com.aia.case360.web.service.impl.AbstractHelperImpl;

public class ParamsUtil extends AbstractHelperImpl {

	private static final String THE_PARAMETER_NAME_IS_NULL_PLEASE_SEND_IT_NOT_NULL = "the parameter name is null, please send it not null";
	public static final Logger m_Logger_static = LoggerFactory.getLogger(ParamsUtil.class);

	public static String validateParams(Map<String, String> params, String serviceName, List<String> validateStrs) {
		String errorInfo = null;
		try {
			if (params.isEmpty()) {
				LogUtil.logInfo(m_Logger_static,"params is null");
				errorInfo = THE_PARAMETER_NAME_IS_NULL_PLEASE_SEND_IT_NOT_NULL;
			}
			if (validateStrs != null && validateStrs.size() > 0) {
				for (String tempVal : validateStrs) {
					if (!params.containsKey(tempVal) || StringUtils.isEmpty(params.get(tempVal).toString())) {
						LogUtil.logInfo(m_Logger_static,serviceName + tempVal + " is null");
						errorInfo = "the " + tempVal + " is null, please send it not null";
					}
				}
			}
		} catch (Exception e) {
			 
			errorInfo = "validation error " + e.getMessage();
		}
		return errorInfo;

	}

	/**
	 * @param params
	 * @param validateStrs list to be validated not null
	 * @ throws RemoteException
	 */
	public static String validateParams(Map<String, String> params, List<String> validateStrs)  throws RemoteException {
		String result = null;
		if (params.isEmpty()) {
			throw new CustomException(THE_PARAMETER_NAME_IS_NULL_PLEASE_SEND_IT_NOT_NULL, HttpStatus.BAD_REQUEST);
		}
		if (validateStrs != null && validateStrs.size() > 0) {
			for (String tempVal : validateStrs) {
				if (!params.containsKey(tempVal) || "".equals(params.get(tempVal)) || params.get(tempVal) == null) {
					result = tempVal;
					return result;
				}
			}
		}
		return result;
	}

	/**
	 * @param params
	 * @param validateStrs list to be validated not null
	 * @ throws RemoteException
	 */
	public static void validateParamsThrowException(Map<String, String> params, List<String> validateStrs)
			 throws RemoteException {

		if (params.isEmpty()) {
			throw new CustomException(THE_PARAMETER_NAME_IS_NULL_PLEASE_SEND_IT_NOT_NULL, HttpStatus.BAD_REQUEST);
		}
		if (validateStrs != null && validateStrs.size() > 0) {
			for (String tempVal : validateStrs) {
				if (!params.containsKey(tempVal) || StringUtils.isEmpty(params.get(tempVal).toString())) {
					throw new CustomException(tempVal + " is null, please send it not null", HttpStatus.BAD_REQUEST);
				}
			}
		}

	}

	/**
	 * validate magnumDecision
	 * 
	 * @param magnumDecision
	 * @return
	 * @author bsnpc37
	 * @date: 2018-4-9 18:30:15
	 */
	public static boolean isMagnumDecision(String magnumDecision) {
		if ("Unavail".equals(magnumDecision) || "Loaded".equals(magnumDecision) || "Standard".equals(magnumDecision)
				|| "Exclusion".equals(magnumDecision) || "Refer".equals(magnumDecision)
				|| "Requirements".equals(magnumDecision) || "Decline".equals(magnumDecision))
			return true;
		return false;
	}

	/**
	 * validate companyNo
	 * 
	 * @param companyNo
	 * @return
	 * @author bsnpc37
	 * @date: 2018-4-9 18:34:00
	 */
	public static boolean isCompanyNo(String companyNo) {
		if ("011".equals(companyNo) || "014".equals(companyNo))
			return true;
		return false;
	}

	/**
	 * Valadate DateTime
	 * 
	 * @param dateTime
	 * @return
	 * @author bsnpc37
	 * @date: 2018-4-9 18:48:47
	 */
	public static boolean isValadateDateTime(String dateTime) {
		boolean convertSuccess = true;
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		try {
			format.setLenient(false);
			format.parse(dateTime);
		} catch (ParseException e) {
			//  
			convertSuccess = false;
		}
		return convertSuccess;
	}

	/**
	 * Valadate Date
	 * 
	 * @param date
	 * @return
	 * @author bsnpc37
	 * @date: 2018-4-9 6:49:19
	 */
	public static boolean isValadateDate(String date) {
		boolean convertSuccess = true;
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		try {
			format.setLenient(false);
			format.parse(date);
		} catch (ParseException e) {
			//  
			convertSuccess = false;
		}
		return convertSuccess;
	}

	/**
	 * validate requestNo
	 * 
	 * @param requestNo
	 * @return
	 * @author bsnpc37
	 * @date: 2018-4-10 10:39:06
	 */
	public static boolean isValidateRequestNo(String requestNo) {
		if (requestNo != null && (requestNo.startsWith("POS") || requestNo.startsWith("UNI")
				|| requestNo.startsWith("CLM") || requestNo.startsWith("HNW") || requestNo.startsWith("CS")
				|| requestNo.startsWith("SOS") || requestNo.startsWith("TMP")))
			return true;
		return false;
	}

	/**
	 * validate parentRequestNo
	 * 
	 * @param parentRequestNo
	 * @return
	 * @author bsnpc37
	 * @date: 2018-4-10 10:39:23
	 */
	public static boolean isValidateParentRequestNo(String parentRequestNo) {
		if (parentRequestNo != null && (parentRequestNo.startsWith("POS") || parentRequestNo.startsWith("UNI")
				|| parentRequestNo.startsWith("CLM") || parentRequestNo.startsWith("HNW")
				|| parentRequestNo.startsWith("CS") || parentRequestNo.startsWith("SOS")
				|| parentRequestNo.startsWith("TMP")))
			return true;
		return false;
	}

	/**
	 * 
	 * @param params
	 * @param validateStrs
	 * @return
	 * @ throws RemoteException
	 * @date: 6:45:05 PM , May 4, 2018
	 * @author: bsnpc57
	 */
	public static boolean validate_MapParams(Map<String, String> params, List<String> validateStrs)  throws RemoteException {
		if (params.isEmpty()) {
			throw new CustomException(THE_PARAMETER_NAME_IS_NULL_PLEASE_SEND_IT_NOT_NULL, HttpStatus.BAD_REQUEST);
		}
		boolean fig = false;
		if (validateStrs != null && validateStrs.size() > 0) {
			for (String tempVal : validateStrs) {
				if (params.containsKey(tempVal) && params.size() == validateStrs.size()) {
					fig = true;
				}
			}
		}
		return fig;
	}

	public static boolean isValidateRequestNoType(String requestNoType, String requestParams) {
		switch (requestNoType) {
		case "callingSystem":
			return requestNoTypeEqCallingSys(requestParams);
		case "policyNo":
			// CALL SCRIPT_DO_POLICY_FORMAT
			return requestTypeEqPolicyNo(requestParams);
		case "processName"://
			return requestNoTypeEqProcessName(requestParams);
		case "caseStatus"://
			return requestNoTypeEqCaseStatus(requestParams);
		case "codeCategory":
			return requestNoTypeEqCodeCategory(requestParams);
		case "uwid":
			return requestNoTypeEqUwid(requestParams);
		case "paymentMode":
			return requestNoTypeEqPaymentMode(requestParams);
		case "userCode":
			return requestNoTypeEqUserCode(requestParams);
		case "signatureVerifyFlag":
			return requestNoTypeEqSignature(requestParams);
		case "pasName":
			return requestNoTypeEqPasName(requestParams);
		case "bigDecimal":
			return requestNoTypeEqBigDecimal(requestParams);
		default:
			return false;
		}

	}

	private static boolean requestNoTypeEqBigDecimal(String requestParams) {
		try {
			new BigDecimal(requestParams);
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	private static boolean requestNoTypeEqPasName(String requestParams) {
		if (PFHConstants.PASNAME_IL.equals(requestParams) || PFHConstants.PASNAME_PLAS.equals(requestParams)
				|| PFHConstants.PASNAME_HIAS.equals(requestParams))
			return true;
		return false;
	}

	private static boolean requestNoTypeEqSignature(String requestParams) {
		if ("0".equals(requestParams) || "1".equals(requestParams) || "2".equals(requestParams)
				|| "3".equals(requestParams))
			return true;
		return false;
	}

	private static boolean requestNoTypeEqUserCode(String requestParams) {
		if (requestParams != null && requestParams.length() == 5 && requestParams.matches("[0-9]+")) {
			return true;
		}
		return false;
	}

	private static boolean requestNoTypeEqPaymentMode(String requestParams) {
		if ("R".equalsIgnoreCase(requestParams) || "O".equalsIgnoreCase(requestParams) || "S".equalsIgnoreCase(requestParams)
				|| "Q".equalsIgnoreCase(requestParams) || "V".equalsIgnoreCase(requestParams) || "M".equalsIgnoreCase(requestParams)) {
			return true;
		}
		return false;
	}

	private static boolean requestNoTypeEqUwid(String requestParams) {
		if ("SPIPOSSP".equals(requestParams) || "SPIPOSST".equals(requestParams)
				|| "SPIPOS24".equals(requestParams)) {
			return true;
		}
		return false;
	}

	private static boolean requestNoTypeEqCodeCategory(String requestParams) {
		String codecategories = "POS,UNI,CLM,MCS";
		String[] codecategoryArray = codecategories.split(",");
		if (Arrays.asList(codecategoryArray).contains(requestParams)) {
			return true;
		}
		;
		return false;
	}

	private static boolean requestNoTypeEqCallingSys(String requestParams) {
		String callingSystems = "IL,iPoS,iDES,ECare,STP-PORTAL,TrustedHub,OMS,eDoc,eCabinet,eCommerce,ServiceTracking,"
				+ "AgIA,AgIAMinorClaims,Case360,eScan";
		String[] callingSystemArray = callingSystems.split(",");
		if (Arrays.asList(callingSystemArray).contains(requestParams)) {
			return true;
		}
		;
		return false;
	}

	private static boolean requestNoTypeEqCaseStatus(String requestParams) {
		List<String> caseStatus = new ArrayList<String>();
		caseStatus.add("Draft");
		caseStatus.add("Pending");
		caseStatus.add("In-Progress");
		caseStatus.add("Close");
		List<String> caseStatuses = new ArrayList<String>();
		if (requestParams.indexOf(',') != -1) {
			caseStatuses = Arrays.asList(requestParams.split(","));
		} else {
			caseStatuses.add(requestParams);
		}
		for (String requestParam : caseStatuses) {
			if (!caseStatus.contains(requestParam)) {
				return false;
			}
			;
		}
		;
		return true;
	}

	private static boolean requestNoTypeEqProcessName(String requestParams) {
		List<String> processNames = new ArrayList<String>();
		processNames.add("POS");
		processNames.add("UNI");
		processNames.add("CLM");
		List<String> requestParamss = new ArrayList<String>();
		if (requestParams.indexOf(',') != -1) {
			requestParamss = Arrays.asList(requestParams.split(","));
		} else {
			requestParamss.add(requestParams);
		}
		for (String requestParam : requestParamss) {
			if (!processNames.contains(requestParam)) {
				return false;
			}
			;
		}
		;
		return true;
	}

	private static boolean requestTypeEqPolicyNo(String requestParams) {
		HashMap<String, String> policyNOFormatParams = new HashMap<String, String>();
		policyNOFormatParams.put("policyNum", requestParams);
		try {
			Map<String, Object> policyNOFormatResult = ScriptUtil.doScript(
					PropertyUtil.getScriptAndQueryProperty("SCRIPT_DO_POLICY_FORMAT"), policyNOFormatParams,
					Locale.CHINA, getSysSEJB());
			return Boolean.parseBoolean(policyNOFormatResult.get("result").toString());
		} catch (Exception e) {
			 
			return false;
		}
	}

}
