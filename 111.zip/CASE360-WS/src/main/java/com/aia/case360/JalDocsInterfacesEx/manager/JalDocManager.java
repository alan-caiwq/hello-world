package com.aia.case360.JalDocsInterfacesEx.manager;

import java.io.File;
import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aia.case360.JalDocsInterfacesEx.dao.JalDocDao;
import com.aia.case360.JalDocsInterfacesEx.util.JALUtil;
import com.aia.case360.JalDocsInterfacesEx.util.StrUtil;
import com.aia.case360.JalDocsInterfacesEx.vo.InputParamVo;
import com.aia.case360.JalDocsInterfacesEx.vo.PolNumReqs;
import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.common.PropertyUtil;
import com.aia.case360.web.common.FileUtil;
import com.eistream.jal.JalClient;
import com.eistream.jal.JalClientList;
import com.eistream.jal.JalClientListItem;
import com.eistream.jal.JalConst;
import com.eistream.jal.JalDocument;
import com.eistream.jal.JalException;
import com.eistream.jal.JalFormField;
import com.eistream.jal.JalFormFields;
import com.eistream.jal.JalObjID;
import com.eistream.jal.JalWorkitem;
import com.eistream.jal.JalWorkitemInfo;

@Service
public class JalDocManager {

	private static final String IS_VOID = "isVoid";

	private static final String IS_DELETED = "isDeleted";

	private static final String PROCESS_TYPE = "ProcessType";
	
	private static final String LOWER_PROCESS_TYPE = "processType";

	private static final String RECEIVED_DATE = "ReceivedDate";
	
	private static final String LOWER_RECEIVED_DATE = "receivedDate";

	private static final String POLICY_NO = "PolicyNo";
	
	private static final String LOWER_POLICY_NO = "policyNo";

	private static final String FORM_ID = "formId";
	
	private static final String UPPER_FORM_ID = "FormId";

	private static final String REQUEST_NO = "RequestNo";
	
	private static final String LOWER_REQUEST_NO = "requestNo";

	private static final String COMPANY_NO = "CompanyNo";
	
	private static final String LOWER_COMPANY_NO = "companyNo";

	private static final String STATUS_INDICATOR = "StatusIndicator";
	
	private static final String LOWER_STATUS_INDICATOR = "statusIndicator";

	private static final String LINK_INDICATOR = "LinkIndicator";
	
	private static final String LOWER_LINK_INDICATOR = "linkIndicator";

	private static final String PAGE_INDICATOR = "pageIndicator";
	
	private static final String UPPER_PAGE_INDICATOR = "PageIndicator";

	private static final String FILE_EXTENSION_TIF = "TIF";

	private static final String DELETE_STATUS = "S";

	private static final String VOID_STATUS = "V";

	private Logger m_Logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private JalDocDao jalDao;

	@Autowired
	private JalLogicalLinkDocManager jalLogicalLinkDocManager;

	@Autowired
	private JalObjectDefManager jalObjectDefManager;

	@Autowired
	private JalFormFieldsManager jalFormFieldsManager;

	@Autowired
	private JALUtil jalUtil;

	private String txtFailedVoidFilePath = PropertyUtil.getCommonProperty("JAL_FAILED_VOID_OBJECTID_PATH");

	private String DOC_TYPE = null; // del static
	private String IMPORT_CLASS = null; // del static
	private String defDocClasses = null;
	private JalClient jalClient = null;
	private String strDocClass = null;
	private Map parFormFieldsMap = null;

	private static final String EXITPROC = " : exit process";

	public String getStrDocClass() {
		return strDocClass;
	}

	public void setStrDocClass(String strDocClass) {
		this.strDocClass = strDocClass;
	}

	public Map getParFormFieldsMap() {
		return parFormFieldsMap;
	}

	public void setParFormFieldsMap(Map parFormFieldsMap) {
		this.parFormFieldsMap = parFormFieldsMap;
	}

	/**
	 * Create a document
	 * 
	 * @param params
	 * @return objectId @ throws RemoteException
	 */
	public Map<String, Object> process(InputParamVo params) throws RemoteException {

		m_Logger.info(this.getClass().getSimpleName() + " : enter process");

		Map<String, Object> resultMap = new HashMap<String, Object>();

		List<PolNumReqs> polNumReqsList = params.getPolNumReqs();

		JalDocument jalDoc = null;
		String objectId = null;
		String objectName = null;

		try {
			jalClient = jalUtil.initJalClient();
			if (jalClient == null) {
				return null;
			} else {
				constructPolReqList(polNumReqsList, params);

				// init info
				boolean isSuccess = init(params);

				if (isSuccess) {
					m_Logger.error("process() init successful");
					jalDoc = constructJalDoc(jalDoc, params);

					if (jalDoc != null) {
						// create logical link
						objectId = jalDoc.getInfo().getObjID().getInternalName();
						objectName = jalDoc.getInfo().getName();
					} else {
						objectId = getObjectId(params);
					}

					List<Map> logicalLinkInfoList = jalLogicalLinkDocManager.procLogicalLinks(params, objectId);

					resultMap.put("objectId", objectId);
					resultMap.put("objectName", objectName);
					resultMap.put("logicalLinkInfoList", logicalLinkInfoList);

				} else {
					m_Logger.error("process() init failed");
					return null;
				}
			}

		} catch (Exception e) {
			try {
				jalUtil.jalClientDestroy();
			} catch (Exception ex) {
				m_Logger.info("Jal client destroy fail");
			}
			resultMap = null;
			m_Logger.error("process failed:", e);
		} finally {
			try {
				jalUtil.jalClientDestroy();
			} catch (Exception e) {
				m_Logger.info("Jal client destroy fail");
			}
		}

		m_Logger.info(this.getClass().getSimpleName() + EXITPROC);

		return resultMap;
	}

	private String getObjectId(InputParamVo params) {
		if ("I".equalsIgnoreCase(params.getsFlag())) {
			return null;
		} else {
			return params.getCaseObjectId();
		}
	}

	private JalDocument constructJalDoc(JalDocument jalDoc, InputParamVo params) throws RemoteException {
		if ("I".equalsIgnoreCase(params.getsFlag())) {
			// Import
			try {
				jalDoc = createDocument(params);
			} catch (JalException e) {
				throw new RemoteException(e.getMessage());
			}
		} else if ("R".equalsIgnoreCase(params.getsFlag())) {

			Map firstLogicLinkIdInfo = getParentInfo(params);
			if (firstLogicLinkIdInfo != null) {
				// get the first case in DOC Link Table, and then update in
				// Attributes
				jalDoc = updateAttrReindexDocument(params, firstLogicLinkIdInfo);
			}

		}
		return jalDoc;
	}

	private void constructPolReqList(List<PolNumReqs> polNumReqsList, InputParamVo params) throws ParseException {
		SimpleDateFormat out = new SimpleDateFormat("MMddyyyy");
		m_Logger.info("process: object id:=" + params.getCaseObjectId());
		for (PolNumReqs polNumReq : polNumReqsList) {
			String receivedDate = polNumReq.getReceivedDate();
			if (receivedDate == null || receivedDate.isEmpty()) {
				receivedDate = out.format(new Date());
			} else {
				SimpleDateFormat in = new SimpleDateFormat("yyyy-MM-dd");
				receivedDate = out.format(in.parse(receivedDate));
			}
			polNumReq.setReceivedDate(receivedDate);
		}
	}

	/**
	 * Create a document
	 * 
	 * @param params
	 * @return objectId
	 * @throws JalException
	 * @ throws RemoteException
	 */
	public JalDocument createDocument(InputParamVo params) throws RemoteException, JalException {

		m_Logger.info(this.getClass().getSimpleName() + " : enter createDocument");

		JalDocument jalDoc = null;

		jalDoc = jalCreation(params);
		m_Logger.info(this.getClass().getSimpleName() + " : exit createDocument");

		return jalDoc;
	}

	/**
	 * update attributes, use first logic link id
	 * 
	 * @param params
	 * @return objectId @ throws RemoteException
	 */
	public JalDocument updateAttrReindexDocument(InputParamVo params, Map firstLogicLinkIdInfo) {

		m_Logger.info(this.getClass().getSimpleName() + " : start process");
		JalDocument jalDocument = null;
		JalWorkitem workitem = this.createClient(params.getCaseObjectId());
		jalDocument = (JalDocument) workitem;
		JalWorkitemInfo jalWorkItemInfo = null;
		try {
			jalWorkItemInfo = jalDocument.getInfo();
			m_Logger.info("Document befor update ObjectName Value:" + jalWorkItemInfo.getName());
			JalFormFields formFields = jalDocument.getFormFields(JalConst.JAL_FIELDS_NO_VIEWS);
			JalFormField jalFormField_policyNo = formFields.find(POLICY_NO);
			JalFormField jalFormField_formId = formFields.find(UPPER_FORM_ID);
			JalFormField jalFormField_receivedDate = formFields.find(RECEIVED_DATE);
			JalFormField jalFormField_requestNo = formFields.find(REQUEST_NO);
			JalFormField jalFormField_companyNo = formFields.find(COMPANY_NO);
			JalFormField jalFormField_processType = formFields.find(PROCESS_TYPE);
			JalFormField jalFormField_statusIndicator = formFields.find(STATUS_INDICATOR);
			JalFormField jalFormField_linkIndicator = formFields.find(LINK_INDICATOR);

			m_Logger.info("firstLogicLinkIdInfo.get receivedDate" + firstLogicLinkIdInfo.get(LOWER_RECEIVED_DATE));
			jalFormField_policyNo.setValue(StrUtil.nullToEmptyForObject(firstLogicLinkIdInfo.get(LOWER_POLICY_NO)));
			jalFormField_formId.setValue(StrUtil.nullToEmptyForObject(firstLogicLinkIdInfo.get(FORM_ID)));
			jalFormField_receivedDate.setValue(firstLogicLinkIdInfo.get(LOWER_RECEIVED_DATE) == null ? ""
					: (String) firstLogicLinkIdInfo.get(LOWER_RECEIVED_DATE));
			jalFormField_requestNo.setValue(StrUtil.nullToEmptyForObject(firstLogicLinkIdInfo.get(LOWER_REQUEST_NO)));
			jalFormField_companyNo.setValue(StrUtil.nullToEmptyForObject(firstLogicLinkIdInfo.get(LOWER_COMPANY_NO)));
			jalFormField_processType.setValue(StrUtil.nullToEmptyForObject(firstLogicLinkIdInfo.get(LOWER_PROCESS_TYPE)));

			// status indicator & link indicator need get from Case360
			// Attributes table for object_name
			String statusIndicator = "";
			short isDeleted = firstLogicLinkIdInfo.get(IS_DELETED) == null ? 0
					: (short) firstLogicLinkIdInfo.get(IS_DELETED);
			short isVoid = firstLogicLinkIdInfo.get(IS_VOID) == null ? 0 : (short) firstLogicLinkIdInfo.get(IS_VOID);

			if (isDeleted == 0) {
				if (isVoid == 1) {
					statusIndicator = VOID_STATUS;
				} else {
					statusIndicator = "N";
				}
			} else if (isDeleted == 1) {
				statusIndicator = DELETE_STATUS;
			}

			jalFormField_statusIndicator.setValue(statusIndicator);

			params.setStatusIndicator(statusIndicator);
			params.setLinkIndicator(StrUtil.nullToEmptyForObject(jalFormField_linkIndicator.getValue()));

			jalDocument.setName(getObjName(params, DOC_TYPE));

			workitem.save();
			workitem.destroy(JalConst.JAL_DEFAULT);
			m_Logger.info(
					"after updated,statusIndicator:" + statusIndicator + "; objectName:" + jalWorkItemInfo.getName());
		} catch (JalException e) {
			m_Logger.error(e.toString());
		} catch (Exception e) {
			m_Logger.error(e.toString());
		}
		m_Logger.info(this.getClass().getSimpleName() + EXITPROC);

		return jalDocument;

	}

	public void updatePageIndForAttr(String objectId, String pageInd) {
		List<String> failedVoidObjectIdList = new ArrayList<String>();
		m_Logger.info(this.getClass().getSimpleName() + " : enter process");
		JalDocument jalDocument = null;
		JalWorkitem workitem = this.createClient(objectId);
		jalDocument = (JalDocument) workitem;
		JalWorkitemInfo jalWorkItemInfo;
		try {
			jalWorkItemInfo = jalDocument.getInfo();
			JalFormFields formFields = jalDocument.getFormFields(JalConst.JAL_FIELDS_NO_VIEWS);
			JalFormField jalFormField_pageIndicator = formFields.find(UPPER_PAGE_INDICATOR);

			jalFormField_pageIndicator.setValue(pageInd);
			workitem.save();
			workitem.destroy(JalConst.JAL_DEFAULT);
		} catch (JalException e) {
			failedVoidObjectIdList.add(objectId);
			m_Logger.error(e.toString());

		} catch (Exception e) {
			failedVoidObjectIdList.add(objectId);
			m_Logger.error(e.toString());
		} finally {
			if (!failedVoidObjectIdList.isEmpty()) {
				for (String sCObjId : failedVoidObjectIdList) {
					// generate failed objectId in file
					int iReturn = FileUtil.genFailedObjTxtFile(txtFailedVoidFilePath, sCObjId + "    " + new Date());
					if (iReturn == 0) {
						m_Logger.info(sCObjId + " : generate Failed PageVoidObjectId Txt File successfully");
					} else {
						m_Logger.info(sCObjId + " : generate Failed PageVoidObjectId Txt File fail");
					}

				}
			}
		}
		m_Logger.info(this.getClass().getSimpleName() + EXITPROC);
	}

	public JalWorkitem createClient(String objectid) {
		JalClientList clientList;
		JalWorkitem workitem = null;
		try {
			jalClient = jalUtil.initJalClient();
			clientList = jalClient.getClientList();
			JalObjID myID = new JalObjID();
			myID.setInternalName(objectid);
			JalClientListItem clientListItem = clientList.find(myID);

			if (clientListItem == null) {
				clientListItem = clientList.add(myID, JalConst.JAL_ADD_RETAIN);
			}
			if (clientListItem != null) {
				workitem = clientListItem.getOpenedItem();
				if (workitem == null) {
					workitem = clientListItem.open(JalConst.JAL_OPEN_READWRITE + JalConst.JAL_OPEN_ARCHIVE);
				}

			}
		} catch (JalException e) {
			m_Logger.error(e.toString());
		} catch (Exception e) {
			m_Logger.error(e.toString());
		}

		return workitem;
	}

	/**
	 * Creation of G360 Document in the client list for resource manager to
	 * create in the server
	 * 
	 * @param params
	 * @return JalDocument
	 * @throws RemoteException
	 * @ throws RemoteException
	 */
	protected JalDocument jalCreation(InputParamVo params) throws JalException, RemoteException {

		JalDocument jalDoc = null;

		String objId = null;

		String objName = getObjName(params, DOC_TYPE);

		String objClass = null;

		if (parFormFieldsMap == null || parFormFieldsMap.isEmpty()) {
			parFormFieldsMap = getParentInfo(params);
		}

		if (parFormFieldsMap != null && !parFormFieldsMap.isEmpty()) {
			if (this.getStrDocClass() == null || this.getStrDocClass().isEmpty()) {
				String processType = (String) parFormFieldsMap.get(LOWER_PROCESS_TYPE);
				objClass = getDocClass(processType);
				this.setStrDocClass(objClass);
			} else {
				objClass = this.getStrDocClass();
			}

			JalClientListItem jalClientListItem;
			try {
				jalClientListItem = this.jalClient.createDocument(objName, objClass);

				jalDoc = (JalDocument) jalClientListItem.open(JalConst.JAL_OPEN_READWRITE);

				m_Logger.info(this.getClass().getSimpleName() + " : Opened Document (ReadWrite)"
						+ jalDoc.getInfo().getName());

				localJalCreation(params, jalDoc);

				JalFormFields jalFormFields = jalDoc.getFormFields(JalConst.JAL_FIELDS_NO_VIEWS);

				jalFormFieldsManager.setJalFormFieldSet(jalFormFields, objClass, params, DOC_TYPE);

				jalDoc.save();

				objId = jalDoc.getInfo().getObjID().getInternalName();

				m_Logger.info(this.getClass().getSimpleName() + " : Add Document objname=" + jalDoc.getInfo().getName()
						+ ", obj Id=" + objId);

			} catch (JalException e) {
				jalDocDestroy(jalDoc, e);
				jalUtil.jalClientDestroy();
				jalDoc = null;
				m_Logger.error(e.toString());
			} catch (Exception e) {
				jalUtil.jalClientDestroy();
				jalDoc = null;
				m_Logger.error(e.toString());
			}
		}

		return jalDoc;
	}

	private void jalDocDestroy(JalDocument jalDoc, JalException e) {
		if (jalDoc != null) {
			try {
				jalDoc.destroy(JalConst.JAL_WORKITEM_DESTROY_ABORT_CHANGES);
			} catch (Exception e1) {
				m_Logger.error(e.toString());
			}
		}
	}

	/**
	 * Create G360 document workitem
	 * 
	 * @param params
	 * @param jalDoc
	 * @ throws RemoteException
	 */
	protected void localJalCreation(InputParamVo params, JalDocument jalDoc) throws RemoteException {

		int iRet = addPages(params, jalDoc);

		if (iRet < 0) {
			throw new RemoteException("localJalCreation fail");
		}
	}

	/**
	 * Add G360 pages into the input G360 document
	 * 
	 * @param params
	 * @param jalDoc
	 * @return @ throws RemoteException
	 */
	protected int addPages(InputParamVo params, JalDocument jalDoc) throws RemoteException {
		int iRet = 0;
		try {

			int pageNo = 1;
			String pageMsg = "Page " + pageNo;
			List<Map<String, Object>> codeLookupList = null;
			codeLookupList = jalDao.getCodeLookup(IMPORT_CLASS);
			String fileExtension = params.getFileExtension();
			boolean isBytes = params.isBytes();
			String fileName = params.getFileName();
			byte[] fileBytes = params.getFileBytes();
			boolean isClassExist = false;
			String strImportClass = null;
			if (checkIsListEmpty(codeLookupList)) {
				for (Map<String, Object> importClass : codeLookupList) {
					String code = StrUtil.nullToEmpty((String) importClass.get("code"));
					if (code.equalsIgnoreCase(fileExtension)) {
						isClassExist = true;
						strImportClass = StrUtil.nullToEmpty((String) importClass.get("code_desc"));
						break;
					}
				}
			}

			if (isBytes) {
				extractDocFromEx360(jalDoc, pageNo, pageMsg, fileExtension, fileBytes, isClassExist, strImportClass);

				m_Logger.info(this.getClass().getSimpleName() + " : Added Page: " + pageMsg + ", pageNo=" + pageNo
						+ ", file =" + fileBytes);

			} else {
				File file = new File(fileName);
				if (!file.exists()) {
					throw new FileNotFoundException(fileName + " (The system cannot find the path specified)");
				} else {
					extractDocFromEx360(jalDoc, pageNo, pageMsg, fileExtension, fileName, isClassExist, strImportClass);
				}

				m_Logger.info(this.getClass().getSimpleName() + " : Added Page: " + pageMsg + ", pageNo=" + pageNo
						+ ", file =" + fileName);

			}

		} catch (JalException e) {
			try {
				jalDoc.destroy(JalConst.JAL_WORKITEM_DESTROY_ABORT_CHANGES);
				jalUtil.jalClientDestroy();
			} catch (Exception e1) {
				LogUtil.logException(m_Logger, "", e1);
			}
			iRet = -1;
			m_Logger.error(e.toString());
		} catch (Exception e) {
			iRet = -1;
			m_Logger.error(e.toString());
		}
		return iRet;
	}

	private boolean checkIsListEmpty(List<Map<String, Object>> codeLookupList) {
		return codeLookupList != null && !codeLookupList.isEmpty();
	}

	private void extractDocFromEx360(JalDocument jalDoc, int pageNo, String pageMsg, String fileExtension,
			byte[] fileBytes, boolean isClassExist, String strImportClass) throws JalException, RemoteException {
		try {
			if (fileExtension.equalsIgnoreCase(FILE_EXTENSION_TIF)) {
				jalDoc.getPages().add(pageNo, pageMsg, fileBytes, JalConst.JAL_IMAGE_FILE_TYPE_TIFF,
						JalConst.JAL_DEFAULT);
			} else {
				if (isClassExist && !strImportClass.isEmpty()) {
					jalDoc.getImports().add(JalConst.JAL_DOCUMENT_IMPORT_LAST, fileExtension, strImportClass,
							fileBytes);
				} else {
					throw new RemoteException("Unsupported file extension: " + fileExtension);
				}
			}

		} catch (Exception e1) {
			throw new RemoteException(e1.getMessage());
		}
	}

	private void extractDocFromEx360(JalDocument jalDoc, int pageNo, String pageMsg, String fileExtension,
			String fileName, boolean isClassExist, String strImportClass) throws JalException, RemoteException {
		try {
			if (fileExtension.equalsIgnoreCase(FILE_EXTENSION_TIF)) {
				jalDoc.getPages().add(pageNo, pageMsg, fileName, JalConst.JAL_IMAGE_FILE_TYPE_TIFF,
						JalConst.JAL_DEFAULT);
			} else {
				if (isClassExist && !strImportClass.isEmpty()) {
					jalDoc.getImports().add(JalConst.JAL_DOCUMENT_IMPORT_LAST, fileExtension, strImportClass, fileName);
					m_Logger.info(this.getClass().getSimpleName() + " file =" + fileName + "Import Success");
				} else {
					throw new RemoteException("Unsupported file extension: " + fileExtension);
				}
			}
		} catch (Exception e1) {
			throw new RemoteException(e1.getMessage());
		}
	}

	/**
	 * Get the object name of the document workitem
	 * 
	 * @param params
	 * @param workItemType
	 * @return objName @ throws RemoteException
	 */
	protected String getObjName(InputParamVo params, String workItemType) throws RemoteException {

		String objName = getDefaultObjName(params, workItemType);

		return objName;
	}

	/**
	 * Get the default object name (Object type = workitem type ["FLD_", "DOC_"]
	 * + process type)
	 * 
	 * @param params
	 * @param workItemType
	 * @return @ throws RemoteException
	 */
	protected String getDefaultObjName(InputParamVo params, String workItemType) throws RemoteException {

		if (parFormFieldsMap == null || parFormFieldsMap.isEmpty()) {
			parFormFieldsMap = getParentInfo(params);
		}
		String processType = "";
		if (parFormFieldsMap != null && !parFormFieldsMap.isEmpty()) {
			processType = (String) parFormFieldsMap.get(LOWER_PROCESS_TYPE);
		}
		// Get the default object name when the object name defined on the
		String objectType = workItemType + processType;

		m_Logger.info(this.getClass().getSimpleName() + " : default objectType=" + objectType);

		String objName = jalObjectDefManager.constructDynamicObjName(objectType, params);

		m_Logger.info(this.getClass().getSimpleName() + " : default objName=" + objName);

		return objName;
	}

	/**
	 * Get the document class
	 * 
	 * @param params
	 * @return docClass @ throws RemoteException
	 */
	protected String getDocClass(String processType) throws RemoteException {

		Set defDocClassSet;
		String docClass = null;

		defDocClassSet = StrUtil.strToSet(defDocClasses);
		Iterator it = defDocClassSet.iterator();

		while (it.hasNext()) {
			String docClassMap = (String) it.next();

			if (processType.startsWith(docClassMap.split(":")[0])) {
				docClass = docClassMap.split(":")[1];
				break;
			}
		}

		m_Logger.info(this.getClass().getSimpleName() + " : default docClass=" + docClass);

		return docClass;

	}

	/**
	 * Retrieve parent info
	 * 
	 * @return procType @ throws RemoteException
	 */
	@SuppressWarnings("unchecked")
	protected Map getParentInfo(InputParamVo params) throws RemoteException {

		List<PolNumReqs> polNumReqs = params.getPolNumReqs();
		String companyNo = null;
		String polNum = null;
		String processType = null;
		String formId = null;
		String requestNo = null;
		String receivedDate = null;
		BigDecimal sParentRowId = null;
		short isVoid = 0;
		short isDeleted = 0;
		int status = 0;
		String lastUpdateDate = null;
		for (PolNumReqs pol : polNumReqs) {
			Short isLogical = pol.getIsLogical();
			isDeleted = pol.getIsDeleted();
			status = pol.getStatus();
			if (isLogical == 0 && ((isDeleted == 0 && status != 99) || (isDeleted == 1))) {
						companyNo = pol.getCompany();
						polNum = pol.getPolNum();
						processType = pol.getProcessType();
						formId = pol.getFormId();
						requestNo = pol.getRequestNo();
						receivedDate = pol.getReceivedDate();
						sParentRowId = pol.getsRowId();
						isVoid = pol.getIsVoid();
						lastUpdateDate = pol.getLastUpdatedDate();
					
					break;
			}
		}

		if (!StrUtil.nullToEmptyForObject(companyNo).isEmpty() && !StrUtil.nullToEmptyForObject(polNum).isEmpty()) {
			parFormFieldsMap.put(LOWER_COMPANY_NO, companyNo);//
			parFormFieldsMap.put(LOWER_POLICY_NO, polNum);//
			parFormFieldsMap.put(LOWER_PROCESS_TYPE, processType);//
			parFormFieldsMap.put(FORM_ID, formId);//
			parFormFieldsMap.put(LOWER_REQUEST_NO, requestNo);
			parFormFieldsMap.put(LOWER_RECEIVED_DATE, receivedDate); //
			parFormFieldsMap.put("sParentRowId", sParentRowId);
			parFormFieldsMap.put("caseObjectId", params.getCaseObjectId());

			String statusIndicator = params.getStatusIndicator();

			statusIndicator = getStatusIndicatorValue(isVoid, isDeleted, statusIndicator);

			parFormFieldsMap.put(LOWER_STATUS_INDICATOR, statusIndicator); //

			parFormFieldsMap.put(LOWER_LINK_INDICATOR, params.getLinkIndicator()); //
			parFormFieldsMap.put(PAGE_INDICATOR, params.getPageIndicator());
			parFormFieldsMap.put(IS_VOID, isVoid);
			parFormFieldsMap.put(IS_DELETED, isDeleted);
			parFormFieldsMap.put("status", status);
			parFormFieldsMap.put("lastUpdateDate", lastUpdateDate);
		} else {
			parFormFieldsMap = null;
		}
		return parFormFieldsMap;
	}

	private String getStatusIndicatorValue(short isVoid, short isDeleted, String statusIndicator) {
		if (isDeleted == 1) {
			statusIndicator = DELETE_STATUS;
		} else {
			if (isVoid == 1) {
				statusIndicator = VOID_STATUS;
			}
		}
		return statusIndicator;
	}

	/**
	 * Init info
	 * 
	 * @return params @ throws RemoteException
	 */
	protected boolean init(InputParamVo params) throws RemoteException {
		try {
			DOC_TYPE = PropertyUtil.getCommonProperty("DOC_TYPE");
			IMPORT_CLASS = PropertyUtil.getCommonProperty("IMPORT_CLASS");
			defDocClasses = PropertyUtil.getCommonProperty("DEF_DOC_CLASSES");
			// int parFormFieldsMap
			parFormFieldsMap = new HashMap();
			parFormFieldsMap = getParentInfo(params);
			if (parFormFieldsMap != null && !parFormFieldsMap.isEmpty()) {
				// int strDocClass
				String processType = (String) parFormFieldsMap.get(LOWER_PROCESS_TYPE);
				strDocClass = getDocClass(processType);
			}

		} catch (RemoteException e) {

			m_Logger.error(e.toString());
			return false;
		}

		return true;

	}

}
