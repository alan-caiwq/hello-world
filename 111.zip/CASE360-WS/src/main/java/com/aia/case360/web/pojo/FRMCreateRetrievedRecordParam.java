package com.aia.case360.web.pojo;

public class FRMCreateRetrievedRecordParam {
  private Long caseId;

  private String reqNum;

  private String polNum;

  private String reason;

  private String collector;

  private String office;

  private String currentUser;

  /**
   * @return the caseId
   */
  public Long getCaseId() {
    return caseId;
  }

  /**
   * @return the reqNum
   */
  public String getReqNum() {
    return reqNum;
  }

  /**
   * @return the polNum
   */
  public String getPolNum() {
    return polNum;
  }

  /**
   * @return the reason
   */
  public String getReason() {
    return reason;
  }

  /**
   * @return the collector
   */
  public String getCollector() {
    return collector;
  }

  /**
   * @return the office
   */
  public String getOffice() {
    return office;
  }

  /**
   * @return the currentUser
   */
  public String getCurrentUser() {
    return currentUser;
  }

  /**
   * @param caseId the caseId to set
   */
  public void setCaseId(Long caseId) {
    this.caseId = caseId;
  }

  /**
   * @param reqNum the reqNum to set
   */
  public void setReqNum(String reqNum) {
    this.reqNum = reqNum;
  }

  /**
   * @param polNum the polNum to set
   */
  public void setPolNum(String polNum) {
    this.polNum = polNum;
  }

  /**
   * @param reason the reason to set
   */
  public void setReason(String reason) {
    this.reason = reason;
  }

  /**
   * @param collector the collector to set
   */
  public void setCollector(String collector) {
    this.collector = collector;
  }

  /**
   * @param office the office to set
   */
  public void setOffice(String office) {
    this.office = office;
  }

  /**
   * @param currentUser the currentUser to set
   */
  public void setCurrentUser(String currentUser) {
    this.currentUser = currentUser;
  }

  /*
   * (non-Javadoc)
   * 
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "FRMCreateRetrievedRecordParam [caseId=" + caseId + ", reqNum=" + reqNum + ", polNum="
        + polNum + ", reason=" + reason + ", collector=" + collector + ", office=" + office
        + ", currentUser=" + currentUser + "]";
  }
}
