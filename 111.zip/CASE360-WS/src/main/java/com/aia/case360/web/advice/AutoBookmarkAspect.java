package com.aia.case360.web.advice;

import java.io.File;
import java.rmi.RemoteException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.web.dao.DocOMSDao;
import com.aia.case360.web.dao.DocSigDao;
import com.aia.case360.web.dao.DocumentsRelatedDataDao;
import com.aia.case360.web.pojo.DocOMSDetailsInfo;
import com.aia.case360.web.pojo.DocOMSParameter;
import com.aia.case360.web.service.OWSCommentService;
import com.aia.case360.web.service.SonoraConfigInfoService;
import com.aia.case360.web.service.impl.AbstractServiceImpl;
import com.aia.case360.web.vo.OWSBookmark;
import com.aia.case360.web.vo.OWSComment;
import com.aia.case360.web.vo.RenameDocFormLinkParam;

@Component
@Aspect
public class AutoBookmarkAspect extends AbstractServiceImpl {

   private static final String LOCALOBJECT_ID = "OBJECT_ID";
private static final String LOCALPOL_NUM = "POL_NUM";
private static final String LOCALCOMPANY_NO = "COMPANY_NO";
private static final String LOCALRECEIVED_DT = "RECEIVED_DT";
private static final String LOCALFORM_ID = "FORM_ID";
@Autowired
   private DocSigDao docSigDao;
   @Autowired
   private DocOMSDao docOMSDao;
   @Autowired
   private OWSCommentService owsCommentService;
   @Autowired
   private DocumentsRelatedDataDao documentsRelatedDataDao;
   @Autowired
   private SonoraConfigInfoService sonoraConfigInfoService;
   
   @Pointcut("execution( * com.aia.case360.web.dao.DocumentsRelatedDataDao.renameDocFormLinks(..))")
   public void pointCutRenameDocFormLinks(){   
	// NOSONAR
   }
   
   
   @Pointcut("execution( * com.aia.case360.web.jdbcDao.impl.DocDaoImpl.insertDocLink(..))")
   public void pointCutInsertDocLink(){   
	   // NOSONAR
   }
   
   
   @After("pointCutInsertDocLink()")
	public void afterCopyOrReindex(JoinPoint jp)  throws RemoteException {

     Map<String, Object> docLink = (Map<String, Object>) jp.getArgs()[0];

		// AutoBookmark

		OWSComment comment = new OWSComment();

       List<String> bookMarkFormIds = new ArrayList<String>();
       List<String> bookMarkFormDates = new ArrayList<String>();
		bookMarkFormIds.add(docLink.get(LOCALFORM_ID) == null ? "" : docLink.get(LOCALFORM_ID).toString());
		String dateString = docLink.get(LOCALRECEIVED_DT) == null ? "" : docLink.get(LOCALRECEIVED_DT).toString();
       bookMarkFormDates.add(getFormatDateString(dateString));
       comment.setBookMarkFormIds(bookMarkFormIds);
       comment.setBookMarkFormDates(bookMarkFormDates);
       try {
			String userId = userHelper.getCurrentUser();
         comment.setCreatedBy(userId);
       } catch (RemoteException e) {
			 
			LogUtil.logException(m_Logger, "AutoBookmarkAspect getCurrentUser " ,e);
       }
		comment.setOwsCompanyCode(docLink.get(LOCALCOMPANY_NO) == null ? "" : docLink.get(LOCALCOMPANY_NO).toString());
       comment.setOwsDepartmentCode("");
		comment.setOwsPlocyNumber(docLink.get(LOCALPOL_NUM) == null ? "" : docLink.get(LOCALPOL_NUM).toString());
       List<OWSBookmark> owsBookmarks  = new ArrayList<OWSBookmark>();
       OWSBookmark owsBookmark = new OWSBookmark();
		owsBookmark.setFormId(docLink.get(LOCALFORM_ID) == null ? "" : docLink.get(LOCALFORM_ID).toString());
		owsBookmark.setOwsCommentBookmarkObjectId(
				docLink.get(LOCALOBJECT_ID) == null ? "" : docLink.get(LOCALOBJECT_ID).toString());
       DocOMSParameter dop = new DocOMSParameter();
		dop.setObjectID(docLink.get(LOCALOBJECT_ID) == null ? "" : docLink.get(LOCALOBJECT_ID).toString());
       try {
          List<DocOMSDetailsInfo> dodis = docOMSDao.queryDocumentByIDOMS(dop);
          owsBookmark.setOwsCommentBookmarkDocumentId(dodis.get(0).getDocumentId().toString());
       } catch (Exception e) {
          // TODO Auto-generated catch block
			LogUtil.logError(m_Logger, "AutoBookmarkAspect queryDocumentByIDOMS " + e.toString());
       }

       owsBookmark.setOwsBookmarkPage("");
       owsBookmark.setPolicyNos(comment.getOwsPlocyNumber());
       owsBookmarks.add(owsBookmark);
       comment.setOwsBookmarks(owsBookmarks);
       owsBookmarks.add(owsBookmark);
       comment.setOwsBookmarks(owsBookmarks);
       try {
        owsCommentService.createComment(comment, new File[0], new File[0], new File[0], "", "AutoBookmarkAspect");
      } catch (Exception e) {
        // TODO Auto-generated catch block
			 
			LogUtil.logError(m_Logger, "AutoBookmarkAspect createComment " + e.toString());
      }
     }

   @After("pointCutRenameDocFormLinks()")
	public void afterRename(JoinPoint jp)  throws RemoteException {

		List<RenameDocFormLinkParam> dfLinks = (List<RenameDocFormLinkParam>) jp.getArgs()[0];

		List<String> linkIDs = new ArrayList<String>();
		for (RenameDocFormLinkParam RenameParm : dfLinks) {
			linkIDs.add(RenameParm.getLinkID());
		}
		List<Map<String, Object>> linkIDsResults = new ArrayList<Map<String, Object>>();
		try {
			linkIDsResults = documentsRelatedDataDao.getDocLinkByID(linkIDs);
			// AutoBookmark
			for (RenameDocFormLinkParam renameParm : dfLinks) {
				List<String> bookMarkFormIds = new ArrayList<String>();
				List<String> bookMarkFormDates = new ArrayList<String>();

				Map<String, Object> linkIDsResult = new HashMap<String, Object>();
				for (Map<String, Object> it : linkIDsResults) {
					if (renameParm.getLinkID().equals(it.get("S_ROWID").toString())) {
						linkIDsResult = it;
					}
				}
				OWSComment comment = new OWSComment();

				String userId = userHelper.getCurrentUser();
				comment.setCreatedBy(userId);

				bookMarkFormIds.add(renameParm.getFormID());
				String dateString = valueIsNull(linkIDsResult.get(LOCALRECEIVED_DT));
				bookMarkFormDates.add(getFormatDateString(dateString));

				comment.setBookMarkFormIds(bookMarkFormIds);
				comment.setBookMarkFormDates(bookMarkFormDates);
				comment.setOwsCompanyCode(valueIsNull(linkIDsResult.get(LOCALCOMPANY_NO)));
				comment.setOwsDepartmentCode("");
				comment.setOwsPlocyNumber(valueIsNull(linkIDsResult.get(LOCALPOL_NUM)));
				List<OWSBookmark> owsBookmarks = new ArrayList<OWSBookmark>();
				OWSBookmark owsBookmark = new OWSBookmark();
				owsBookmark.setFormId(renameParm.getFormID());
				owsBookmark.setOwsCommentBookmarkObjectId(valueIsNull(linkIDsResult.get(LOCALOBJECT_ID)));
				DocOMSParameter dop = new DocOMSParameter();
				dop.setObjectID(valueIsNull(linkIDsResult.get(LOCALOBJECT_ID)));

				List<DocOMSDetailsInfo> dodis = docOMSDao.queryDocumentByIDOMS(dop);
				owsBookmark.setOwsCommentBookmarkDocumentId(dodis.get(0).getDocumentId().toString());

				owsBookmark.setOwsBookmarkPage("");
				String polNum = valueIsNull(linkIDsResult.get(LOCALPOL_NUM));
				String claimNo = valueIsNull(linkIDsResult.get("CLAIM_NO"));
				String requestNum = valueIsNull(linkIDsResult.get("REQUEST_NUM"));
				owsBookmark.setPolicyNos(polNum);
				owsBookmark.setRequestNo(StringUtils.isBlank(claimNo) ? requestNum : claimNo);
				owsBookmark.setDocSource("CASE360");
				owsBookmark.setsRowId(linkIDsResult.get("S_ROWID").toString());
				owsBookmarks.add(owsBookmark);
				comment.setOwsBookmarks(owsBookmarks);

				owsCommentService.createComment(comment, new File[0], new File[0], new File[0], "",
						"AutoBookmarkAspect");

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block

			LogUtil.logError(m_Logger, "AutoBookmarkAspect createComment " + e.toString());
		}
   }

	private String getFormatDateString(String recDate) {
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		SimpleDateFormat dateformat = new SimpleDateFormat("d MMM yyyy", Locale.ENGLISH);
     Date date = null;
     try {
         date = format1.parse(recDate);
      } catch (ParseException e) {
			LogUtil.logException(m_Logger, "", e);
      }
     return dateformat.format(date);
   }
	
	private String valueIsNull(Object value){
      
      if(value==null){
        return "";
      }else if("".equals(value.toString().trim())){
        return "";
      }else if(value.toString().trim().length()==0){
        return "";
      }else{
        return value.toString().trim();
      }
  }
}
