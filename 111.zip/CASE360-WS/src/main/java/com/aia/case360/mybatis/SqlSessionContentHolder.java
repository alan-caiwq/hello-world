package com.aia.case360.mybatis;

/**
 * @Author: huiyun ma
 * @Create Date: 03/02/2018
 */
public abstract class SqlSessionContentHolder {
	private SqlSessionContentHolder() {
	};

	public final static String SESSION_FACTORY_IL = "mybatisIL";
	public final static String SESSION_FACTORY_PLASANDHIAS = "plasAndHias";
	public final static String SESSION_FACTORY_ODS = "ods";
	public final static String SESSION_FACTORY_EDOC = "eDoc";
	public final static String SESSION_FACTORY_AMS = "ams";
	public final static String SESSION_FACTORY_EIMAGE = "eImage";
	public final static String SESSION_FACTORY_EXTIMAGE = "extImage";
	public final static String SESSION_FACTORY_SONORA = "sonora";

	private static final ThreadLocal<String> contextHolder = new ThreadLocal<String>();

	public static void setContextType(String contextType) {
		contextHolder.set(contextType);
	}

	public static String getContextType() {
		return contextHolder.get();
	}

	public static void clearContextType() {
		contextHolder.remove();
	}
}