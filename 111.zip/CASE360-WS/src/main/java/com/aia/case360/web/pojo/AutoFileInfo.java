package com.aia.case360.web.pojo;

import java.util.Date;

public class AutoFileInfo {

	private String txtID;
	private Date dteCycleDate;
	private String txtCompNo;
	private String txtPolicyNo;
	private String txtDocType;
	private String txtFormID;
	private String txtProcessName;
	private String txtRequestNo;
	private String txtSourceSys;
	private String txtFuncCode;
	private String txtFilePath;
	private String txtFolderName;
	private String txtStatus;
	private String txtMatchReq;
	private Date dteCreateOn;
	private String txtCreateBy;
	private Date dteLastUpdatedOn;
	private String txtLastUpdatedBy;
	private Date dteTranDate;
	private Date dtePreDate;

	public String getTxtID() {
		return txtID;
	}

	public void setTxtID(String txtID) {
		this.txtID = txtID;
	}

	public Date getDteCycleDate() {
		return dteCycleDate;
	}

	public void setDteCycleDate(Date dteCycleDate) {
		this.dteCycleDate = dteCycleDate;
	}

	public String getTxtCompNo() {
		return txtCompNo;
	}

	public void setTxtCompNo(String txtCompNo) {
		this.txtCompNo = txtCompNo;
	}

	public String getTxtPolicyNo() {
		return txtPolicyNo;
	}

	public void setTxtPolicyNo(String txtPolicyNo) {
		this.txtPolicyNo = txtPolicyNo;
	}

	public String getTxtDocType() {
		return txtDocType;
	}

	public void setTxtDocType(String txtDocType) {
		this.txtDocType = txtDocType;
	}

	public String getTxtFormID() {
		return txtFormID;
	}

	public void setTxtFormID(String txtFormID) {
		this.txtFormID = txtFormID;
	}

	public String getTxtRequestNo() {
		return txtRequestNo;
	}

	public void setTxtRequestNo(String txtRequestNo) {
		this.txtRequestNo = txtRequestNo;
	}

	public String getTxtSourceSys() {
		return txtSourceSys;
	}

	public void setTxtSourceSys(String txtSourceSys) {
		this.txtSourceSys = txtSourceSys;
	}

	public String getTxtFuncCode() {
		return txtFuncCode;
	}

	public void setTxtFuncCode(String txtFuncCode) {
		this.txtFuncCode = txtFuncCode;
	}

	public String getTxtFilePath() {
		return txtFilePath;
	}

	public void setTxtFilePath(String txtFilePath) {
		this.txtFilePath = txtFilePath;
	}

	public String getTxtFolderName() {
		return txtFolderName;
	}

	public void setTxtFolderName(String txtFolderName) {
		this.txtFolderName = txtFolderName;
	}

	public String getTxtStatus() {
		return txtStatus;
	}

	public void setTxtStatus(String txtStatus) {
		this.txtStatus = txtStatus;
	}

	public Date getDteCreateOn() {
		return dteCreateOn;
	}

	public void setDteCreateOn(Date dteCreateOn) {
		this.dteCreateOn = dteCreateOn;
	}

	public String getTxtCreateBy() {
		return txtCreateBy;
	}

	public void setTxtCreateBy(String txtCreateBy) {
		this.txtCreateBy = txtCreateBy;
	}

	public Date getDteLastUpdatedOn() {
		return dteLastUpdatedOn;
	}

	public void setDteLastUpdatedOn(Date dteLastUpdatedOn) {
		this.dteLastUpdatedOn = dteLastUpdatedOn;
	}

	public String getTxtLastUpdatedBy() {
		return txtLastUpdatedBy;
	}

	public void setTxtLastUpdatedBy(String txtLastUpdatedBy) {
		this.txtLastUpdatedBy = txtLastUpdatedBy;
	}

	public Date getDteTranDate() {
		return dteTranDate;
	}

	public void setDteTranDate(Date dteTranDate) {
		this.dteTranDate = dteTranDate;
	}

	public Date getDtePreDate() {
		return dtePreDate;
	}

	public void setDtePreDate(Date dtePreDate) {
		this.dtePreDate = dtePreDate;
	}

	public String getTxtMatchReq() {
		return txtMatchReq;
	}

	public void setTxtMatchReq(String txtMatchReq) {
		this.txtMatchReq = txtMatchReq;
	}

	public String getTxtProcessName() {
		return txtProcessName;
	}

	public void setTxtProcessName(String txtProcessName) {
		this.txtProcessName = txtProcessName;
	}

	@Override
	public String toString() {
		return "AutoFileInfo [txtID=" + txtID + ", dteCycleDate=" + dteCycleDate + ", txtCompNo=" + txtCompNo
				+ ", txtPolicyNo=" + txtPolicyNo + ", txtDocType=" + txtDocType + ", txtFormID=" + txtFormID
				+ ", txtProcessName=" + txtProcessName + ", txtRequestNo=" + txtRequestNo + ", txtSourceSys="
				+ txtSourceSys + ", txtFuncCode=" + txtFuncCode + ", txtFilePath=" + txtFilePath + ", txtFolderName="
				+ txtFolderName + ", txtStatus=" + txtStatus + ", txtMatchReq=" + txtMatchReq + ", dteCreateOn="
				+ dteCreateOn + ", txtCreateBy=" + txtCreateBy + ", dteLastUpdatedOn=" + dteLastUpdatedOn
				+ ", txtLastUpdatedBy=" + txtLastUpdatedBy + ", dteTranDate=" + dteTranDate + ", dtePreDate="
				+ dtePreDate + "]";
	}

}
