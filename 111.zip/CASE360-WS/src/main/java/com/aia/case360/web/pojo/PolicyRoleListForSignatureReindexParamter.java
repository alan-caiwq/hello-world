/**
 * 
 */
package com.aia.case360.web.pojo;

/**
 * @author bsnpc55
 * @date:6:56:41 PM Jul 24, 2018
 */
public class PolicyRoleListForSignatureReindexParamter {
	private String customerNRIC;
	private String source;

	public String getCustomerNRIC() {
		return customerNRIC;
	}

	public void setCustomerNRIC(String customerNRIC) {
		this.customerNRIC = customerNRIC;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

}
