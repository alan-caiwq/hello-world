package com.aia.case360.web.auditTrail;

import java.math.BigDecimal;
import java.util.List;

public interface AuditTrail {
	
	public List<AuditFieldSpecialAction> registFieldSpecialActionlist();

	public List<AuditEntityIgnoreCondition> registIgnoreEntitylist();

	public BigDecimal getRowID();

	public String getKeyDisplayName();

	/**
	 * 
	 * 
	 * @author bsnpbjd
	 * @return Object
	 * @since Only master entity need to set it. For relation entity just overwrite
	 *        it and do nothing.
	 */
	public Object getKey();
}
