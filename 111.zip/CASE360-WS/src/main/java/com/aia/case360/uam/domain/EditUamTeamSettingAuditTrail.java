package com.aia.case360.uam.domain;

import java.math.BigDecimal;

public class EditUamTeamSettingAuditTrail {

	private BigDecimal componentId;

	private String reqIds;
	private String actIds;

	private String loginUser;

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "EditUamTeamSettingAuditTrail [componentId=" + componentId + ", reqIds=" + reqIds + ", actIds=" + actIds
				+ ", loginUser=" + loginUser + "]";
	}

	/**
	 * @return the componentId
	 */
	public BigDecimal getComponentId() {
		return componentId;
	}

	/**
	 * @return the reqIds
	 */
	public String getReqIds() {
		return reqIds;
	}

	/**
	 * @return the actIds
	 */
	public String getActIds() {
		return actIds;
	}

	/**
	 * @return the loginUser
	 */
	public String getLoginUser() {
		return loginUser;
	}

	/**
	 * @param componentId the componentId to set
	 */
	public void setComponentId(BigDecimal componentId) {
		this.componentId = componentId;
	}

	/**
	 * @param reqIds the reqIds to set
	 */
	public void setReqIds(String reqIds) {
		this.reqIds = reqIds;
	}

	/**
	 * @param actIds the actIds to set
	 */
	public void setActIds(String actIds) {
		this.actIds = actIds;
	}

	/**
	 * @param loginUser the loginUser to set
	 */
	public void setLoginUser(String loginUser) {
		this.loginUser = loginUser;
	}
}
