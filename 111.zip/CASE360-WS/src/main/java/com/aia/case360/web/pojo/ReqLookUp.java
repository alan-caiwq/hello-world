package com.aia.case360.web.pojo;

import java.sql.Timestamp;

public class ReqLookUp {

	private String sRowid;

	private String category;

	private Timestamp createdTimestamp;

	private String createdBy;

	private String lookUpValue;

	private String lookUpGroup;

	private String lookUpCode;

	private Timestamp lastUpdatedTimestamp;

	private String lastUpdatedBy;

	private String remark;

	private String isActive;

	public String getsRowid() {
		return sRowid;
	}

	public void setsRowid(String sRowid) {
		this.sRowid = sRowid;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Timestamp getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Timestamp createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLookUpValue() {
		return lookUpValue;
	}

	public void setLookUpValue(String lookUpValue) {
		this.lookUpValue = lookUpValue;
	}

	public String getLookUpGroup() {
		return lookUpGroup;
	}

	public void setLookUpGroup(String lookUpGroup) {
		this.lookUpGroup = lookUpGroup;
	}

	public String getLookUpCode() {
		return lookUpCode;
	}

	public void setLookUpCode(String lookUpCode) {
		this.lookUpCode = lookUpCode;
	}

	public Timestamp getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Timestamp lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

}
