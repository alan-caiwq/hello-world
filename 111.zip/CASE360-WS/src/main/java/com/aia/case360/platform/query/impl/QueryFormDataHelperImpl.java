package com.aia.case360.platform.query.impl;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.stereotype.Component;

import com.aia.case360.platform.common.CaseUtilities;
import com.aia.case360.platform.common.DataFieldUtil;
import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.common.PropertyUtil;
import com.aia.case360.platform.common.QueryResultsHandler;
import com.aia.case360.platform.process.WorkItemDetail;
import com.aia.case360.platform.query.QueryFormDataHelper;
import com.aia.case360.web.service.impl.AbstractHelperImpl;
import com.eistream.sonora.fields.FieldPropertiesTO;
import com.eistream.sonora.fields.FmsRowSetTO;
import com.eistream.sonora.util.StringUtil;

@Component
public class QueryFormDataHelperImpl extends AbstractHelperImpl implements QueryFormDataHelper {

	private static final String LOCALPOLNUM = "POL_NUM";
	private static final String LOCALISLEAVING = " is leaving . ";
	private static final String LOCALISSTART = " is start . ";
	private static final String LOCALLINKCASEID = "LINKCASEID";
	private static final String LOCALCASEID = " caseId : ";

	/**
	 * 
	 * Get notes by linkcaseid
	 * 
	 * @param linkcaseid workfolder's id
	 * @return queryResults
	 * @throws RemoteException
	 */
	@Override
	public ArrayList<Map<String, Object>> getNotes(String caseId) throws RemoteException {

		Map<String, String> queryParams = new HashMap<String, String>();
		LogUtil.logInfo(m_Logger,LOCALCASEID + caseId);
		queryParams.put(PropertyUtil.getCommonProperty(LOCALLINKCASEID), caseId);
		String query = PropertyUtil.getScriptAndQueryProperty("QUERY_GETNOTES");
		return doQuery(queryParams, query);
	}

	/**
	 * 
	 * Get audit trail by linkcaseid
	 * 
	 * @param linkcaseid workfolder's id
	 * @return queryResults
	 * @throws RemoteException
	 */
	@Override
	public ArrayList<Map<String, Object>> getAuditTrail(String caseId) throws RemoteException {

		Map<String, String> queryParams = new HashMap<String, String>();
		LogUtil.logInfo(m_Logger,LOCALCASEID + caseId);
		queryParams.put(PropertyUtil.getCommonProperty(LOCALLINKCASEID), caseId);
		String query = PropertyUtil.getScriptAndQueryProperty("QUERY_AUDITTRAIL");
		return doQuery(queryParams, query);
	}

	@Override
	public ArrayList<Map<String, Object>> getCFAuditTrail(String caseId) throws RemoteException {

		Map<String, String> queryParams = new HashMap<String, String>();
		LogUtil.logInfo(m_Logger,LOCALCASEID + caseId);
		queryParams.put(PropertyUtil.getCommonProperty(LOCALLINKCASEID), caseId);
		String query = PropertyUtil.getScriptAndQueryProperty("QUERY_CFAUDITTRAIL");
		return doQuery(queryParams, query);
	}

	public ArrayList<Map<String, Object>> doQuery(Map<String, String> queryParams, String queryName)
			throws RemoteException {

		String message = "queryName:" + queryName;

		String paramStr = DataFieldUtil.getInMapStr(queryParams);

		if (paramStr != null && paramStr.length() > 0) {
			message += "," + paramStr;
		} else {
			message += ", no query parameters input!";
		}

		ArrayList<Map<String, Object>> queryResults;

		try {
			FmsRowSetTO[] queryResultsSet = doQuery4RowSet(queryParams, queryName);

			queryResults = QueryResultsHandler.convertQueryResultsAsObject(queryResultsSet);
			LogUtil.logInfo(m_Logger,message);
			return queryResults;
		} catch (RemoteException e) {
			 
			LogUtil.logError(m_Logger, message + " " + e.getMessage());
			e = new RemoteException(message, e);
			throw e;
		}
	}

	private FmsRowSetTO[] doQuery4RowSet(Map<String, String> queryParams, String queryName) throws RemoteException {
		String message = "queryName:" + queryName;

		String paramStr = DataFieldUtil.getInMapStr(queryParams);

		if (paramStr != null && paramStr.length() > 0) {
			message += "," + paramStr;
		} else {
			message += ", no query parameters input!";
		}

		// Get the list of contents
		FieldPropertiesTO[] queryFields = null;
		if (queryParams != null) {
			queryFields = new FieldPropertiesTO[queryParams.size()];
			setQueryFields(queryParams, queryFields, 0);
		}
		try {
			FmsRowSetTO[] queryResultsSet = getWsEJB().doQueryByScriptName(queryName, queryFields);

			LogUtil.logInfo(m_Logger,message);
			return queryResultsSet;
		} catch (RemoteException e) {
			LogUtil.logError(m_Logger, message + " " + e.getMessage());
			e = new RemoteException(message, e);
			throw e;
		}
	}

	private int setQueryFields(Map<String, String> queryParams, FieldPropertiesTO[] queryFields, int fieldsNum) {
		for (Entry<String, String> paramName : queryParams.entrySet()) {
			queryFields[fieldsNum++] = CaseUtilities.createFieldPropertyTO(paramName.getKey(), paramName.getValue());
		}
		return fieldsNum;
	}

	@Override
	public ArrayList<Map<String, Object>> getFlpDoc(String caseId) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		LogUtil.logInfo(m_Logger,LOCALCASEID + caseId);
		queryParams.put(PropertyUtil.getCommonProperty(LOCALLINKCASEID), caseId);
		String query = PropertyUtil.getScriptAndQueryProperty("QUERY_FLPDOC");
		return doQuery(queryParams, query);
	}

	@Override
	public ArrayList<Map<String, Object>> getCfAndDocRelation(String caseId) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		LogUtil.logInfo(m_Logger,LOCALCASEID + caseId);
		queryParams.put(PropertyUtil.getCommonProperty(LOCALLINKCASEID), caseId);
		String query = PropertyUtil.getScriptAndQueryProperty("QUERY_CFANDDOCRELATION");
		return doQuery(queryParams, query);
	}

	@Override
	public ArrayList<Map<String, Object>> getReqTypeDef(String reqType) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		LogUtil.logInfo(m_Logger," reqType : " + reqType);
		queryParams.put(PropertyUtil.getCommonProperty("REQ_TYPE"), reqType);
		String query = PropertyUtil.getScriptAndQueryProperty("QUERY_GET_REQTYPE_DEF");
		return doQuery(queryParams, query);
	}

	@Override
	public String getWorkStepHistoryUser(Map<String, String> inputParamsMap) throws RemoteException {
		String message = "function : getWorkStepHistoryUser";
		LogUtil.logInfo(m_Logger,message + LOCALISSTART);
		String userId = "";
		LogUtil.logInfo(m_Logger," inputParamsMap : " + inputParamsMap.toString());

		String query = PropertyUtil.getScriptAndQueryProperty("QUERY_SEARCHWORKSTEPHISTORYUSER");

		ArrayList<Map<String, Object>> result = doQuery(inputParamsMap, query);
		LogUtil.logInfo(m_Logger,result.toString());
		if (result.size() == 1) {
			userId = result.get(0).get(PropertyUtil.getCommonProperty("CURRENT_USER")).toString();
		}
		LogUtil.logInfo(m_Logger,"user id : " + userId);
		LogUtil.logInfo(m_Logger,message + LOCALISLEAVING);
		return userId;
	}

	@Override
	public ArrayList<Map<String, Object>> getPolicyInfo(String polNum) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		LogUtil.logInfo(m_Logger," polNum : " + polNum);
		queryParams.put(PropertyUtil.getCommonProperty(LOCALPOLNUM), polNum);
		String query = PropertyUtil.getScriptAndQueryProperty("QUERY_GET_POLICY_INFO");
		return doQuery(queryParams, query);
	}

	@Override
	public ArrayList<Map<String, Object>> getFormDefinition(String docId) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		LogUtil.logInfo(m_Logger," docId : " + docId);
		queryParams.put(PropertyUtil.getCommonProperty("DOCID"), docId);
		String query = PropertyUtil.getScriptAndQueryProperty("QUERY_GET_FORMINFO_BY_DOCID");
		return doQuery(queryParams, query);
	}

	@Override
	public ArrayList<Map<String, Object>> getPolicyOwner(String linkCaseId) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		LogUtil.logInfo(m_Logger," linkCaseId : " + linkCaseId);
		queryParams.put(PropertyUtil.getCommonProperty(LOCALLINKCASEID), linkCaseId);
		String query = PropertyUtil.getScriptAndQueryProperty("QUERY_GET_POLOWNER_BY_CASEID");
		return doQuery(queryParams, query);
	}

	@Override
	public ArrayList<Map<String, Object>> getPOByPolNum(String polNum) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		LogUtil.logInfo(m_Logger," polNum : " + polNum);
		queryParams.put(PropertyUtil.getCommonProperty(LOCALPOLNUM), polNum);
		String query = PropertyUtil.getScriptAndQueryProperty("QUERY_GET_POLOWNER_BY_POLNO");
		return doQuery(queryParams, query);
	}

	@Override
	public ArrayList<Map<String, Object>> searchSignature(Map<String, String> inputParamsMap) throws RemoteException {
		String message = "function : searchSignature";
		LogUtil.logInfo(m_Logger,message + LOCALISSTART);
		LogUtil.logInfo(m_Logger," inputParamsMap : " + inputParamsMap.toString());

		String query = PropertyUtil.getScriptAndQueryProperty("QUERY_SEARCHSIGNATURE");
		Map<String, String> queryParam = new HashMap<String, String>();
		if (!StringUtil.isBlank(inputParamsMap.get(LOCALPOLNUM))) {
			queryParam.put(LOCALPOLNUM, inputParamsMap.get(LOCALPOLNUM));
		}
		if (!StringUtil.isBlank(inputParamsMap.get("ROLE"))) {
			queryParam.put("ROLE", inputParamsMap.get("ROLE"));
		}
		ArrayList<Map<String, Object>> result = doQuery(queryParam, query);
		LogUtil.logInfo(m_Logger,result.toString());
		LogUtil.logInfo(m_Logger,message + LOCALISLEAVING);
		return result;
	}

	@Override
	public ArrayList<Map<String, Object>> searchEmailTemplete(Map<String, String> inputParamsMap)
			throws RemoteException {
		String message = "function : searchEmailTemplete";
		LogUtil.logInfo(m_Logger,message + LOCALISSTART);
		String queryName = PropertyUtil.getScriptAndQueryProperty("QUERY_SEARCHEMAILTEMPLETE");
		ArrayList<Map<String, Object>> result = doQuery(inputParamsMap, queryName);

		LogUtil.logInfo(m_Logger,message + LOCALISLEAVING);
		return result;
	}

	@Override
	public List<BigDecimal> getPendingReasonId(String caseId, String pendingSeq) throws RemoteException {
		String message = "function name : getPendingReasonId";
		LogUtil.logInfo(m_Logger,message + " is start .");
		List<BigDecimal> prIds = new ArrayList<BigDecimal>();
		Map<String, String> queryParams = new HashMap<String, String>();
		LogUtil.logInfo(m_Logger," getPendingReasonId 1");
		queryParams.put(PropertyUtil.getCommonProperty(LOCALLINKCASEID), caseId);
		queryParams.put(PropertyUtil.getCommonProperty("PENDING_SEQ"), pendingSeq);
		LogUtil.logInfo(m_Logger," getPendingReasonId 2");
		String query = PropertyUtil.getScriptAndQueryProperty("QUERY_PENDINGHISTORY");
		ArrayList<Map<String, Object>> result = doQuery(queryParams, query);
		for (Map<String, Object> map : result) {
			prIds.add(new BigDecimal(map.get("S_ROWID").toString()));
		}
		LogUtil.logInfo(m_Logger," getPendingReasonId 3");
		LogUtil.logInfo(m_Logger,message + " is leaving .");
		LogUtil.logInfo(m_Logger,prIds.toString());
		return prIds;
	}

	@Override
	public List<String> getPendingReason(String caseId, String pendingSeq) throws RemoteException {
		String message = "function name : getPendingReason";
		LogUtil.logInfo(m_Logger,message + " is start .");
		List<String> reasons = new ArrayList<String>();
		Map<String, String> queryParams = new HashMap<String, String>();
		LogUtil.logInfo(m_Logger," getPendingReason 1");
		queryParams.put(PropertyUtil.getCommonProperty(LOCALLINKCASEID), caseId);
		queryParams.put(PropertyUtil.getCommonProperty("PENDING_SEQ"), pendingSeq);
		LogUtil.logInfo(m_Logger," getPendingReason 2");
		String query = PropertyUtil.getScriptAndQueryProperty("QUERY_PENDINGHISTORY");
		ArrayList<Map<String, Object>> result = doQuery(queryParams, query);
		for (Map<String, Object> map : result) {
			reasons.add(map.get(PropertyUtil.getCommonProperty("PENDING_REASON")).toString());
		}
		LogUtil.logInfo(m_Logger," getPendingReason 3");
		LogUtil.logInfo(m_Logger,message + " is leaving .");
		LogUtil.logInfo(m_Logger,reasons.toString());
		return reasons;
	}

	@Override
	public ArrayList<Map<String, Object>> getOfficeEmail(String officeCode) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		LogUtil.logInfo(m_Logger," officeCode : " + officeCode);
		queryParams.put(PropertyUtil.getCommonProperty("OFFICE_CODE"), officeCode);
		String query = PropertyUtil.getScriptAndQueryProperty("QUERY_GET_EMAIL_BY_OFFCODE");
		return doQuery(queryParams, query);
	}

	@Override
	public ArrayList<Map<String, Object>> getUserProfile(String userId) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		LogUtil.logInfo(m_Logger," userId : " + userId);
		queryParams.put(PropertyUtil.getCommonProperty("USER_NAME"), userId);
		String query = PropertyUtil.getScriptAndQueryProperty("QUERY_GET_USER_PROFILE");
		return doQuery(queryParams, query);
	}

	@Override
	public ArrayList<Map<String, Object>> genCallbackRpt() throws RemoteException {
		String query = PropertyUtil.getScriptAndQueryProperty("QUERY_GET_CBOD_RPT");
		return doQuery(null, query);
	}

	@Override
	public ArrayList<Map<String, Object>> getChangeItems(String caseId) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();
		LogUtil.logInfo(m_Logger,LOCALCASEID + caseId);
		queryParams.put(PropertyUtil.getCommonProperty(LOCALLINKCASEID), caseId);
		String query = PropertyUtil.getScriptAndQueryProperty("QUERY_CHANGEITEMS");
		return doQuery(queryParams, query);
	}

	@Override
	public ArrayList<Map<String, Object>> getProduct(String polNum) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();

		queryParams.put(WorkItemDetail.POL_NUM, polNum);
		return doQuery(queryParams, "getProductsByPolNo");
	}

	@Override
	public ArrayList<Map<String, Object>> getPolicyRole(String policyNum) throws RemoteException {
		Map<String, String> queryParams = new HashMap<String, String>();

		queryParams.put(WorkItemDetail.POL_NUM, policyNum);
		String query = PropertyUtil.getScriptAndQueryProperty("QUERY_SEARCH_POLICYROLE");
		return doQuery(queryParams, query);
	}
}