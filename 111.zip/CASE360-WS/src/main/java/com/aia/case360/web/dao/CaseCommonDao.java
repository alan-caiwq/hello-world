package com.aia.case360.web.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.aia.case360.web.pojo.CaseAvailableStep;
import com.aia.case360.web.pojo.CaseCloseReason;

@Repository
public interface CaseCommonDao {
	public List<String> getCloseReasonByDept(String dept);

	public List<CaseCloseReason> getCloseReason(CaseCloseReason caseCloseReason);

	public void batchUpdateAvailableStep(List<CaseAvailableStep> caseAvailableSteps);

	public Map<String, String> getDroolsParam(String linkcaseid);

}
