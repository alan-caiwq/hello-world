package com.aia.case360.web.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.aia.case360.web.pojo.FRMCaseCheckResult;
import com.aia.case360.web.pojo.FRMCaseCheckRetrieveDocResult;
import com.aia.case360.web.pojo.FRMCreateCaseParam;
import com.aia.case360.web.pojo.FRMCreateRetrieveDocRecordParam;
import com.aia.case360.web.pojo.FRMCreateRetrievedRecordParam;
import com.aia.case360.web.pojo.FRMSearchScannedPolicyParam;
import com.aia.case360.web.vo.FRMOfficeVo;
import com.aia.case360.web.vo.FRMReasonVo;
import com.aia.case360.web.vo.FRMSearchScannedPolicyVo;

public interface FRMRetrievedDao {

  List<FRMSearchScannedPolicyVo> searchScannedPolicy(FRMSearchScannedPolicyParam param) throws SQLException;
  
  Boolean createRetrievedRecord(FRMCreateRetrievedRecordParam createParam) throws SQLException;
  
  Boolean createRetrieveDocRecord(FRMCreateRetrieveDocRecordParam createParam) throws SQLException;

  List<FRMCaseCheckRetrieveDocResult> getSameRetrievedDocCase(@Param("policyNum")String policyNum, @Param("objectId")String objectId, @Param("page")String page, @Param("reqType")String reqType, @Param("companyNo")String companyNo);

  List<FRMReasonVo> getReasons(@Param("user")String user, @Param("type")Integer type) throws SQLException;

  String addReason(@Param("user")String user, @Param("reason")String reason) throws SQLException;

  List<FRMOfficeVo> getOffices(String user) throws SQLException;

  String addOffice(@Param("user")String user, @Param("office")String office) throws SQLException;
}
