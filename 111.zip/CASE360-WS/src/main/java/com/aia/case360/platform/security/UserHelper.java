package com.aia.case360.platform.security;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import com.eistream.sonora.users.UserElement;

public interface UserHelper {

	/**
	 * search user by searchType, the status is default active
	 * 
	 * @param searchType include loginId,firstName,lastName,displayName
	 * @param searchText
	 * @return
	 * @throws RemoteException
	 */
	public List<UserElement> getUserList(String searchType, String searchText) throws RemoteException;

	/**
	 * To determine if the user exists by loginId
	 * 
	 * @param loginId
	 * @return
	 * @throws RemoteException
	 */
	public boolean userExists(String loginId) throws RemoteException;

	/**
	 * Remove user by loginId
	 * 
	 * @param loginId
	 * @return
	 * @throws RemoteException
	 */
	public boolean removeUser(String loginId) throws RemoteException;

	/**
	 * Get the user name of the current login
	 * 
	 * @return
	 * @throws RemoteException
	 */
	public String getCurrentUser() throws RemoteException;

	/**
	 * Create user
	 * 
	 * @param params These parameters are necessary:loginID(unique),displayName.
	 *               These parameters are not necessary:
	 *               comments,deliveryFlag,deliveryString,firstName,group,lastName,licenseGroupID,
	 *               managerID, busyFactor,
	 *               preferredLocale,status,timeZone,userVariables,workCalendarName,
	 *               persona,defaultQueries, homePage,allowApplets If you do not
	 *               fill in and the system will fill in default value
	 * @return
	 * @throws RemoteException
	 */
	public boolean createUser(Map<String, String> params) throws RemoteException;

	/**
	 * Update user
	 * 
	 * @param params
	 * @return
	 * @throws RemoteException
	 */
	public boolean updateUser(Map<String, String> params) throws RemoteException;

	/**
	 * Query Users
	 * 
	 * @param searchType loginID firstName lastName displayName
	 * @param searchText
	 * 
	 * @return
	 * @throws RemoteException
	 */
	public List<Map<String, String>> searchUser(String searchType, String searchText) throws RemoteException;

	/**
	 * 
	 * @param loginID
	 * @return
	 * @throws RemoteException
	 */
	public Map<String, Object> getUserElement(String loginID) throws RemoteException;

	public boolean createUserTeam(Map<String, String> params) throws RemoteException;

	public boolean updateUserTeam(Map<String, String> params) throws RemoteException;

	public boolean deleteUserTeam(Map<String, String> params) throws RemoteException;

	public String getUserTeam(String userName) throws RemoteException;

	public boolean createUserGroup(Map<String, String> params, List<String> roles) throws RemoteException;

	public boolean updateUserGroup(Map<String, String> params, List<String> roles) throws RemoteException;

	public boolean deleteUserGroup(Map<String, String> params) throws RemoteException;

	public boolean updateUserGroupByUser(Map<String, String> params, List<String> userGroups) throws RemoteException;

	public List<Map<String, Object>> getUserGroups(String loginID) throws RemoteException;
}
