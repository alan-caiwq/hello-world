package com.aia.case360.web.auditTrail;

public class AuditEntityIgnoreCondition {

	public AuditEntityIgnoreCondition(String fieldName, Object fieldValue) {
		 this.fieldName = fieldName;
		 this.fieldValue = fieldValue;

	}

	String fieldName;
	Object fieldValue;

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public Object getFieldValue() {
		return fieldValue;
	}

	public void setFieldValue(Object fieldValue) {
		this.fieldValue = fieldValue;
	}

}
