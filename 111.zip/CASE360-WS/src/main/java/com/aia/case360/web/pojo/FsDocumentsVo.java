package com.aia.case360.web.pojo;

public class FsDocumentsVo {

	private String objectId;

	private String createDate;

	private int isVoid = 0;

	private int isSysVoid = 0;

	private String lastUpdatedBy;

	private String lastUpdatedTimestamp;

	private String pageIndicator;

	private String documentId;

	private String processType;

	public String getProcessType() {
		return processType;
	}

	public void setProcessType(String processType) {
		this.processType = processType;
	}

	public String getObjectId() {
		return objectId;
	}

	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public int getIsVoid() {
		return isVoid;
	}

	public void setIsVoid(int isVoid) {
		this.isVoid = isVoid;
	}

	public int getIsSysVoid() {
		return isSysVoid;
	}

	public void setIsSysVoid(int isSysVoid) {
		this.isSysVoid = isSysVoid;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public String getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(String lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public String getPageIndicator() {
		return pageIndicator;
	}

	public void setPageIndicator(String pageIndicator) {
		this.pageIndicator = pageIndicator;
	}

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

}
