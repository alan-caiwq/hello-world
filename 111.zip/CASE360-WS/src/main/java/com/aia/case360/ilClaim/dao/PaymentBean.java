package com.aia.case360.ilClaim.dao;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class PaymentBean {


	private JdbcTemplate jdbcTemplate = ILDataSource.getILjdbcTemplate();

	/**
	 * payment Approval
	 * 
	 * @param params
	 * @return
	 * @throws SQLException
	 */
	public List<Map<String, String>> getPaymentApproval(Map<String, String> params) throws SQLException {

		String paymentIds = "";
		if (null != params && params.size() > 0) {
			paymentIds = params.get("paymentIds");

		}

		StringBuilder str = new StringBuilder();

		str.append(
				"SELECT a.PYMT AS payment_amount, a.REQNNO AS payment_ID, b.SACSCODE||b.SACSTYP AS subaccount_code , c.PROCIND");
		str.append(" FROM  ZPMPPF a JOIN  ACMVPF b ON a.REQNNO=b.RDOCNUM ");
		str.append(" JOIN CHEQPF c ON a.REQNNO=c.REQNNO");
		str.append(" where a.VALIDFLAG = '1' ");

		if (null != paymentIds && paymentIds.length() > 0) {
			str.append(" and  a.REQNNO in ( ");
			str.append(paymentIds + ")");

		}
		str.append(" and c.PROCIND='AQ'");

		List<Map<String, String>> result = jdbcTemplate.query(str.toString(), new RowMapper<Map<String, String>>() {

			@Override
			public Map<String, String> mapRow(ResultSet rs, int index) throws SQLException {
				Map<String, String> map = new HashMap<String, String>();
				ResultSetMetaData meta = rs.getMetaData();
				int count = meta.getColumnCount();
				for (int i = 1; i <= count; i++) {
					map.put(meta.getColumnName(i), rs.getString(i) == null ? "" : rs.getString(i));
				}
				return map;
			}
		});

		return result;

	}

	/**
	 * payment Authorization
	 * 
	 * @param params
	 * @return
	 * @throws SQLException
	 */
	public List<Map<String, String>> getPaymentAuthorization(Map<String, String> params) throws SQLException {

		String paymentIds = "";
		if (null != params && params.size() > 0) {
			paymentIds = params.get("paymentIds");

		}

		StringBuilder str = new StringBuilder();

		str.append(
				"SELECT a.PYMT AS payment_amount, a.REQNNO AS payment_ID, b.SACSCODE||b.SACSTYP AS subaccount_code , c.PROCIND");
		str.append(" FROM  ZPMPPF a JOIN  ACMVPF b ON a.REQNNO=b.RDOCNUM ");
		str.append(" JOIN CHEQPF c ON a.REQNNO=c.REQNNO");
		str.append(" where a.VALIDFLAG = '1' ");

		if (null != paymentIds && paymentIds.length() > 0) {
			str.append(" and  a.REQNNO in ( ");
			str.append(paymentIds + ")");

		}
		str.append(" and c.PROCIND='AU'");

		List<Map<String, String>> result = jdbcTemplate.query(str.toString(), new RowMapper<Map<String, String>>() {

			@Override
			public Map<String, String> mapRow(ResultSet rs, int index) throws SQLException {
				Map<String, String> map = new HashMap<String, String>();
				ResultSetMetaData meta = rs.getMetaData();
				int count = meta.getColumnCount();
				for (int i = 1; i <= count; i++) {
					map.put(meta.getColumnName(i), rs.getString(i) == null ? "" : rs.getString(i));
				}
				return map;
			}
		});

		return result;

	}

}
