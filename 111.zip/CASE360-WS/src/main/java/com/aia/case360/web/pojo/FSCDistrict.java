package com.aia.case360.web.pojo;

public class FSCDistrict {

	private String agentCode;
	private String agentName;
	private String agencyCode;
	private String agencyChannel;
	private String districtCode;
	private String aiaEmail;
	private String agentStatus;

	public String getAgentCode() {
		return agentCode;
	}

	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public String getAgencyCode() {
		return agencyCode;
	}

	public void setAgencyCode(String agencyCode) {
		this.agencyCode = agencyCode;
	}

	public String getAgencyChannel() {
		return agencyChannel;
	}

	public void setAgencyChannel(String agencyChannel) {
		this.agencyChannel = agencyChannel;
	}

	public String getDistrictCode() {
		return districtCode;
	}

	public void setDistrictCode(String districtCode) {
		this.districtCode = districtCode;
	}

	public String getAiaEmail() {
		return aiaEmail;
	}

	public void setAiaEmail(String aiaEmail) {
		this.aiaEmail = aiaEmail;
	}

	public String getAgentStatus() {
		return agentStatus;
	}

	public void setAgentStatus(String agentStatus) {
		this.agentStatus = agentStatus;
	}

}
