package com.aia.case360.platform.formdata.impl;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.FinderException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.aia.case360.platform.common.DateUtil;
import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.common.PropertyUtil;
import com.aia.case360.platform.dao.TableIdBean;
import com.aia.case360.platform.formdata.DataTableHelper;
import com.aia.case360.platform.formdata.PendingReasonListHelper;
import com.aia.case360.platform.process.WorkItemHelper;
import com.aia.case360.platform.query.QueryFormDataHelper;
import com.aia.case360.platform.security.UserHelper;
import com.aia.case360.web.service.impl.AbstractHelperImpl;
import com.aia.case360.web.vo.PendingParam;
import com.aia.case360.web.vo.PendingReason;
import com.eistream.sonora.exceptions.SonoraException;
import com.eistream.sonora.fields.FmsField;
import com.eistream.sonora.fields.FmsRow;
import com.eistream.sonora.fields.FmsRowChange;
import com.eistream.sonora.fields.FmsRowConflict;
import com.eistream.sonora.fields.FmsRowNative;

@Component
public class PendingReasonListHelperImpl extends AbstractHelperImpl implements PendingReasonListHelper {

	private static final String FDPENDINGREASONSSTR = "FD_PENDINGREASONS";
	private static final String FOUNDSTR = " found!";
	private static final String REQTYPESTR = "REQ_TYPE";
	private static final String PENDINGREASONSTR = "PENDING_REASON";
	private static final String PENDINGSEQSTR = "PENDING_SEQ";
	private static final String LINKCASEIDSTR = "LINKCASEID";
	private static final String PENDINGDURATIONSTR = "PENDING_DURATION";
	
	@Autowired
	public UserHelper userHelper;

	@Autowired
	public QueryFormDataHelper queryFdHelper;

	@Autowired
	public DataTableHelper dtHelper;

	@Autowired
	private TableIdBean tableIdBean;

	@Autowired
	public WorkItemHelper workItemHelper;

	/**
	 * @throws SQLException
	 * 
	 */
	@Override
	public List<FmsRowNative> getPendingReasonRow(List<BigDecimal> rowIds) throws RemoteException, SQLException {
		LogUtil.logInfo(m_Logger,"FunciontName getPendingReasonRow is entering!");
		List<FmsRowNative> result = new ArrayList<FmsRowNative>();

		BigDecimal fd_pendingReasonTableId = new BigDecimal(
				 tableIdBean.getTableIds().get(PropertyUtil.getTableIDProperty("TABLEID_PENDINGREASON")));

		if (fd_pendingReasonTableId == new BigDecimal(0)) {
			String errMsg = "No any formdata definition for " + PropertyUtil.getCommonProperty(FDPENDINGREASONSSTR)
					+ FOUNDSTR;
			LogUtil.logError(m_Logger, errMsg);
			throw new RemoteException(errMsg);
		}

		for (BigDecimal rowId : rowIds) {
			try {
				result.add(getFmsEJB().fetch(fd_pendingReasonTableId, rowId));
			} catch (RemoteException e) {
				String errMsg = "No any data for " + PropertyUtil.getCommonProperty(FDPENDINGREASONSSTR) + " rowId "
						+ rowId + FOUNDSTR + "|" + e.getMessage();
				throw LogUtil.logException(m_Logger, errMsg, e);
			} catch (FinderException e) {

				 
				String errMsg = "No any data for " + PropertyUtil.getCommonProperty(FDPENDINGREASONSSTR) + " rowId "
						+ rowId + FOUNDSTR + "|" + e.getMessage();
				throw LogUtil.logException(m_Logger, errMsg, e);
			}
		}
		LogUtil.logInfo(m_Logger,"FunciontName getPendingReasonRow is leaving!");

		return result;
	}

	@Override
	public boolean addPendingReasonHistory(FmsRow parentRow, List<FmsRowNative> prDefines, Map<String, String> params)
			throws RemoteException {
		LogUtil.logInfo(m_Logger,"FunciontName addPendingReasonHistory is entering!");
		StringBuilder sb = new StringBuilder();
		sb.append("PI RowKey:");
		try {
			sb.append(parentRow.getRowId());
			List<FmsRowChange> historyChanges = new ArrayList<FmsRowChange>();
			for (FmsRowNative row : prDefines) {
				if (savePIRow(parentRow, row, params)) {

					sb.append(" pendingReasion Definition Id:" + row.getRowId());
					FmsRow nPendingReasonHistory = getFmsEJB().createRelatedRow(parentRow,
							PropertyUtil.getCommonProperty("TABLE_RELATION_CASEPENDINGHISTORY"));
					FmsRow prHistory = (FmsRow) nPendingReasonHistory.clone();
					for (FmsField ff : prHistory.getFieldList()) {
						LogUtil.logInfo(m_Logger,ff.getFmsFieldTO().getFieldName() + "   " + ff.getValue());
					}
					prHistory.setValue(REQTYPESTR, parentRow.getValue(REQTYPESTR));
					prHistory.setValue("WFWORKSTEPNAME", parentRow.getValue("WFWORKSTEPNAME"));
					prHistory.setValue("CREATED_BY", params.get("userId"));
					prHistory.setValue("DATE_RAISED", DateUtil.getCurrentTime());
					prHistory.setValue("NOTIFY", row.getValue("NOTIFY"));
					prHistory.setValue(PENDINGREASONSTR, row.getValue(PENDINGREASONSTR));
					prHistory.setValue(PENDINGSEQSTR, (Integer) parentRow.getValue(PENDINGSEQSTR));

					historyChanges.add(FmsRowChange.getInstanceSaveChanges(nPendingReasonHistory, prHistory, false));
				} else {
					return false;
				}
			}

			FmsRowChange[] changes = new FmsRowChange[historyChanges.size()];
			historyChanges.toArray(changes);
			saveAllChanges(sb, changes);
			LogUtil.logInfo(m_Logger,sb.toString());
			LogUtil.logInfo(m_Logger,"FunciontName addPendingReasonHistory is leaving!");

			return true;

		} catch (SonoraException e) {

			 
			throw LogUtil.logException(m_Logger, sb.toString(), e);
		} catch (Exception e) {

			 
			throw LogUtil.logException(m_Logger, sb.toString(), e);
		}
	}

	public boolean addPendingReasonHistory(FmsRow parentRow, List<PendingParam> params) throws RemoteException {
		for (PendingParam param : params) {
			addPendingReasonHistory(parentRow, param);
		}
		return true;
	}

	public boolean addPendingReasonHistory(FmsRow parentRow1, PendingParam params) throws RemoteException {
		LogUtil.logInfo(m_Logger,"FunciontName addPendingReasonHistory is entering!");
		StringBuilder sb = new StringBuilder();
		sb.append("PI RowKey:");
		try {

			FmsRow workItemRow = workItemHelper.getWorkItemRow(params.getRepositoryKey());
			FmsRow workItemSysRow = workItemHelper.getWorkItemSysRow(params.getRepositoryKey());
			String workstep = workItemHelper.getCurWorkstep(params.getRepositoryKey());

			FmsRow caseFolderRow = getCfsEJB()
					.getCaseFolderFields(new BigDecimal(String.valueOf(workItemRow.getValue(LINKCASEIDSTR))));

			sb.append(workItemRow.getRowId());
			List<String> currentReasonList = new ArrayList<String>();

			// calcute PENDING_SEQ
			FmsRow oldRow = (FmsRow) workItemRow.clone();
			int pending_seq = 1;
			if (!workstep.equals(PropertyUtil.getCommonProperty("PENDING_STEP_NAME"))) {
				pending_seq = (Integer) workItemRow.getValue(PENDINGSEQSTR) == null ? 1
						: ((Integer) workItemRow.getValue(PENDINGSEQSTR) + 1);
			} else {
				if (workItemRow.getValue(PENDINGSEQSTR) == null) {
					throw new RemoteException("PENDING_SEQ is null");
				}
				pending_seq = (Integer) workItemRow.getValue(PENDINGSEQSTR);

				// get current pending reason history reason list
				currentReasonList = queryFdHelper.getPendingReason(workItemRow.getValue(LINKCASEIDSTR).toString(),
						String.valueOf(pending_seq));
			}

			workItemRow.setValue(PENDINGSEQSTR, pending_seq);
			FmsRowConflict result = getFmsEJB().saveChanges(oldRow, (FmsRowNative) workItemRow, false);

			if (null != result && result.conflictArray.length != 0) {
				return false;
			}

			for (PendingReason reason : params.getPendingReasons()) {
				if (currentReasonList != null && currentReasonList.contains(reason.getReason())) {
					continue;
				}
				sb.append(" pendingReasion Definition:" + reason.toString());

				BigDecimal pendingReasonHistoryTableId = new BigDecimal(
						tableIdBean.getTableIds().get(PropertyUtil.getTableIDProperty("TABLEID_PENDINGHISTORY")));

				Map<String, String> createParams = new HashMap<String, String>();

				createParams.put(REQTYPESTR, String.valueOf(caseFolderRow.getValue(REQTYPESTR)));
				createParams.put("WORKSTEPNAME", workstep);
				createParams.put("CREATED_BY", userHelper.getCurrentUser());
				createParams.put("CREATED_DT", DateUtil.getCurrentTime());
				createParams.put("POL_NUM", reason.getPolicyNumber());
				createParams.put("IL_FOLLOWUP_CD", reason.getIlFollowupCode());
				createParams.put("IL_PROCESS_TYPE", reason.getIlProcessType());
				createParams.put(PENDINGDURATIONSTR, reason.getDuration());
				createParams.put("WORKFLOWID", String.valueOf(workItemSysRow.getValue("WORKFLOWID")));
				createParams.put(LINKCASEIDSTR, String.valueOf(workItemRow.getValue(LINKCASEIDSTR)));
				createParams.put(PENDINGREASONSTR, reason.getReason());
				createParams.put(PENDINGSEQSTR, String.valueOf(workItemRow.getValue(PENDINGSEQSTR)));

				dtHelper.createTableRow(pendingReasonHistoryTableId, createParams);
			}

			LogUtil.logInfo(m_Logger,sb.toString());
			LogUtil.logInfo(m_Logger,"FunciontName addPendingReasonHistory is leaving!");

			return true;

		} catch (SonoraException e) {

			 
			throw LogUtil.logException(m_Logger, sb.toString(), e);
		} catch (Exception e) {

			 
			throw LogUtil.logException(m_Logger, sb.toString(), e);
		}
	}

	private void saveAllChanges(StringBuilder sb, FmsRowChange[] changes) throws RemoteException {
		LogUtil.logInfo(m_Logger,"FunciontName saveAllChanges is entering!");
		FmsRowConflict[] moreConflict;
		try {
			moreConflict = getFmsEJB().saveChanges(changes);

			if (moreConflict != null && moreConflict.length > 0) {
				boolean conflictFlag = false;
				for (FmsRowConflict frc : moreConflict) {
					if (frc != null) {
						conflictFlag = true;
						sb.append("|conflictRow:");
						if (frc.getConflictFieldNames() != null) {
							addSB(sb, frc.getConflictFieldNames());
						}
					}
				}
				if (conflictFlag) {
					throw LogUtil.logException(m_Logger, sb.toString(), new RemoteException());
				}
			}
			LogUtil.logInfo(m_Logger,"FunciontName saveAllChanges is leaving!");
		} catch (FinderException e) {
			throw LogUtil.logException(m_Logger, sb.toString(), e);
		}
	}

	private void addSB(StringBuilder sb, String[] conflictFieldNames) {
		for (String fldName : conflictFieldNames) {
			sb.append(fldName);
		}
	}

	private boolean savePIRow(FmsRow pi_process_row, FmsRowNative prDefine, Map<String, String> fldPair)
			throws RemoteException {

		LogUtil.logInfo(m_Logger,"FunciontName savePIRow is entering!");

		String message = "PI Row Key:";
		try {

			message += pi_process_row.rowId + fldPair.toString();
			FmsRow oldRow = (FmsRow) pi_process_row.clone();
			int pending_seq = (Integer) pi_process_row.getValue(PENDINGSEQSTR) == null ? 1
					: ((Integer) pi_process_row.getValue(PENDINGSEQSTR) + 1);
			pi_process_row.setValue(PENDINGSEQSTR, pending_seq);
			pi_process_row.setValue(PENDINGDURATIONSTR, prDefine.getField(PENDINGDURATIONSTR).value.toString());
			FmsRowConflict result = getFmsEJB().saveChanges(oldRow, (FmsRowNative) pi_process_row, false);

			LogUtil.logInfo(m_Logger,message);
			LogUtil.logInfo(m_Logger,"FunciontName savePIRow is leaving!");

			return null == result || result.conflictArray.length == 0;

		} catch (SonoraException e) {
			 
			throw LogUtil.logException(m_Logger, message, e);
		} catch (RemoteException e) {
			 
			throw LogUtil.logException(m_Logger, message, e);
		} catch (Exception e) {
			 
			throw LogUtil.logException(m_Logger, message, e);
		}
	}

	@Override
	public List<FmsRowNative> getPendingReasonHistoryRows(List<BigDecimal> prIdsList)
			throws RemoteException, SQLException {
		LogUtil.logInfo(m_Logger,"FunciontName getPendingReasonHistoryRows is entering!");
		LogUtil.logInfo(m_Logger,"input parameters: " + prIdsList.toString());
		List<FmsRowNative> result = new ArrayList<FmsRowNative>();
		if (prIdsList.isEmpty()) {
			throw LogUtil.logException(m_Logger, "No rowId passed",
					new IllegalArgumentException("No row id list input"));
		}

		for (BigDecimal rowId : prIdsList) {
			try {
				result.add(getFmsEJB().fetch(new BigDecimal(
						 tableIdBean.getTableIds().get(PropertyUtil.getTableIDProperty("TABLEID_PENDINGHISTORY"))),
						rowId));
			} catch (FinderException e) {

				 
				throw LogUtil.logException(m_Logger, prIdsList.toString(), e);
			}
		}
		LogUtil.logInfo(m_Logger,"FunciontName getPendingReasonHistoryRows is leaving!");

		return result;
	}

	@Override
	public List<FmsRow> getAllPendingReasonHistory(FmsRow parentRow) throws RemoteException {
		LogUtil.logInfo(m_Logger,"FunciontName getAllPendingReasonHistory is entering!");
		FmsRow[] pendingHistory = getFmsEJB().fetchRelatedRows(parentRow,
				PropertyUtil.getCommonProperty("TABLE_RELATION_CASEPENDINGHISTORY"));

		List<FmsRow> result = new ArrayList<FmsRow>();
		for (FmsRow row : pendingHistory) {
			Object obj = row.getValue("RECEIVED_DATE");
			if (null == obj) {
				result.add(row);
			}
		}
		LogUtil.logInfo(m_Logger,"FunciontName getAllPendingReasonHistory is leaving!");
		return result;
	}

	@Override
	public boolean updatePendingReasonHistory(List<FmsRowNative> oldpendingReasons, List<FmsRowNative> pendingReasons)
			throws RemoteException {
		LogUtil.logInfo(m_Logger,"FunciontName updatePendingReasonHistory is entering!");
		FmsRowChange[] changes = new FmsRowChange[pendingReasons.size()];
		LogUtil.logInfo(m_Logger,"updatePendingReasonHistory 1");
		for (int i = 0; i < pendingReasons.size(); i++) {
			changes[i] = FmsRowChange.getInstanceSaveChanges(oldpendingReasons.get(i), pendingReasons.get(i), false);
		}
		LogUtil.logInfo(m_Logger,"updatePendingReasonHistory 2");
		StringBuilder sb = new StringBuilder();
		saveAllChanges(sb, changes);
		LogUtil.logInfo(m_Logger,"FunciontName updatePendingReasonHistory is leaving!");
		return true;

	}
}