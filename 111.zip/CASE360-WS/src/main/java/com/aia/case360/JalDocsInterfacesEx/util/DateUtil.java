package com.aia.case360.JalDocsInterfacesEx.util;

import java.rmi.RemoteException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aia.case360.platform.common.LogUtil;

/**
 * @author asnpw16
 * 
 *         To change the template for this generated type comment go to
 *         Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class DateUtil {

	private static Logger m_Logger = LoggerFactory.getLogger(DateUtil.class.getClass());

	private DateUtil() {
	}

	private static final int VALUE_OF_A_CHAR = (int) 'A';

	private static final int VALUE_OF_SMALL_CAP_A_CHAR = (int) 'a';

	/**
	 * Convert eistream form date string to Julian Date String
	 * 
	 * @param dateString
	 * @return
	 * @ throws RemoteException
	 */
	public final static String releaseXmlDate2Julian(String iStrDate, String sDateTimeFormat)  throws RemoteException {
		SimpleDateFormat JULIAN_SDF = new SimpleDateFormat("yyDDD");

		SimpleDateFormat xmlDateSdf = new SimpleDateFormat("yyyy-MM-dd");
		String strJulianDate = "";
		if (iStrDate != null && !iStrDate.isEmpty()) {
			try {
				if (iStrDate.length() == 10) {

					Date julianDate = xmlDateSdf.parse(iStrDate);
					strJulianDate = JULIAN_SDF.format(julianDate);

				} else if (iStrDate.length() == 8) {
					SimpleDateFormat in = new SimpleDateFormat("MMddyyyy");
					SimpleDateFormat out = new SimpleDateFormat(sDateTimeFormat);
					Date julianDate = out.parse(out.format(in.parse(iStrDate)));
					strJulianDate = JULIAN_SDF.format(julianDate);

				} else {
					SimpleDateFormat xmlDateTimeSdf = new SimpleDateFormat(sDateTimeFormat);
					Date julianDate = xmlDateTimeSdf.parse(iStrDate);
					strJulianDate = JULIAN_SDF.format(julianDate);
				}

			} catch (ParseException e) {
				 throw LogUtil.logException(m_Logger , iStrDate, e);
			}
		}
		return strJulianDate;
	}

	/**
	 * Convert Julian date string to three digit string
	 * 
	 * @param julian
	 * @return
	 */
	public final static String julian2ThreeDigitsDate(String julianDate)  throws RemoteException {

		String compressedJulianDate = "";

		if (julianDate != null && !julianDate.isEmpty()) {

			long julianLong = Long.parseLong(julianDate);
			long remainder = julianLong % (52 * 52);
			int valueof1Char = (int) julianLong / (52 * 52);
			int valueof2Char = (int) remainder / 52;
			int valueof3Char = (int) remainder % 52;
			char threeDigit[] = new char[3];
			valueof1Char = valueof1Char > 25 ? valueof1Char - 26 + VALUE_OF_SMALL_CAP_A_CHAR
					: valueof1Char + VALUE_OF_A_CHAR;
			valueof2Char = valueof2Char > 25 ? valueof2Char - 26 + VALUE_OF_SMALL_CAP_A_CHAR
					: valueof2Char + VALUE_OF_A_CHAR;
			valueof3Char = valueof3Char > 25 ? valueof3Char - 26 + VALUE_OF_SMALL_CAP_A_CHAR
					: valueof3Char + VALUE_OF_A_CHAR;

			threeDigit[0] = (char) valueof1Char;
			threeDigit[1] = (char) valueof2Char;
			threeDigit[2] = (char) valueof3Char;

			compressedJulianDate = new String(threeDigit);
		}

		return compressedJulianDate;
	}

	public static String formatDate(String inDate, String fromFmt, String toFmt)  throws RemoteException {
		SimpleDateFormat fromSDF = new SimpleDateFormat(fromFmt);
		Date julianDate;
		try {
			julianDate = fromSDF.parse(inDate);
			SimpleDateFormat toSDF = new SimpleDateFormat(toFmt);
			return toSDF.format(julianDate);
		} catch (ParseException e) {
			throw new RemoteException(e.getMessage());
		}
		
	}
}
