package com.aia.case360.web.pojo;

public class AutoFileGetAutoFileRequestNoCaseIdResult {
  
  private Boolean isMatchRequestNo;
  
  private String requestNo;
  
  private Long caseId;

  /**
   * @return the isMatchRequestNo
   */
  public Boolean getIsMatchRequestNo() {
    return isMatchRequestNo;
  }

  /**
   * @return the requestNo
   */
  public String getRequestNo() {
    return requestNo;
  }

  /**
   * @return the caseId
   */
  public Long getCaseId() {
    return caseId;
  }

  /**
   * @param isMatchRequestNo the isMatchRequestNo to set
   */
  public void setIsMatchRequestNo(Boolean isMatchRequestNo) {
    this.isMatchRequestNo = isMatchRequestNo;
  }

  /**
   * @param requestNo the requestNo to set
   */
  public void setRequestNo(String requestNo) {
    this.requestNo = requestNo;
  }

  /**
   * @param caseId the caseId to set
   */
  public void setCaseId(Long caseId) {
    this.caseId = caseId;
  }

  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "AutoFileGetAutoFileRequestNoCaseIdResult [isMatchRequestNo=" + isMatchRequestNo
        + ", requestNo=" + requestNo + ", caseId=" + caseId + "]";
  }
  
  

}
