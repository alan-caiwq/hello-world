package com.aia.case360.platform.common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class JsonUtil {

	private JsonUtil() {
	}

	public static Map<String, String> getStringMap(JSONObject request) {
		Map<String, String> result = new HashMap<>();
		@SuppressWarnings("unchecked")
		Iterator<String> keys = request.keys();
		while (keys.hasNext()) {
			String key = keys.next();
			String value = request.getString(key);
			result.put(key, value);
		}
		return result;
	}

	public static Map<String, String> getStringMap2(Map<String, Object> request) {
		Map<String, String> result = new HashMap<>();
		@SuppressWarnings("unchecked")
		Iterator<String> keys = request.keySet().iterator();
		while (keys.hasNext()) {
			String key = keys.next();
			String value = request.get(key).toString();
			result.put(key, value);
		}
		return result;
	}

	public static List<Map<String, String>> getRequestParamsList(JSONObject request, String keyName) {

		List<Map<String, String>> paramsList = new ArrayList<>();
		if (request != null && !request.isEmpty()) {
			String keyValue = request.get(keyName) == null ? "" : request.get(keyName).toString();
			JSONArray array = JSONArray.fromObject(keyValue);
			if(array != null && array.size() > 0){// add logic to avoid null pointRemoteException by charley 20181205
				for (int i = 0; i < array.size(); i++) {
					Map<String, String> paramPairs = null;
					JSONObject j = array.getJSONObject(i);
					if (!j.isEmpty()) {
						paramPairs = getStringMap(j);
						paramsList.add(paramPairs);
					}
				}
			}
		}
		return paramsList;
	}

	public static List<Map<String, String>> getMapList(String srcStr) {

		List<Map<String, String>> paramsList = new ArrayList<>();
		if (StringUtils.isNotBlank(srcStr)) {
			JSONArray array = JSONArray.fromObject(srcStr);
			for (int i = 0; i < array.size(); i++) {
				JSONObject jsonObject = array.getJSONObject(i);
				if (!jsonObject.isEmpty()) {
					paramsList.add(getStringMap(jsonObject));
				}
			}
		}
		return paramsList;
	}
}
