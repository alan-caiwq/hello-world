package com.aia.case360.drools.model;

public class RuleCase {
	String GROUPID;
	String ACTIVITY;
	String REQTYPE;
	String DEPARTMENT;
	String CREATE_TIMESTAMP;
	String PENDING_INDICATOR;
	String IS_ARCHIVED;

	public String getIS_ARCHIVED() {
		return IS_ARCHIVED;
	}

	public void setIS_ARCHIVED(String iS_ARCHIVED) {
		IS_ARCHIVED = iS_ARCHIVED;
	}

	public String getCREATE_TIMESTAMP() {
		return CREATE_TIMESTAMP;
	}

	public void setCREATE_TIMESTAMP(String cREATE_TIMESTAMP) {
		CREATE_TIMESTAMP = cREATE_TIMESTAMP;
	}

	public String getPENDING_INDICATOR() {
		return PENDING_INDICATOR;
	}

	public void setPENDING_INDICATOR(String pENDING_INDICATOR) {
		PENDING_INDICATOR = pENDING_INDICATOR;
	}

	public String getGROUPID() {
		return GROUPID;
	}

	public void setGROUPID(String gROUPID) {
		GROUPID = gROUPID;
	}

	public String getACTIVITY() {
		return ACTIVITY;
	}

	public void setACTIVITY(String aCTIVITY) {
		ACTIVITY = aCTIVITY;
	}

	public String getREQTYPE() {
		return REQTYPE;
	}

	public void setREQTYPE(String rEQTYPE) {
		REQTYPE = rEQTYPE;
	}

	public String getDEPARTMENT() {
		return DEPARTMENT;
	}

	public void setDEPARTMENT(String dEPARTMENT) {
		DEPARTMENT = dEPARTMENT;
	}

	@Override
	public String toString() {
		return "RuleCase [GROUPID=" + GROUPID + ", ACTIVITY=" + ACTIVITY + ", REQTYPE=" + REQTYPE + "]";
	}

	public String toTxt() {
		return "		RuleCase(\"" + RuleEnum.RULECASE_GROUPID + "\" == \"" + getGROUPID() + "\"," + "\""
				+ RuleEnum.RULECASE_ACTIVITY + "\" == \"" + getACTIVITY() + "\"," + "\"" + RuleEnum.RULECASE_REQTYPE
				+ " == \"" + getREQTYPE() + "\"" + ")";
	}
}
