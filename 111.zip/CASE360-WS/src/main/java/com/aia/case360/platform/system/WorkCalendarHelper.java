package com.aia.case360.platform.system;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.eistream.sonora.nbd.WorkCalendar;
import com.eistream.sonora.nbd.WorkCalendarDefElement;

/**
 * 
 * @author bsnpbjd
 *
 */
public interface WorkCalendarHelper {

	public List<String> getCustomCalendarCompanyList();

	/**
	 * 
	 * @param name
	 * @return CalendarList
	 */
	List<WorkCalendar> getCustomCalendarList(String name);

	/**
	 * 
	 * @param tWorkCalendarDefElement
	 * @return
	 */
	boolean addWorkCalendarDEF(WorkCalendarDefElement tWorkCalendarDefElement);

	/**
	 * 
	 * @param tWorkCalendarDefElementlist
	 * @param name
	 * @return
	 */
	boolean updateWorkCalendarDEF(ArrayList tWorkCalendarDefElementlist, String name);

	/**
	 * 
	 * @param tWorkCalendarDefElement
	 * @return
	 */
	boolean removeWorkCalendarDEF(WorkCalendarDefElement tWorkCalendarDefElement);

	/**
	 * 
	 * @param obj
	 * @return
	 */
	Map<String, Object> toMap(Object obj);

}
