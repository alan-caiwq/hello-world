package com.aia.case360.uam.dao;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface UserAccountDao {

	public List<Map<String, Object>> getAuthorityByUserId(String userId);

	public boolean deleteUserRoleByUserId(String userId);

	public boolean insertUsers(Set<String> lanIds);

	public List<Map<String, Object>> getUserInfoInFirestNodeByReq(String req);

	public String getDeptByUserId(String userId);

	public List<Map<String, Object>> getTrainee(Map<String, String> param);

	// added by bsnpc1g on 04/02/2018
	public String getCompanyByUserId(String userId);

	public List<Map<String, String>> getTeamByUserId(String userId);

	public List<Map<String, String>> getTeamList();
	// added end

	public List<Map<String, String>> getUserTeamAndRole(String userId);

}
