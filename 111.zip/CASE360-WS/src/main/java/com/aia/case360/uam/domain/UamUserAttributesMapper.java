package com.aia.case360.uam.domain;

import javax.naming.NamingException;
import javax.naming.directory.Attributes;

import org.springframework.ldap.core.AttributesMapper;

public class UamUserAttributesMapper implements AttributesMapper<Object> {

	@Override
	public UamUser mapFromAttributes(Attributes attrs) throws NamingException {
		UamUser uUser = new UamUser();
		if (attrs.get("mail") != null) {
			uUser.setEmail((String) attrs.get("mail").get());
		}
		if (attrs.get("telephoneNumber") != null) {
			uUser.setPhoneNumber((String) attrs.get("telephoneNumber").get());
		}
		if (attrs.get("sAMAccountName") != null) {
			uUser.setUserId((String) attrs.get("sAMAccountName").get());
		}
		if (attrs.get("displayName") != null) {
			uUser.setUserName((String) attrs.get("displayName").get());
		}
		if (attrs.get("department") != null) {
			uUser.setDepartment((String) attrs.get("department").get());
		}
		if (attrs.get("company") != null) {
			uUser.setCompany((String) attrs.get("company").get());
		}
		uUser.setFromAD(true);
		return uUser;
	}

}
