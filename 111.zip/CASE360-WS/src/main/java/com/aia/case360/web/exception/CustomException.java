package com.aia.case360.web.exception;

import org.springframework.http.HttpStatus;

public class CustomException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	private Error error;

	private HttpStatus status;
	
	private Throwable cause;
	   /**
	   * @return the cause
	   */
	  public Throwable getCause() {
	    return cause;
	  }

	  /**
	   * @param cause the cause to set
	   */
	  public void setCause(Throwable cause) {
	    this.cause = cause;
	  }
	
  public Error getError() {
		return error;
	}

  public void setError(Error error) {
		this.error = error;
	}

	public HttpStatus getStatus() {
		return status;
	}

	public void setStatus(HttpStatus status) {
		this.status = status;
	}

	public CustomException(Error error, HttpStatus status) {
		super(error.getError());
		this.error = error;
		this.status = status;
	}

	public CustomException(String message, HttpStatus status) {
		super(message);
		error = new Error(message);
		this.status = status;
	}

	public CustomException(Exception e, HttpStatus status) {
		super(e.getMessage());
		error = new Error(e.getMessage());
		this.status = status;
		cause = e;
	}
	
	public CustomException(Exception e) {
		super(e.getMessage());
		cause = e;
	}
	
}
