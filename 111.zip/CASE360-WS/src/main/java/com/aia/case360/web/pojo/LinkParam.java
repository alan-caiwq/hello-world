package com.aia.case360.web.pojo;

public class LinkParam {

  //FORM_ID VALUE_LIST LINKCASEID IS_VOID VALUE_LIST1
  private String formId;
  
  private String policyNo;
  
  private String objectId;
  
  private Long linkCaseId;
  
  private Integer isVoid;

  /**
   * @return the formId
   */
  public String getFormId() {
    return formId;
  }

  /**
   * @return the policyNo
   */
  public String getPolicyNo() {
    return policyNo;
  }

  /**
   * @return the objectId
   */
  public String getObjectId() {
    return objectId;
  }

  /**
   * @return the linkCaseId
   */
  public Long getLinkCaseId() {
    return linkCaseId;
  }

  /**
   * @return the isVoid
   */
  public Integer getIsVoid() {
    return isVoid;
  }

  /**
   * @param formId the formId to set
   */
  public void setFormId(String formId) {
    this.formId = formId;
  }

  /**
   * @param policyNo the policyNo to set
   */
  public void setPolicyNo(String policyNo) {
    this.policyNo = policyNo;
  }

  /**
   * @param objectId the objectId to set
   */
  public void setObjectId(String objectId) {
    this.objectId = objectId;
  }

  /**
   * @param linkCaseId the linkCaseId to set
   */
  public void setLinkCaseId(Long linkCaseId) {
    this.linkCaseId = linkCaseId;
  }

  /**
   * @param isVoid the isVoid to set
   */
  public void setIsVoid(Integer isVoid) {
    this.isVoid = isVoid;
  }

  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "LinkParam [formId=" + formId + ", policyNo=" + policyNo + ", objectId=" + objectId
        + ", linkCaseId=" + linkCaseId + ", isVoid=" + isVoid + "]";
  }
  
}
