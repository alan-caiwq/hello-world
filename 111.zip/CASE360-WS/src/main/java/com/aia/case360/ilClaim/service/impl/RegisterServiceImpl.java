package com.aia.case360.ilClaim.service.impl;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.aia.case360.ilClaim.dao.RegisterBean;
import com.aia.case360.ilClaim.service.RegisterService;

@Service
public class RegisterServiceImpl implements RegisterService {

	
	private RegisterBean registDao = new RegisterBean();

	@Override
	public List<Map<String, String>> getClaimNo(Map<String, String> params)  throws SQLException {
		String landId = "";
		String policyNo = "";
		String createDate = "";


		if (null != params) {
			landId = params.get("landId");
			policyNo = params.get("policyNo");
			createDate = params.get("createDate");
		} 

		return registDao.getClaimNo(landId, policyNo, createDate);
	}

}
