package com.aia.case360.web.exception;

import org.springframework.http.HttpStatus;

public class ObjectNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	private String id;

	private Error error;

	private HttpStatus status;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Error getError() {
		return error;
	}

	public void setError(Error error) {
		this.error = error;
	}

	public HttpStatus getStatus() {
		return status;
	}

	public void setStatus(HttpStatus status) {
		this.status = status;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public ObjectNotFoundException(String id) {
		super("Object [" + id +"] not found");
		this.id = id;
		this.error = new Error("Object [" + id +"] not found");
		this.status = HttpStatus.NOT_FOUND;
	}

	public ObjectNotFoundException(String message, HttpStatus status) {
		super(message);
		this.error = new Error(message);
		this.status = status;
	}

}
