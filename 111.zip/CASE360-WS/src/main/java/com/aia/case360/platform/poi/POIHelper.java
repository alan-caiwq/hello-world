package com.aia.case360.platform.poi;

import org.apache.poi.ss.usermodel.Cell;

public interface POIHelper {
	public String getCellValue(Cell cell);
}
