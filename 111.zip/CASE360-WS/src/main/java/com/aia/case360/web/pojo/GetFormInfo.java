package com.aia.case360.web.pojo;

public class GetFormInfo {
	// formCategory
	private String formCategory;
	// formID
	private String formID;
	// formName
	private String formName;

	public String getFormCategory() {
		return formCategory;
	}

	public void setFormCategory(String formCategory) {
		this.formCategory = formCategory;
	}

	public String getFormID() {
		return formID;
	}

	public void setFormID(String formID) {
		this.formID = formID;
	}

	public String getFormName() {
		return formName;
	}

	public void setFormName(String formName) {
		this.formName = formName;
	}

}
