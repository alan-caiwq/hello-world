package com.aia.case360.ilClaim.controller;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.aia.case360.ilClaim.service.DecisionService;

/**
 * claim decision approval
 * 
 * @author bsnpc0y
 *
 */
@RestController
public class DecisionController {

	private static final String LOCALFAILEDERRORMESSAGE = " failed.error message:";
	private static final String LOCALCALL = "call ";
	private static final String LOCALERRMESAGE = "errMesage";
	@Autowired
	DecisionService decisionService;

	@RequestMapping(value = "/case/ows/getTrainerDecision/{claimNos}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Map<String, String>>> getTrainerDecision(@PathVariable("claimNos") String claimNos,
			@RequestBody Map<String, String> request)  throws RemoteException {
		List<Map<String, String>> result = new ArrayList<Map<String, String>>();
		String serviceName = "webservice : getTrainerDecision";
		try {
			result = decisionService.getTrainerDecision(claimNos, request);
			return new ResponseEntity<List<Map<String, String>>>(result, HttpStatus.OK);
		} catch (Exception e) {
			 
			Map<String, String> errMapping = new HashMap<String, String>();
			errMapping.put(LOCALERRMESAGE, LOCALCALL + serviceName + LOCALFAILEDERRORMESSAGE + e.getMessage());
			result.add(errMapping);
			return new ResponseEntity<List<Map<String, String>>>(result, HttpStatus.OK);
		}
	}

	@RequestMapping(value = "/case/ows/getTLDecision/{claimNos}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Map<String, String>>> getTLDecision(@PathVariable("claimNos") String claimNos,
			@RequestBody Map<String, String> request)  throws RemoteException {
		List<Map<String, String>> result = new ArrayList<Map<String, String>>();
		String serviceName = "webservice : getTLDecision";
		try {
			result = decisionService.getTrainerDecision(claimNos, request);
			return new ResponseEntity<List<Map<String, String>>>(result, HttpStatus.OK);
		} catch (Exception e) {
			 
			Map<String, String> errMapping = new HashMap<String, String>();
			errMapping.put(LOCALERRMESAGE, LOCALCALL + serviceName + LOCALFAILEDERRORMESSAGE + e.getMessage());
			result.add(errMapping);
			return new ResponseEntity<List<Map<String, String>>>(result, HttpStatus.OK);
		}
	}

	@RequestMapping(value = "/case/ows/getQualifiedDecision/{claimNos}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Map<String, String>>> getQualifiedDecision(@PathVariable("claimNos") String claimNos,
			@RequestBody Map<String, String> request)  throws RemoteException {
		List<Map<String, String>> result = new ArrayList<Map<String, String>>();
		String serviceName = "webservice : getQualifiedDecision";
		try {
			result = decisionService.getTrainerDecision(claimNos, request);
			return new ResponseEntity<List<Map<String, String>>>(result, HttpStatus.OK);
		} catch (Exception e) {
			 
			Map<String, String> errMapping = new HashMap<String, String>();
			errMapping.put(LOCALERRMESAGE, LOCALCALL + serviceName + LOCALFAILEDERRORMESSAGE + e.getMessage());
			result.add(errMapping);
			return new ResponseEntity<List<Map<String, String>>>(result, HttpStatus.OK);
		}
	}

}
