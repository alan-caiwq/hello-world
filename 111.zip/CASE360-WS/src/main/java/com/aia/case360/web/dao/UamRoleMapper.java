package com.aia.case360.web.dao;

import java.util.List;

public interface UamRoleMapper {

	/**
	 * List all defined Role list
	 * 
	 * @return
	 */
	public List<UamRole> findAllRoles();

}
