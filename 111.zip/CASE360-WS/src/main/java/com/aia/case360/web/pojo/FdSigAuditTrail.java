package com.aia.case360.web.pojo;

import java.util.Date;

public class FdSigAuditTrail {
	private String createdBy;
	private Date createdTimestamp;
	private String comments;
	private String category;
	private String objectId;
	private String fromPolNum;
	private String fromPolRole;
	private String toPolNum;
	private String toPolRole;
	private String documentsName;

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getObjectId() {
		return objectId;
	}

	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}

	public String getFromPolNum() {
		return fromPolNum;
	}

	public void setFromPolNum(String fromPolNum) {
		this.fromPolNum = fromPolNum;
	}

	public String getFromPolRole() {
		return fromPolRole;
	}

	public void setFromPolRole(String fromPolRole) {
		this.fromPolRole = fromPolRole;
	}

	public String getToPolNum() {
		return toPolNum;
	}

	public void setToPolNum(String toPolNum) {
		this.toPolNum = toPolNum;
	}

	public String getToPolRole() {
		return toPolRole;
	}

	public void setToPolRole(String toPolRole) {
		this.toPolRole = toPolRole;
	}

	public String getDocumentsName() {
		return documentsName;
	}

	public void setDocumentsName(String documentsName) {
		this.documentsName = documentsName;
	}

}
