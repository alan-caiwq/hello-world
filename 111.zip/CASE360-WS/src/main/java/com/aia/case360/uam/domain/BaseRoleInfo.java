package com.aia.case360.uam.domain;

import java.util.Map;

public class BaseRoleInfo {

	private String UAM_ROLE_ID;

	private String UAM_ROLE_NAME;

	private String UAM_DEP_NAME;

	private String UAM_ROLE_TYPE;

	private String UAM_IS_ENABLE;

	private String UAM_REMARK;

	public String getUAM_ROLE_ID() {
		return UAM_ROLE_ID;
	}

	public void setUAM_ROLE_ID(String uAM_ROLE_ID) {
		UAM_ROLE_ID = uAM_ROLE_ID;
	}

	public String getUAM_ROLE_NAME() {
		return UAM_ROLE_NAME;
	}

	public void setUAM_ROLE_NAME(String uAM_ROLE_NAME) {
		UAM_ROLE_NAME = uAM_ROLE_NAME;
	}

	public String getUAM_DEP_NAME() {
		return UAM_DEP_NAME;
	}

	public void setUAM_DEP_NAME(String uAM_DEP_NAME) {
		UAM_DEP_NAME = uAM_DEP_NAME;
	}

	public String getUAM_ROLE_TYPE() {
		return UAM_ROLE_TYPE;
	}

	public void setUAM_ROLE_TYPE(String uAM_ROLE_TYPE) {
		UAM_ROLE_TYPE = uAM_ROLE_TYPE;
	}

	public String getUAM_IS_ENABLE() {
		return UAM_IS_ENABLE;
	}

	public void setUAM_IS_ENABLE(String uAM_IS_ENABLE) {
		UAM_IS_ENABLE = uAM_IS_ENABLE;
	}

	public String getUAM_REMARK() {
		return UAM_REMARK;
	}

	public void setUAM_REMARK(String uAM_REMARK) {
		UAM_REMARK = uAM_REMARK;
	}

	public void setValues(Map<String, Object> roleBaseInfo) {
		if (roleBaseInfo.get("UAM_ROLE_NAME") != null)
			setUAM_ROLE_NAME(String.valueOf(roleBaseInfo.get("UAM_ROLE_NAME")));
		if (roleBaseInfo.get("UAM_DEP_NAME") != null)
			setUAM_DEP_NAME(String.valueOf(roleBaseInfo.get("UAM_DEP_NAME")));
		if (roleBaseInfo.get("UAM_IS_ENABLE") != null)
			setUAM_IS_ENABLE(String.valueOf(roleBaseInfo.get("UAM_IS_ENABLE")));
		if (roleBaseInfo.get("UAM_REMARK") != null)
			setUAM_REMARK(String.valueOf(roleBaseInfo.get("UAM_REMARK")));
		if (roleBaseInfo.get("UAM_ROLE_TYPE") != null)
			setUAM_ROLE_TYPE(String.valueOf(roleBaseInfo.get("UAM_ROLE_TYPE")));
		if (roleBaseInfo.get("UAM_ROLE_ID") != null)
			setUAM_ROLE_ID(String.valueOf(roleBaseInfo.get("UAM_ROLE_ID")));
	}

}
