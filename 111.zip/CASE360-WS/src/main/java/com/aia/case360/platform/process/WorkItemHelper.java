package com.aia.case360.platform.process;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import com.eistream.sonora.fields.FmsRow;

/**
 * A <code>WorkItemHelper</code> is the common helper class for the operations
 * on special WorkItem.
 *
 * @author bsnpbdu
 *
 */
public interface WorkItemHelper {

	/**
	 * Update one specified customer field with value.
	 * 
	 * @param fldName  field Name
	 * @param fldValue fields Value
	 * @throws RemoteException
	 */
	public void updateFldVal(String fldName, String fldValue, String rpKeyStr) throws RemoteException;

	/**
	 * route On one specified WorkItem which is indicated by repository key
	 * 
	 * @throws RemoteException
	 */

	public void routeOn(String userId, String rpKeyStr) throws RemoteException;

	/**
	 * route On one specified WorkItem which is indicated by repository key
	 * 
	 * @param dispatchName process's dispatch button's name
	 * @throws RemoteException
	 */
	public void routeOn(String dispatchName, String userId, String rpKeyStr) throws RemoteException;

	/**
	 * return the workitem's row information
	 * 
	 * @return
	 * @throws RemoteException
	 */
	public FmsRow getWorkItemRow(String rpKeyStr) throws RemoteException;

	/**
	 * get workitem's activity dispatch buttons name
	 * 
	 * @param workstep current activity's name
	 * @return
	 * @throws RemoteException
	 */
	public List<String> getDispatchButtons(String workstep, String rpKeyStr) throws RemoteException;

	/**
	 * return the workitem's current workstep name
	 * 
	 * @return
	 * @throws RemoteException
	 */
	public String getCurWorkstep(String rpKeyStr) throws RemoteException;

	/**
	 * check if this workitem's workstep can present PEND button
	 * 
	 * @param workstep
	 * @return
	 * @throws RemoteException
	 */
	public boolean canPend(String workstep, String rpKeyStr) throws RemoteException;

	/**
	 * get workitem's FmsRow detail formation as Map object, all fiedls will be
	 * returned. // can devploer this?
	 * 
	 * @return
	 * @throws RemoteException
	 */
	public Map<String, Object> getWorkItemDetail(String rpKeyStr) throws RemoteException;

	/**
	 * assign some workitem to another specified person UserId
	 * 
	 * @param userEntity
	 * @param repositoryKeys
	 * @return
	 * @throws RemoteException
	 */
	public boolean assign(String userEntity, String... repositoryKeys) throws RemoteException;

	/**
	 * It's used to update loginid_user if WorkItem owner want to send it to
	 * another.
	 * 
	 * @throws RemoteException
	 */

	public boolean reassignWork(String userId, String rpKeyStr) throws RemoteException;

	/**
	 * 
	 * It's used to update Expiry Type
	 * 
	 * if Expiry Type is 1 ,means first notice. this method will change it to 2; if
	 * Expiry Type is 2 ,means second notice. this method will change it to 0; if
	 * Expiry Type is 0,means pend return or not pend;
	 * 
	 * @throws RemoteException
	 */
	public boolean updateExpiryType(String rpKeyStr) throws RemoteException;

	/**
	 * update workitem envelope fields values based on the input Map object
	 * 
	 * @param fieldMap fieldName and value
	 * @throws RemoteException
	 */
	public void updateCustomFields(Map<String, ?> fieldMap, String rpKeyStr) throws RemoteException;

	/**
	 * update workitem envelope fields values based on the input Map object
	 * 
	 * @param fieldMap fieldName and value
	 * @throws RemoteException
	 */
	public void updateSysFields1(Map<String, ?> fieldMap, String rpKeyStr) throws RemoteException;

	/**
	 * Re-assignment workitem because assigned user takes leave be chance.
	 * 
	 * @param userId         Team leader userId. He/Her can unlock workitem.
	 * @param reAssignUserId Re-assignment userId. He/Her get this workitem.
	 * 
	 *                       1. unlock workitem --change lockType and delete lock
	 *                       user. 2. change workitem user. 3. add Audit Trail .
	 * @throws RemoteException
	 */

	public boolean reassign(String caseId, String userId, String reAssignUserId, String rpKeyStr)
			throws RemoteException;

	public void routeOnToSpecifiedWorkstep(String workstepName, String userId, String wfstatus, String rpKeyStr)
			throws RemoteException;

	public void doReleaseFromErroe(String rpKeyStr) throws RemoteException;

	/**
	 * To determine whether the current workStepName
	 * 
	 * @param stepName : stepName that need to judge
	 * @return
	 * @throws RemoteException
	 */
	public boolean isCurrentWorkStepName(String stepName, String rpKeyStr) throws RemoteException;

	public Map<String, String> getWorkItemData(String rpKeyStr) throws RemoteException;

	public FmsRow getWorkItemSysRow(String rpKeyStr) throws RemoteException;

	public void putUserIdTATHistory(String userId, String rpKeyStr) throws RemoteException;

	public void putActivityTATHistory(String userId, String rpKeyStr) throws RemoteException;

}
