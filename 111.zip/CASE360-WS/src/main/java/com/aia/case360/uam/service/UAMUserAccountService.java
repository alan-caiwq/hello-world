package com.aia.case360.uam.service;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import com.aia.case360.uam.domain.UserAuthorityVO;
import com.aia.case360.web.pojo.OutputVO;
import com.aia.case360.web.vo.UAMCopyToParam;

import net.sf.json.JSONObject;

/**
 * 
 * @author bsnpc2s
 *
 */

public interface UAMUserAccountService {

	public OutputVO synchUserAccounts() throws RemoteException;

	// user update
	public boolean updateUser(JSONObject userParamas) throws RemoteException;

	public Map<String, Map<String, String>> getAllUserAccounts(Map<String, Object> request) throws RemoteException;

	public OutputVO getAuthority(Map<String, Object> params) throws RemoteException;

	public List<Map<String, Object>> getUserInfoInFirestNodeByReq(String req);

	public String getCurrentUserDepartment() throws RemoteException;

	public String getUserDepartment(String userId) throws RemoteException;

	public Map<String, Object> getTraineeByUserAct(Map<String, String> param) throws RemoteException;

	// added by bsnpc1g
	public List<Map<String, String>> getCurrentUserCompany() throws RemoteException;

	public List<Map<String, String>> getUserTeam() throws RemoteException;
	// added end

	public List<Map<String, String>> getUserTeamAndRole(String userId) throws RemoteException;

	public List<UserAuthorityVO> getAuthorityById(String userId) throws RemoteException;

	public OutputVO getLeaderUsers(Map<String, Object> request) throws RemoteException;

	public List<Map<String, String>> getUserList(JSONObject params) throws RemoteException;

	public OutputVO updateUserAuth(Map<String, Object> params) throws RemoteException;

	public String getUserCompany(String userId) throws RemoteException;

	public String findUserNameById(String currentUserObj) throws RemoteException;

	public OutputVO getCLMAuthDropDownList() throws RemoteException;

	public Boolean isUserRoleExist(String userId, String uuid) throws RemoteException;

	public void copyTo(UAMCopyToParam param, String uuid) throws RemoteException;

	public List<Map<String, String>> getAllUserInfoList(JSONObject params) throws RemoteException;

	/**
	 * check if user is available
	 * 
	 * @param userId
	 * @return
	 */
	public boolean isUserAvaliable(String userId);

	/**
	 * check if user is leader
	 * 
	 * @param userId
	 * @return
	 */
	public String isLeader(String userId);

}
