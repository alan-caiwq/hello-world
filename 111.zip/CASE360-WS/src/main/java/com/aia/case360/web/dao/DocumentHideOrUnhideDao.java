package com.aia.case360.web.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import net.sf.json.JSONObject;

@Repository
public interface DocumentHideOrUnhideDao {

	public List<Map<String, Object>> searchHideOrUnhide(Object params);

	public void setHideOrUnhide(Object params);

	public void updateHide(JSONObject params);

	public void updateUnhide(JSONObject params);

	public List<Map<String, Object>> searchCustDoc(String formId);

}
