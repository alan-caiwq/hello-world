package com.aia.case360.uam.controller;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.aia.case360.platform.common.JsonUtil;
import com.aia.case360.platform.security.UserHelper;
import com.aia.case360.uam.service.UAMUserAccountService;
import com.aia.case360.web.common.ParamsUtil;
import com.aia.case360.web.pojo.OutputVO;
import com.aia.case360.web.vo.UAMCopyToParam;
import com.aia.case360.web.webservice.AbstractController;

import net.sf.json.JSONObject;

@RestController
public class UAMUserAccountController extends AbstractController {

	private static final String LOCALCOPY_TO = "copyTo ";

	private static final String LOCALIS_USER_ROLE_EXIST = "isUserRoleExist ";

	private static final String LOCALCURLOGINUSER = "CURLOGINUSER";

	@Autowired
	private UAMUserAccountService uamUserAccountService;

	@Autowired
	private UserHelper userHelper;

	/**
	 * query users from sonora, this users can be chosen as leader
	 * 
	 * @author bsnpbys
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/case/workpool/getLeaderUsers", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Object>> getLeaderUsers(@RequestBody Map<String, Object> request) {
		OutputVO output = new OutputVO();
		try {
			m_Logger.info("getLeaderUsers start");
			output = uamUserAccountService.getLeaderUsers(request);
			return new ResponseEntity<Map<String, Object>>(output.toMap(), HttpStatus.OK);
		} catch (Exception e) {
			 
			m_Logger.error("getLeaderUsers error" + e);
			output.addErrorInfo("getLeaderUsers error");
			return new ResponseEntity<Map<String, Object>>(output.toMap(), HttpStatus.OK);
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/case/uam/getAllUserAccount", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Map<String, Object>>> getAllUserAccount(@RequestBody Map<String, Object> request)
			 throws RemoteException {
		Map<String, Map<String, String>> allUserAccounts = uamUserAccountService.getAllUserAccounts(request);
		OutputVO OutputVO = new OutputVO();
		OutputVO.setDatas(allUserAccounts);
		return new ResponseEntity(OutputVO.toMap(), HttpStatus.OK);

	}

	@RequestMapping(value = "/case/uam/getAllUserInfo", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Object>> getAllUserInfo(@RequestBody JSONObject params)  throws RemoteException {
		List<Map<String, String>> allUserName = uamUserAccountService.getAllUserInfoList(params);
		OutputVO outputVO = new OutputVO();
		outputVO.setDatas(allUserName);
		return new ResponseEntity<Map<String, Object>>(outputVO.toMap(), HttpStatus.OK);

	}

	@RequestMapping(value = "/case/uam/saveUserAccount", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Object>> saveUserAccount(@RequestBody JSONObject params) {
		OutputVO outputVO = new OutputVO();
		try {
			m_Logger.info("saveUserAccount start");
			boolean result = uamUserAccountService.updateUser(params);
			outputVO.setDatas(result);
			return new ResponseEntity<Map<String, Object>>(outputVO.toMap(), HttpStatus.OK);
		} catch (Exception e) {
			 
			m_Logger.error("saveUserAccount error", e);
			outputVO.addErrorInfo("saveUserAccount error" + e);
			return new ResponseEntity<Map<String, Object>>(outputVO.toMap(), HttpStatus.OK);
		}
	}

	@RequestMapping(value = "/case/uam/synchuseraccounts", method = RequestMethod.GET)
	public ResponseEntity<Map<String, Object>> synchUserAccounts()  throws RemoteException {
		OutputVO outputVO = new OutputVO();
		try {
			m_Logger.info("synchUserAccounts start");
			outputVO = uamUserAccountService.synchUserAccounts();
			return new ResponseEntity<Map<String, Object>>(outputVO.toMap(), HttpStatus.OK);
		} catch (Exception e) {
			m_Logger.error("synchUserAccounts error", e);
			outputVO.addErrorInfo("synchUserAccounts error:" + e);
			return new ResponseEntity<Map<String, Object>>(outputVO.toMap(), HttpStatus.OK);
		}
	}

	@RequestMapping(value = "/case/uam/updateuser", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Object>> updateUser(@RequestBody JSONObject params)  throws RemoteException {
		List<String> validateStrs = new ArrayList<String>();
		validateStrs.add("LOGINID");
		validateStrs.add("STATUS");
		validateStrs.add("TEAM");
		validateStrs.add("PHONENUMBER");
		validateStrs.add("ROLES");
		ParamsUtil.validateParamsThrowException(JsonUtil.getStringMap(params), validateStrs);
		boolean result = uamUserAccountService.updateUser(params);
		if (result) {
			OutputVO outputVO = new OutputVO();
			outputVO.setDatas(result);
			return new ResponseEntity<Map<String, Object>>(outputVO.toMap(), HttpStatus.OK);
		}
		return new ResponseEntity<Map<String, Object>>(HttpStatus.BAD_REQUEST);
	}

	@RequestMapping(value = "/case/uam/getUserAuth", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Map<String, Object>> getAuthority(@RequestBody Map<String, Object> params) {
		OutputVO output = new OutputVO();
		try {
			m_Logger.info("getUserAuth start");
			output = uamUserAccountService.getAuthority(params);
			return new ResponseEntity<Map<String, Object>>(output.toMap(), HttpStatus.OK);
		} catch (Exception e) {
			m_Logger.error("getUserAuth error:", e);
			output.addErrorInfo("getUserAuth error" + e);
			return new ResponseEntity<Map<String, Object>>(output.toMap(), HttpStatus.OK);
		}
	}

	@RequestMapping(value = "/case/uam/getTrainneInfo", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Map<String, Object>> getTrainneInfo(@RequestBody JSONObject params)  throws RemoteException {

		Map<String, String> param = new HashMap<String, String>();
		String actName = params.getString("reqType") + params.getString("workstepId");
		param.put("actName", actName);
		String userId = userHelper.getCurrentUser();
		param.put("userId", userId);
		Map<String, Object> result = uamUserAccountService.getTraineeByUserAct(param);

		OutputVO OutputVO = new OutputVO();
		OutputVO.setDatas(result);
		return new ResponseEntity<Map<String, Object>>(OutputVO.toMap(), HttpStatus.OK);
	}

	// added by bsnpc1g

	// added by bsnpc1g
	@RequestMapping(value = "/case/uam/getCurrentUserCompay", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<List<Map<String, Object>>> getCurrentUserCompay(@RequestBody JSONObject params)
			 throws RemoteException {
		m_Logger.info("getCurrentUserCompany start ");

		List<Map<String, String>> result = uamUserAccountService.getCurrentUserCompany();

		OutputVO OutputVO = new OutputVO();
		OutputVO.setDatas(result);

		return new ResponseEntity(OutputVO.toMap(), HttpStatus.OK);
	}

	@RequestMapping(value = "/case/uam/getUserTeam", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<List<Map<String, Object>>> getUserTeam(@RequestBody JSONObject params)  throws RemoteException {
		m_Logger.info("getUserTeam start ");

		List<Map<String, String>> result = uamUserAccountService.getUserTeam();

		OutputVO OutputVO = new OutputVO();
		OutputVO.setDatas(result);

		return new ResponseEntity(OutputVO.toMap(), HttpStatus.OK);
	}
	// added end

	@RequestMapping(value = "/case/uam/getUserTeamAndRole", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<List<Map<String, Object>>> getUserTeamAndRole(@RequestBody JSONObject params)
			 throws RemoteException {
		m_Logger.info("get current UserTeamAndRole start ");
		String userId = (String) params.get("USER_ID");
		List<Map<String, String>> result = uamUserAccountService.getUserTeamAndRole(userId);

		OutputVO OutputVO = new OutputVO();
		OutputVO.setDatas(result);

		return new ResponseEntity(OutputVO.toMap(), HttpStatus.OK);
	}

	@RequestMapping(value = "/case/uam/getUserList", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<List<Map<String, String>>> getUserList(@RequestBody JSONObject params)  throws RemoteException {
		m_Logger.info("getUserList start ");
		List<Map<String, String>> result = uamUserAccountService.getUserList(params);

		OutputVO OutputVO = new OutputVO();
		OutputVO.setDatas(result);
		m_Logger.info("getUserList end ");

		return new ResponseEntity(OutputVO.toMap(), HttpStatus.OK);
	}

	/**
	 * update user's authority
	 * 
	 * @param params
	 * @return
	 */
	@RequestMapping(value = "/case/uam/updateUserAuth", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Map<String, Object>> updateUserAuth(@RequestBody Map<String, Object> params) {
		OutputVO output = new OutputVO();
		try {
			m_Logger.info("updateUserAuth start");
			String currentUserId = userHelper.getCurrentUser();
			params.put(LOCALCURLOGINUSER, currentUserId);
			output = uamUserAccountService.updateUserAuth(params);
			return new ResponseEntity<Map<String, Object>>(output.toMap(), HttpStatus.OK);
		} catch (Exception e) {
			 
			m_Logger.error("updateUserAuth error");
			output.addErrorInfo("updateUserAuth error" + e);
			return new ResponseEntity<Map<String, Object>>(output.toMap(), HttpStatus.OK);
		}
	}

	/**
	 * copyTo check, check if the user can be copyTo
	 * 
	 * @param params
	 * @return
	 */
	@RequestMapping(value = "/case/uam/copyToCheck", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Map<String, Object>> copyToCheck(@RequestBody Map<String, Object> params) {
		OutputVO output = new OutputVO();
		try {
			m_Logger.info("copyToCheck start");
			String currentUserId = userHelper.getCurrentUser();
			params.put(LOCALCURLOGINUSER, currentUserId);
			output = uamUserAccountService.updateUserAuth(params);
			return new ResponseEntity<Map<String, Object>>(output.toMap(), HttpStatus.OK);
		} catch (Exception e) {
			 
			m_Logger.error("copyToCheck error" + e);
			output.addErrorInfo("copyToCheck error" + e);
			return new ResponseEntity<Map<String, Object>>(output.toMap(), HttpStatus.OK);
		}
	}

	/**
	 * copyTo user, copy one user roles & authority configuration to another user
	 * 
	 * @param params
	 * @return
	 */
	@RequestMapping(value = "/case/uam/copyToUser", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Map<String, Object>> copyToUser(@RequestBody Map<String, Object> params) {
		OutputVO output = new OutputVO();
		try {
			m_Logger.info("copyToUser start");
			String currentUserId = userHelper.getCurrentUser();
			params.put(LOCALCURLOGINUSER, currentUserId);
			output = uamUserAccountService.updateUserAuth(params);
			return new ResponseEntity<Map<String, Object>>(output.toMap(), HttpStatus.OK);
		} catch (Exception e) {
			 
			m_Logger.error("copyToUser error" + e);
			output.addErrorInfo("copyToUser error" + e);
			return new ResponseEntity<Map<String, Object>>(output.toMap(), HttpStatus.OK);
		}
	}

	@RequestMapping(value = "/case/uam/getCLMAuthDropDownList", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Map<String, Object>> getCLMAuthDropDownList(@RequestBody Map<String, Object> params) {
		OutputVO output = new OutputVO();
		try {
			m_Logger.info("getCLMAuthDropDownList start");
			output = uamUserAccountService.getCLMAuthDropDownList();
			return new ResponseEntity<Map<String, Object>>(output.toMap(), HttpStatus.OK);
		} catch (Exception e) {
			 
			m_Logger.error("getCLMAuthDropDownList error" + e);
			output.addErrorInfo("getCLMAuthDropDownList error" + e);
			return new ResponseEntity<Map<String, Object>>(output.toMap(), HttpStatus.OK);
		}
	}

	/**
	 * copyTo user, copy one user roles & authority configuration to another user
	 * 
	 * @param params
	 * @return
	 * @ throws RemoteException
	 */
	@RequestMapping(value = "/case/uam/isUserRoleExist", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Map<String, Object>> isUserRoleExist(@RequestParam("userId") String userId)  throws RemoteException {
		String uuidStr = getReqUUID();
		m_Logger.info(LOCALIS_USER_ROLE_EXIST + uuidStr + " start.");
		m_Logger.info(LOCALIS_USER_ROLE_EXIST + uuidStr + " userId: " + userId);

		Boolean isUserRoleExist = uamUserAccountService.isUserRoleExist(userId, uuidStr);

		Map<String, Object> result = new HashMap<String, Object>();
		result.put("isUserRoleExist", (isUserRoleExist ? 1 : 0));
		result.put("uuid", uuidStr);

		m_Logger.info(LOCALIS_USER_ROLE_EXIST + uuidStr + " end.");

		return new ResponseEntity<Map<String, Object>>(result, HttpStatus.OK);
	}

	/**
	 * copyTo user, copy one user roles & authority configuration to another user
	 * 
	 * @param param
	 * @return
	 * @ throws RemoteException
	 */
	@RequestMapping(value = "/case/uam/copyTo", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Object>> copyTo(@RequestBody UAMCopyToParam param)  throws RemoteException {
		String uuidStr = getReqUUID();
		m_Logger.info(LOCALCOPY_TO + uuidStr + " start.");
		m_Logger.info(LOCALCOPY_TO + uuidStr + " param: " + param);

		uamUserAccountService.copyTo(param, uuidStr);

		Map<String, Object> result = new HashMap<String, Object>();
		result.put("uuid", uuidStr);

		m_Logger.info(LOCALCOPY_TO + uuidStr + " end.");

		return new ResponseEntity<Map<String, Object>>(result, HttpStatus.OK);

	}
}
