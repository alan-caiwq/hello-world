package com.aia.case360.web.dao;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface DropDownListBoxDao {

	public List<Map<String, Object>> listDept(@Param("type") int type);

	public List<Map<String, String>> getCategory(@Param("department") String department);

	public List<Map<String, String>> getRequestTypeByCategory(List<String> list);

	public List<Map<String, String>> queryClosedReason();

	public List<Map<String, String>> queryUserId();

	public List<Map<String, String>> querySubmissionChannel();

	public List<String> queryCitiSLARptMonth();

	public List<String> queryCitiSLALevel_2();

	public List<String> queryCitiSLALevel_3(@Param("organizer")String organizer);
	
	public void generateCitiSlaDtl()  throws RemoteException;
	
}