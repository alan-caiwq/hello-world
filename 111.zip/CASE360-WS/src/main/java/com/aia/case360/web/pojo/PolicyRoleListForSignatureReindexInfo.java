/**
 * 
 */
package com.aia.case360.web.pojo;

/**
 * @author bsnpc55
 *
 */
public class PolicyRoleListForSignatureReindexInfo {
	private String role;
	private String policyNo;
	private String companyNo;
	private String source;
	private String nric;

	public String getNric() {
		return nric;
	}

	public void setNric(String nric) {
		this.nric = nric;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getCompanyNo() {
		return companyNo;
	}

	public void setCompanyNo(String companyNo) {
		this.companyNo = companyNo;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	@Override
	public String toString() {
		return "PolicyRoleListForSignatureReindexInfo [role=" + role + ", policyNo=" + policyNo + ", companyNo="
				+ companyNo + ", source=" + source + ", nric=" + nric + "]";
	}

}
