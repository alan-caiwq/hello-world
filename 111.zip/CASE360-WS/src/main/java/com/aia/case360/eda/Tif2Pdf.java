package com.aia.case360.eda;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.RandomAccessFileOrArray;
import com.itextpdf.text.pdf.codec.TiffImage;

public class Tif2Pdf {
	
	private static Logger m_Logger = LoggerFactory.getLogger("Tif2Pdf");

	private Tif2Pdf(){
		
	}
	/**
	 * Method to convert a TIFF to PDF directly.
	 * 
	 * @throws IOException
	 */
	@SuppressWarnings("deprecation")
	public static Map<String, Object> genBytePDFFromTIF(byte[] byteTif, Map<String, Object> indexMap)
			throws DocumentException, IOException {
		long iStart = System.currentTimeMillis();
		m_Logger.info("Tif2Pdf: genBytePDFFromTIF start ========== " + iStart);

		int numPdfPages;
		long pdfSize;
		/*
		 * RandomAccessFileOrArray is a class from iText API which is
		 * representing our TIF file here. We are passing or TIF in the
		 * constructor of RandomAccessFileOrArray class. We need to pass full
		 * path of TIF file as string. I am assuming it in ��D:\�� drive of
		 * windows.
		 */
		RandomAccessFileOrArray myTifFile = new RandomAccessFileOrArray(byteTif);

		/*
		 * Now find number of pages (images) in TIF file using static method of
		 * TiffImage class. TiffImage class is from iText API.
		 */
		int numberOfPages = TiffImage.getNumberOfPages(myTifFile);

		Document pdf = new Document();
		/*
		 * Now use a static method getInstance() from PdfWriter class to get an
		 * instance of PdfWriter class to write data from TIF to this PDF. As we
		 * can see the first parameter is Document instance that we created
		 * above and second parameter is an instance of FileOutputStream. We are
		 * passing full path of PDF under constructor of FileOutputStream.
		 * FileOutputStream creats an stream to pdf on that path to write data
		 * in PDF file.
		 */
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		PdfWriter writer = PdfWriter.getInstance(pdf, baos);

		writer.setStrictImageSequence(true);
		// We must open the Document before writing anything to pdf.
		pdf.open();
		/*
		 * Now itterate over pages under TIF file. Fetching images one by one
		 * from TIF creates an Image object and write that Image instance to PDF
		 * Document.
		 */
		for (int tiffImageCounter = 1; tiffImageCounter <= numberOfPages; tiffImageCounter++) {
			/*
			 * This Image class is not from java awt package. This Image class
			 * is from iText API. We need to call static method getTiffImage()
			 * of TiffImage class by passing the TIf file and tiffImageCounter.
			 */
			Image img = TiffImage.getTiffImage(myTifFile, tiffImageCounter);

			Rectangle pageSize = new Rectangle(img.getWidth(), img.getHeight());
			pdf.setPageSize(pageSize);
			pdf.setMargins(0, 0, 0, 0);
			// Now just add this Image instance to TiffToPDF Document using
			// add() method.
			pdf.newPage();
			pdf.add(img);

		} // close loop
		// must close the Document	
		pdf.close();
		myTifFile.close();

		byte[] content = baos.toByteArray();

		PdfReader r = new PdfReader(content);
		numPdfPages = r.getNumberOfPages();
		pdfSize = r.getFileLength();
		
		indexMap.put("TIF_PAGES", numberOfPages);
		indexMap.put("PDF_PAGES", numPdfPages);
		indexMap.put("PDF_SIZE", pdfSize);
		indexMap.put("convertDateTime", new Date());
		indexMap.put("pdfByte", content);
		
		indexMap.put("convertTifToPdfDateTime", new Date());
		
		long iEnd = System.currentTimeMillis();
		m_Logger.info("Tif2Pdf: genBytePDFFromTIF end ========== " + iEnd);
		m_Logger.info("Tif2Pdf: genBytePDFFromTIF spend time ========== " + (iEnd - iStart));
		indexMap.put("CONVERT_FIEL_SPENDTIME", (iEnd - iStart));
		return indexMap;
	}

}
