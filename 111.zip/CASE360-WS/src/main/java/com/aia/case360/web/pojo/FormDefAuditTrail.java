package com.aia.case360.web.pojo;

import java.math.BigDecimal;
import java.util.Date;

public class FormDefAuditTrail {
	private String acl;
	private BigDecimal sRowid;
	private String actionDesc;
	private String category;
	private String createdBy;
	private Date createdTimestamp;
	private String formId;

	public String getAcl() {
		return acl;
	}

	public void setAcl(String acl) {
		this.acl = acl;
	}

	public BigDecimal getsRowid() {
		return sRowid;
	}

	public void setsRowid(BigDecimal sRowid) {
		this.sRowid = sRowid;
	}

	public String getActionDesc() {
		return actionDesc;
	}

	public void setActionDesc(String actionDesc) {
		this.actionDesc = actionDesc;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public String getFormId() {
		return formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "FormDefAuditTrail [acl=" + acl + ", sRowid=" + sRowid + ", actionDesc=" + actionDesc + ", category="
				+ category + ", createdBy=" + createdBy + ", createdTimestamp=" + createdTimestamp + ", formId="
				+ formId + "]";
	}

}
