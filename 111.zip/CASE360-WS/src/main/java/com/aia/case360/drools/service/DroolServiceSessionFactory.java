package com.aia.case360.drools.service;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.runtime.StatefulKnowledgeSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aia.case360.platform.common.LogUtil;

public enum DroolServiceSessionFactory {

	INSTANCE;
	private StatefulKnowledgeSession statefulKnowledgeSession;
	private KnowledgeBase knowledgeBase;
	private Logger m_Logger = LoggerFactory.getLogger(getClass());

	private DroolServiceSessionFactory() {
		knowledgeBase = newSingletonBase();
	}

	private KnowledgeBase newSingletonBase() {
		KnowledgeBuilder kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder();
		kbuilder.add(ResourceFactory.newFileResource("D:/DroolsRules/sgp.rule.drl"), ResourceType.DRL);
		KnowledgeBuilderErrors errors = kbuilder.getErrors();
		LogUtil.logInfo(m_Logger,"DroolServiceSessionFactory load end");
		for (KnowledgeBuilderError error : errors) {
			LogUtil.logError(m_Logger, error.toString());
			LogUtil.logError(m_Logger,  error.toString());
		}
		if (errors.isEmpty()) {
			LogUtil.logInfo(m_Logger,"kbuilder has no error");
		}
		KnowledgeBase kBase = KnowledgeBaseFactory.newKnowledgeBase();
		kBase.addKnowledgePackages(kbuilder.getKnowledgePackages());
		return kBase;
	}

	public StatefulKnowledgeSession getSingletonSession() {
		if (statefulKnowledgeSession == null) {
			statefulKnowledgeSession = newSingletonBase().newStatefulKnowledgeSession();
		}
		return statefulKnowledgeSession;
	}

	public KnowledgeBase getSingletonBase() {
		return knowledgeBase;
	}

	public void refreshBase() {
		KnowledgeBuilder kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder();
		kbuilder.add(ResourceFactory.newFileResource("D:/DroolsRules/sgp.rule.drl"), ResourceType.DRL);
		KnowledgeBuilderErrors errors = kbuilder.getErrors();
		LogUtil.logInfo(m_Logger,"DroolServiceSessionFactory refreshBase");
		for (KnowledgeBuilderError error : errors) {
			LogUtil.logError(m_Logger,error.toString());
		}
		if (errors.isEmpty()) {
			LogUtil.logInfo(m_Logger,"kbuilder has no error");
		}

		KnowledgeBase kBase = KnowledgeBaseFactory.newKnowledgeBase();
		kBase.addKnowledgePackages(kbuilder.getKnowledgePackages());
		knowledgeBase = kBase;
	}

	public void disposeSession() {
		if (statefulKnowledgeSession != null)
			statefulKnowledgeSession.dispose();
	}

}
