package com.aia.case360.web.pojo;

public class FSCChannelParameter {

	private String fscCode;
	private String companyCode;

	public String getFscCode() {
		return fscCode;
	}

	public void setFscCode(String fscCode) {
		this.fscCode = fscCode;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

}
