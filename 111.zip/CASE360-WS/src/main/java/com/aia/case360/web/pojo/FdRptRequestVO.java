package com.aia.case360.web.pojo;

import java.util.Date;

public class FdRptRequestVO {
	private String createdBy;
	private Date createdTimestamp;
	private String  fileUrl;
	private String  lastUpdatedBy;
	private String  lastUpdatedTimestamp;
	private String  reportNmae;
	private String  reportParam;
	private String  reportSpName;
	private String  reportStatus;
	private String  sRowid;
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedTimestamp() {
		return createdTimestamp;
	}
	public void setCreatedTimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}
	public String getFileUrl() {
		return fileUrl;
	}
	public void setFileUrl(String fileUrl) {
		this.fileUrl = fileUrl;
	}
	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}
	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	public String getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}
	public void setLastUpdatedTimestamp(String lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}
	public String getReportNmae() {
		return reportNmae;
	}
	public void setReportNmae(String reportNmae) {
		this.reportNmae = reportNmae;
	}
	public String getReportParam() {
		return reportParam;
	}
	public void setReportParam(String reportParam) {
		this.reportParam = reportParam;
	}
	public String getReportSpName() {
		return reportSpName;
	}
	public void setReportSpName(String reportSpName) {
		this.reportSpName = reportSpName;
	}
	public String getReportStatus() {
		return reportStatus;
	}
	public void setReportStatus(String reportStatus) {
		this.reportStatus = reportStatus;
	}
	public String getsRowid() {
		return sRowid;
	}
	public void setsRowid(String sRowid) {
		this.sRowid = sRowid;
	}
	@Override
	public String toString() {
		return "FdRptRequestVO [createdBy=" + createdBy + ", createdTimestamp="
				+ createdTimestamp + ", fileUrl=" + fileUrl
				+ ", lastUpdatedBy=" + lastUpdatedBy
				+ ", lastUpdatedTimestamp=" + lastUpdatedTimestamp
				+ ", reportNmae=" + reportNmae + ", reportParam=" + reportParam
				+ ", reportSpName=" + reportSpName + ", reportStatus="
				+ reportStatus + ", sRowid=" + sRowid + "]";
	}
	
      
      
}
