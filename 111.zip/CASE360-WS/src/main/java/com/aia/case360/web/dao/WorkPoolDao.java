package com.aia.case360.web.dao;

import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.aia.case360.web.pojo.CaseCodeVO;
import com.aia.case360.web.pojo.CaseNotesVO;
import com.aia.case360.web.pojo.UserColumnVO;

@Repository
public interface WorkPoolDao {

	public List<Map<String, Object>> queryScoreCases() throws RemoteException;

	public void insertCaseCode(@Param("list") List<CaseCodeVO> caseCodeList) throws RemoteException;

	public void deleteCaseCode(@Param("list") List<Integer> list) throws RemoteException;

	public List<Map<String, Object>> querySortedPriorityCases(Map<String, Object> map) throws RemoteException;
	
	public List<Map<String, Object>> querySortedPriorityCasesSP(@Param("userId") String userId, @Param("department") String department) throws RemoteException;

	public List<Map<String, Object>> queryUserRoleAuth(String userId) throws RemoteException;

	public List<Map<String, Object>> queryCasePolicyInfoByCaseId(String casefolderid) throws RemoteException;

	public List<Map<String, Object>> queryAssociatedCaseBySameInsured(@Param("caseId") String caseId) throws RemoteException;

	public List<Map<String, Object>> queryAssociatedCaseBySamePOwner(@Param("caseId") String caseId) throws RemoteException;

	public List<Map<String, Object>> queryAssociatedCaseBySamePol(@Param("caseId") String caseId) throws RemoteException;

  
  public List<Map<String, Object>> queryBusinessSourceFromAMS(@Param("list")List<String> list) throws RemoteException;
	public List<Map<String, Object>> queryAssociatedCaseBySameInsuredOrPOwner(@Param("caseId") String caseId)
			throws RemoteException;

	public List<Map<String, Object>> queryCaseData() throws RemoteException;

	public List<Map<String, Object>> queryAssociatedCase(@Param("caseId") String caseId, @Param("rule1") String rule1,
			@Param("andOr") String andOr, @Param("rule2") String rule2) throws RemoteException;

	public List<Map<String, Object>> queryMyTeamWork(@Param("team") Integer team, @Param("topCount") Integer topCount,
			@Param("startCount") Integer startCount, @Param("orderBy") String orderBy, @Param("filter") String filter)
			throws RemoteException;

	public List<Map<String, Object>> queryMyTeamPendingWork(@Param("team") Integer team,
			@Param("topCount") Integer topCount, @Param("startCount") Integer startCount,
			@Param("orderBy") String orderBy, @Param("filter") String filter) throws RemoteException;

	public List<Map<String, Object>> queryMyReferWork(@Param("userId") String userId,
			@Param("topCount") Integer topCount, @Param("startCount") Integer startCount,
			@Param("orderBy") String orderBy, @Param("filter") String filter) throws RemoteException;

	/**
	 * get how many records in my pending pool
	 * 
	 * @param userId
	 * @return
	 * @throws RemoteException
	 */
	public List<Map<String, Integer>> queryMyReferWorkCount(@Param("userId") String userId,
			@Param("filter") String filter) throws RemoteException;

	public List<Map<String, Object>> queryMyPendingWork(@Param("userId") String userId,
			@Param("topCount") Integer topCount, @Param("startCount") Integer startCount,
			@Param("orderBy") String orderBy, @Param("filter") String filter) throws RemoteException;

	/**
	 * get how many records in my pending pool
	 * 
	 * @param userId
	 * @return
	 * @throws RemoteException
	 */
	public List<Map<String, Integer>> queryMyPendingWorkCount(@Param("userId") String userId,
			@Param("filter") String filter) throws RemoteException;

	public List<Map<String, Object>> queryMyWork(@Param("userId") String userId, @Param("topCount") Integer topCount,
			@Param("startCount") Integer startCount, @Param("orderBy") String orderBy, @Param("filter") String filter)
			throws RemoteException;

  public List<Map<String, Object>> queryBRUBusinessSourceFromAMS(@Param("list")List<String> list);
  
  public List<String> queryChangedCasePolNum();
	/**
	 * get how many records in my work pool
	 * 
	 * @param userId
	 * @return
	 * @throws RemoteException
	 */
	public List<Map<String, Integer>> queryMyWorkCount(@Param("userId") String userId, @Param("filter") String filter)
			throws RemoteException;

	public List<Map<String, Object>> queryCounterSignWork(@Param("userId") String userId,
			@Param("topCount") Integer topCount, @Param("startCount") Integer startCount,
			@Param("orderBy") String orderBy, @Param("filter") String filter) throws RemoteException;

	/**
	 * get how many records in counter sign pool
	 * 
	 * @param userId
	 * @return
	 * @throws RemoteException
	 */
	public List<Map<String, Integer>> queryCounterSignCount(@Param("userId") String userId,
			@Param("filter") String filter) throws RemoteException;

	public List<UserColumnVO> queryColumnConfig(@Param("userId") String userId, @Param("poolName") String poolName)
			throws RemoteException;

	public Integer deleteUserColumn(@Param("userId") String userId, @Param("poolName") String poolName)
			throws RemoteException;

	public Integer insertUserColumn(List<UserColumnVO> ucVOs) throws RemoteException;

	public List<UserColumnVO> queryDefaultColumnConfig(@Param("configName") String configName) throws RemoteException;

	public Integer setCaseUrgent(List<Integer> caseIds) throws RemoteException;

	public Integer callBackRefer(List<Integer> caseIds) throws RemoteException;

	public Integer callBackCounterSign(@Param("caseIds") List<Integer> caseIds, @Param("userId") String userId)
			throws RemoteException;

	public Integer insertCaseNote(List<CaseNotesVO> caseNotes) throws RemoteException;

	public Integer unpendCase(List<Integer> caseIds) throws RemoteException;

	public List<Map<String, Object>> validateReferLock(List<Integer> caseIds) throws RemoteException;

	public List<Map<String, Object>> validateCounterSignLock(List<Integer> caseIds) throws RemoteException;

	public Integer snatchCase(@Param("caseId") Integer caseId, @Param("userId") String userId) throws RemoteException;

	public List<Map<String, Object>> queryCasesByAct(Map<String, Object> map) throws RemoteException;

	public List<String> queryUserActName(@Param("userId") String userId) throws RemoteException;

	public List<Map<String, Object>> queryCasesNoDepartment(Map<String, Object> map) throws RemoteException;

	public List<String> queryScoreCasesPolicy() throws RemoteException;

	public Integer preUpdatePol(@Param("policys") String policys) throws RemoteException;

	public Integer lockCounterSign(Map<String, Object> params) throws RemoteException;

	public List<Map<String, Object>> batchCallBackCounterSign(Map<String, Object> params) throws RemoteException;

	public Integer changeCaseUrgent(List<Integer> caseIds) throws RemoteException;

	public List<Map<String, Object>> queryAllTeams() throws RemoteException;

	public List<Integer> queryLeaderTeams(@Param("userId") String userId) throws RemoteException;

	public List<Map<String, Object>> queryCaseInfo(@Param("caseId") Integer caseId) throws RemoteException;

	public List<Map<String, Object>> queryCaseTSARInfo() throws RemoteException;

	public List<Map<String, Object>> queryCounterSignTeamByUser(@Param("userId") String userId) throws RemoteException;

	public List<Map<String, Object>> queryCounterSignCases(Map<String, Object> map) throws RemoteException;

	public List<Map<String, Object>> queryUserRoleAuthByDepartment(@Param("userId") String userId,
			@Param("department") String department) throws RemoteException;

	/**
	 * query cases by request type & activity. case has no owner & no pending &
	 * status is normal
	 * 
	 * @return
	 * @throws RemoteException
	 */
	public List<Map<String, Object>> queryCasesByAuthority(Map<String, Object> map) throws RemoteException;

	public List<Map<String, Object>> queryCaseUserStatus(List<Integer> caseIds) throws RemoteException;

	public Integer clearCaseOwner(List<Integer> caseIdInactiveList) throws RemoteException;

	public List<Map<String, Object>> queryCaseAutoAssinInfo(@Param("caseId") Integer caseId) throws RemoteException;

	public List<Map<String, Object>> queryConcurrentRuleAutoAssign(@Param("reqType") String reqType,
			@Param("actName") String actName, @Param("department") String department,
			@Param("department2") String department2) throws RemoteException;

	public List<Map<String, Object>> queryAssociatedHistoryCaseBySameInsured(@Param("caseId") String caseId)
			throws RemoteException;

	public List<Map<String, Object>> queryAssociatedHistoryCaseBySamePOwner(@Param("caseId") String caseId)
			throws RemoteException;

	public List<Map<String, Object>> queryAssociatedHistoryCaseBySamePol(@Param("caseId") String caseId)
			throws RemoteException;

	public List<Map<String, Object>> queryAssociatedHistoryCaseBySameInsuredOrPOwner(@Param("caseId") String caseId)
			throws RemoteException;

	public List<Map<String, Object>> queryAssociatedHistoryCase(@Param("caseId") String caseId,
			@Param("rule1") String rule1, @Param("andOr") String andOr, @Param("rule2") String rule2) throws RemoteException;

	public List<Map<String, Object>> queryTest(String item) throws RemoteException;

	public void deletePriorityFactor(List<Map<String, Object>> thousandPriorityFactors) throws RemoteException;

	public int insertPriorityFactor(List<Map<String, Object>> thousandPriorityFactors) throws RemoteException;

	public int queryPolCount() throws RemoteException;

	public List<Map<String, Object>> queryPolDataInCase360() throws RemoteException;

	public List<Map<String, Object>> queryFSCCODEFromIL(@Param("polNum") String polNum) throws RemoteException;

	public void updatePolData(@Param("list") List<Map<String, Object>> changedPolData) throws RemoteException;

	public List<Map<String, Object>> queryChangedCaseInfo() throws RemoteException;

	public List<Map<String, Object>> queryCasePolicyInfo(@Param("list") List<String> caseIdList) throws RemoteException;

	public List<Map<String, Object>> queryCaseRepositoryKey(@Param("list") List<Integer> caseIds) throws RemoteException;

	public List<Map<String, Object>> queryCaseRepositoryKeyAndCounterSignLock(@Param("list") List<Integer> datas)
			throws RemoteException;

	public Integer updateCaseChangedStatus(@Param("caseIdList") List<String> caseIdList,
			@Param("changeStatus") int changeStatus) throws RemoteException;

	/**
	 * find user's current day's capacity config
	 * 
	 * @param userId
	 * @return
	 * @throws RemoteException
	 */
	public List<Map<String, Object>> queryCurCapacity(@Param("userId") String userId) throws RemoteException;

	/**
	 * find user's capacity info
	 * 
	 * @param userId
	 * @return
	 * @throws RemoteException
	 */
	public List<Map<String, Object>> queryUserCapacity(@Param("userId") String userId) throws RemoteException;

	/**
	 * update existed capacity record to delete
	 * 
	 * @param userId
	 * @throws RemoteException
	 */
	public void deleteCurCapacity(@Param("userId") String userId) throws RemoteException;

	/**
	 * add new capacity record
	 * 
	 * @param userId
	 * @param capacity
	 * @param oTCapacity
	 * @throws RemoteException
	 */
	public void addCurCapacity(@Param("userId") String userId, @Param("capacity") String capacity,
			@Param("oTCapacity") String oTCapacity) throws RemoteException;

	public List<Map<String, Object>> queryBatchSubmissionWork(String userId);

	public Map<String, Object> queryUserWorkLoad(@Param("userId") String userId) throws RemoteException;

	public String queryCaseOwner(@Param("caseId") Integer caseId) throws RemoteException;

	public List<Map<String, Object>> queryBRUBusinessSourceFromAMSybase(@Param("list") List<String> list);
	
	public List<Map<String, Object>> queryCasesPolicy(@Param("list") List<String> list) throws RemoteException;
	
	public List<Map<String, Object>> queryCasesInsuredOwner(@Param("list") List<String> list) throws RemoteException;

	public List<Map<String, String>> queryUserAgencyLocation(@Param("userId") String userId) throws RemoteException;

	public List<Map<String, Object>> queryReqTypeTSARInfo(@Param("reqType") String reqType) throws RemoteException;
	
	public Map<String, Object> calculatePoolCounts(@Param("userId") String userId, @Param("teamId") String teamId) throws RemoteException;
	
	public Integer updatePolBusinessSrc(@Param("list") List<Map<String, Object>> list) throws RemoteException;

	public List<Map<String, Object>> getCaseProcess(@Param("caseID") String caseID) throws RemoteException;

	public void queryFSCCODEFromODS(Map<String, Object> map) throws SQLException;
	
	public void updateCaseOwner(@Param("userId") String userId, @Param("caseId") String caseId) throws RemoteException;
	
	public List<Map<String, Object>> queryCasePolicy(@Param("list") List<String> caseIdList) throws RemoteException;
	
	public void updateCaseClaimNo(@Param("caseId") long linkcaseid, @Param("claimNo") String claimNo) throws RemoteException;
//	<!--  	 for defect C360P-172  -->
	public String getCasePreProcessor(@Param("caseId") String caseId);
}
