package com.aia.case360.web.pojo;

import java.io.Serializable;

public class PaymentModeInfo implements Serializable {
	private String companyCode;
	private String policyNo;
	private String paymentMode;
	private String cpfMode;

	public String getCpfMode() {
		return cpfMode;
	}

	public void setCpfMode(String cpfMode) {
		this.cpfMode = cpfMode;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	@Override
	public String toString() {
		return "PaymentModeInfo [companyCode=" + companyCode + ", policyNo=" + policyNo + ", paymentMode=" + paymentMode
				+ ", cpfMode=" + cpfMode + "]";
	}

}
