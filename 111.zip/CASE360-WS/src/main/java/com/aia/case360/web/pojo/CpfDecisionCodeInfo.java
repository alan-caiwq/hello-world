package com.aia.case360.web.pojo;

/**
 * 
 * @author bsnpc37(Leo Li)
 *
 */
public class CpfDecisionCodeInfo {

	private String cpfDecisionCode;
	private String cpfErrorCode;

	public String getCpfDecisionCode() {
		return cpfDecisionCode;
	}

	public void setCpfDecisionCode(String cpfDecisionCode) {
		this.cpfDecisionCode = cpfDecisionCode;
	}

	public String getCpfErrorCode() {
		return cpfErrorCode;
	}

	public void setCpfErrorCode(String cpfErrorCode) {
		this.cpfErrorCode = cpfErrorCode;
	}

}
