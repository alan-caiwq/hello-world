package com.aia.case360.platform.casefolder;

import java.rmi.RemoteException;
import java.util.List;

public interface CasefolderSearchHelper {

	public List<String> getFormDefinition(String queryName) throws RemoteException;

}
