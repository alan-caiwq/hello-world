package com.aia.case360.ilClaim.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public interface AssessService {

	public List<Map<String, String>> getClaimStatus(String claimNos, String matherClaimNo, String childClaimNo)
			 throws SQLException;
}
