package com.aia.case360.web.exception;

import java.io.Serializable;

public class Error implements Serializable{
	private static final long serialVersionUID = 1L;
	private String errorInfo;

	public Error(String error) {
		this.errorInfo = error;
	}

	public String getError() {
		return errorInfo;
	}

	public void setError(String error) {
		this.errorInfo = error;
	}
}
