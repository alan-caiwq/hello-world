package com.aia.case360.platform.query;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Map;

public interface QueryCaseFolderHelper {

	/**
	 * 
	 * Get userId's own job list by workstep
	 * 
	 * @param userId   login userId should be registered in Case360 side.
	 * @param workstep activity name indicates which activity queue for finding
	 *                 workitems of the current user
	 * @return queryResults
	 * @throws RemoteException
	 */

	public ArrayList<Map<String, Object>> getWorkFolder(Map<String, String> parameters) throws RemoteException;

	public ArrayList<Map<String, Object>> getWorkFolderByReqNo(String reqNo) throws RemoteException;

	public ArrayList<Map<String, Object>> getWorkFolderByCaseID(String caseID) throws RemoteException;

	public ArrayList<Map<String, Object>> getWorkFolderByPolNum(String policyNum, String department, String processName)
			throws RemoteException;

	public String getDiscussionId(String discussionName) throws RemoteException;

	public ArrayList<Map<String, Object>> getCustomer(String clientId) throws RemoteException;

	public ArrayList<Map<String, Object>> getActiveWorkFolderByPolNum(String policyNum, String department,
			String processName) throws RemoteException;

}
