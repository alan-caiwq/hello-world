package com.aia.case360.web.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

@Repository
public interface SearchLeaveTypeDao {

	public List<Map<String, Object>> searchLeaveType();

	public List<Map<String, Object>> searchAuditTaril();

	public List<Map<String, Object>> searchCurrentUser(String userId);

	// added by bsnpc1g : for public holiday audit trail
	public List<Map<String, Object>> queryPublicHolidayAuditTrail();
}
