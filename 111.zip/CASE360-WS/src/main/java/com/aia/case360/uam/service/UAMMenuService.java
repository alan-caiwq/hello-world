/**
 * -------------------------------------------------
 * Copyright (c) 2017-2019 AIA . All Rights Reserved.  
 *-------------------------------------------------
 * Project Name: Pulse
 * @author: 
 * @version: 1.0
 * Description: 
 * Revised Records:
 */
package com.aia.case360.uam.service;

import java.rmi.RemoteException;
import java.util.Map;

import com.aia.case360.web.pojo.OutputVO;

/**
 * @author bsnpbdu
 *
 */
public interface UAMMenuService {
	public String getAllMenus(int menuType);

	/**
	 * @param userId
	 * @return
	 */
	String getMenusByUserId(String userId, int menuType);

	public OutputVO getUserButtons()  throws RemoteException;

	public OutputVO getFormCategory(Map<String, Object> request)  throws RemoteException;

}
