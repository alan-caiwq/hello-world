package com.aia.case360.web.dao;

public interface LeaveMgmtDao {
	public int deleteFdLeaveMgmt(String rowid);
}
