package com.aia.case360.web.pojo;

import java.util.List;

public class CasePara {

	private List<String> caseIds;
	private List<String> reqNos;
	private List<String> companyNos;

	private String receivedDate;
	private String processType;
	private String docId;
	private String fileName;
	private String formId;
	private String companyNo;

	public List<String> getCompanyNos() {
		return companyNos;
	}

	public void setCompanyNos(List<String> companyNos) {
		this.companyNos = companyNos;
	}

	public String getCompanyNo() {
		return companyNo;
	}

	public void setCompanyNo(String companyNo) {
		this.companyNo = companyNo;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getDocId() {
		return docId;
	}

	public void setDocId(String docId) {
		this.docId = docId;
	}

	public List<String> getCaseIds() {
		return caseIds;
	}

	public void setCaseIds(List<String> caseIds) {
		this.caseIds = caseIds;
	}

	public List<String> getReqNos() {
		return reqNos;
	}

	public void setReqNos(List<String> reqNos) {
		this.reqNos = reqNos;
	}

	public String getReceivedDate() {
		return receivedDate;
	}

	public void setReceivedDate(String receivedDate) {
		this.receivedDate = receivedDate;
	}

	public String getProcessType() {
		return processType;
	}

	public void setProcessType(String processType) {
		this.processType = processType;
	}

	public String getFormId() {
		return formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}
}