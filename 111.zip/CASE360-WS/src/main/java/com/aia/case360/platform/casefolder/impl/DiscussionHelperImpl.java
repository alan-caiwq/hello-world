package com.aia.case360.platform.casefolder.impl;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.ejb.CreateException;

import org.springframework.stereotype.Component;

import com.aia.case360.platform.casefolder.DiscussionHelper;
import com.aia.case360.platform.common.DataFieldUtil;
import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.common.PropertyUtil;
import com.aia.case360.web.service.impl.AbstractHelperImpl;
import com.eistream.sonora.casefolder.discussions.DiscussionElement;
import com.eistream.sonora.casefolder.discussions.DiscussionTO;

@Component
public class DiscussionHelperImpl extends AbstractHelperImpl implements DiscussionHelper {

	private Map<String, String> dataTableIds;

	@Override
	public void addDiscussionContent(String caseId, String name, String contents, String userName)
			throws RemoteException {
		String message = "function addDiscussionContent";
		LogUtil.logInfo(m_Logger,message + "is start . ");
		Map<String, String> params = DataFieldUtil.getParamsMap(new String[] { "caseId", caseId },
				new String[] { "name", name }, new String[] { "contents", contents },
				new String[] { "userName", userName });

		if (DataFieldUtil.isNull(caseId, name, contents)) {

			RemoteException e = new RemoteException("Parameters is invalid::" + params.toString());
			LogUtil.logError(m_Logger, "Parameters is invalid::" + params.toString());
			throw e;
		}
		String tableId = dataTableIds.get(PropertyUtil.getTableIDProperty("TABLE_NAME_CF_WORK"));
		DiscussionTO disTo = new DiscussionTO();

		disTo.setCaseFolderID(new BigDecimal(caseId));

		disTo.setName(name);

		disTo.setBody(contents);
		disTo.setModifiedBy(userName);
		disTo.setTemplateID(new BigDecimal(tableId));

		disTo.setElementType(3);
		disTo.setComponentElementID(new BigDecimal(0));
		DiscussionElement topicElem = new DiscussionElement(disTo);

		try {

			getDisEJB().createElement(topicElem);

		} catch (CreateException e) {
			LogUtil.logException(m_Logger, "", e);
			 
		}

	}

	@Override
	public List<Map<String, Object>> getDiscussionList(String caseId) throws RemoteException {
		List<DiscussionElement> discussionList = getDisEJB().getAll(new BigDecimal(caseId));
		Class<DiscussionElement> clazz = DiscussionElement.class;
		return DataFieldUtil.getPOJORowList(clazz, discussionList);

	}

	@Override
	public List<Map<String, Object>> getTopicList(String caseId) throws RemoteException {

		List<DiscussionElement> topics = getDisEJB().getTopics(new BigDecimal(caseId));
		Class<DiscussionElement> clazz = DiscussionElement.class;
		List<Map<String, Object>> result = DataFieldUtil.getPOJORowList(clazz, topics);
		return result;
	}

	@Override
	public List<String> getTopicList() throws RemoteException {
		String message = "function getTopicList";
		LogUtil.logInfo(m_Logger,message + " is start .");
		BigDecimal templeteId = new BigDecimal(dataTableIds.get(PropertyUtil.getTableIDProperty("TABLE_NAME_CF_WORK")));
		List<DiscussionElement> topics = getDisEJB().getTopics(templeteId);
		Class<DiscussionElement> clazz = DiscussionElement.class;
		List<Map<String, Object>> result = DataFieldUtil.getPOJORowList(clazz, topics);
		List<String> topList = new ArrayList<String>();
		for (Map<String, Object> map : result) {
			topList.add(map.get("name").toString());
		}

		LogUtil.logInfo(m_Logger,message + " is leaving .");
		return topList;
	}

}
