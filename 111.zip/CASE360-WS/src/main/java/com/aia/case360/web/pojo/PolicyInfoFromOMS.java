package com.aia.case360.web.pojo;

/**
 * call db_inw po_oms_fixit_get_policy procedure result
 * 
 * @Author: bsnpc1w(huiyun)
 * @Create Date: 2018.04.23
 */
public class PolicyInfoFromOMS {
	private String TxnId;
	private String PolicyNo;
	private String PendingReason;
	private String ADLRDATE;
	private String PlanDesc;
	private String DP;
	private String ContractType;
	private String BasicComponent;
	private String UserId;

	public String getTxnId() {
		return TxnId;
	}

	public void setTxnId(String txnId) {
		TxnId = txnId;
	}

	public String getPolicyNo() {
		return PolicyNo;
	}

	public void setPolicyNo(String policyNo) {
		PolicyNo = policyNo;
	}

	public String getPendingReason() {
		return PendingReason;
	}

	public void setPendingReason(String pendingReason) {
		PendingReason = pendingReason;
	}

	public String getADLRDATE() {
		return ADLRDATE;
	}

	public void setADLRDATE(String aDLRDATE) {
		ADLRDATE = aDLRDATE;
	}

	public String getPlanDesc() {
		return PlanDesc;
	}

	public void setPlanDesc(String planDesc) {
		PlanDesc = planDesc;
	}

	public String getDP() {
		return DP;
	}

	public void setDP(String dP) {
		DP = dP;
	}

	public String getContractType() {
		return ContractType;
	}

	public void setContractType(String contractType) {
		ContractType = contractType;
	}

	public String getBasicComponent() {
		return BasicComponent;
	}

	public void setBasicComponent(String basicComponent) {
		BasicComponent = basicComponent;
	}

	public String getUserId() {
		return UserId;
	}

	public void setUserId(String userId) {
		UserId = userId;
	}

}
