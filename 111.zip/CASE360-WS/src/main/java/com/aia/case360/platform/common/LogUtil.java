package com.aia.case360.platform.common;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.rmi.RemoteException;

import org.slf4j.Logger;

public class LogUtil {
    //add by paul 2018-12-06 start
	public static final String LOG_MESSAGE_PARAMS=" params:";
	public static final String LOG_MESSAGE_START=" start";
	public static final String LOG_MESSAGE_END=" end";
	public static final String LOG_MESSAGE_RESULT=" result: ";
	public static final String LOG_MESSAGE_CALL=" call ";
	public static final String LOG_MESSAGE_FAILED="failed.error message:"; 
	public static final String LOG_MESSAGE_UUID=". uuid:"; 
	public static final String LOG_MESSAGE_SUCC="success";
	public static final String LOG_MESSAGE_REOPEN="reopen case ";
	// end
	
	private LogUtil() {}

	public static final  RemoteException logException(Logger mLogger, String message,RemoteException e) {
		if(mLogger.isErrorEnabled()) {
			mLogger.error(String.format("%s --- %s", message , e.getMessage()), e);
		}
		return new RemoteException(message, e);
	}

	public static final  RemoteException logException(Logger mLogger, String message, Throwable e) {
		if(mLogger.isErrorEnabled()) {
			mLogger.error(String.format("%s --- %s", message , e.getMessage()), e);
		}
		return new RemoteException(message, e);
	}
	public static final  void logError(Logger mLogger, Exception e) {
		try (StringWriter sw=new StringWriter();
		PrintWriter pw=new PrintWriter(sw);){
			e.printStackTrace(pw);
			logError(mLogger, sw.toString());
		} catch (Exception e2) {
			mLogger.warn("log Exception deatil execption", e2);
		}
	}
	public static final  void logError(Logger mLogger, String message, Exception e) {
		logError(mLogger, message);
		logError(mLogger, e);
	}
	public static final  void logError(Logger mLogger, String message) {
		if(mLogger.isErrorEnabled()) {
			mLogger.error( message );
		}
	}
	
	public static final void logInfo(Logger mLogger,String message) {
		if(mLogger.isDebugEnabled()) {
			mLogger.info( message );
		}
	}
	public static final void logApiNameAndParams(Logger mLogger,String serviceName,String uuidStr){
		logInfo(mLogger,serviceName+LOG_MESSAGE_UUID+uuidStr+LOG_MESSAGE_START);
	}
	 //add by paul 2018-12-06 
	public static final void logApiNameAndParams(Logger mLogger,String serviceName,String uuidStr,Object params) {
		logApiNameAndParams(mLogger,serviceName,uuidStr);
		logInfo(mLogger,LOG_MESSAGE_PARAMS+params);
	}
}