package com.aia.case360.web.pojo;

public class ClaimNo {

	private String mClaimNo;
	private String policyNum;
	private String subClaimNo;
	private String objectId;

	public String getmClaimNo() {
		return mClaimNo;
	}

	public void setmClaimNo(String mClaimNo) {
		this.mClaimNo = mClaimNo;
	}

	public String getPolicyNum() {
		return policyNum;
	}

	public void setPolicyNum(String policyNum) {
		this.policyNum = policyNum;
	}

	public String getSubClaimNo() {
		return subClaimNo;
	}

	public void setSubClaimNo(String subClaimNo) {
		this.subClaimNo = subClaimNo;
	}

	public String getObjectId() {
		return objectId;
	}

	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}
}
