package com.aia.case360.uam.service;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import com.aia.case360.uam.domain.RoleMenuVo;
import com.aia.case360.uam.domain.RoleQueryPara;
import com.aia.case360.uam.domain.RoleReqActVo;
import com.aia.case360.web.pojo.OutputVO;

public interface UAMUserRoleService {

	public List<Map<String, Object>> getRolesByRoleInfo(RoleQueryPara roleQueryPara)  throws RemoteException;

	public List<Map<String, Object>> getRoleAndActivityInfoByRoleId(String RoleId)  throws RemoteException;

	public boolean addRequestTypeAndActivity(String roleId, Map<String, String> params)  throws RemoteException;

	public boolean modifyRole(Map<String, Object> params)  throws RemoteException;

	public boolean addRoleMenu(RoleMenuVo roleMenuVo);

	public boolean addRoleAct(RoleReqActVo roleReqActVo);

	public Object getRoleInfoByRoleId(String roleId);

	public Object getAllRequestAndActivty(Map<String, Object> roleBaseInfo);

	public Object getRoleByUserIdAndRoleType(Map<String, Object> para);

	public OutputVO addRole(Map<String, Object> param)  throws RemoteException;

	public List<Map<String, Object>> getAllRoles();

}
