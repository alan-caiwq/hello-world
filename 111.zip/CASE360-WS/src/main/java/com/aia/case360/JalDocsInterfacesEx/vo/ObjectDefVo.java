package com.aia.case360.JalDocsInterfacesEx.vo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ObjectDefVo {

	private String objectType;

	private List objectNameDefList = new ArrayList();

	private Map objectFieldDefMap = new HashMap();

	/**
	 * @return Returns the objectType.
	 */
	public String getObjectType() {
		return objectType;
	}

	/**
	 * @param objectType The objectType to set.
	 */
	public void setObjectType(String objectType) {
		 this.objectType = objectType;
	}

	/**
	 * @return Returns the objectNameDefList.
	 */
	public List getObjectNameDefList() {
		return objectNameDefList;
	}

	/**
	 * @param objectNameDefList The objectNameDefList to set.
	 */
	public void setObjectNameDefList(List objectNameDefList) {
		 this.objectNameDefList = objectNameDefList;
	}

	/**
	 * @return Returns the objectFieldDefMap.
	 */
	public Map getObjectFieldDefMap() {
		return objectFieldDefMap;
	}

	/**
	 * @param objectFieldDefMap The objectFieldDefMap to set.
	 */
	public void setObjectFieldDefMap(Map objectFieldDefMap) {
		 this.objectFieldDefMap = objectFieldDefMap;
	}

}
