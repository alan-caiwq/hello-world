package com.aia.case360.drools.model;

public class RuleStep {
	private static final String TXTSTRING = "\" == \"";
	//20181119  public update private 
	private String AC_DECISION;
	private String ACRA_CHECKING;
	private String ACTIVITY_LIST;
	private String CALL_CENTRE_CLOSE_REASON;
	private String CALL_CENTRE_DECISION;
	private String CLAIM_APPROVAL;
	private String CLOSE_REASON;
	private String MANUAL_LETTER;
	private String MLNS;
	private String NEED_PREPARE_MANUAL_LETTER;
	private String OUTRIGHT_REJECT;
	private String REJECT;
	private String REQUEST_PLAS_TEAM_PROCESS;
	private String USER_LIST;

	// SOS available steps, add by bsnpc2r 2018-03-06
	private String SOS_001_APPROVE;
	private String SOS_002_REQUEST_POS_FOLLOW_UP;
	private String SOS_003_NEED_TL_APPROVAL;
	private String SOS_004_APPROVER_DECSION;
	private String SOS_005_PAYMENT_NEED_APPROVAL;
	private String SOS_006_PAYMENT_APPROVER_DECISION;
	private String SOS_007_CYO_ANNIVERSARY;
	// ADD 20180525
	private String SOS_008_NEED_AP;
	private String SOS_009_PRO_DC;
	private String SOS_010_NEED_AP;
	//add by bsnpc65 20190320 begin
	private String CMP_COM;
	private String CMP_DEC;
	private String ROUTE_BACK_CMP_USER;
	
	// add by Harry,Mar 28
	private String NEED_MEDICAL_ADJ;
	private String NEED_MR_RPT;
	private String NEED_ROUTE_TECH_TM;
	private String CREATE_CHILD_CASE;
	private String RETURN_TO_TRAINEE;
	private String APPROVAL_DC;
	private String REJECT_REASON;
	private String PENDING_ASSESSOR_REVI_TM;
	
	//private String CLM_NUM;
	private String SEEK_DOCTOR;
	private String NEED_APPROVAL;
	private String CLM_46;//IS_TRAINEE
	private String CLM_47;//TRAINER

	private String NEED_CHEQUE_AND_LETTER;
	private String BACK_TO_TRAINEE;
	private String APPROVAL_DC_PL;
	private String HI_APPROVAL_DC_PL;
	private String HIG_APPROVAL_DC;
	private String NEED_HIG_APPROVAL;
	private String CLM_COURT;
	private String CNC_DEC;

	


	private String CUSTOM_01;
	private String CUSTOM_02;
	private String CUSTOM_03;
	private String CUSTOM_04;
	private String CUSTOM_05;
	private String CUSTOM_06;
	private String CUSTOM_07;
	private String CUSTOM_08;
	private String CUSTOM_09;
	private String CUSTOM_10;
	private String CUSTOM_11;
	private String CUSTOM_12;
	private String CUSTOM_13;
	private String CUSTOM_14;
	private String CUSTOM_15;
	private String CUSTOM_16;
	private String CUSTOM_17;
	private String CUSTOM_18;
	private String CUSTOM_19;
	private String CUSTOM_20;
	private String CUSTOM_21;
	private String CUSTOM_22;
	private String CUSTOM_23;
	private String CUSTOM_24;
	private String CUSTOM_25;
	private String CUSTOM_26;
	private String CUSTOM_27;
	private String CUSTOM_28;
	private String CUSTOM_29;
	private String CUSTOM_30;
	private String CUSTOM_31;
	private String CUSTOM_32;
	private String CUSTOM_33;
	private String CUSTOM_34;
	private String CUSTOM_35;
	private String CUSTOM_36;
	private String CUSTOM_37;
	private String CUSTOM_38;
	private String CUSTOM_39;
	private String CUSTOM_40;
	private String CUSTOM_41;
	private String CUSTOM_42;
	private String CUSTOM_43;
	private String CUSTOM_44;
	private String CUSTOM_45;
	private String CUSTOM_46;
	private String CUSTOM_47;
	private String CUSTOM_48;
	private String CUSTOM_49;
	private String CUSTOM_50;
	private String CUSTOM_51;
	private String CUSTOM_52;
	private String CUSTOM_53;
	private String CUSTOM_54;
	private String CUSTOM_55;
	private String CUSTOM_56;
	private String CUSTOM_57;
	private String CUSTOM_58;
	private String CUSTOM_59;
	private String CUSTOM_60;
	private String CUSTOM_61;
	private String CUSTOM_62;
	private String CUSTOM_63;
	private String CUSTOM_64;
	private String CUSTOM_65;
	private String CUSTOM_66;
	private String CUSTOM_67;
	private String CUSTOM_68;
	private String CUSTOM_69;
	private String CUSTOM_70;
	private String CUSTOM_71;
	private String CUSTOM_72;
	private String CUSTOM_73;
	private String CUSTOM_74;
	private String CUSTOM_75;
	private String CUSTOM_76;
	private String CUSTOM_77;
	private String CUSTOM_78;
	private String CUSTOM_79;
	private String CUSTOM_80;
	private String CUSTOM_81;
	private String CUSTOM_82;
	private String CUSTOM_83;
	private String CUSTOM_84;
	private String CUSTOM_85;
	private String CUSTOM_86;
	private String CUSTOM_87;
	private String CUSTOM_88;
	private String CUSTOM_89;
	private String CUSTOM_90;
	private String CUSTOM_91;
	private String CUSTOM_92;
	private String CUSTOM_93;
	private String CUSTOM_94;
	private String CUSTOM_95;
	private String CUSTOM_96;
	private String CUSTOM_97;
	private String CUSTOM_98;
	private String CUSTOM_99;
	private String CUSTOM_100;
	
	

	// claim end
	// ---add pos bsnpc0y 2018-02-11------
	private String POS_001;
	private String POS_002;
	private String POS_003;
	private String POS_004;
	private String POS_005;
	private String POS_006;
	private String POS_007;
	private String POS_008;
	private String POS_009;
	private String POS_010;
	private String POS_011;
	private String POS_012;
	private String POS_013;
	private String POS_014;
	private String POS_015;

	private String POS_016;
	private String POS_017;
	private String POS_018;
	private String POS_019;
	private String POS_020;

	private String POS_021;
	private String POS_022;
	private String POS_023;
	private String POS_024;
	private String POS_025;

	private String IS_APPROVAL;
	private String COMMENT;

	// add for UNI by bsnpc1g 2018-03-06
	private String AC_CLOSE_REASON;

	private String APPROVAL_DECISION;
	private String APPROVAL_DECISION_HOD;
	private String CASHIER_CLOSE_REASON;
	private String CASHIER_DECISION;
	private String COMPLIANCE_DECISION;
	private String COUNTER_SIGN_HNW;
	private String COUNTER_SIGN_OSS;
	private String COUNTER_SIGN_SG;
	
	private String FIRST_APPROVAL;
	private String NEED_COUNTER_SIGN;
	private String ROUTE_TO_CASE_MANAGER;
	
	private String ROUTE_TO_COUNTERSIGNING_INITIATOR;
	private String SEND_CASE_TO_SG_TEAM;
	private String SEND_TO_ERROR_LOGGER;
	private String SEND_TO_ORIGINAL_UNDERWRITER;
	private String SEND_TO_OSS_ERROR_PIC;
	private String SEND_TO_OSS_HSG_PIC;
	private String SEND_TO_POS_POST_ADLR_PIC;
	private String SEND_TO_SG_ERROR_PIC;
	private String SEND_TO_SG_HSG_PIC_FOR_CPFB_CHECKING;
	private String SEND_TO_SG_POST_ADLR_PIC;
	private String UNDERWRITING_DECISION;
	private String TL_DECISION;
	private String SG_STAFF;

	// added on 2018/05/04 for UNI reunderwriting of POS
	private String COUNTER_SIGN_TEAM_SG;
	private String COUNTER_SIGN_TEAM_OSS;
	private String COUNTER_SIGN_TEAM_HNW;
	private String UNDERWRITING_DECISION_POS;
	private String ROUTE_TO_OTHER_UNDERWRITER;
	
	private String ROUTE_BACK_TO_CASE_MANAGER;
	private String SEND_TO_COUNTERSIGNING_INITIATOR;
	private String SEND_TO_RE_UNDERWRITING;
	
	private String COUNTER_SIGNOR_ALEX;
	private String COUNTER_SIGNOR_TAMP;
	private String COUNTER_SIGNOR_OSS;
	private String COUNTER_SIGNOR_HNW;
	private String SEND_TO_TAMP;
	private String SEND_TO_ALEX;
	private String SEND_TO_HNW;
	private String COUNTERSIGN_INITIATOR;
	private String CASECREATER;
	private String CTS_INIT;// Repalce the SEND_TO_COUNTERSIGNING_INITIATOR
	private String RT_OTHER_UW;// Replace the ROUTE_TO_OTHER_UNDERWRITER
	private String UW_DCS_SGOSS;// to replace the UNDERWRITING_DECISION
	private String UW_DCS_HNW;
	private String RTCTS_INITIATOR;
	private String SEND_BACK_UW;
	private String SEND_TAMP_FROM_OSS;
	private String SEND_ALEX_FROM_OSS;
	private String SEND_TAMP_FROM_HNW;
	private String SEND_ALEX_FROM_HNW;
	private String RTBACK_UW;
	private String BUDDY_CHK;
	private String SEND_MANAGER;
	private String SEND_UW;
	private String CASE_MANAGER;
	private String IS_PEND;

	// added on 2018/05/15
	private String UNI_001;
	private String UNI_002;
	private String UNI_003;
	private String UNI_004;
	private String UNI_005;
	private String UNI_006;
	private String UNI_007;
	private String UNI_008;
	private String UNI_009;
	private String UNI_010;
	
	//change on 2019/01/14 Weini
	
	private String SEND_TO_SG;
	private String COUNTER_SIGN_TEAM;
	private String ROUTE_DECISION;
	private String COUNTER_SIGNOR;
	private String UWDCS_SGOSS_PRL;
	private String UWDCS_HNW_PRL;
	private String COUNTERSIGN_DECISION;
	private String ROUTE_BACK_TO_UNDERWRITER;
	private String APPEAL_DECISION;
	private String ROUTE_TO_CMB_PIC;
	private String GO_BACK_TO_UW;
	private String ROUTE_BACK_TO_UW;
	private String ROUTING_DECISION;
	
	private String ROUNT_DECISION_ADLR;
	private String ROUNT_DECISION_ADLR_OSS;
	private String REUW_DCS_POS_OSS;
	private String SM_CHANNEL;
	private String SEND_TO_UW;
	
	//update by Harry 20190129
	private String UWID;
	private String UW_TYPE;
	private String UW_DC_UNI;
	private String UW_DC_HNW;
	private String CNT_SN_TM;
	private String ASSGN_UW;
	private String MAGNUM_DECISION;
	private String RISKTYPE;
	private String SARGROUP;
	private String TSAR;
	private String PAYMENT_MOD;
	private String TOTAL_RP;
	private String TOTAL_SP;
	private String APP_FORM_CAME;
	private String UWREQTYPE;
	private String COUNTER_OFFER_CAME;
	private String POL_STATUS;
	private String UW_DC_UNI_UL_AGY;
	private String AUTO_CLOSURE_RPT_CAME;
	private String IS_MANUAL_UNPEND;
	private String CHECK_UW_DC_RESULT;
	
	// add CS process
	private String COMPLI_APPV;
	
	
	
	//BNSPC0Y CLM ADD 20190326
	private String PENIDNG_CPF_OUT;
	private String STATUS_AND_FAIL_REASON;
	private String CLM_STATUS_IL;
	
	private String PEND_TYPE;
	private String MR_REPORT;
	private String HIG_APPROVAL;
	private String PEND_OUTSTAND;
	private String MEDICAL_ADJ;
	private String PREPARE_LETTER;
	private String TRAINER_REJECT_RS;
	private String TRAINER_DC;
	private String HIG_REJECT_RS;
	private String ROUTE_BACK_TRAINEE;
	private String ROUTE_PEND_RW;
	private String ROUTE_BACK_AS;
	private String PEND_CPFADV;
	private String ASSESSOR_ID;
	private String CLM_APPEAL_ROUTE_ADM;
	
	private String COURT_DOC;
	private String DOCTOR_ADVICE;
	private String HIGH_APP_DEC;
	private String CLM_SUBMIT_CHANNEL;
	private String CLM_PENDINGREASON_TPD;
	private String CLM_ASSIGN_TO;
	private String CNC_CREATE_CLM_CASE;
	

	private String INVESTI_RESULT;
	private String FILE_STATUS;
	private String SG_COLLECTOR;
	private String DOC_STATUS;
	
	private String FRM_APPROVE_DC;
	private String FRM_DOC_STATUS;
	private String FRM_NEED_UP_DOC_STATUS;
	
	
	public String getFRM_APPROVE_DC() {
		return FRM_APPROVE_DC;
	}

	public void setFRM_APPROVE_DC(String fRM_APPROVE_DC) {
		FRM_APPROVE_DC = fRM_APPROVE_DC;
	}

	public String getFRM_DOC_STATUS() {
		return FRM_DOC_STATUS;
	}

	public void setFRM_DOC_STATUS(String fRM_DOC_STATUS) {
		FRM_DOC_STATUS = fRM_DOC_STATUS;
	}

	public String getFRM_NEED_UP_DOC_STATUS() {
		return FRM_NEED_UP_DOC_STATUS;
	}

	public void setFRM_NEED_UP_DOC_STATUS(String fRM_NEED_UP_DOC_STATUS) {
		FRM_NEED_UP_DOC_STATUS = fRM_NEED_UP_DOC_STATUS;
	}

	public String getSG_COLLECTOR() {
		return SG_COLLECTOR;
	}

	public void setSG_COLLECTOR(String sG_COLLECTOR) {
		SG_COLLECTOR = sG_COLLECTOR;
	}

	public String getDOC_STATUS() {
		return DOC_STATUS;
	}

	public void setDOC_STATUS(String dOC_STATUS) {
		DOC_STATUS = dOC_STATUS;
	}

	public String getCNC_CREATE_CLM_CASE() {
		return CNC_CREATE_CLM_CASE;
	}

	public void setCNC_CREATE_CLM_CASE(String cNC_CREATE_CLM_CASE) {
		CNC_CREATE_CLM_CASE = cNC_CREATE_CLM_CASE;
	}

	public String getINVESTI_RESULT() {
		return INVESTI_RESULT;
	}

	public void setINVESTI_RESULT(String iNVESTI_RESULT) {
		INVESTI_RESULT = iNVESTI_RESULT;
	}

	public String getFILE_STATUS() {
		return FILE_STATUS;
	}

	public void setFILE_STATUS(String fILE_STATUS) {
		FILE_STATUS = fILE_STATUS;
	}

	public String getCLM_ASSIGN_TO() {
		return CLM_ASSIGN_TO;
	}

	public void setCLM_ASSIGN_TO(String cLM_ASSIGN_TO) {
		CLM_ASSIGN_TO = cLM_ASSIGN_TO;
	}

	public String getCLM_PENDINGREASON_TPD() {
		return CLM_PENDINGREASON_TPD;
	}

	public void setCLM_PENDINGREASON_TPD(String cLM_PENDINGREASON_TPD) {
		CLM_PENDINGREASON_TPD = cLM_PENDINGREASON_TPD;
	}

	public String getCLM_SUBMIT_CHANNEL() {
		return CLM_SUBMIT_CHANNEL;
	}

	public void setCLM_SUBMIT_CHANNEL(String cLM_SUBMIT_CHANNEL) {
		CLM_SUBMIT_CHANNEL = cLM_SUBMIT_CHANNEL;
	}

	public String getHIGH_APP_DEC() {
		return HIGH_APP_DEC;
	}

	public void setHIGH_APP_DEC(String hIGH_APP_DEC) {
		HIGH_APP_DEC = hIGH_APP_DEC;
	}

	public String getCOURT_DOC() {
		return COURT_DOC;
	}

	public void setCOURT_DOC(String cOURT_DOC) {
		COURT_DOC = cOURT_DOC;
	}

	public String getDOCTOR_ADVICE() {
		return DOCTOR_ADVICE;
	}

	public void setDOCTOR_ADVICE(String dOCTOR_ADVICE) {
		DOCTOR_ADVICE = dOCTOR_ADVICE;
	}

	public String getCLM_APPEAL_ROUTE_ADM() {
		return CLM_APPEAL_ROUTE_ADM;
	}

	public void setCLM_APPEAL_ROUTE_ADM(String cLM_APPEAL_ROUTE_ADM) {
		CLM_APPEAL_ROUTE_ADM = cLM_APPEAL_ROUTE_ADM;
	}

	public String getCMP_COM() {
		return CMP_COM;
	}

	
	public String getROUTE_BACK_CMP_USER() {
		return ROUTE_BACK_CMP_USER;
	}

	public void setROUTE_BACK_CMP_USER(String rOUTE_BACK_CMP_USER) {
		ROUTE_BACK_CMP_USER = rOUTE_BACK_CMP_USER;
	}

	public void setCMP_COM(String cMP_COM) {
		CMP_COM = cMP_COM;
	}

	public String getCMP_DEC() {
		return CMP_DEC;
	}

	public void setCMP_DEC(String cMP_DEC) {
		CMP_DEC = cMP_DEC;
	}
	//add by bsnpc65 20190320 end
	public String getSOS_008_NEED_AP() {
		return SOS_008_NEED_AP;
	}

	public void setSOS_008_NEED_AP(String sOS_008_NEED_AP) {
		SOS_008_NEED_AP = sOS_008_NEED_AP;
	}

	public String getSOS_009_PRO_DC() {
		return SOS_009_PRO_DC;
	}

	public void setSOS_009_PRO_DC(String sOS_009_PRO_DC) {
		SOS_009_PRO_DC = sOS_009_PRO_DC;
	}

	public String getSOS_010_NEED_AP() {
		return SOS_010_NEED_AP;
	}

	public void setSOS_010_NEED_AP(String sOS_010_NEED_AP) {
		SOS_010_NEED_AP = sOS_010_NEED_AP;
	}
	
	
	
	public String getCOMPLI_APPV() {
		return COMPLI_APPV;
	}

	public void setCOMPLI_APPV(String cOMPLI_APPV) {
		COMPLI_APPV = cOMPLI_APPV;
	}

	public String getCHECK_UW_DC_RESULT() {
		return CHECK_UW_DC_RESULT;
	}

	public void setCHECK_UW_DC_RESULT(String cHECK_UW_DC_RESULT) {
		CHECK_UW_DC_RESULT = cHECK_UW_DC_RESULT;
	}

	public String getIS_MANUAL_UNPEND() {
		return IS_MANUAL_UNPEND;
	}

	public void setIS_MANUAL_UNPEND(String iS_MANUAL_UNPEND) {
		IS_MANUAL_UNPEND = iS_MANUAL_UNPEND;
	}

	public String getAUTO_CLOSURE_RPT_CAME() {
		return AUTO_CLOSURE_RPT_CAME;
	}

	public void setAUTO_CLOSURE_RPT_CAME(String aUTO_CLOSURE_RPT_CAME) {
		AUTO_CLOSURE_RPT_CAME = aUTO_CLOSURE_RPT_CAME;
	}

	public String getUW_DC_UNI_UL_AGY() {
		return UW_DC_UNI_UL_AGY;
	}

	public void setUW_DC_UNI_UL_AGY(String uW_DC_UNI_UL_AGY) {
		UW_DC_UNI_UL_AGY = uW_DC_UNI_UL_AGY;
	}

	public String getUWID() {
		return UWID;
	}

	public void setUWID(String uWID) {
		UWID = uWID;
	}

	public String getUW_TYPE() {
		return UW_TYPE;
	}

	public void setUW_TYPE(String uW_TYPE) {
		UW_TYPE = uW_TYPE;
	}

	public String getUW_DC_UNI() {
		return UW_DC_UNI;
	}

	public void setUW_DC_UNI(String uW_DC_UNI) {
		UW_DC_UNI = uW_DC_UNI;
	}

	public String getUW_DC_HNW() {
		return UW_DC_HNW;
	}

	public void setUW_DC_HNW(String uW_DC_HNW) {
		UW_DC_HNW = uW_DC_HNW;
	}

	public String getCNT_SN_TM() {
		return CNT_SN_TM;
	}

	public void setCNT_SN_TM(String cNT_SN_TM) {
		CNT_SN_TM = cNT_SN_TM;
	}

	public String getASSGN_UW() {
		return ASSGN_UW;
	}

	public void setASSGN_UW(String aSSGN_UW) {
		ASSGN_UW = aSSGN_UW;
	}

	public String getMAGNUM_DECISION() {
		return MAGNUM_DECISION;
	}

	public void setMAGNUM_DECISION(String mAGNUM_DECISION) {
		MAGNUM_DECISION = mAGNUM_DECISION;
	}

	public String getRISKTYPE() {
		return RISKTYPE;
	}

	public void setRISKTYPE(String rISKTYPE) {
		RISKTYPE = rISKTYPE;
	}

	public String getSARGROUP() {
		return SARGROUP;
	}

	public void setSARGROUP(String sARGROUP) {
		SARGROUP = sARGROUP;
	}

	public String getTSAR() {
		return TSAR;
	}

	public void setTSAR(String tSAR) {
		TSAR = tSAR;
	}

	public String getPAYMENT_MOD() {
		return PAYMENT_MOD;
	}

	public void setPAYMENT_MOD(String pAYMENT_MOD) {
		PAYMENT_MOD = pAYMENT_MOD;
	}

	public String getTOTAL_RP() {
		return TOTAL_RP;
	}

	public void setTOTAL_RP(String tOTAL_RP) {
		TOTAL_RP = tOTAL_RP;
	}

	public String getTOTAL_SP() {
		return TOTAL_SP;
	}

	public void setTOTAL_SP(String tOTAL_SP) {
		TOTAL_SP = tOTAL_SP;
	}

	public String getAPP_FORM_CAME() {
		return APP_FORM_CAME;
	}

	public void setAPP_FORM_CAME(String aPP_FORM_CAME) {
		APP_FORM_CAME = aPP_FORM_CAME;
	}

	public String getUWREQTYPE() {
		return UWREQTYPE;
	}

	public void setUWREQTYPE(String uWREQTYPE) {
		UWREQTYPE = uWREQTYPE;
	}

	public String getCOUNTER_OFFER_CAME() {
		return COUNTER_OFFER_CAME;
	}

	public void setCOUNTER_OFFER_CAME(String cOUNTER_OFFER_CAME) {
		COUNTER_OFFER_CAME = cOUNTER_OFFER_CAME;
	}

	public String getPOL_STATUS() {
		return POL_STATUS;
	}

	public void setPOL_STATUS(String pOL_STATUS) {
		POL_STATUS = pOL_STATUS;
	}

	public String getSEND_TO_SG() {
		return SEND_TO_SG;
	}
	public void setSEND_TO_SG(String sEND_TO_SG) {
		SEND_TO_SG = sEND_TO_SG;
	}

	// added by bsnpc1g on 2018/11/27

	private String SDTOCSINITOR;
	private String SEND_OSS_ERRPIC;
	private String SEND_SG_ERRPIC;
	private String SEND_ERRLOG;
	
	public String getUWDCS_SGOSS_PRL() {
		return UWDCS_SGOSS_PRL;
	}
	public void setUWDCS_SGOSS_PRL(String uWDCS_SGOSS_PRL) {
		UWDCS_SGOSS_PRL = uWDCS_SGOSS_PRL;
	}
	public String getUWDCS_HNW_PRL() {
		return UWDCS_HNW_PRL;
	}
	public void setUWDCS_HNW_PRL(String uWDCS_HNW_PRL) {
		UWDCS_HNW_PRL = uWDCS_HNW_PRL;
	}
	public String getSDTOCSINITOR() {
		return SDTOCSINITOR;
	}
	public void setSDTOCSINITOR(String sDTOCSINITOR) {
		SDTOCSINITOR = sDTOCSINITOR;
	}
	public String getSEND_OSS_ERRPIC() {
		return SEND_OSS_ERRPIC;
	}
	public void setSEND_OSS_ERRPIC(String sEND_OSS_ERRPIC) {
		SEND_OSS_ERRPIC = sEND_OSS_ERRPIC;
	}
	public String getSEND_SG_ERRPIC() {
		return SEND_SG_ERRPIC;
	}
	public void setSEND_SG_ERRPIC(String sEND_SG_ERRPIC) {
		SEND_SG_ERRPIC = sEND_SG_ERRPIC;
	}
	public String getSEND_ERRLOG() {
		return SEND_ERRLOG;
	}
	public void setSEND_ERRLOG(String sEND_ERRLOG) {
		SEND_ERRLOG = sEND_ERRLOG;
	}
	public String getCASE_MANAGER() {
		return CASE_MANAGER;
	}

	public void setCASE_MANAGER(String cASE_MANAGER) {
		CASE_MANAGER = cASE_MANAGER;
	}

	public String getIS_PEND() {
		return IS_PEND;
	}

	public void setIS_PEND(String iS_PEND) {
		IS_PEND = iS_PEND;
	}

	public String getUW_DCS_SGOSS() {
		return UW_DCS_SGOSS;
	}

	public void setUW_DCS_SGOSS(String uW_DCS_SGOSS) {
		UW_DCS_SGOSS = uW_DCS_SGOSS;
	}

	public String getUW_DCS_HNW() {
		return UW_DCS_HNW;
	}

	public void setUW_DCS_HNW(String uW_DCS_HNW) {
		UW_DCS_HNW = uW_DCS_HNW;
	}

	public String getRTCTS_INITIATOR() {
		return RTCTS_INITIATOR;
	}

	public void setRTCTS_INITIATOR(String rTCTS_INITIATOR) {
		RTCTS_INITIATOR = rTCTS_INITIATOR;
	}

	public String getSEND_BACK_UW() {
		return SEND_BACK_UW;
	}

	public void setSEND_BACK_UW(String sEND_BACK_UW) {
		SEND_BACK_UW = sEND_BACK_UW;
	}

	public String getSEND_TAMP_FROM_OSS() {
		return SEND_TAMP_FROM_OSS;
	}

	public void setSEND_TAMP_FROM_OSS(String sEND_TAMP_FROM_OSS) {
		SEND_TAMP_FROM_OSS = sEND_TAMP_FROM_OSS;
	}

	public String getSEND_ALEX_FROM_OSS() {
		return SEND_ALEX_FROM_OSS;
	}

	public void setSEND_ALEX_FROM_OSS(String sEND_ALEX_FROM_OSS) {
		SEND_ALEX_FROM_OSS = sEND_ALEX_FROM_OSS;
	}

	public String getSEND_TAMP_FROM_HNW() {
		return SEND_TAMP_FROM_HNW;
	}

	public void setSEND_TAMP_FROM_HNW(String sEND_TAMP_FROM_HNW) {
		SEND_TAMP_FROM_HNW = sEND_TAMP_FROM_HNW;
	}

	public String getSEND_ALEX_FROM_HNW() {
		return SEND_ALEX_FROM_HNW;
	}

	public void setSEND_ALEX_FROM_HNW(String sEND_ALEX_FROM_HNW) {
		SEND_ALEX_FROM_HNW = sEND_ALEX_FROM_HNW;
	}

	public String getRTBACK_UW() {
		return RTBACK_UW;
	}

	public void setRTBACK_UW(String rTBACK_UW) {
		RTBACK_UW = rTBACK_UW;
	}

	public String getBUDDY_CHK() {
		return BUDDY_CHK;
	}

	public void setBUDDY_CHK(String bUDDY_CHK) {
		BUDDY_CHK = bUDDY_CHK;
	}

	public String getSEND_MANAGER() {
		return SEND_MANAGER;
	}

	public void setSEND_MANAGER(String sEND_MANAGER) {
		SEND_MANAGER = sEND_MANAGER;
	}

	public String getSEND_UW() {
		return SEND_UW;
	}

	public void setSEND_UW(String sEND_UW) {
		SEND_UW = sEND_UW;
	}

	public String getUNI_001() {
		return UNI_001;
	}

	public void setUNI_001(String uNI_001) {
		UNI_001 = uNI_001;
	}

	public String getUNI_002() {
		return UNI_002;
	}

	public void setUNI_002(String uNI_002) {
		UNI_002 = uNI_002;
	}

	public String getUNI_003() {
		return UNI_003;
	}

	public void setUNI_003(String uNI_003) {
		UNI_003 = uNI_003;
	}

	public String getUNI_004() {
		return UNI_004;
	}

	public void setUNI_004(String uNI_004) {
		UNI_004 = uNI_004;
	}

	public String getUNI_005() {
		return UNI_005;
	}

	public void setUNI_005(String uNI_005) {
		UNI_005 = uNI_005;
	}

	public String getUNI_006() {
		return UNI_006;
	}

	public void setUNI_006(String uNI_006) {
		UNI_006 = uNI_006;
	}

	public String getUNI_007() {
		return UNI_007;
	}

	public void setUNI_007(String uNI_007) {
		UNI_007 = uNI_007;
	}

	public String getUNI_008() {
		return UNI_008;
	}

	public void setUNI_008(String uNI_008) {
		UNI_008 = uNI_008;
	}

	public String getUNI_009() {
		return UNI_009;
	}

	public void setUNI_009(String uNI_009) {
		UNI_009 = uNI_009;
	}

	public String getUNI_010() {
		return UNI_010;
	}

	public void setUNI_010(String uNI_010) {
		UNI_010 = uNI_010;
	}

	public String getRT_OTHER_UW() {
		return RT_OTHER_UW;
	}

	public void setRT_OTHER_UW(String rT_OTHER_UW) {
		RT_OTHER_UW = rT_OTHER_UW;
	}

	
	public String getCOUNTER_SIGN_TEAM() {
    return COUNTER_SIGN_TEAM;
  }

  public void setCOUNTER_SIGN_TEAM(String cOUNTER_SIGN_TEAM) {
    COUNTER_SIGN_TEAM = cOUNTER_SIGN_TEAM;
  }

  public String getCTS_INIT() {
		return CTS_INIT;
	}

	public void setCTS_INIT(String cTS_INIT) {
		CTS_INIT = cTS_INIT;
	}

	public String getCOUNTERSIGN_INITIATOR() {
		return COUNTERSIGN_INITIATOR;
	}

	public void setCOUNTERSIGN_INITIATOR(String cOUNTERSIGN_INITIATOR) {
		COUNTERSIGN_INITIATOR = cOUNTERSIGN_INITIATOR;
	}

	public String getCASECREATER() {
		return CASECREATER;
	}

	public void setCASECREATER(String cASECREATER) {
		CASECREATER = cASECREATER;
	}

	public String getCOUNTER_SIGNOR_ALEX() {
		return COUNTER_SIGNOR_ALEX;
	}

	public void setCOUNTER_SIGNOR_ALEX(String cOUNTER_SIGNOR_ALEX) {
		COUNTER_SIGNOR_ALEX = cOUNTER_SIGNOR_ALEX;
	}

	public String getCOUNTER_SIGNOR_TAMP() {
		return COUNTER_SIGNOR_TAMP;
	}

	public void setCOUNTER_SIGNOR_TAMP(String cOUNTER_SIGNOR_TAMP) {
		COUNTER_SIGNOR_TAMP = cOUNTER_SIGNOR_TAMP;
	}

	public String getCOUNTER_SIGNOR_OSS() {
		return COUNTER_SIGNOR_OSS;
	}

	public void setCOUNTER_SIGNOR_OSS(String cOUNTER_SIGNOR_OSS) {
		COUNTER_SIGNOR_OSS = cOUNTER_SIGNOR_OSS;
	}

	public String getCOUNTER_SIGNOR_HNW() {
		return COUNTER_SIGNOR_HNW;
	}

	public void setCOUNTER_SIGNOR_HNW(String cOUNTER_SIGNOR_HNW) {
		COUNTER_SIGNOR_HNW = cOUNTER_SIGNOR_HNW;
	}

	public String getSEND_TO_TAMP() {
		return SEND_TO_TAMP;
	}

	public void setSEND_TO_TAMP(String sEND_TO_TAMP) {
		SEND_TO_TAMP = sEND_TO_TAMP;
	}

	public String getSEND_TO_ALEX() {
		return SEND_TO_ALEX;
	}

	public void setSEND_TO_ALEX(String sEND_TO_ALEX) {
		SEND_TO_ALEX = sEND_TO_ALEX;
	}

	public String getSEND_TO_HNW() {
		return SEND_TO_HNW;
	}

	public void setSEND_TO_HNW(String sEND_TO_HNW) {
		SEND_TO_HNW = sEND_TO_HNW;
	}

	public String getCOUNTER_SIGNOR() {
		return COUNTER_SIGNOR;
	}

	public void setCOUNTER_SIGNOR(String cOUNTER_SIGNOR) {
		COUNTER_SIGNOR = cOUNTER_SIGNOR;
	}

	public String getCOUNTER_SIGN_TEAM_SG() {
		return COUNTER_SIGN_TEAM_SG;
	}

	public void setCOUNTER_SIGN_TEAM_SG(String cOUNTER_SIGN_TEAM_SG) {
		COUNTER_SIGN_TEAM_SG = cOUNTER_SIGN_TEAM_SG;
	}

	public String getCOUNTER_SIGN_TEAM_OSS() {
		return COUNTER_SIGN_TEAM_OSS;
	}

	public void setCOUNTER_SIGN_TEAM_OSS(String cOUNTER_SIGN_TEAM_OSS) {
		COUNTER_SIGN_TEAM_OSS = cOUNTER_SIGN_TEAM_OSS;
	}

	public String getCOUNTER_SIGN_TEAM_HNW() {
		return COUNTER_SIGN_TEAM_HNW;
	}

	public void setCOUNTER_SIGN_TEAM_HNW(String cOUNTER_SIGN_TEAM_HNW) {
		COUNTER_SIGN_TEAM_HNW = cOUNTER_SIGN_TEAM_HNW;
	}

	public String getUNDERWRITING_DECISION_POS() {
		return UNDERWRITING_DECISION_POS;
	}

	public void setUNDERWRITING_DECISION_POS(String uNDERWRITING_DECISION_POS) {
		UNDERWRITING_DECISION_POS = uNDERWRITING_DECISION_POS;
	}

	public String getROUTE_TO_OTHER_UNDERWRITER() {
		return ROUTE_TO_OTHER_UNDERWRITER;
	}

	public void setROUTE_TO_OTHER_UNDERWRITER(String rOUTE_TO_OTHER_UNDERWRITER) {
		ROUTE_TO_OTHER_UNDERWRITER = rOUTE_TO_OTHER_UNDERWRITER;
	}

	public String getROUTE_BACK_TO_UNDERWRITER() {
		return ROUTE_BACK_TO_UNDERWRITER;
	}

	public void setROUTE_BACK_TO_UNDERWRITER(String rOUTE_BACK_TO_UNDERWRITER) {
		ROUTE_BACK_TO_UNDERWRITER = rOUTE_BACK_TO_UNDERWRITER;
	}

	public String getROUTE_BACK_TO_CASE_MANAGER() {
		return ROUTE_BACK_TO_CASE_MANAGER;
	}

	public void setROUTE_BACK_TO_CASE_MANAGER(String rOUTE_BACK_TO_CASE_MANAGER) {
		ROUTE_BACK_TO_CASE_MANAGER = rOUTE_BACK_TO_CASE_MANAGER;
	}

	public String getSEND_TO_COUNTERSIGNING_INITIATOR() {
		return SEND_TO_COUNTERSIGNING_INITIATOR;
	}

	public void setSEND_TO_COUNTERSIGNING_INITIATOR(String sEND_TO_COUNTERSIGNING_INITIATOR) {
		SEND_TO_COUNTERSIGNING_INITIATOR = sEND_TO_COUNTERSIGNING_INITIATOR;
	}

	public String getSEND_TO_RE_UNDERWRITING() {
		return SEND_TO_RE_UNDERWRITING;
	}

	public void setSEND_TO_RE_UNDERWRITING(String sEND_TO_RE_UNDERWRITING) {
		SEND_TO_RE_UNDERWRITING = sEND_TO_RE_UNDERWRITING;
	}
	// end

	public String getTL_DECISION() {
		return TL_DECISION;
	}

	public void setTL_DECISION(String tL_DECISION) {
		TL_DECISION = tL_DECISION;
	}

	public String getSG_STAFF() {
		return SG_STAFF;
	}

	public void setSG_STAFF(String sG_STAFF) {
		SG_STAFF = sG_STAFF;
	}

	public String getAC_CLOSE_REASON() {
		return AC_CLOSE_REASON;
	}

	public void setAC_CLOSE_REASON(String aC_CLOSE_REASON) {
		AC_CLOSE_REASON = aC_CLOSE_REASON;
	}

	public String getAPPEAL_DECISION() {
		return APPEAL_DECISION;
	}

	public void setAPPEAL_DECISION(String aPPEAL_DECISION) {
		APPEAL_DECISION = aPPEAL_DECISION;
	}

	public String getAPPROVAL_DECISION() {
		return APPROVAL_DECISION;
	}

	public void setAPPROVAL_DECISION(String aPPROVAL_DECISION) {
		APPROVAL_DECISION = aPPROVAL_DECISION;
	}

	public String getAPPROVAL_DECISION_HOD() {
		return APPROVAL_DECISION_HOD;
	}

	public void setAPPROVAL_DECISION_HOD(String aPPROVAL_DECISION_HOD) {
		APPROVAL_DECISION_HOD = aPPROVAL_DECISION_HOD;
	}

	public String getCASHIER_CLOSE_REASON() {
		return CASHIER_CLOSE_REASON;
	}

	public void setCASHIER_CLOSE_REASON(String cASHIER_CLOSE_REASON) {
		CASHIER_CLOSE_REASON = cASHIER_CLOSE_REASON;
	}

	public String getCASHIER_DECISION() {
		return CASHIER_DECISION;
	}

	public void setCASHIER_DECISION(String cASHIER_DECISION) {
		CASHIER_DECISION = cASHIER_DECISION;
	}

	public String getCOMPLIANCE_DECISION() {
		return COMPLIANCE_DECISION;
	}

	public void setCOMPLIANCE_DECISION(String cOMPLIANCE_DECISION) {
		COMPLIANCE_DECISION = cOMPLIANCE_DECISION;
	}

	public String getCOUNTER_SIGN_HNW() {
		return COUNTER_SIGN_HNW;
	}

	public void setCOUNTER_SIGN_HNW(String cOUNTER_SIGN_HNW) {
		COUNTER_SIGN_HNW = cOUNTER_SIGN_HNW;
	}

	public String getCOUNTER_SIGN_OSS() {
		return COUNTER_SIGN_OSS;
	}

	public void setCOUNTER_SIGN_OSS(String cOUNTER_SIGN_OSS) {
		COUNTER_SIGN_OSS = cOUNTER_SIGN_OSS;
	}

	public String getCOUNTER_SIGN_SG() {
		return COUNTER_SIGN_SG;
	}

	public void setCOUNTER_SIGN_SG(String cOUNTER_SIGN_SG) {
		COUNTER_SIGN_SG = cOUNTER_SIGN_SG;
	}

	public String getCOUNTERSIGN_DECISION() {
		return COUNTERSIGN_DECISION;
	}

	public void setCOUNTERSIGN_DECISION(String cOUNTERSIGN_DECISION) {
		COUNTERSIGN_DECISION = cOUNTERSIGN_DECISION;
	}

	public String getFIRST_APPROVAL() {
		return FIRST_APPROVAL;
	}

	public void setFIRST_APPROVAL(String fIRST_APPROVAL) {
		FIRST_APPROVAL = fIRST_APPROVAL;
	}

	public String getNEED_COUNTER_SIGN() {
		return NEED_COUNTER_SIGN;
	}

	public void setNEED_COUNTER_SIGN(String nEED_COUNTER_SIGN) {
		NEED_COUNTER_SIGN = nEED_COUNTER_SIGN;
	}

	public String getROUTE_TO_CASE_MANAGER() {
		return ROUTE_TO_CASE_MANAGER;
	}

	public void setROUTE_TO_CASE_MANAGER(String rOUTE_TO_CASE_MANAGER) {
		ROUTE_TO_CASE_MANAGER = rOUTE_TO_CASE_MANAGER;
	}

	public String getROUTE_TO_CMB_PIC() {
		return ROUTE_TO_CMB_PIC;
	}

	public void setROUTE_TO_CMB_PIC(String rOUTE_TO_CMB_PIC) {
		ROUTE_TO_CMB_PIC = rOUTE_TO_CMB_PIC;
	}

	public String getROUTE_TO_COUNTERSIGNING_INITIATOR() {
		return ROUTE_TO_COUNTERSIGNING_INITIATOR;
	}

	public void setROUTE_TO_COUNTERSIGNING_INITIATOR(String rOUTE_TO_COUNTERSIGNING_INITIATOR) {
		ROUTE_TO_COUNTERSIGNING_INITIATOR = rOUTE_TO_COUNTERSIGNING_INITIATOR;
	}

	public String getSEND_CASE_TO_SG_TEAM() {
		return SEND_CASE_TO_SG_TEAM;
	}

	public void setSEND_CASE_TO_SG_TEAM(String sEND_CASE_TO_SG_TEAM) {
		SEND_CASE_TO_SG_TEAM = sEND_CASE_TO_SG_TEAM;
	}

	public String getSEND_TO_ERROR_LOGGER() {
		return SEND_TO_ERROR_LOGGER;
	}

	public void setSEND_TO_ERROR_LOGGER(String sEND_TO_ERROR_LOGGER) {
		SEND_TO_ERROR_LOGGER = sEND_TO_ERROR_LOGGER;
	}

	public String getSEND_TO_ORIGINAL_UNDERWRITER() {
		return SEND_TO_ORIGINAL_UNDERWRITER;
	}

	public void setSEND_TO_ORIGINAL_UNDERWRITER(String sEND_TO_ORIGINAL_UNDERWRITER) {
		SEND_TO_ORIGINAL_UNDERWRITER = sEND_TO_ORIGINAL_UNDERWRITER;
	}

	public String getSEND_TO_OSS_ERROR_PIC() {
		return SEND_TO_OSS_ERROR_PIC;
	}

	public void setSEND_TO_OSS_ERROR_PIC(String sEND_TO_OSS_ERROR_PIC) {
		SEND_TO_OSS_ERROR_PIC = sEND_TO_OSS_ERROR_PIC;
	}

	public String getSEND_TO_OSS_HSG_PIC() {
		return SEND_TO_OSS_HSG_PIC;
	}

	public void setSEND_TO_OSS_HSG_PIC(String sEND_TO_OSS_HSG_PIC) {
		SEND_TO_OSS_HSG_PIC = sEND_TO_OSS_HSG_PIC;
	}

	public String getSEND_TO_POS_POST_ADLR_PIC() {
		return SEND_TO_POS_POST_ADLR_PIC;
	}

	public void setSEND_TO_POS_POST_ADLR_PIC(String sEND_TO_POS_POST_ADLR_PIC) {
		SEND_TO_POS_POST_ADLR_PIC = sEND_TO_POS_POST_ADLR_PIC;
	}

	public String getSEND_TO_SG_ERROR_PIC() {
		return SEND_TO_SG_ERROR_PIC;
	}

	public void setSEND_TO_SG_ERROR_PIC(String sEND_TO_SG_ERROR_PIC) {
		SEND_TO_SG_ERROR_PIC = sEND_TO_SG_ERROR_PIC;
	}

	public String getSEND_TO_SG_HSG_PIC_FOR_CPFB_CHECKING() {
		return SEND_TO_SG_HSG_PIC_FOR_CPFB_CHECKING;
	}

	public void setSEND_TO_SG_HSG_PIC_FOR_CPFB_CHECKING(String sEND_TO_SG_HSG_PIC_FOR_CPFB_CHECKING) {
		SEND_TO_SG_HSG_PIC_FOR_CPFB_CHECKING = sEND_TO_SG_HSG_PIC_FOR_CPFB_CHECKING;
	}

	public String getSEND_TO_SG_POST_ADLR_PIC() {
		return SEND_TO_SG_POST_ADLR_PIC;
	}

	public void setSEND_TO_SG_POST_ADLR_PIC(String sEND_TO_SG_POST_ADLR_PIC) {
		SEND_TO_SG_POST_ADLR_PIC = sEND_TO_SG_POST_ADLR_PIC;
	}

	public String getUNDERWRITING_DECISION() {
		return UNDERWRITING_DECISION;
	}

	public void setUNDERWRITING_DECISION(String uNDERWRITING_DECISION) {
		UNDERWRITING_DECISION = uNDERWRITING_DECISION;
	}
	// add end

	public String getOUTRIGHT_REJECT() {
		return OUTRIGHT_REJECT;
	}

	public void setOUTRIGHT_REJECT(String oUTRIGHT_REJECT) {
		OUTRIGHT_REJECT = oUTRIGHT_REJECT;
	}

	public String getREQUEST_PLAS_TEAM_PROCESS() {
		return REQUEST_PLAS_TEAM_PROCESS;
	}

	public void setREQUEST_PLAS_TEAM_PROCESS(String rEQUEST_PLAS_TEAM_PROCESS) {
		REQUEST_PLAS_TEAM_PROCESS = rEQUEST_PLAS_TEAM_PROCESS;
	}

	public String getAC_DECISION() {
		return AC_DECISION;
	}

	public void setAC_DECISION(String aC_DECISION) {
		AC_DECISION = aC_DECISION;
	}

	public String getACRA_CHECKING() {
		return ACRA_CHECKING;
	}

	public void setACRA_CHECKING(String aCRA_CHECKING) {
		ACRA_CHECKING = aCRA_CHECKING;
	}

	public String getACTIVITY_LIST() {
		return ACTIVITY_LIST;
	}

	public void setACTIVITY_LIST(String aCTIVITY_LIST) {
		ACTIVITY_LIST = aCTIVITY_LIST;
	}

	public String getCALL_CENTRE_CLOSE_REASON() {
		return CALL_CENTRE_CLOSE_REASON;
	}

	public void setCALL_CENTRE_CLOSE_REASON(String cALL_CENTRE_CLOSE_REASON) {
		CALL_CENTRE_CLOSE_REASON = cALL_CENTRE_CLOSE_REASON;
	}

	public String getCALL_CENTRE_DECISION() {
		return CALL_CENTRE_DECISION;
	}

	public void setCALL_CENTRE_DECISION(String cALL_CENTRE_DECISION) {
		CALL_CENTRE_DECISION = cALL_CENTRE_DECISION;
	}

	public String getCLAIM_APPROVAL() {
		return CLAIM_APPROVAL;
	}

	public void setCLAIM_APPROVAL(String cLAIM_APPROVAL) {
		CLAIM_APPROVAL = cLAIM_APPROVAL;
	}

	public String getCLOSE_REASON() {
		return CLOSE_REASON;
	}

	public void setCLOSE_REASON(String cLOSE_REASON) {
		CLOSE_REASON = cLOSE_REASON;
	}

	public String getMANUAL_LETTER() {
		return MANUAL_LETTER;
	}

	public void setMANUAL_LETTER(String mANUAL_LETTER) {
		MANUAL_LETTER = mANUAL_LETTER;
	}

	public String getMLNS() {
		return MLNS;
	}

	public void setMLNS(String mLNS) {
		MLNS = mLNS;
	}

	public String getNEED_PREPARE_MANUAL_LETTER() {
		return NEED_PREPARE_MANUAL_LETTER;
	}

	public void setNEED_PREPARE_MANUAL_LETTER(String nEED_PREPARE_MANUAL_LETTER) {
		NEED_PREPARE_MANUAL_LETTER = nEED_PREPARE_MANUAL_LETTER;
	}

	public String getREJECT() {
		return REJECT;
	}

	public void setREJECT(String rEJECT) {
		REJECT = rEJECT;
	}

	public String getUSER_LIST() {
		return USER_LIST;
	}

	public void setUSER_LIST(String uSER_LIST) {
		USER_LIST = uSER_LIST;
	}

	// --sos
	public String getSOS_001_APPROVE() {
		return SOS_001_APPROVE;
	}

	public void setSOS_001_APPROVE(String sOS_001_APPROVE) {
		SOS_001_APPROVE = sOS_001_APPROVE;
	}

	public String getSOS_002_REQUEST_POS_FOLLOW_UP() {
		return SOS_002_REQUEST_POS_FOLLOW_UP;
	}

	public void setSOS_002_REQUEST_POS_FOLLOW_UP(String sOS_002_REQUEST_POS_FOLLOW_UP) {
		SOS_002_REQUEST_POS_FOLLOW_UP = sOS_002_REQUEST_POS_FOLLOW_UP;
	}

	public String getSOS_003_NEED_TL_APPROVAL() {
		return SOS_003_NEED_TL_APPROVAL;
	}

	public void setSOS_003_NEED_TL_APPROVAL(String sOS_003_NEED_TL_APPROVAL) {
		SOS_003_NEED_TL_APPROVAL = sOS_003_NEED_TL_APPROVAL;
	}

	public String getSOS_004_APPROVER_DECSION() {
		return SOS_004_APPROVER_DECSION;
	}

	public void setSOS_004_APPROVER_DECSION(String sOS_004_APPROVER_DECSION) {
		SOS_004_APPROVER_DECSION = sOS_004_APPROVER_DECSION;
	}

	public String getSOS_005_PAYMENT_NEED_APPROVAL() {
		return SOS_005_PAYMENT_NEED_APPROVAL;
	}

	public void setSOS_005_PAYMENT_NEED_APPROVAL(String sOS_005_PAYMENT_NEED_APPROVAL) {
		SOS_005_PAYMENT_NEED_APPROVAL = sOS_005_PAYMENT_NEED_APPROVAL;
	}

	public String getSOS_006_PAYMENT_APPROVER_DECISION() {
		return SOS_006_PAYMENT_APPROVER_DECISION;
	}

	public void setSOS_006_PAYMENT_APPROVER_DECISION(String sOS_006_PAYMENT_APPROVER_DECISION) {
		SOS_006_PAYMENT_APPROVER_DECISION = sOS_006_PAYMENT_APPROVER_DECISION;
	}
	// --sos end

	public String getPOS_001() {
		return POS_001;
	}

	public void setPOS_001(String pOS_001) {
		POS_001 = pOS_001;
	}

	public String getPOS_002() {
		return POS_002;
	}

	public void setPOS_002(String pOS_002) {
		POS_002 = pOS_002;
	}

	public String getPOS_003() {
		return POS_003;
	}

	public void setPOS_003(String pOS_003) {
		POS_003 = pOS_003;
	}

	public String getPOS_004() {
		return POS_004;
	}

	public void setPOS_004(String pOS_004) {
		POS_004 = pOS_004;
	}

	public String getPOS_005() {
		return POS_005;
	}

	public void setPOS_005(String pOS_005) {
		POS_005 = pOS_005;
	}

	public String getPOS_006() {
		return POS_006;
	}

	public void setPOS_006(String pOS_006) {
		POS_006 = pOS_006;
	}

	public String getPOS_007() {
		return POS_007;
	}

	public void setPOS_007(String pOS_007) {
		POS_007 = pOS_007;
	}

	public String getPOS_008() {
		return POS_008;
	}

	public void setPOS_008(String pOS_008) {
		POS_008 = pOS_008;
	}

	public String getPOS_009() {
		return POS_009;
	}

	public void setPOS_009(String pOS_009) {
		POS_009 = pOS_009;
	}

	public String getPOS_010() {
		return POS_010;
	}

	public void setPOS_010(String pOS_010) {
		POS_010 = pOS_010;
	}

	public String getPOS_011() {
		return POS_011;
	}

	public void setPOS_011(String pOS_011) {
		POS_011 = pOS_011;
	}

	public String getPOS_012() {
		return POS_012;
	}

	public void setPOS_012(String pOS_012) {
		POS_012 = pOS_012;
	}

	public String getPOS_013() {
		return POS_013;
	}

	public void setPOS_013(String pOS_013) {
		POS_013 = pOS_013;
	}

	public String getPOS_014() {
		return POS_014;
	}

	public void setPOS_014(String pOS_014) {
		POS_014 = pOS_014;
	}

	public String getPOS_015() {
		return POS_015;
	}

	public void setPOS_015(String pOS_015) {
		POS_015 = pOS_015;
	}

	public String getPOS_016() {
		return POS_016;
	}

	public void setPOS_016(String pOS_016) {
		POS_016 = pOS_016;
	}

	public String getPOS_017() {
		return POS_017;
	}

	public void setPOS_017(String pOS_017) {
		POS_017 = pOS_017;
	}

	public String getPOS_018() {
		return POS_018;
	}

	public void setPOS_018(String pOS_018) {
		POS_018 = pOS_018;
	}

	public String getPOS_019() {
		return POS_019;
	}

	public void setPOS_019(String pOS_019) {
		POS_019 = pOS_019;
	}

	public String getPOS_020() {
		return POS_020;
	}

	public void setPOS_020(String pOS_020) {
		POS_020 = pOS_020;
	}

	public String getPOS_021() {
		return POS_021;
	}

	public void setPOS_021(String pOS_021) {
		POS_021 = pOS_021;
	}

	public String getPOS_022() {
		return POS_022;
	}

	public void setPOS_022(String pOS_022) {
		POS_022 = pOS_022;
	}

	public String getPOS_023() {
		return POS_023;
	}

	public void setPOS_023(String pOS_023) {
		POS_023 = pOS_023;
	}

	public String getPOS_024() {
		return POS_024;
	}

	public void setPOS_024(String pOS_024) {
		POS_024 = pOS_024;
	}

	public String getPOS_025() {
		return POS_025;
	}

	public void setPOS_025(String pOS_025) {
		POS_025 = pOS_025;
	}

	public String getIS_APPROVAL() {
		return IS_APPROVAL;
	}

	public void setIS_APPROVAL(String iS_APPROVAL) {
		IS_APPROVAL = iS_APPROVAL;
	}

	public String getCOMMENT() {
		return COMMENT;
	}

	public void setCOMMENT(String cOMMENT) {
		COMMENT = cOMMENT;
	}

	public String getSOS_007_CYO_ANNIVERSARY() {
		return SOS_007_CYO_ANNIVERSARY;
	}

	public void setSOS_007_CYO_ANNIVERSARY(String sOS_007_CYO_ANNIVERSARY) {
		SOS_007_CYO_ANNIVERSARY = sOS_007_CYO_ANNIVERSARY;
	}

	public String getCUSTOM_01() {
		return CUSTOM_01;
	}

	public void setCUSTOM_01(String cUSTOM_01) {
		CUSTOM_01 = cUSTOM_01;
	}

	public String getCUSTOM_02() {
		return CUSTOM_02;
	}

	public void setCUSTOM_02(String cUSTOM_02) {
		CUSTOM_02 = cUSTOM_02;
	}

	public String getCUSTOM_03() {
		return CUSTOM_03;
	}

	public void setCUSTOM_03(String cUSTOM_03) {
		CUSTOM_03 = cUSTOM_03;
	}

	public String getCUSTOM_04() {
		return CUSTOM_04;
	}

	public void setCUSTOM_04(String cUSTOM_04) {
		CUSTOM_04 = cUSTOM_04;
	}

	public String getCUSTOM_05() {
		return CUSTOM_05;
	}

	public void setCUSTOM_05(String cUSTOM_05) {
		CUSTOM_05 = cUSTOM_05;
	}

	public String getCUSTOM_06() {
		return CUSTOM_06;
	}

	public void setCUSTOM_06(String cUSTOM_06) {
		CUSTOM_06 = cUSTOM_06;
	}

	public String getCUSTOM_07() {
		return CUSTOM_07;
	}

	public void setCUSTOM_07(String cUSTOM_07) {
		CUSTOM_07 = cUSTOM_07;
	}

	public String getCUSTOM_08() {
		return CUSTOM_08;
	}

	public void setCUSTOM_08(String cUSTOM_08) {
		CUSTOM_08 = cUSTOM_08;
	}

	public String getCUSTOM_09() {
		return CUSTOM_09;
	}

	public void setCUSTOM_09(String cUSTOM_09) {
		CUSTOM_09 = cUSTOM_09;
	}

	public String getCUSTOM_10() {
		return CUSTOM_10;
	}

	public void setCUSTOM_10(String cUSTOM_10) {
		CUSTOM_10 = cUSTOM_10;
	}

	public String getCUSTOM_11() {
		return CUSTOM_11;
	}

	public void setCUSTOM_11(String cUSTOM_11) {
		CUSTOM_11 = cUSTOM_11;
	}

	public String getCUSTOM_12() {
		return CUSTOM_12;
	}

	public void setCUSTOM_12(String cUSTOM_12) {
		CUSTOM_12 = cUSTOM_12;
	}

	public String getCUSTOM_13() {
		return CUSTOM_13;
	}

	public void setCUSTOM_13(String cUSTOM_13) {
		CUSTOM_13 = cUSTOM_13;
	}

	public String getCUSTOM_14() {
		return CUSTOM_14;
	}

	public void setCUSTOM_14(String cUSTOM_14) {
		CUSTOM_14 = cUSTOM_14;
	}

	public String getCUSTOM_15() {
		return CUSTOM_15;
	}

	public void setCUSTOM_15(String cUSTOM_15) {
		CUSTOM_15 = cUSTOM_15;
	}

	public String getCUSTOM_16() {
		return CUSTOM_16;
	}

	public void setCUSTOM_16(String cUSTOM_16) {
		CUSTOM_16 = cUSTOM_16;
	}

	public String getCUSTOM_17() {
		return CUSTOM_17;
	}

	public void setCUSTOM_17(String cUSTOM_17) {
		CUSTOM_17 = cUSTOM_17;
	}

	public String getCUSTOM_18() {
		return CUSTOM_18;
	}

	public void setCUSTOM_18(String cUSTOM_18) {
		CUSTOM_18 = cUSTOM_18;
	}

	public String getCUSTOM_19() {
		return CUSTOM_19;
	}

	public void setCUSTOM_19(String cUSTOM_19) {
		CUSTOM_19 = cUSTOM_19;
	}

	public String getCUSTOM_20() {
		return CUSTOM_20;
	}

	public void setCUSTOM_20(String cUSTOM_20) {
		CUSTOM_20 = cUSTOM_20;
	}

	public String getCUSTOM_21() {
		return CUSTOM_21;
	}

	public void setCUSTOM_21(String cUSTOM_21) {
		CUSTOM_21 = cUSTOM_21;
	}

	public String getCUSTOM_22() {
		return CUSTOM_22;
	}

	public void setCUSTOM_22(String cUSTOM_22) {
		CUSTOM_22 = cUSTOM_22;
	}

	public String getCUSTOM_23() {
		return CUSTOM_23;
	}

	public void setCUSTOM_23(String cUSTOM_23) {
		CUSTOM_23 = cUSTOM_23;
	}

	public String getCUSTOM_24() {
		return CUSTOM_24;
	}

	public void setCUSTOM_24(String cUSTOM_24) {
		CUSTOM_24 = cUSTOM_24;
	}

	public String getCUSTOM_25() {
		return CUSTOM_25;
	}

	public void setCUSTOM_25(String cUSTOM_25) {
		CUSTOM_25 = cUSTOM_25;
	}

	public String getCUSTOM_26() {
		return CUSTOM_26;
	}

	public void setCUSTOM_26(String cUSTOM_26) {
		CUSTOM_26 = cUSTOM_26;
	}

	public String getCUSTOM_27() {
		return CUSTOM_27;
	}

	public void setCUSTOM_27(String cUSTOM_27) {
		CUSTOM_27 = cUSTOM_27;
	}

	public String getCUSTOM_28() {
		return CUSTOM_28;
	}

	public void setCUSTOM_28(String cUSTOM_28) {
		CUSTOM_28 = cUSTOM_28;
	}

	public String getCUSTOM_29() {
		return CUSTOM_29;
	}

	public void setCUSTOM_29(String cUSTOM_29) {
		CUSTOM_29 = cUSTOM_29;
	}

	public String getCUSTOM_30() {
		return CUSTOM_30;
	}

	public void setCUSTOM_30(String cUSTOM_30) {
		CUSTOM_30 = cUSTOM_30;
	}

	public String getCUSTOM_31() {
		return CUSTOM_31;
	}

	public void setCUSTOM_31(String cUSTOM_31) {
		CUSTOM_31 = cUSTOM_31;
	}

	public String getCUSTOM_32() {
		return CUSTOM_32;
	}

	public void setCUSTOM_32(String cUSTOM_32) {
		CUSTOM_32 = cUSTOM_32;
	}

	public String getCUSTOM_33() {
		return CUSTOM_33;
	}

	public void setCUSTOM_33(String cUSTOM_33) {
		CUSTOM_33 = cUSTOM_33;
	}

	public String getCUSTOM_34() {
		return CUSTOM_34;
	}

	public void setCUSTOM_34(String cUSTOM_34) {
		CUSTOM_34 = cUSTOM_34;
	}

	public String getCUSTOM_35() {
		return CUSTOM_35;
	}

	public void setCUSTOM_35(String cUSTOM_35) {
		CUSTOM_35 = cUSTOM_35;
	}

	public String getCUSTOM_36() {
		return CUSTOM_36;
	}

	public void setCUSTOM_36(String cUSTOM_36) {
		CUSTOM_36 = cUSTOM_36;
	}

	public String getCUSTOM_37() {
		return CUSTOM_37;
	}

	public void setCUSTOM_37(String cUSTOM_37) {
		CUSTOM_37 = cUSTOM_37;
	}

	public String getCUSTOM_38() {
		return CUSTOM_38;
	}

	public void setCUSTOM_38(String cUSTOM_38) {
		CUSTOM_38 = cUSTOM_38;
	}

	public String getCUSTOM_39() {
		return CUSTOM_39;
	}

	public void setCUSTOM_39(String cUSTOM_39) {
		CUSTOM_39 = cUSTOM_39;
	}

	public String getCUSTOM_40() {
		return CUSTOM_40;
	}

	public void setCUSTOM_40(String cUSTOM_40) {
		CUSTOM_40 = cUSTOM_40;
	}

	public String getCUSTOM_41() {
		return CUSTOM_41;
	}

	public void setCUSTOM_41(String cUSTOM_41) {
		CUSTOM_41 = cUSTOM_41;
	}

	public String getCUSTOM_42() {
		return CUSTOM_42;
	}

	public void setCUSTOM_42(String cUSTOM_42) {
		CUSTOM_42 = cUSTOM_42;
	}

	public String getCUSTOM_43() {
		return CUSTOM_43;
	}

	public void setCUSTOM_43(String cUSTOM_43) {
		CUSTOM_43 = cUSTOM_43;
	}

	public String getCUSTOM_44() {
		return CUSTOM_44;
	}

	public void setCUSTOM_44(String cUSTOM_44) {
		CUSTOM_44 = cUSTOM_44;
	}

	public String getCUSTOM_45() {
		return CUSTOM_45;
	}

	public void setCUSTOM_45(String cUSTOM_45) {
		CUSTOM_45 = cUSTOM_45;
	}

	public String getCUSTOM_46() {
		return CUSTOM_46;
	}

	public void setCUSTOM_46(String cUSTOM_46) {
		CUSTOM_46 = cUSTOM_46;
	}

	public String getCUSTOM_47() {
		return CUSTOM_47;
	}

	public void setCUSTOM_47(String cUSTOM_47) {
		CUSTOM_47 = cUSTOM_47;
	}

	public String getCUSTOM_48() {
		return CUSTOM_48;
	}

	public void setCUSTOM_48(String cUSTOM_48) {
		CUSTOM_48 = cUSTOM_48;
	}

	public String getCUSTOM_49() {
		return CUSTOM_49;
	}

	public void setCUSTOM_49(String cUSTOM_49) {
		CUSTOM_49 = cUSTOM_49;
	}

	public String getCUSTOM_50() {
		return CUSTOM_50;
	}

	public void setCUSTOM_50(String cUSTOM_50) {
		CUSTOM_50 = cUSTOM_50;
	}

	public String getCUSTOM_51() {
		return CUSTOM_51;
	}

	public void setCUSTOM_51(String cUSTOM_51) {
		CUSTOM_51 = cUSTOM_51;
	}

	public String getCUSTOM_52() {
		return CUSTOM_52;
	}

	public void setCUSTOM_52(String cUSTOM_52) {
		CUSTOM_52 = cUSTOM_52;
	}

	public String getCUSTOM_53() {
		return CUSTOM_53;
	}

	public void setCUSTOM_53(String cUSTOM_53) {
		CUSTOM_53 = cUSTOM_53;
	}

	public String getCUSTOM_54() {
		return CUSTOM_54;
	}

	public void setCUSTOM_54(String cUSTOM_54) {
		CUSTOM_54 = cUSTOM_54;
	}

	public String getCUSTOM_55() {
		return CUSTOM_55;
	}

	public void setCUSTOM_55(String cUSTOM_55) {
		CUSTOM_55 = cUSTOM_55;
	}

	public String getCUSTOM_56() {
		return CUSTOM_56;
	}

	public void setCUSTOM_56(String cUSTOM_56) {
		CUSTOM_56 = cUSTOM_56;
	}

	public String getCUSTOM_57() {
		return CUSTOM_57;
	}

	public void setCUSTOM_57(String cUSTOM_57) {
		CUSTOM_57 = cUSTOM_57;
	}

	public String getCUSTOM_58() {
		return CUSTOM_58;
	}

	public void setCUSTOM_58(String cUSTOM_58) {
		CUSTOM_58 = cUSTOM_58;
	}

	public String getCUSTOM_59() {
		return CUSTOM_59;
	}

	public void setCUSTOM_59(String cUSTOM_59) {
		CUSTOM_59 = cUSTOM_59;
	}

	public String getCUSTOM_60() {
		return CUSTOM_60;
	}

	public void setCUSTOM_60(String cUSTOM_60) {
		CUSTOM_60 = cUSTOM_60;
	}

	public String getCUSTOM_61() {
		return CUSTOM_61;
	}

	public void setCUSTOM_61(String cUSTOM_61) {
		CUSTOM_61 = cUSTOM_61;
	}

	public String getCUSTOM_62() {
		return CUSTOM_62;
	}

	public void setCUSTOM_62(String cUSTOM_62) {
		CUSTOM_62 = cUSTOM_62;
	}

	public String getCUSTOM_63() {
		return CUSTOM_63;
	}

	public void setCUSTOM_63(String cUSTOM_63) {
		CUSTOM_63 = cUSTOM_63;
	}

	public String getCUSTOM_64() {
		return CUSTOM_64;
	}

	public void setCUSTOM_64(String cUSTOM_64) {
		CUSTOM_64 = cUSTOM_64;
	}

	public String getCUSTOM_65() {
		return CUSTOM_65;
	}

	public void setCUSTOM_65(String cUSTOM_65) {
		CUSTOM_65 = cUSTOM_65;
	}

	public String getCUSTOM_66() {
		return CUSTOM_66;
	}

	public void setCUSTOM_66(String cUSTOM_66) {
		CUSTOM_66 = cUSTOM_66;
	}

	public String getCUSTOM_67() {
		return CUSTOM_67;
	}

	public void setCUSTOM_67(String cUSTOM_67) {
		CUSTOM_67 = cUSTOM_67;
	}

	public String getCUSTOM_68() {
		return CUSTOM_68;
	}

	public void setCUSTOM_68(String cUSTOM_68) {
		CUSTOM_68 = cUSTOM_68;
	}

	public String getCUSTOM_69() {
		return CUSTOM_69;
	}

	public void setCUSTOM_69(String cUSTOM_69) {
		CUSTOM_69 = cUSTOM_69;
	}

	public String getCUSTOM_70() {
		return CUSTOM_70;
	}

	public void setCUSTOM_70(String cUSTOM_70) {
		CUSTOM_70 = cUSTOM_70;
	}

	public String getCUSTOM_71() {
		return CUSTOM_71;
	}

	public void setCUSTOM_71(String cUSTOM_71) {
		CUSTOM_71 = cUSTOM_71;
	}

	public String getCUSTOM_72() {
		return CUSTOM_72;
	}

	public void setCUSTOM_72(String cUSTOM_72) {
		CUSTOM_72 = cUSTOM_72;
	}

	public String getCUSTOM_73() {
		return CUSTOM_73;
	}

	public void setCUSTOM_73(String cUSTOM_73) {
		CUSTOM_73 = cUSTOM_73;
	}

	public String getCUSTOM_74() {
		return CUSTOM_74;
	}

	public void setCUSTOM_74(String cUSTOM_74) {
		CUSTOM_74 = cUSTOM_74;
	}

	public String getCUSTOM_75() {
		return CUSTOM_75;
	}

	public void setCUSTOM_75(String cUSTOM_75) {
		CUSTOM_75 = cUSTOM_75;
	}

	public String getCUSTOM_76() {
		return CUSTOM_76;
	}

	public void setCUSTOM_76(String cUSTOM_76) {
		CUSTOM_76 = cUSTOM_76;
	}

	public String getCUSTOM_77() {
		return CUSTOM_77;
	}

	public void setCUSTOM_77(String cUSTOM_77) {
		CUSTOM_77 = cUSTOM_77;
	}

	public String getCUSTOM_78() {
		return CUSTOM_78;
	}

	public void setCUSTOM_78(String cUSTOM_78) {
		CUSTOM_78 = cUSTOM_78;
	}

	public String getCUSTOM_79() {
		return CUSTOM_79;
	}

	public void setCUSTOM_79(String cUSTOM_79) {
		CUSTOM_79 = cUSTOM_79;
	}

	public String getCUSTOM_80() {
		return CUSTOM_80;
	}

	public void setCUSTOM_80(String cUSTOM_80) {
		CUSTOM_80 = cUSTOM_80;
	}

	public String getCUSTOM_81() {
		return CUSTOM_81;
	}

	public void setCUSTOM_81(String cUSTOM_81) {
		CUSTOM_81 = cUSTOM_81;
	}

	public String getCUSTOM_82() {
		return CUSTOM_82;
	}

	public void setCUSTOM_82(String cUSTOM_82) {
		CUSTOM_82 = cUSTOM_82;
	}

	public String getCUSTOM_83() {
		return CUSTOM_83;
	}

	public void setCUSTOM_83(String cUSTOM_83) {
		CUSTOM_83 = cUSTOM_83;
	}

	public String getCUSTOM_84() {
		return CUSTOM_84;
	}

	public void setCUSTOM_84(String cUSTOM_84) {
		CUSTOM_84 = cUSTOM_84;
	}

	public String getCUSTOM_85() {
		return CUSTOM_85;
	}

	public void setCUSTOM_85(String cUSTOM_85) {
		CUSTOM_85 = cUSTOM_85;
	}

	public String getCUSTOM_86() {
		return CUSTOM_86;
	}

	public void setCUSTOM_86(String cUSTOM_86) {
		CUSTOM_86 = cUSTOM_86;
	}

	public String getCUSTOM_87() {
		return CUSTOM_87;
	}

	public void setCUSTOM_87(String cUSTOM_87) {
		CUSTOM_87 = cUSTOM_87;
	}

	public String getCUSTOM_88() {
		return CUSTOM_88;
	}

	public void setCUSTOM_88(String cUSTOM_88) {
		CUSTOM_88 = cUSTOM_88;
	}

	public String getCUSTOM_89() {
		return CUSTOM_89;
	}

	public void setCUSTOM_89(String cUSTOM_89) {
		CUSTOM_89 = cUSTOM_89;
	}

	public String getCUSTOM_90() {
		return CUSTOM_90;
	}

	public void setCUSTOM_90(String cUSTOM_90) {
		CUSTOM_90 = cUSTOM_90;
	}

	public String getCUSTOM_91() {
		return CUSTOM_91;
	}

	public void setCUSTOM_91(String cUSTOM_91) {
		CUSTOM_91 = cUSTOM_91;
	}

	public String getCUSTOM_92() {
		return CUSTOM_92;
	}

	public void setCUSTOM_92(String cUSTOM_92) {
		CUSTOM_92 = cUSTOM_92;
	}

	public String getCUSTOM_93() {
		return CUSTOM_93;
	}

	public void setCUSTOM_93(String cUSTOM_93) {
		CUSTOM_93 = cUSTOM_93;
	}

	public String getCUSTOM_94() {
		return CUSTOM_94;
	}

	public void setCUSTOM_94(String cUSTOM_94) {
		CUSTOM_94 = cUSTOM_94;
	}

	public String getCUSTOM_95() {
		return CUSTOM_95;
	}

	public void setCUSTOM_95(String cUSTOM_95) {
		CUSTOM_95 = cUSTOM_95;
	}

	public String getCUSTOM_96() {
		return CUSTOM_96;
	}

	public void setCUSTOM_96(String cUSTOM_96) {
		CUSTOM_96 = cUSTOM_96;
	}

	public String getCUSTOM_97() {
		return CUSTOM_97;
	}

	public void setCUSTOM_97(String cUSTOM_97) {
		CUSTOM_97 = cUSTOM_97;
	}

	public String getCUSTOM_98() {
		return CUSTOM_98;
	}

	public void setCUSTOM_98(String cUSTOM_98) {
		CUSTOM_98 = cUSTOM_98;
	}

	public String getCUSTOM_99() {
		return CUSTOM_99;
	}

	public void setCUSTOM_99(String cUSTOM_99) {
		CUSTOM_99 = cUSTOM_99;
	}

	public String getCUSTOM_100() {
		return CUSTOM_100;
	}

	public void setCUSTOM_100(String cUSTOM_100) {
		CUSTOM_100 = cUSTOM_100;
	}
	
	

	public String getROUTE_DECISION() {
    return ROUTE_DECISION;
  }

  public void setROUTE_DECISION(String rOUTE_DECISION) {
    ROUTE_DECISION = rOUTE_DECISION;
  }
  
  public String getGO_BACK_TO_UW() {
    return GO_BACK_TO_UW;
  }

  public void setGO_BACK_TO_UW(String gO_BACK_TO_UW) {
    GO_BACK_TO_UW = gO_BACK_TO_UW;
  }

  public String getROUTE_BACK_TO_UW() {
    return ROUTE_BACK_TO_UW;
  }

  public void setROUTE_BACK_TO_UW(String rOUTE_BACK_TO_UW) {
    ROUTE_BACK_TO_UW = rOUTE_BACK_TO_UW;
  }

  public String getROUTING_DECISION() {
    return ROUTING_DECISION;
  }

  public void setROUTING_DECISION(String rOUTING_DECISION) {
    ROUTING_DECISION = rOUTING_DECISION;
  }

  public String getROUNT_DECISION_ADLR() {
    return ROUNT_DECISION_ADLR;
  }

  public void setROUNT_DECISION_ADLR(String rOUNT_DECISION_ADLR) {
    ROUNT_DECISION_ADLR = rOUNT_DECISION_ADLR;
  }

  public String getROUNT_DECISION_ADLR_OSS() {
    return ROUNT_DECISION_ADLR_OSS;
  }

  public void setROUNT_DECISION_ADLR_OSS(String rOUNT_DECISION_ADLR_OSS) {
    ROUNT_DECISION_ADLR_OSS = rOUNT_DECISION_ADLR_OSS;
  }

  public String getREUW_DCS_POS_OSS() {
    return REUW_DCS_POS_OSS;
  }

  public void setREUW_DCS_POS_OSS(String rEUW_DCS_POS_OSS) {
    REUW_DCS_POS_OSS = rEUW_DCS_POS_OSS;
  }
  
  public String getSM_CHANNEL() {
    return SM_CHANNEL;
  }

  public void setSM_CHANNEL(String sM_CHANNEL) {
    SM_CHANNEL = sM_CHANNEL;
  }
    
  public String getSEND_TO_UW() {
    return SEND_TO_UW;
  }

  public void setSEND_TO_UW(String sEND_TO_UW) {
    SEND_TO_UW = sEND_TO_UW;
  }
  
  

  public String getSEEK_DOCTOR() {
	return SEEK_DOCTOR;
}

public void setSEEK_DOCTOR(String sEEK_DOCTOR) {
	SEEK_DOCTOR = sEEK_DOCTOR;
}

public String getNEED_APPROVAL() {
	return NEED_APPROVAL;
}

public void setNEED_APPROVAL(String nEED_APPROVAL) {
	NEED_APPROVAL = nEED_APPROVAL;
}



public String getPENIDNG_CPF_OUT() {
	return PENIDNG_CPF_OUT;
}

public void setPENIDNG_CPF_OUT(String pENIDNG_CPF_OUT) {
	PENIDNG_CPF_OUT = pENIDNG_CPF_OUT;
}

public String getSTATUS_AND_FAIL_REASON() {
	return STATUS_AND_FAIL_REASON;
}

public void setSTATUS_AND_FAIL_REASON(String sTATUS_AND_FAIL_REASON) {
	STATUS_AND_FAIL_REASON = sTATUS_AND_FAIL_REASON;
}

public String getCLM_STATUS_IL() {
	return CLM_STATUS_IL;
}

public void setCLM_STATUS_IL(String cLM_STATUS_IL) {
	CLM_STATUS_IL = cLM_STATUS_IL;
}


public String getPEND_TYPE() {
	return PEND_TYPE;
}

public void setPEND_TYPE(String pEND_TYPE) {
	PEND_TYPE = pEND_TYPE;
}

public String getMR_REPORT() {
	return MR_REPORT;
}

public void setMR_REPORT(String mR_REPORT) {
	MR_REPORT = mR_REPORT;
}

public String getHIG_APPROVAL() {
	return HIG_APPROVAL;
}

public void setHIG_APPROVAL(String hIG_APPROVAL) {
	HIG_APPROVAL = hIG_APPROVAL;
}

public String getPEND_OUTSTAND() {
	return PEND_OUTSTAND;
}

public void setPEND_OUTSTAND(String pEND_OUTSTAND) {
	PEND_OUTSTAND = pEND_OUTSTAND;
}

public String getMEDICAL_ADJ() {
	return MEDICAL_ADJ;
}

public void setMEDICAL_ADJ(String mEDICAL_ADJ) {
	MEDICAL_ADJ = mEDICAL_ADJ;
}

public String getPREPARE_LETTER() {
	return PREPARE_LETTER;
}

public void setPREPARE_LETTER(String pREPARE_LETTER) {
	PREPARE_LETTER = pREPARE_LETTER;
}

public String getTRAINER_REJECT_RS() {
	return TRAINER_REJECT_RS;
}

public void setTRAINER_REJECT_RS(String tRAINER_REJECT_RS) {
	TRAINER_REJECT_RS = tRAINER_REJECT_RS;
}

public String getTRAINER_DC() {
	return TRAINER_DC;
}

public void setTRAINER_DC(String tRAINER_DC) {
	TRAINER_DC = tRAINER_DC;
}

public String getHIG_REJECT_RS() {
	return HIG_REJECT_RS;
}

public void setHIG_REJECT_RS(String hIG_REJECT_RS) {
	HIG_REJECT_RS = hIG_REJECT_RS;
}

public String getROUTE_BACK_TRAINEE() {
	return ROUTE_BACK_TRAINEE;
}

public void setROUTE_BACK_TRAINEE(String rOUTE_BACK_TRAINEE) {
	ROUTE_BACK_TRAINEE = rOUTE_BACK_TRAINEE;
}

public String getROUTE_PEND_RW() {
	return ROUTE_PEND_RW;
}

public void setROUTE_PEND_RW(String rOUTE_PEND_RW) {
	ROUTE_PEND_RW = rOUTE_PEND_RW;
}

public String getROUTE_BACK_AS() {
	return ROUTE_BACK_AS;
}

public void setROUTE_BACK_AS(String rOUTE_BACK_AS) {
	ROUTE_BACK_AS = rOUTE_BACK_AS;
}

public String getPEND_CPFADV() {
	return PEND_CPFADV;
}

public void setPEND_CPFADV(String pEND_CPFADV) {
	PEND_CPFADV = pEND_CPFADV;
}

public String getASSESSOR_ID() {
	return ASSESSOR_ID;
}

public void setASSESSOR_ID(String aSSESSOR_ID) {
	ASSESSOR_ID = aSSESSOR_ID;
}

public String getHIG_APPROVAL_DC() {
	return HIG_APPROVAL_DC;
}

public String getCLM_COURT() {
	return CLM_COURT;
}

public String getCNC_DEC() {
	return CNC_DEC;
}

public void setCNC_DEC(String cNC_DEC) {
	CNC_DEC = cNC_DEC;
}

public void setCLM_COURT(String cLM_COURT) {
	CLM_COURT = cLM_COURT;
}

public void setHIG_APPROVAL_DC(String hIG_APPROVAL_DC) {
	HIG_APPROVAL_DC = hIG_APPROVAL_DC;
}

public String getNEED_HIG_APPROVAL() {
	return NEED_HIG_APPROVAL;
}

public void setNEED_HIG_APPROVAL(String nEED_HIG_APPROVAL) {
	NEED_HIG_APPROVAL = nEED_HIG_APPROVAL;
}

public String getCLM_46() {
	return CLM_46;
}

public void setCLM_46(String cLM_46) {
	CLM_46 = cLM_46;
}

public String getCLM_47() {
	return CLM_47;
}

public void setCLM_47(String cLM_47) {
	CLM_47 = cLM_47;
}

public String getNEED_MEDICAL_ADJ() {
	return NEED_MEDICAL_ADJ;
}

public void setNEED_MEDICAL_ADJ(String nEED_MEDICAL_ADJ) {
	NEED_MEDICAL_ADJ = nEED_MEDICAL_ADJ;
}

public String getNEED_MR_RPT() {
	return NEED_MR_RPT;
}

public void setNEED_MR_RPT(String nEED_MR_RPT) {
	NEED_MR_RPT = nEED_MR_RPT;
}

public String getNEED_ROUTE_TECH_TM() {
	return NEED_ROUTE_TECH_TM;
}

public void setNEED_ROUTE_TECH_TM(String nEED_ROUTE_TECH_TM) {
	NEED_ROUTE_TECH_TM = nEED_ROUTE_TECH_TM;
}

public String getNEED_CHEQUE_AND_LETTER() {
	return NEED_CHEQUE_AND_LETTER;
}

public void setNEED_CHEQUE_AND_LETTER(String nEED_CHEQUE_AND_LETTER) {
	NEED_CHEQUE_AND_LETTER = nEED_CHEQUE_AND_LETTER;
}

public String getBACK_TO_TRAINEE() {
	return BACK_TO_TRAINEE;
}

public void setBACK_TO_TRAINEE(String bACK_TO_TRAINEE) {
	BACK_TO_TRAINEE = bACK_TO_TRAINEE;
}

public String getAPPROVAL_DC_PL() {
	return APPROVAL_DC_PL;
}

public void setAPPROVAL_DC_PL(String aPPROVAL_DC_PL) {
	APPROVAL_DC_PL = aPPROVAL_DC_PL;
}

public String getHI_APPROVAL_DC_PL() {
	return HI_APPROVAL_DC_PL;
}

public void setHI_APPROVAL_DC_PL(String hI_APPROVAL_DC_PL) {
	HI_APPROVAL_DC_PL = hI_APPROVAL_DC_PL;
}

public String getCREATE_CHILD_CASE() {
	return CREATE_CHILD_CASE;
}

public void setCREATE_CHILD_CASE(String cREATE_CHILD_CASE) {
	CREATE_CHILD_CASE = cREATE_CHILD_CASE;
}

public String getRETURN_TO_TRAINEE() {
	return RETURN_TO_TRAINEE;
}

public void setRETURN_TO_TRAINEE(String rETURN_TO_TRAINEE) {
	RETURN_TO_TRAINEE = rETURN_TO_TRAINEE;
}

public String getAPPROVAL_DC() {
	return APPROVAL_DC;
}

public void setAPPROVAL_DC(String aPPROVAL_DC) {
	APPROVAL_DC = aPPROVAL_DC;
}

public String getREJECT_REASON() {
	return REJECT_REASON;
}

public void setREJECT_REASON(String rEJECT_REASON) {
	REJECT_REASON = rEJECT_REASON;
}

public String getPENDING_ASSESSOR_REVI_TM() {
	return PENDING_ASSESSOR_REVI_TM;
}

public void setPENDING_ASSESSOR_REVI_TM(String pENDING_ASSESSOR_REVI_TM) {
	PENDING_ASSESSOR_REVI_TM = pENDING_ASSESSOR_REVI_TM;
}

@Override
	public String toString() {
		return "RuleStep [AC_DECISION=" + AC_DECISION + ", ACRA_CHECKING=" + ACRA_CHECKING + ", ACTIVITY_LIST="
				+ ACTIVITY_LIST + ", CALL_CENTRE_CLOSE_REASON=" + CALL_CENTRE_CLOSE_REASON + ", CALL_CENTRE_DECISION="
				+ CALL_CENTRE_DECISION + ", CLAIM_APPROVAL=" + CLAIM_APPROVAL + ", CLOSE_REASON=" + CLOSE_REASON
				+ ", MANUAL_LETTER=" + MANUAL_LETTER + ", MLNS=" + MLNS + ", NEED_PREPARE_MANUAL_LETTER="
				+ NEED_PREPARE_MANUAL_LETTER + ", OUTRIGHT_REJECT=" + OUTRIGHT_REJECT + ", REJECT=" + REJECT
				+ ", REQUEST_PLAS_TEAM_PROCESS=" + REQUEST_PLAS_TEAM_PROCESS + ", USER_LIST=" + USER_LIST + "]";
	}

	public String toTxt() {

		return "		RuleStep(\"" + RuleEnum.RULESTEP_AC_DECISION + TXTSTRING + getAC_DECISION() + "\"," + "\""
				+ RuleEnum.RULESTEP_ACRA_CHECKING + TXTSTRING +  getACRA_CHECKING() + "\"," + "\""
				+ RuleEnum.RULESTEP_ACTIVITY_LIST + TXTSTRING +  getACTIVITY_LIST() + "\"," + "\""
				+ RuleEnum.RULESTEP_CALL_CENTRE_CLOSE_REASON + TXTSTRING +  getCALL_CENTRE_CLOSE_REASON() + "\","
				+ "\"" + RuleEnum.RULESTEP_CALL_CENTRE_DECISION + TXTSTRING +  getCALL_CENTRE_DECISION() + "\","
				+ "\"" + RuleEnum.RULESTEP_CLAIM_APPROVAL + TXTSTRING +  getCLAIM_APPROVAL() + "\"," + "\""
				+ RuleEnum.RULESTEP_CLOSE_REASON + TXTSTRING +  getCLOSE_REASON() + "\"," + "\""
				+ RuleEnum.RULESTEP_MANUAL_LETTER + TXTSTRING +  getMANUAL_LETTER() + "\"," + "\""
				+ RuleEnum.RULESTEP_MLNS + TXTSTRING +  getMLNS() + "\"," + "\""
				+ RuleEnum.RULESTEP_NEED_PREPARE_MANUAL_LETTER + TXTSTRING +  getNEED_PREPARE_MANUAL_LETTER()
				+ "\"," + "\"" + RuleEnum.RULESTEP_OUTRIGHT_REJECT + TXTSTRING +  getOUTRIGHT_REJECT() + "\","
				+ "\"" + RuleEnum.RULESTEP_REJECT + TXTSTRING +  getREJECT() + "\"," + "\""
				+ RuleEnum.RULESTEP_REQUEST_PLAS_TEAM_PROCESS + TXTSTRING +  getREQUEST_PLAS_TEAM_PROCESS() + "\","
				+ "\"" + RuleEnum.RULESTEP_USER_LIST + TXTSTRING +  getUSER_LIST() + "\"" + ")";
	}

}
