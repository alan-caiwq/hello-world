package com.aia.case360.web.pojo;

/**
 * 
 * @author
 * 
 */

public class Address {

	private String clientNum;

	private String cltAddr01;

	private String cltAddr02;

	private String cltAddr03;

	private String cltAddr04;

	private String cltAddr05;

	private String postCode;
	private String ctryCode;

	private String c2Owctry;
	
	private String clientType;
	
	public String getClientType() {
		return clientType;
	}

	public void setClientType(String clientType) {
		this.clientType = clientType;
	}



	public String getClientNum() {
		return clientNum;
	}



	public void setClientNum(String clientNum) {
		this.clientNum = clientNum;
	}

	public String getCltAddr01() {
		return cltAddr01;
	}

	public void setCltAddr01(String cltAddr01) {
		this.cltAddr01 = cltAddr01;
	}

	public String getCltAddr02() {
		return cltAddr02;
	}

	public void setCltAddr02(String cltAddr02) {
		this.cltAddr02 = cltAddr02;
	}

	public String getCltAddr03() {
		return cltAddr03;
	}

	public void setCltAddr03(String cltAddr03) {
		this.cltAddr03 = cltAddr03;
	}

	public String getCltAddr04() {
		return cltAddr04;
	}

	public void setCltAddr04(String cltAddr04) {
		this.cltAddr04 = cltAddr04;
	}

	public String getCltAddr05() {
		return cltAddr05;
	}

	public void setCltAddr05(String cltAddr05) {
		this.cltAddr05 = cltAddr05;
	}

	public String getPostCode() {
		return postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public String getCtryCode() {
		return ctryCode;
	}

	public void setCtryCode(String ctryCode) {
		this.ctryCode = ctryCode;
	}

	public String getC2Owctry() {
		return c2Owctry;
	}

	public void setC2Owctry(String c2Owctry) {
		this.c2Owctry = c2Owctry;
	}
	@Override
	public String toString() {
		return "Address [clientNum=" + clientNum + ", cltAddr01=" + cltAddr01 + ", cltAddr02=" + cltAddr02
				+ ", cltAddr03=" + cltAddr03 + ", cltAddr04=" + cltAddr04 + ", cltAddr05=" + cltAddr05 + ", postCode="
				+ postCode + ", ctryCode=" + ctryCode + ", c2Owctry=" + c2Owctry + ", clientType=" + clientType + "]";
	}

}
