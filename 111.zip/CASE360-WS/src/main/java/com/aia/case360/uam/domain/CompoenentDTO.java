package com.aia.case360.uam.domain;

import java.math.BigDecimal;

public class CompoenentDTO {

	public enum fieldNames {
		UAM_COMPONENT_ID, UAM_COMPONENT_NAME, UAM_COMPONENT_PARENTID, UAM_COMPONENT_TYPE
	};

	private BigDecimal componentId;
	private String componentName;
	private BigDecimal componentParentId;
	private String componentType;

	public BigDecimal getComponentId() {
		return componentId;
	}

	public String getComponentName() {
		return componentName;
	}

	public BigDecimal getComponentParentId() {
		return componentParentId;
	}

	public String getComponentType() {
		return componentType;
	}

	public void setComponentId(BigDecimal componentId) {
		this.componentId = componentId;
	}

	public void setComponentName(String componentName) {
		this.componentName = componentName;
	}

	public void setComponentParentId(BigDecimal componentParentId) {
		this.componentParentId = componentParentId;
	}

	public void setComponentType(String componentType) {
		this.componentType = componentType;
	}

}
