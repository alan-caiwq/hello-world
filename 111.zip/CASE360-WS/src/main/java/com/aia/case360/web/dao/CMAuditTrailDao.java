package com.aia.case360.web.dao;

import java.sql.SQLException;
import java.util.List;

import com.aia.case360.web.pojo.CMAddAuditTrailParam;
import com.aia.case360.web.pojo.CMGetAuditTrailParam;
import com.aia.case360.web.vo.CMGetAuditTrailVo;

public interface CMAuditTrailDao {

  List<CMGetAuditTrailVo> getAuditTrail(CMGetAuditTrailParam param) throws SQLException;

  Boolean addAuditTrail(CMAddAuditTrailParam param) throws SQLException;
}
