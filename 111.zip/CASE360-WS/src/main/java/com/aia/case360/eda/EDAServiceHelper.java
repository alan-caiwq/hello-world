package com.aia.case360.eda;

import org.springframework.beans.factory.ObjectFactory;
import org.springframework.stereotype.Service;

import com.aia.case360.eda.service.EdaDocService;
import com.aia.case360.eda.service.impl.EdaDocServiceImpl;
import com.aia.case360.platform.common.PropertyUtil;

@Service
public class EDAServiceHelper {

	private ObjectFactory<EdaDocServiceImpl> edaDocServiceBeanFactory;

	private int curEdaDocServiceIndex = 0;
	private final int EDASERVICESNUM = 10;
	private EdaDocServiceImpl[] edaServices = null;

	

	public  EdaDocService getEdaDocService() throws InterruptedException {
			synchronized (EDAServiceHelper.class) {
				if (edaServices == null) {
					String edaQueryNames = PropertyUtil.getCommonProperty("EDA_QUERY_NAMES");
					if(edaQueryNames == null || edaQueryNames.trim().length()<1){
						return edaDocServiceBeanFactory
								.getObject();
					}
				
					edaServices = new EdaDocServiceImpl[EDASERVICESNUM];
					for (int i = 0; i < EDASERVICESNUM; i++) {
						EdaDocServiceImpl o = edaDocServiceBeanFactory
								.getObject();
						edaServices[i] = o;
					}
				}
		}
		if (curEdaDocServiceIndex >= EDASERVICESNUM) {
			curEdaDocServiceIndex = curEdaDocServiceIndex % EDASERVICESNUM;
		}
		EdaDocService currEdaDocService = edaServices[curEdaDocServiceIndex++];

		return currEdaDocService;
	}

	public ObjectFactory<EdaDocServiceImpl> getEdaDocServiceBeanFactory() {
		return edaDocServiceBeanFactory;
	}

	public void setEdaDocServiceBeanFactory(
			ObjectFactory<EdaDocServiceImpl> edaDocServiceBeanFactory) {
		this.edaDocServiceBeanFactory = edaDocServiceBeanFactory;
	}

}
