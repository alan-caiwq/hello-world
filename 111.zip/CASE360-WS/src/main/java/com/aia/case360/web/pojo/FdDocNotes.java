package com.aia.case360.web.pojo;

import java.math.BigDecimal;

public class FdDocNotes {
	private String acl;
	private String comments;
	private String createdBy;
	private String createdTimestamp;
	private String docNoteSecurityLevel;
	private int isConfidential;
	private String objectId;
	private BigDecimal sRowId;
	private String formId;
	private int isVoid;
	private String canceledBy;
	private String canceledTimestamp;

	public String getAcl() {
		return acl;
	}

	public void setAcl(String acl) {
		this.acl = acl;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(String createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public String getDocNoteSecurityLevel() {
		return docNoteSecurityLevel;
	}

	public void setDocNoteSecurityLevel(String docNoteSecurityLevel) {
		this.docNoteSecurityLevel = docNoteSecurityLevel;
	}

	public int getIsConfidential() {
		return isConfidential;
	}

	public void setIsConfidential(int isConfidential) {
		this.isConfidential = isConfidential;
	}

	public String getObjectId() {
		return objectId;
	}

	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}

	public BigDecimal getsRowId() {
		return sRowId;
	}

	public void setsRowId(BigDecimal sRowId) {
		this.sRowId = sRowId;
	}

	public String getFormId() {
		return formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}

	public int getIsVoid() {
		return isVoid;
	}

	public void setIsVoid(int isVoid) {
		this.isVoid = isVoid;
	}

	public String getCanceledBy() {
		return canceledBy;
	}

	public void setCanceledBy(String canceledBy) {
		this.canceledBy = canceledBy;
	}

	public String getCanceledTimestamp() {
		return canceledTimestamp;
	}

	public void setCanceledTimestamp(String canceledTimestamp) {
		this.canceledTimestamp = canceledTimestamp;
	}

}
