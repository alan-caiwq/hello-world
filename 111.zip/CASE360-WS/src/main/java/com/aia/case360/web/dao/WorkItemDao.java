package com.aia.case360.web.dao;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.aia.case360.web.pojo.FdCaseCheckListVO;
import com.aia.case360.web.pojo.GetPolicyInfoDetailsInfo;

@Repository
public interface WorkItemDao {

	public void updateCheckList(List<FdCaseCheckListVO> listCheckList);

	public Integer updatePiWork(Map<String, String> params)  throws RemoteException;

	public Integer updateFdPolicySource(@Param("policy") String policy, @Param("source") String source);

	public String getPendReasonRowId(@Param("caseId") String caseId, @Param("objId") String objId);

	public Map<String, String> getCaseReqtypeGrpAndWorkstepName(@Param("caseId") String caseId);

	public int getActivePendingReasonCount(@Param("caseId") String caseId);

	public void updatePolData(@Param("policyInfoList") List<GetPolicyInfoDetailsInfo> policyInfoList, @Param("userId") String userId);

	public List<String> getAutoPendingReasonRowid(@Param("caseId")  String caseId);
	
}
