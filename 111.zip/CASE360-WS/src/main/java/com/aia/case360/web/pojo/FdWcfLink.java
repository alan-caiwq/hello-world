package com.aia.case360.web.pojo;

public class FdWcfLink {

	private String clmNum;
	private String mclmNum;
	private String polNum;
	private String requestNum;
	private int sRowId;
	private int linkcaseid;
	private String companyNo;
	private int dummyPolicyFlag;
	private int isDeleted;
	private String childClaimNo;

	public String getChildClaimNo() {
		return childClaimNo;
	}

	public void setChildClaimNo(String childClaimNo) {
		this.childClaimNo = childClaimNo;
	}

	public String getClmNum() {
		return clmNum;
	}

	public void setClmNum(String clmNum) {
		this.clmNum = clmNum;
	}

	public String getMclmNum() {
		return mclmNum;
	}

	public void setMclmNum(String mclmNum) {
		this.mclmNum = mclmNum;
	}

	public String getPolNum() {
		return polNum;
	}

	public void setPolNum(String polNum) {
		this.polNum = polNum;
	}

	public String getRequestNum() {
		return requestNum;
	}

	public void setRequestNum(String requestNum) {
		this.requestNum = requestNum;
	}

	public int getsRowId() {
		return sRowId;
	}

	public void setsRowId(int sRowId) {
		this.sRowId = sRowId;
	}

	public int getLinkcaseid() {
		return linkcaseid;
	}

	public void setLinkcaseid(int linkcaseid) {
		this.linkcaseid = linkcaseid;
	}

	public String getCompanyNo() {
		return companyNo;
	}

	public void setCompanyNo(String companyNo) {
		this.companyNo = companyNo;
	}

	public int getDummyPolicyFlag() {
		return dummyPolicyFlag;
	}

	public void setDummyPolicyFlag(int dummyPolicyFlag) {
		this.dummyPolicyFlag = dummyPolicyFlag;
	}

	public int getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(int isDeleted) {
		this.isDeleted = isDeleted;
	}

}
