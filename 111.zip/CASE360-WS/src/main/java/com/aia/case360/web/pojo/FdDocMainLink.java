package com.aia.case360.web.pojo;

public class FdDocMainLink {
	private String mainlinkFormId;
	private String objectId;
	private String nric;
	private String caseId;
	private String receivedDate;
	private String policyNo;
	private String requestNo;
	private String processType;
	private String companyNo;
	private String isLogical;
	
	public FdDocMainLink(String mainlinkFormId, String objectId, String policyNo,
			String requestNo, String processType, String caseId, String receivedDate) {
		super();
		this.mainlinkFormId = mainlinkFormId;
		this.objectId = objectId;
		this.policyNo = policyNo;
		this.requestNo = requestNo;
		this.processType = processType;
		this.caseId = caseId;
		this.receivedDate = receivedDate;
	}

	public FdDocMainLink(String mainlinkFormId, String objectId, String nric) {
	      super();
	      this.mainlinkFormId = mainlinkFormId;
	      this.objectId = objectId;
	      this.nric = nric;
	    }
		
		public FdDocMainLink(String mainlinkFormId, String objectId, String nric , String caseId, String receivedDate) {
			super();
			this.mainlinkFormId = mainlinkFormId;
			this.objectId = objectId;
			this.nric = nric;
			this.caseId = caseId;
			this.receivedDate = receivedDate;
		}
		
		public FdDocMainLink(String mainlinkFormId, String objectId, String nric , String receivedDate) {
	      super();
	      this.mainlinkFormId = mainlinkFormId;
	      this.objectId = objectId;
	      this.nric = nric;
	      this.receivedDate = receivedDate;
	    }
	
	
	public FdDocMainLink() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getmainlinkFormId() {
		return mainlinkFormId;
	}
	public void setmainlinkFormId(String mainlinkFormId) {
		this.mainlinkFormId = mainlinkFormId;
	}
	public String getObjectId() {
		return objectId;
	}
	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}
	public String getNric() {
		return nric;
	}
	public void setNric(String nric) {
		this.nric = nric;
	}
	public String getCaseId() {
		return caseId;
	}
	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}
	public String getReceivedDate() {
		return receivedDate;
	}
	public void setReceivedDate(String receivedDate) {
		this.receivedDate = receivedDate;
	}
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getRequestNo() {
		return requestNo;
	}
	public void setRequestNo(String requestNo) {
		this.requestNo = requestNo;
	}
	public String getProcessType() {
		return processType;
	}
	public void setProcessType(String processType) {
		this.processType = processType;
	}
	public String getCompanyNo() {
		return companyNo;
	}
	public void setCompanyNo(String companyNo) {
		this.companyNo = companyNo;
	}
	public String getIsLogical() {
		return isLogical;
	}
	public void setIsLogical(String isLogical) {
		this.isLogical = isLogical;
	}
	@Override
	public String toString() {
		return "FdDocMainLink [mainlinkFormId=" + mainlinkFormId
				+ ", objectId=" + objectId + ", nric=" + nric + ", caseId="
				+ caseId + ", receivedDate=" + receivedDate + ", policyNo="
				+ policyNo + ", requestNo=" + requestNo + ", processType="
				+ processType + ", companyNo=" + companyNo + ", isLogical="
				+ isLogical + "]";
	}
	
	
}
