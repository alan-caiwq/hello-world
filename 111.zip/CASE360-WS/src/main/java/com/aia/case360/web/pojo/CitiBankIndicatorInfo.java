package com.aia.case360.web.pojo;

public class CitiBankIndicatorInfo {
	private String citiBank;
	private String longDesc;

	public String getCitiBank() {
		return citiBank;
	}

	public void setCitiBank(String citiBank) {
		this.citiBank = citiBank;
	}

	public String getLongDesc() {
		return longDesc;
	}

	public void setLongDesc(String longDesc) {
		this.longDesc = longDesc;
	}

}
