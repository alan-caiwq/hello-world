package com.aia.case360.web.pojo;

public class CPFaccountNoInfo {

	private String cpfAccountNo;

	private String policyNo;

	private String claimNo;

	public String getCpfAccountNo() {
		return cpfAccountNo;
	}

	public void setCpfAccountNo(String cpfAccountNo) {
		this.cpfAccountNo = cpfAccountNo;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

}
