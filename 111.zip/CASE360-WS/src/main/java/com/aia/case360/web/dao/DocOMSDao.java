package com.aia.case360.web.dao;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.aia.case360.web.pojo.DocListDetailsInfo;
import com.aia.case360.web.pojo.DocListParameter;
import com.aia.case360.web.pojo.DocOMSDetailsInfo;
import com.aia.case360.web.pojo.DocOMSParameter;

@Repository
public interface DocOMSDao {

	// Get document by object ID by OMS
	public List<DocOMSDetailsInfo> queryDocumentByIDOMS(DocOMSParameter params)  throws RemoteException;

	// Get Document list by OMS
	// Get document by object ID
	public List<DocOMSDetailsInfo> queryDocumentByID(DocOMSParameter params)  throws RemoteException;

	// Get Document list
	public List<DocListDetailsInfo> queryDocumentList(DocListParameter params)  throws RemoteException;

	// Check ObjectID existed in edoc_Inbox or not
	public List<String> checkObjectIDEdoc(DocListParameter params)  throws RemoteException;

	public List<DocOMSDetailsInfo> getDocumentsByID(String documentId)  throws RemoteException;

	// Get object_name by object ID. add by wanjun
	public Map<String, Object> getObjectNameByID(String objectId)  throws RemoteException;
}
