package com.aia.case360.common;

import org.apache.commons.lang.StringUtils;

/***
 * 
 * @author ASNPHEC
 *
 */
public enum SystemNameEnum {

	CUST_EDOC("ECare", "1"), FSC_COPY("eCabinet", "FSC Copy overlay with blank image"),
	FSC_COPY_OVERLAY("eDoc", "FSC Copy overlay with blank image");

	private String code, name;

	public static String getSystemName(String code) {
		if (StringUtils.isNotBlank(code)) {
			for (SystemNameEnum c : SystemNameEnum.values()) {
				if (c.getCode().equals(code)) {
					return c.getName();
				}
			}
		}
		return "";
	}

	SystemNameEnum(String code, String name) {
		 this.code = code;
		 this.name = name;
	}

	public String getCode() {
		return code;
	}
   public String getName() {
		return name;
	}

}
