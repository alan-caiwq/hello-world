package com.aia.case360.web.dao;

import java.rmi.RemoteException;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.aia.case360.web.vo.OWSAuditTrail;

public interface OWSAuditTrailDao {

	public boolean insertAuditTrail(OWSAuditTrail auditTrail)  throws RemoteException;

  public List<OWSAuditTrail> searchAuditTrail(@Param("requestNumber") String requestNumber,
    @Param("policyNumbers") List<String> policyNumbers, 
    @Param("owsClaimNumber") String claimNumber, 
    @Param("owsCompanyCode") String companyCode, 
    @Param("searchType") String searchType)  throws RemoteException;

}
