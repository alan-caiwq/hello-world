package com.aia.case360.platform.casefolder;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

/**
 * Wrap discussion API for web service calling
 * 
 * @author bsnpbdu
 *
 */
public interface DiscussionHelper {

	/**
	 * Add a discussion based on one Discussion which maybe a topic or a normal
	 * discussion.
	 * 
	 * @param caseId             The case Id
	 * @param parentDiscussionId The parent discussion Id
	 * @param contents           The discussion content
	 * @return The discussion list for the caseId
	 * @throws RemoteException
	 */
	public void addDiscussionContent(String caseId, String discussionName, String contents, String userName)
			throws RemoteException;

	/**
	 * Return all discussions items for the caseId, including topic items. When
	 * display the list, the UI should organize the list as a tree based on the
	 * ParentId
	 * 
	 * 
	 * 
	 * @param caseId
	 * @return
	 * @throws RemoteException
	 */
	public List<Map<String, Object>> getDiscussionList(String caseId) throws RemoteException;

	/**
	 * Return all topics items for the case.
	 * 
	 * @param caseId caseId
	 * @return Topic List
	 * @throws RemoteException
	 */
	public List<Map<String, Object>> getTopicList(String caseId) throws RemoteException;

	public List<String> getTopicList() throws RemoteException;

}
