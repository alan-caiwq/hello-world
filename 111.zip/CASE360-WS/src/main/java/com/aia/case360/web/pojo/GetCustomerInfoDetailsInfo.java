package com.aia.case360.web.pojo;

public class GetCustomerInfoDetailsInfo {
	private String fullName;
	private String surName;
	private String givName;
	private String secuityNo;
	private String DOB;
	private String companyCode;
	private String policyNo;
	private String contractNo;
	private String clientRole;
	private String clientNum;

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getSurName() {
		return surName;
	}

	public void setSurName(String surName) {
		this.surName = surName;
	}

	public String getGivName() {
		return givName;
	}

	public void setGivName(String givName) {
		this.givName = givName;
	}

	public String getSecuityNo() {
		return secuityNo;
	}

	public void setSecuityNo(String secuityNo) {
		this.secuityNo = secuityNo;
	}

	public String getDOB() {
		return DOB;
	}

	public void setDOB(String dOB) {
		DOB = dOB;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getContractNo() {
		return contractNo;
	}

	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	public String getClientRole() {
		return clientRole;
	}

	public void setClientRole(String clientRole) {
		this.clientRole = clientRole;
	}

	public String getClientNum() {
		return clientNum;
	}

	public void setClientNum(String clientNum) {
		this.clientNum = clientNum;
	}

}
