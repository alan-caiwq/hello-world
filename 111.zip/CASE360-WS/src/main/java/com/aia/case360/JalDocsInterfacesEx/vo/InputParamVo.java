package com.aia.case360.JalDocsInterfacesEx.vo;

import java.io.Serializable;
import java.util.List;

public class InputParamVo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String uuid;

	private String casdId;

	private String docId;

	private String caseObjectId;

	private String fileName;

	private byte[] fileBytes;

	private boolean isBytes;

	private String fileExtension;

	private String statusIndicator;

	private String linkIndicator;

	private String pageIndicator;

	private String sFlag; // "I": Import "R":Reindex

	private List<PolNumReqs> polNumReqs;

	public String getUuid() {
		return uuid;
	}



	public void setUuid(String uuid) {
		this.uuid = uuid;
	}



	public String getCasdId() {
		return casdId;
	}



	public void setCasdId(String casdId) {
		this.casdId = casdId;
	}



	public String getCaseObjectId() {
		return caseObjectId;
	}



	public void setCaseObjectId(String caseObjectId) {
		this.caseObjectId = caseObjectId;
	}



	public String getFileName() {
		return fileName;
	}



	public void setFileName(String fileName) {
		this.fileName = fileName;
	}



	public byte[] getFileBytes() {
		return fileBytes;
	}



	public void setFileBytes(byte[] fileBytes) {
		this.fileBytes = fileBytes;
	}



	public boolean isBytes() {
		return isBytes;
	}



	public void setBytes(boolean isBytes) {
		this.isBytes = isBytes;
	}



	public String getFileExtension() {
		return fileExtension;
	}



	public void setFileExtension(String fileExtension) {
		this.fileExtension = fileExtension;
	}



	public String getStatusIndicator() {
		return statusIndicator;
	}



	public void setStatusIndicator(String statusIndicator) {
		this.statusIndicator = statusIndicator;
	}



	public String getLinkIndicator() {
		return linkIndicator;
	}



	public void setLinkIndicator(String linkIndicator) {
		this.linkIndicator = linkIndicator;
	}



	public String getPageIndicator() {
		return pageIndicator;
	}



	public void setPageIndicator(String pageIndicator) {
		this.pageIndicator = pageIndicator;
	}



	public String getsFlag() {
		return sFlag;
	}



	public void setsFlag(String sFlag) {
		this.sFlag = sFlag;
	}



	public List<PolNumReqs> getPolNumReqs() {
		return polNumReqs;
	}



	public void setPolNumReqs(List<PolNumReqs> polNumReqs) {
		this.polNumReqs = polNumReqs;
	}



	public static long getSerialversionuid() {
		return serialVersionUID;
	}



	public void setDocId(String docId) {
		this.docId = docId;
	}



	public String getDocId() {
		return docId;
	}

	

	@Override
	public String toString() {
		return "ImportPara [uuid=" + uuid + ", casdId=" + casdId + ", docId=" + docId + ", caseObjectId=" + caseObjectId
				+ ", sFlag=" + sFlag + ", fileName=" + fileName + ", polNumReqs=" + polNumReqs + "]";
	}
}
