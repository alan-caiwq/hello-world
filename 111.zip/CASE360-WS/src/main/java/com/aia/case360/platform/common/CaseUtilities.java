package com.aia.case360.platform.common;

import java.math.BigDecimal;
import java.util.Calendar;

import com.eistream.sonora.fields.FieldPropertiesTO;

/**
 * A collection of utilities that is designed to help with processing Case
 * requests
 * 
 * @author hophVWK
 *
 */
public class CaseUtilities {
	
	private CaseUtilities() {}
	/**
	 * Create a new boolean field property
	 * 
	 * @return
	 */
	public static FieldPropertiesTO createFieldPropertyTO(String key, boolean value) {
		FieldPropertiesTO prop = new FieldPropertiesTO();
		prop.setPropertyName(key);
		prop.setBooleanValue(value);
		prop.setDataType(1);
		return prop;
	}

	/**
	 * Create a new int field property
	 * 
	 * @return
	 */
	public static FieldPropertiesTO createFieldPropertyTO(String key, int value) {
		FieldPropertiesTO prop = new FieldPropertiesTO();
		prop.setPropertyName(key);
		prop.setIntValue(value);
		prop.setDataType(2);
		return prop;
	}

	/**
	 * Create a new String field property
	 * 
	 * @return
	 */
	public static FieldPropertiesTO createFieldPropertyTO(String key, String value) {
		FieldPropertiesTO prop = new FieldPropertiesTO();
		prop.setPropertyName(key);
		prop.setStringValue(value);
		prop.setDataType(4);
		return prop;
	}

	/**
	 * Create a new Calendar field property
	 * 
	 * @return
	 */
	public static FieldPropertiesTO createFieldPropertyTO(String key, Calendar value) {
		FieldPropertiesTO prop = new FieldPropertiesTO();
		prop.setPropertyName(key);
		prop.setCalendarValue(value);
		prop.setDataType(5);
		return prop;
	}

	/**
	 * Create a new BigDecimal field property
	 * 
	 * @return
	 */
	public static FieldPropertiesTO createFieldPropertyTO(String key, BigDecimal value) {
		FieldPropertiesTO prop = new FieldPropertiesTO();
		prop.setPropertyName(key);
		prop.setBigDecimalValue(value);
		prop.setDataType(6);
		return prop;
	}

}
