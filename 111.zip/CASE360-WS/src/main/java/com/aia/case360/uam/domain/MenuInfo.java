package com.aia.case360.uam.domain;

import java.util.List;
import java.util.Map;

public class MenuInfo extends BaseRoleInfo {

	public MenuInfo() {

	}

	public MenuInfo(List<Map<String, Object>> menuInfo) {
		super();

		this.menuInfos = menuInfo;
	}

	private List<Map<String, Object>> menuInfos;

	public List<Map<String, Object>> getMenuInfo() {
		return menuInfos;
	}

	public void setMenuInfo(List<Map<String, Object>> menuInfo) {
		this.menuInfos = menuInfo;
	}

}
