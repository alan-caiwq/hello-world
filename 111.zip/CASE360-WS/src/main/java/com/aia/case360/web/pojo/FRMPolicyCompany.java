package com.aia.case360.web.pojo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class FRMPolicyCompany {
  
  @JsonProperty("POLICY_NO")
  private String polNum;
  
  @JsonProperty("COMPANY_NO")
  private String companyNo;
  
  @JsonProperty("REASON_CODE")
  private String reasonCode;
  
  @JsonProperty("REASON")
  private String reason;
  
  @JsonProperty("OBJECT_ID")
  private String objectId;
  
  @JsonProperty("PAGE")
  private String page;
  
  @JsonProperty("FORM_ID")
  private String formId;

  /**
   * @return the polNum
   */
  public String getPolNum() {
    return polNum;
  }

  /**
   * @return the companyNo
   */
  public String getCompanyNo() {
    return companyNo;
  }

  /**
   * @return the reasonCode
   */
  public String getReasonCode() {
    return reasonCode;
  }

  /**
   * @return the reason
   */
  public String getReason() {
    return reason;
  }

  /**
   * @return the objectId
   */
  public String getObjectId() {
    return objectId;
  }

  /**
   * @return the page
   */
  public String getPage() {
    return page;
  }

  /**
   * @return the formId
   */
  public String getFormId() {
    return formId;
  }

  /**
   * @param polNum the polNum to set
   */
  public void setPolNum(String polNum) {
    this.polNum = polNum;
  }

  /**
   * @param companyNo the companyNo to set
   */
  public void setCompanyNo(String companyNo) {
    this.companyNo = companyNo;
  }

  /**
   * @param reasonCode the reasonCode to set
   */
  public void setReasonCode(String reasonCode) {
    this.reasonCode = reasonCode;
  }

  /**
   * @param reason the reason to set
   */
  public void setReason(String reason) {
    this.reason = reason;
  }

  /**
   * @param objectId the objectId to set
   */
  public void setObjectId(String objectId) {
    this.objectId = objectId;
  }

  /**
   * @param page the page to set
   */
  public void setPage(String page) {
    this.page = page;
  }

  /**
   * @param formId the formId to set
   */
  public void setFormId(String formId) {
    this.formId = formId;
  }

  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "FRMPolicyCompany [polNum=" + polNum + ", companyNo=" + companyNo + ", reasonCode="
        + reasonCode + ", reason=" + reason + ", objectId=" + objectId + ", page=" + page
        + ", formId=" + formId + "]";
  }

}
