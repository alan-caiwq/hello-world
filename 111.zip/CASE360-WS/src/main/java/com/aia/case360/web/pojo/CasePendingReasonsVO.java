package com.aia.case360.web.pojo;

public class CasePendingReasonsVO {
	private String s_rowid;
	private String pending_duration;
	private String objID;
	private String comments;
	private String pending_reason;
	private String linkcaseid;
	private String req_nos;
	private String short_payment_count;

	public String getS_rowid() {
		return s_rowid;
	}

	public void setS_rowid(String s_rowid) {
		this.s_rowid = s_rowid;
	}

	public String getPending_duration() {
		return pending_duration;
	}

	public void setPending_duration(String pending_duration) {
		this.pending_duration = pending_duration;
	}

	public String getObjID() {
		return objID;
	}

	public void setObjID(String objID) {
		this.objID = objID;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getPending_reason() {
		return pending_reason;
	}

	public void setPending_reason(String pending_reason) {
		this.pending_reason = pending_reason;
	}

	public String getLinkcaseid() {
		return linkcaseid;
	}

	public void setLinkcaseid(String linkcaseid) {
		this.linkcaseid = linkcaseid;
	}

	public String getReq_nos() {
		return req_nos;
	}

	public void setReq_nos(String req_nos) {
		this.req_nos = req_nos;
	}

	public String getShort_payment_count() {

		return short_payment_count;
	}

	public void setShort_payment_count(String short_payment_count) {
		if (short_payment_count == null || "".equals(short_payment_count.trim())) {
			this.short_payment_count = null;
		} else {
			this.short_payment_count = short_payment_count;
		}

	}

}
