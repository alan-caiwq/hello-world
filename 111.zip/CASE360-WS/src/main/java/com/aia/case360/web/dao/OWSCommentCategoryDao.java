package com.aia.case360.web.dao;

import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.aia.case360.web.vo.OWSCommentCategory;

public interface OWSCommentCategoryDao {

	public OWSCommentCategory insertUpdateCommentCategory(OWSCommentCategory commentCategory)  throws RemoteException,SQLException;

	public void batchUpdateCommentCategoryOrder(@Param("tmpIds") String tmpIds, @Param("tmpSorts") String tmpSorts,@Param("currentUser") String currentUser)  throws RemoteException, SQLException;

	public void batchDeleteCommentCategory(@Param("tmpIds") String tmpIds, @Param("currentUser") String currentUser)  throws RemoteException, SQLException;

	public List<OWSCommentCategory> searchCategory(OWSCommentCategory commentCategory)  throws RemoteException;

	public OWSCommentCategory searchCategoryByID(Long rowID)  throws RemoteException;

}
