package com.aia.case360.web.dao;

import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.aia.case360.web.pojo.PolicyInfoParameter;
import com.aia.case360.web.vo.ClaimInfo;
import com.aia.case360.web.vo.OWSSearchCommentParam;
import com.aia.case360.web.vo.OWSUpdateCommentParam;

public interface OWSCommentDao {

	public List<ClaimInfo> getClaimNosByCaseId(long caseId)  throws RemoteException;

	public Map<String, Object> searchCommentByID(@Param("commentId") long commentId)  throws RemoteException;

	public List<Map<String, Object>> searchComment(OWSSearchCommentParam searchCommentParam)  throws RemoteException;

	public void updateComment(@Param("commentId") long commentId, @Param("updateCommentParam") OWSUpdateCommentParam updateCommentParam, @Param("user") String user)  throws RemoteException;

	public List<PolicyInfoParameter> getPolicySourceInfo(@Param("policyNums") List<String> policyNums)  throws RemoteException;

    public Boolean removeBookmark(@Param("docSource")String docSource, @Param("linkId")Long linkId) throws RemoteException;

}
