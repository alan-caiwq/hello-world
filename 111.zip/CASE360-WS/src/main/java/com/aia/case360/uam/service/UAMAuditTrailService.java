package com.aia.case360.uam.service;

import java.rmi.RemoteException;
import java.util.List;

import com.aia.case360.uam.domain.UAMAuditTrail;
import com.aia.case360.uam.domain.UAMGetAuditTrailParam;
import com.aia.case360.uam.domain.UAMGetOrganizationAuditTrailParam;
import com.aia.case360.uam.domain.UAMOrganizationAuditTrail;

public interface UAMAuditTrailService {

	public boolean addUAMAuditTrail(UAMAuditTrail param, String uuidStr)  throws RemoteException;

	public List<UAMAuditTrail> getUAMAuditTrail(UAMGetAuditTrailParam param, String uuidStr)  throws RemoteException;

	public List<UAMOrganizationAuditTrail> getUAMOrganizationAuditTrail(UAMGetOrganizationAuditTrailParam param,
			String uuidStr)  throws RemoteException;
}
