package com.aia.case360.JalDocsInterfacesEx.vo;

public class ObjectFieldDefVo {

	private String objectFieldName;

	private String objectXmlFieldName;

	private String required;

	private String conversion;

	/**
	 * @return Returns the objectFieldName.
	 */
	public String getObjectFieldName() {
		return objectFieldName;
	}

	public void setObjectFieldName(String objectFieldName) {
		 this.objectFieldName = objectFieldName;
	}

	/**
	 * @return Returns the objectXmlFieldName.
	 */
	public String getObjectXmlFieldName() {
		return objectXmlFieldName;
	}

	/**
	 * @param objectXmlFieldName The objectXmlFieldName to set.
	 */
	public void setObjectXmlFieldName(String objectXmlFieldName) {
		this.objectXmlFieldName = objectXmlFieldName;
	}

	/**
	 * @return Returns the required.
	 */
	public String getRequired() {
		return required;
	}

	/**
	 * @param required The required to set.
	 */
	public void setRequired(String required) {
		this.required = required;
	}

	/**
	 * @return Returns the conversion.
	 */
	public String getConversion() {
		return conversion;
	}

	/**
	 * @param conversion The conversion to set.
	 */
	public void setConversion(String conversion) {
		this.conversion = conversion;
	}

}
