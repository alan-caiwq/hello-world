package com.aia.case360.uam.domain;

import java.util.List;

public class RoleReqActVo {

	private String roleId;

	private String roleName;

	private String department;

	private String roleType;

	private String enable;

	private String remark;

	private List<RequestType> requestTypes;

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getRoleType() {
		return roleType;
	}

	public void setRoleType(String roleType) {
		this.roleType = roleType;
	}

	public String getEnable() {
		return enable;
	}

	public void setEnable(String enable) {
		this.enable = enable;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public List<RequestType> getRequestTypes() {
		return requestTypes;
	}

	public void setRequestTypes(List<RequestType> requestTypes) {
		this.requestTypes = requestTypes;
	}

}
