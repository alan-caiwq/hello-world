package com.aia.case360.platform.query;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Map;

public interface QueryWorkItemHelper {

	/**
	 * 
	 * Get userId's own job list by workstep
	 * 
	 * @param userId   login userId should be registered in Case360 side.
	 * @param workstep activity name indicates which activity queue for finding
	 *                 workitems of the current user
	 * @return queryResults
	 * @throws RemoteException
	 */
	public ArrayList<Map<String, Object>> getJobs(String userId, String workstep) throws RemoteException;

	/**
	 * Get userId's next job
	 * 
	 * @param userId   login userId should be registered in Case360 side.
	 * @param workstep activity name indicates which activity queue for finding
	 *                 workitems of the current user
	 * @return queryResults
	 * @throws RemoteException
	 */

	/**
	 * Get userId's next job list by work step name
	 * 
	 * @param userId   login userId should be registered in Case360 side.
	 * @param workstep activity name indicates which activity queue for finding
	 *                 workitems of the current user
	 * @return queryResults
	 * @throws RemoteException
	 */
	public ArrayList<Map<String, Object>> getNextJobList(String userId, String workstep) throws RemoteException;

	public ArrayList<Map<String, Object>> getCaseByPOSReqNo(String posReqNo) throws RemoteException;

	public ArrayList<Map<String, Object>> getSonoraValues(Map<String, String> queryParams) throws RemoteException;

	public String getEffectiveRpKeyStrWorkItem(String linkCaseId) throws RemoteException;

	public Map<String, Object> searchWorkItem(String workflowid, String wfworkitemid) throws RemoteException;

	public Map<String, Object> searchWorkItem(String rekey) throws RemoteException;

	public ArrayList<Map<String, Object>> getWiByPOSReqNo(String posReqNo) throws RemoteException;

	public ArrayList<Map<String, Object>> getAllJobs(String userId, String workstep) throws RemoteException;

	public ArrayList<Map<String, Object>> getAllPendingWorks(String userId, String workstep) throws RemoteException;

	public ArrayList<Map<String, Object>> getReferedWorks(String userId, String workstep) throws RemoteException;

	public ArrayList<Map<String, Object>> searchAllWorkItem(String requestNo) throws RemoteException;

	public ArrayList<Map<String, Object>> getWaitDocWorks(String userId, String workstep) throws RemoteException;

	public ArrayList<Map<String, Object>> getWorkItemByPolNum(String policyNum, String department, String processName)
			throws RemoteException;

	public String getWorkItems(String linkCaseId) throws RemoteException;

	public Map<String, Object> getWorkItemByLinkCaseId(String linkCaseId) throws RemoteException;

}
