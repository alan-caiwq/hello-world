package com.aia.case360.web.dao;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.aia.case360.web.pojo.ClaimNo;
import com.aia.case360.web.pojo.DocListOMSDetailsInfo;
import com.aia.case360.web.pojo.DocListOMSParameter;
import com.aia.case360.web.pojo.DocOMSDetailsInfo;
import com.aia.case360.web.pojo.DocOMSParameter;

@Repository
public interface WebAPIeDocDao {
	// Get document by object ID by OMS
	/**
	 * 
	 * @param params
	 * @return
	 * @ throws RemoteException
	 * @author: bsnpc55
	 * @date:6:56:41 PM Jul 24, 2018
	 */
	public List<DocOMSDetailsInfo> queryDocumentByIDOMS(DocOMSParameter params)  throws RemoteException;

	// Get Document list by OMS
	/**
	 * 
	 * @param params
	 * @return
	 * @ throws RemoteException
	 * @author bsnpc37
	 * @date:6:56:41 PM Jul 24, 2018
	 */
	public List<DocListOMSDetailsInfo> queryDocumentListOMS(DocListOMSParameter params)  throws RemoteException;

	/**
	 * 
	 * @param params
	 * @return
	 * @ throws RemoteException
	 * @author bsnpc37
	 * @date:6:56:41 PM Jul 24, 2018
	 */
	List<ClaimNo> queryClaimNo(DocListOMSParameter params)  throws RemoteException;

	/**
	 * 
	 * @param params
	 * @return
	 * @ throws RemoteException
	 * @author bsnpc37
	 * @date: 2018-4-11 10:25:13
	 */
	int insertLog(Map<String, String> params)  throws RemoteException;
}
