package com.aia.case360.platform.system;

import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.common.PropertyUtil;
import com.eistream.sonora.casefolder.core.CaseFolderSessionEJB;
import com.eistream.sonora.casefolder.core.CaseFolderSessionEJBHome;
import com.eistream.sonora.casefolder.discussions.DiscussionsSessionEJB;
import com.eistream.sonora.casefolder.discussions.DiscussionsSessionEJBHome;
import com.eistream.sonora.fields.FmsSchemaSessionEJB;
import com.eistream.sonora.fields.FmsSchemaSessionEJBHome;
import com.eistream.sonora.fields.FmsTableSessionEJB;
import com.eistream.sonora.fields.FmsTableSessionEJBHome;
import com.eistream.sonora.filestore.FileStoreSessionEJB;
import com.eistream.sonora.filestore.FileStoreSessionEJBHome;
import com.eistream.sonora.formdata.FormDataSessionEJB;
import com.eistream.sonora.formdata.FormDataSessionEJBHome;
import com.eistream.sonora.history.HistorySessionEJB;
import com.eistream.sonora.history.HistorySessionEJBHome;
import com.eistream.sonora.nbd.NBDSessionEJB;
import com.eistream.sonora.nbd.NBDSessionEJBHome;
import com.eistream.sonora.query.QuerySessionEJB;
import com.eistream.sonora.query.QuerySessionEJBHome;
import com.eistream.sonora.security.ACLSessionEJB;
import com.eistream.sonora.security.ACLSessionEJBHome;
import com.eistream.sonora.security.RolesSessionEJB;
import com.eistream.sonora.security.RolesSessionEJBHome;
import com.eistream.sonora.system.SystemSessionEJB;
import com.eistream.sonora.system.SystemSessionEJBHome;
import com.eistream.sonora.users.UsersSessionEJB;
import com.eistream.sonora.users.UsersSessionEJBHome;
import com.eistream.sonora.webservices.WsSessionEJB;
import com.eistream.sonora.webservices.WsSessionEJBHome;
import com.eistream.sonora.workflow.WorkFlowSessionEJB;
import com.eistream.sonora.workflow.WorkFlowSessionEJBHome;
import com.eistream.sonora.workflow.workflows.WFsSessionEJB;
import com.eistream.sonora.workflow.workflows.WFsSessionEJBHome;
import com.eistream.sonora.workflow.worksteps.WSsSessionEJB;
import com.eistream.sonora.workflow.worksteps.WSsSessionEJBHome;

public class InitCase360EJB {

	/**
	 * change original static to construct function to avoid restarting jboss
	 * initializing Case360WS project error
	 */
	private volatile static InitCase360EJB instance = null;

	private static Logger m_Logger = LoggerFactory.getLogger(InitCase360EJB.class.getClass());

	private InitCase360EJB() {

	}

	private static InitCase360EJB getInstance() {
		try {
			if (instance == null) {
				synchronized (InitCase360EJB.class) {
					if (instance == null) {
						instance = new InitCase360EJB();

						Properties jndiProps = new Properties();
						String url = PropertyUtil.getCommonProperty("JNDI_PROVIDER_URL");

						jndiProps.put(Context.URL_PKG_PREFIXES, "org.jboss.ejb.client.naming");

						jndiProps.put("jboss.naming.client.ejb.context", true);

						jndiProps.put(Context.PROVIDER_URL, url);

						Context ctx = new InitialContext(jndiProps);

						// EJB home
						NBDSessionEJBHome NBDEJBHome = (NBDSessionEJBHome) ctx
								.lookup("ejb:sonora/SonoraBeans//com.eistream.sonora.nbd.NBDSessionEJBHome!"
										+ com.eistream.sonora.nbd.NBDSessionEJBHome.class.getName());
						CaseFolderSessionEJBHome cfsEJBHome = (CaseFolderSessionEJBHome) ctx.lookup(
								"ejb:sonora/SonoraBeans//com.eistream.sonora.casefolder.core.CaseFolderSessionEJBHome!"
										+ com.eistream.sonora.casefolder.core.CaseFolderSessionEJBHome.class.getName());
						FmsSchemaSessionEJBHome fmsSchemaSessionEJBHome = (FmsSchemaSessionEJBHome) ctx
								.lookup("ejb:sonora/SonoraBeans//com.eistream.sonora.fields.FmsSchemaSessionEJBHome!"
										+ com.eistream.sonora.fields.FmsSchemaSessionEJBHome.class.getName());
						FmsTableSessionEJBHome fmsEJBHome = (FmsTableSessionEJBHome) ctx
								.lookup("ejb:sonora/SonoraBeans//com.eistream.sonora.fields.FmsTableSessionEJBHome!"
										+ com.eistream.sonora.fields.FmsTableSessionEJBHome.class.getName());
						SystemSessionEJBHome sysSEJBHome = (SystemSessionEJBHome) ctx
								.lookup("ejb:sonora/SonoraBeans//com.eistream.sonora.system.SystemSessionEJBHome!"
										+ com.eistream.sonora.system.SystemSessionEJBHome.class.getName());
						WorkFlowSessionEJBHome wfEJBHome = (WorkFlowSessionEJBHome) ctx
								.lookup("ejb:sonora/SonoraBeans//com.eistream.sonora.workflow.WorkFlowSessionEJBHome!"
										+ com.eistream.sonora.workflow.WorkFlowSessionEJBHome.class.getName());
						WSsSessionEJBHome wssSEJBHome = (WSsSessionEJBHome) ctx.lookup(
								"ejb:sonora/SonoraBeans//com.eistream.sonora.workflow.worksteps.WSsSessionEJBHome!"
										+ com.eistream.sonora.workflow.worksteps.WSsSessionEJBHome.class.getName());
						RolesSessionEJBHome roleEJBHome = (RolesSessionEJBHome) ctx
								.lookup("ejb:sonora/SonoraBeans//com.eistream.sonora.security.RolesSessionEJBHome!"
										+ com.eistream.sonora.security.RolesSessionEJBHome.class.getName());
						UsersSessionEJBHome userEJBHome = (UsersSessionEJBHome) ctx
								.lookup("ejb:sonora/SonoraBeans//com.eistream.sonora.users.UsersSessionEJBHome!"
										+ com.eistream.sonora.users.UsersSessionEJBHome.class.getName());
						DiscussionsSessionEJBHome disEJBHome = (DiscussionsSessionEJBHome) ctx.lookup(
								"ejb:sonora/SonoraBeans//com.eistream.sonora.casefolder.discussions.DiscussionsSessionEJBHome!"
										+ com.eistream.sonora.casefolder.discussions.DiscussionsSessionEJBHome.class
												.getName());
						ACLSessionEJBHome aclEJBHome = (ACLSessionEJBHome) ctx
								.lookup("ejb:sonora/SonoraBeans//com.eistream.sonora.security.ACLSessionEJBHome!"
										+ com.eistream.sonora.security.ACLSessionEJBHome.class.getName());
						HistorySessionEJBHome hisEJBHome = (HistorySessionEJBHome) ctx
								.lookup("ejb:sonora/SonoraBeans//com.eistream.sonora.history.HistorySessionEJBHome!"
										+ com.eistream.sonora.history.HistorySessionEJBHome.class.getName());
						FormDataSessionEJBHome fdEJBHome = (FormDataSessionEJBHome) ctx
								.lookup("ejb:sonora/SonoraBeans//com.eistream.sonora.formdata.FormDataSessionEJBHome!"
										+ com.eistream.sonora.formdata.FormDataSessionEJBHome.class.getName());
						FileStoreSessionEJBHome fsEJBHome = (FileStoreSessionEJBHome) ctx
								.lookup("ejb:sonora/SonoraBeans//com.eistream.sonora.filestore.FileStoreSessionEJBHome!"
										+ com.eistream.sonora.filestore.FileStoreSessionEJBHome.class.getName());
						WsSessionEJBHome wsEJBHome = (WsSessionEJBHome) ctx
								.lookup("ejb:sonora/SonoraBeans//com.eistream.sonora.webservices.WsSessionEJBHome!"
										+ com.eistream.sonora.webservices.WsSessionEJBHome.class.getName());
						WFsSessionEJBHome wfsSEJBHome = (WFsSessionEJBHome) ctx.lookup(
								"ejb:sonora/SonoraBeans//com.eistream.sonora.workflow.workflows.WFsSessionEJBHome!"
										+ com.eistream.sonora.workflow.workflows.WFsSessionEJBHome.class.getName());
						QuerySessionEJBHome qryEJBHome = (QuerySessionEJBHome) ctx
								.lookup("ejb:sonora/SonoraBeans//com.eistream.sonora.query.QuerySessionEJBHome!"
										+ com.eistream.sonora.query.QuerySessionEJBHome.class.getName());

						// EJB object
						NBDEJB = NBDEJBHome.create();
						cfsEJB = cfsEJBHome.create();
						fmsSchemaSessionEJB = fmsSchemaSessionEJBHome.create();
						fmsEJB = fmsEJBHome.create();
						sysSEJB = sysSEJBHome.create();
						wfEJB = wfEJBHome.create();
						wssSEJB = wssSEJBHome.create();
						roleEJB = roleEJBHome.create();
						userEJB = userEJBHome.create();
						disEJB = disEJBHome.create();
						aclEJB = aclEJBHome.create();
						hisEJB = hisEJBHome.create();
						fdEJB = fdEJBHome.create();
						fsEJB = fsEJBHome.create();
						wsEJB = wsEJBHome.create();
						wfsSEJB = wfsSEJBHome.create();
						qryEJB = qryEJBHome.create();
					} else {
						return instance;
					}
				}
			} else {
				return instance;
			}
		} catch (Exception e) {
			 LogUtil.logException(m_Logger, "", e);
		}
		return instance;
	}

	private static CaseFolderSessionEJB cfsEJB;

	private static FmsSchemaSessionEJB fmsSchemaSessionEJB;

	private static FmsTableSessionEJB fmsEJB;

	private static SystemSessionEJB sysSEJB;

	private static WorkFlowSessionEJB wfEJB;

	private static WSsSessionEJB wssSEJB;

	private static RolesSessionEJB roleEJB;

	private static UsersSessionEJB userEJB;

	private static QuerySessionEJB qryEJB;

	private static DiscussionsSessionEJB disEJB;

	private static ACLSessionEJB aclEJB;

	private static HistorySessionEJB hisEJB;

	private static FormDataSessionEJB fdEJB;

	private static FileStoreSessionEJB fsEJB;

	private static WsSessionEJB wsEJB;

	private static WFsSessionEJB wfsSEJB;

	private static NBDSessionEJB NBDEJB;

	public static CaseFolderSessionEJB getCfsEJB() {

		getInstance();
		return cfsEJB;
	}

	public static FmsSchemaSessionEJB getFmsSchemaSessionEJB() {
		getInstance();
		return fmsSchemaSessionEJB;
	}

	public static FmsTableSessionEJB getFmsEJB() {
		getInstance();
		return fmsEJB;
	}

	public static SystemSessionEJB getSysSEJB() {
		getInstance();
		return sysSEJB;
	}

	public static WorkFlowSessionEJB getWfEJB() {
		getInstance();
		return wfEJB;
	}

	public static WSsSessionEJB getWssSEJB() {
		getInstance();
		return wssSEJB;
	}

	public static RolesSessionEJB getRoleEJB() {
		getInstance();
		return roleEJB;
	}

	public static UsersSessionEJB getUserEJB() {
		getInstance();
		return userEJB;
	}

	public static QuerySessionEJB getQryEJB() {
		getInstance();
		return qryEJB;
	}

	public static DiscussionsSessionEJB getDisEJB() {
		getInstance();
		return disEJB;
	}

	public static ACLSessionEJB getAclEJB() {
		getInstance();
		return aclEJB;
	}

	public static HistorySessionEJB getHisEJB() {
		getInstance();
		return hisEJB;
	}

	public static FormDataSessionEJB getFdEJB() {
		getInstance();
		return fdEJB;
	}

	public static FileStoreSessionEJB getFsEJB() {
		getInstance();
		return fsEJB;
	}

	public static WsSessionEJB getWsEJB() {
		getInstance();
		return wsEJB;
	}

	public static WFsSessionEJB getWfsSEJB() {
		getInstance();
		return wfsSEJB;
	}

	public static NBDSessionEJB getNBDEJB() {
		getInstance();
		return NBDEJB;
	}

}
