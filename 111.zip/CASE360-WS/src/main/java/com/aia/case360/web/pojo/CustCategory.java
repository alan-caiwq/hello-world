package com.aia.case360.web.pojo;

public class CustCategory {

}
