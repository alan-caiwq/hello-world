package com.aia.case360.platform.process.impl;

import java.math.BigDecimal;

/**
 * Identify an envelop of workitem
 * 
 * @author bsnpbdu
 *
 */
public class RepositoryKey {
	private final int workflowId;
	private final BigDecimal workItemId;
	private final BigDecimal envelopeId;

	public int getWorkflowId() {
		return workflowId;
	}

	public BigDecimal getWorkItemId() {
		return workItemId;
	}

	public BigDecimal getEnvelopeId() {
		return envelopeId;
	}

	/**
	 * 
	 * @param repositoryKeyStr WFWORKFLOWID.WFWORKITEMID.WFROUTINGTICKETID
	 */
	public static RepositoryKey getInstance(String repositoryKeyStr) {

		String keyPattern = "\\d+.\\d+.\\d+.\\d+";
		if (repositoryKeyStr != null && repositoryKeyStr.matches(keyPattern)) {

			String ids[] = repositoryKeyStr.split("\\.");
			return new RepositoryKey(ids);
		}

		return null;

	}

	private RepositoryKey(String[] ids) {
		 workflowId =Integer.valueOf(ids[1]);
		 workItemId = new BigDecimal(ids[2]);
		 envelopeId = new BigDecimal(ids[3]);
	}

	@Override
	public String toString() {
		return "2." +  workflowId + "." +  workItemId + "." +  envelopeId;
	}

}