package com.aia.case360.web.dao;

import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.aia.case360.web.pojo.AMLInfo;
import com.aia.case360.web.pojo.AutoFileInfo;
import com.aia.case360.web.pojo.CPFaccountNoInfo;
import com.aia.case360.web.pojo.CampaignCodeInfo;
import com.aia.case360.web.pojo.CitiBankIndicatorInfo;
import com.aia.case360.web.pojo.CitiBankIndicatorMultiInfo;
import com.aia.case360.web.pojo.ClaimForDocumentView;
import com.aia.case360.web.pojo.CpfDecisionCodeInfo;
import com.aia.case360.web.pojo.DistrictInfo;
import com.aia.case360.web.pojo.FormDocLink;
import com.aia.case360.web.pojo.GetCustomerInfoByNRICInfo;
import com.aia.case360.web.pojo.GetLandingPageClaimHistoryPlas;
import com.aia.case360.web.pojo.GetPolicyInfoDetailsInfo;
import com.aia.case360.web.pojo.LandingPageClaimHistoryHSG;
import com.aia.case360.web.pojo.LandingPageClaimHistoryNoHSG;
import com.aia.case360.web.pojo.LandingPagePolicyInfo;
import com.aia.case360.web.pojo.LandingPagePolicyInfoDetail;
import com.aia.case360.web.pojo.MDRTIndicatorMultiInfo;
import com.aia.case360.web.pojo.OutputVO;
import com.aia.case360.web.pojo.PanelDoctorInfo;
import com.aia.case360.web.pojo.PaymentModeInfo;
import com.aia.case360.web.pojo.PolicyAndCaseinfo;
import com.aia.case360.web.pojo.PolicyInfo;
import com.aia.case360.web.pojo.PolicyInfoParameter;
import com.aia.case360.web.pojo.PolicyRole;
import com.aia.case360.web.pojo.PolicyRoleListForSignatureReindexInfo;
import com.aia.case360.web.pojo.PolicyRoleListForSignatureReindexParamter;
import com.aia.case360.web.pojo.SyncCliamNoInfo;
import com.aia.case360.web.pojo.TsarInfo;
import com.aia.case360.web.pojo.WebAPIinternalPAndOIL;

@Repository
public interface WebAPIinternalDao {

	public List<WebAPIinternalPAndOIL> getCustomerInfoByChdrNumIL(Map<Object, Object> IL) throws RemoteException,SQLException;

	/**
	 * 
	 * @param Map<String, String> params
	 * @return List<CitiBankIndicatorInfo>
	 * @throws RemoteException,SQLException
	 * @author bsnpc37
	 * @date:6:56:41 PM Jul 24, 2018
	 */

	List<CitiBankIndicatorInfo> getCitiBankIndicatorIL(Map<String, String> params)throws RemoteException,SQLException;
	/**
	 * @param String policyNo
	 * @return List<PolicyRole>
	 * @throws RemoteException,SQLException
	 * @author bsnpc37
	 * @date:6:56:41 PM Jul 24, 2018
	 */
	List<PolicyRole> getPolicyRolesIL(String policyNo)throws RemoteException,SQLException;
	
	/** 
	 *  
	 * @param：policyNo,LANID
	 * @return update flag
	 * @Author: bsnpc1w
	 * @Create Date: 03/19/2018
	 */
	public Integer updateUWIDIL(Map<String,String> paraMap) throws RemoteException,SQLException;
	
	/** 
	 *  
	 * @param：policyNoList,insuredNRICList
	 * @return:List<SyncCliamNoInfo> 
	 * @Author: bsnpc1w
	 * @Create Date: 03/19/2018
	 */
	public List<SyncCliamNoInfo> getClaimNoIL(Map<String,Object> paraMap) throws RemoteException,SQLException;
	
	/** 
	 *  
	 * @param：policyNoList, insuredNRICList
	 * @return claimDecision
	 * @Author: bsnpc1w
	 * @Create Date: 03/20/2018
	 */
	public List<SyncCliamNoInfo> getClaimDecisionIL(Map<String,Object> paraMap) throws RemoteException,SQLException;
	
	/**
	 * 
	 * @param List<String> policyNos
	 * @return List<PolicyRole>
	 * @throws RemoteException,SQLException
	 * @author bsnpc37
	 * @date:6:56:41 PM Jul 24, 2018
	 */
	List<PolicyRole> getAllpolicyNoIL(Map<String, Object> params)throws RemoteException,SQLException;
	

	
	/** 
	 *  
	 * @param：policyNo,companyCode
	 * @return PolicyInfo
	 * @Author: bsnpc 38
	 * @Create Date: 03/23/2018
	 */
	public List<GetPolicyInfoDetailsInfo> syncPolicyInfoIL(Map<String,Object> params) throws RemoteException,SQLException;
	
	/** 
	 *  
	 * @param：policyNo,companyCode
	 * @return PolicyInfo
	 * @Author: bsnpc1w 
	 * @Create Date: 06/26/2018
	 */
	public List<GetPolicyInfoDetailsInfo> syncPolicyInfoPlas(Map<String,Object> params) throws RemoteException,SQLException;
	
	/** 
	 *  
	 * @param：policyNo,companyCode
	 * @return PolicyInfo
	 * @Author: bsnpc1w
	 * @Create Date: 06/06/2018
	 */
	public List<GetPolicyInfoDetailsInfo> syncPolicyInfoHias(Map<String,Object> params) throws RemoteException,SQLException;
	/** 
	 * 
	 * customerNRIC
	 * @return: CustomerInfo
	 * @Author: bsnpc 38
	 * @Create Date: 03/27/2018
	 */
	public List<GetCustomerInfoByNRICInfo> getCustomerInfoByNRIC(Map<String,Object> paraMap) throws RemoteException,SQLException;
	/** 
	 * 
	 * customerNRIC
	 * @return: CustomerInfo
	 * @Author: bsnpc 38
	 * @Create Date: 03/27/2018
	 */
	public List<GetCustomerInfoByNRICInfo> getCustomerInfoByNRICIL(Map<String,Object> paraMap) throws RemoteException,SQLException;
	
	
	/** 
	 *  
	 * @param：policyInfoList
	 * @return int insertResult
	 * @Author: bsnpc1w(huiyunma)
	 * @Create Date: 03/29/2018
	 */
	public int insertPolicyInfo(String procedureParam) throws RemoteException,SQLException;
	/**
	 * 
	 * @param NRIC
	 * @return
	 * @throws RemoteException,SQLException
	 * @author bsnpc37
	 * @date: 2018-4-3 17:18:54
	 */
	 HashSet<GetPolicyInfoDetailsInfo> getPolicyInfoByNRICIL(String NRIC) throws RemoteException,SQLException;
	/**
	 * 
	 * @param paraMap
	 * @return
	 * @throws RemoteException,SQLException
	 * @author bsnpc37
	 * @date: 2018-4-3 17:18:57
	 */
	 List<GetPolicyInfoDetailsInfo> getPolicyInfoByNRICPlasAndHias(Map<String, Object> params) throws RemoteException,SQLException;
	
	
	/** 
	 * get policyInfo by policy from sonora
	 * @param：policyInfoList
	 * @return policyNoList
	 * @Author: bsnpc1w(huiyunma)
	 * @Create Date: 04/02/2018
	 */
	public List<GetPolicyInfoDetailsInfo> getPolciyInfoByPolicyNo(Map<String,Object> parmaMap);
	
	/** 
	 *  
	 * @param：policyNo
	 * @return premium
	 * @Author: huiyun ma
	 * @Create Date: 04/06/2018
	 */
	public String getPremiumIL(Map<String,Object> parmaMap);
	/**
	 * sync CustomerInfoIL from pas By PolicyNo 
	 * Parameters: String callingSystem String policyNo
	 * return: CustomerInfo
	 * @Author: bsnpc38(Gavin)	
	 * @Create Date: 2018.04.10
	 */
	public List<WebAPIinternalPAndOIL> getCustomerInfoIL(Map<String, Object> paramILmap) throws RemoteException,SQLException;
	
	//get customer info from PLAS
	public List<WebAPIinternalPAndOIL> syncCustomerInfoPlas(Map<String, Object> paramPlasmap) throws RemoteException,SQLException;
	
	//get customer info from HIAS
	public List<WebAPIinternalPAndOIL> syncCustomerInfoHias(Map<String, Object> paramHiasmap) throws RemoteException,SQLException;
	/** 
	 *  
	 * @param：policyInfoList
	 * @return policyNoList
	 * @Author: bsnpc38(Gavin)
	 * @Create Date: 2018.04.10
	 */
	public List<WebAPIinternalPAndOIL> getCustomerInfoByPolicyNo(Map<String, Object> parmaMap) throws RemoteException,SQLException;

	/**
	 *  syncCustomerInfo from pas By NRIC
	 * 
	 * Parameters: CustomerNRIC
	 * 
	 * return: CustomerInfo
	 * 
	 * @Author: bsnpc38(Gavin)
	 * 
	 * @Create Date: 2018.04.13
	 */	
	public List<GetCustomerInfoByNRICInfo> getCustomerInfoByNRICHiasAndPlas(Map<String, Object> paramHiasmap) throws RemoteException,SQLException;
	
	/** 
	 *  getPanelDoctorIndicatorIL
	 * @param：policyNo,claimNo
	 * @return panelDoctorIndicator
	 * @Author: huiyun
	 * @Create Date: 04/26/2018
	 */
	public PanelDoctorInfo getPanelDoctorIndicatorIL(Map<String,Object> param) throws RemoteException,SQLException;
	
	/** 
	 *  
	 * @param：policyNo
	 * @return campaignCode
	 * @Author: huiyun
	 * @Create Date: 04/26/2018
	 */
	public CampaignCodeInfo getCampaignCodeIL(Map<String,String> param) throws RemoteException,SQLException;
	
	
	/** 
	 *  
	 * @param：policyNo
	 * @return campaignCode
	 * @Author: huiyun
	 * @Create Date: 04/26/2018
	 */
	public String getFSCCodeIL(Map<String,String> param) throws RemoteException,SQLException;
	
	/** 
	 *  
	 * @param：policyNo
	 * @return cpfAccountNo
	 * @Author: huiyun
	 * @Create Date: 04/26/2018
	 */
	public List<CPFaccountNoInfo> getCPFaccountNoIL(Map<String,String> param) throws RemoteException,SQLException;
	
	/** 
	 *  
	 * @param：policyNo,claimNo
	 * @return amlIndicator
	 * @Author: huiyun
	 * @Create Date: 04/27/2018
	 */
	public  List<AMLInfo> getAMLIL(Map<String,String> param) throws RemoteException,SQLException;
	
	/**
	 * 
	 * @param claimNo
	 * @return
	 * @throws RemoteException,SQLException
	 * @author bsnpc37(Leo Li)
	 * @date: May 3, 2018 10:53:29 AM
	 */
	List<CpfDecisionCodeInfo> getCPFdecisionCodeIL(String claimNo)throws RemoteException,SQLException;
	/**
	 * Get all policy no for UWS for the by the NRIC of current policy  no
	 * @param params
	 * @return
	 * @throws RemoteException,SQLException
	 * @author bsnpc37(Leo Li)
	 * @date: May 3, 2018 3:07:53 PM
	 */
	List<PolicyRole> getAllpolicyNoPlas(Map<String, Object> params)throws RemoteException,SQLException;
	/**
	 * 
	 * @param params
	 * @return
	 * @throws RemoteException,SQLException
	 * @date:   3:01:03 PM , May 9, 2018
	 * @author: bsnpc57
	 */
	List<PolicyInfo> syncPolicyDetailsByPolicyIL(Map<String, Object> params)throws RemoteException,SQLException;
	/**
	 * 
	 * @param params
	 * @return
	 * @throws RemoteException,SQLException
	 * @date:   11:52:28 AM , May 16, 2018
	 * @author: bsnpc57
	 */
	List<Map<String,Object>> getMDRTIndicatorAMS(Map<String, String> params)throws RemoteException,SQLException;

	/**
	 * 
	 * @return
	 * @throws RemoteException,SQLException
	 * @date:   1:38:18 PM , May 17, 2018
	 * @author: bsnpc57
	 */
	List<Map<String,Object>> getEDocForOMS()throws RemoteException,SQLException;
	/**
	 * 
	 * @return
	 * @throws RemoteException,SQLException
	 * @date:   1:38:31 PM , May 17, 2018
	 * @author: bsnpc57
	 */
	List<Map<String,Object>> getEDocForCust()throws RemoteException,SQLException;

	/**
	 * 
	 * @param params
	 * @return
	 * @author: bsnpc55
	 * @date:6:56:41 PM Jul 24, 2018
	 */
	public List<LandingPagePolicyInfo> getLandingPagePolicyInfoIL(Map<String, Object> params) throws RemoteException,SQLException;
	/**
	 * 
	 * @param params
	 * @return
	 * @author: bsnpc55
	 * @date:6:56:41 PM Jul 24, 2018
	 */
	public List<LandingPagePolicyInfoDetail> getLandingPagePolicyInfoDetailIL(
			Map<String, Object> params) throws RemoteException,SQLException;
	/**
	 * 
	 * @param params
	 * @return
	 * @author: bsnpc55
	 * @date:6:56:41 PM Jul 24, 2018
	 */
	public List<LandingPageClaimHistoryHSG> getLandingPageClaimHistoryHSGIL(
			Map<String, Object> params) throws RemoteException,SQLException;
	/**
	 * 
	 * @param params
	 * @return
	 * @author: bsnpc55
	 * @date:6:56:41 PM Jul 24, 2018
	 */
	public List<LandingPageClaimHistoryNoHSG> getLandingPageClaimHistoryNoHSGIL(
			Map<String, Object> params) throws RemoteException,SQLException;
	/**
	 * 
	 * @param params
	 * @return
	 * @author: bsnpc55
	 * @date:6:56:41 PM Jul 24, 2018
	 */
	public List<LandingPageClaimHistoryHSG> getLandingPageCurrentClaimDetailIL(Map<String, Object> policyAndClaimNoparam);

	/**
	 * 
	 * @param paraMap
	 * @return
	 * @throws RemoteException,SQLException
	 * @author: bsnpc4u
	 * @date:6:56:41 PM Jul 24, 2018
	 */
	public List<LandingPagePolicyInfo> getLandingPageInfoHias(
			Map<String, Object> paraMap) throws RemoteException,SQLException;
	/**
	 * 
	 * @param paraMap
	 * @return
	 * @throws RemoteException,SQLException
	 * @author: bsnpc4u,bsnpc55
	 * @date:6:56:41 PM Jul 24, 2018
	 */
	public List<GetLandingPageClaimHistoryPlas> getLandingPageMinorClaimHitoryHias(
			Map<String, Object> paraMap) throws RemoteException,SQLException;
	/**
	 * 
	 * @param paraMap
	 * @return
	 * @throws RemoteException,SQLException
	 * @author: bsnpc4u、bsnpc55
	 * @date:6:56:41 PM Jul 24, 2018
	 */
	public List<GetLandingPageClaimHistoryPlas> getLandingPageMajorClaimHitoryHias(
			Map<String, Object> paraMap) throws RemoteException,SQLException;
	/**
	 * 
	 * @param paraMap
	 * @return
	 * @throws RemoteException,SQLException
	 * @author: bsnpc4u、bsnpc55
	 * @date:6:56:41 PM Jul 24, 2018
	 */
	public List<LandingPagePolicyInfoDetail> getLandingPageDetailInfoHias(
			Map<String, Object> paraMap) throws RemoteException,SQLException;
	/**
	 * 
	 * @param paraMap
	 * @return
	 * @throws RemoteException,SQLException
	 * @author: bsnpc4u
	 * @date:6:56:41 PM Jul 24, 2018
	 */
	public List<LandingPagePolicyInfo> getLandingPagePolicyListPlas(
			Map<String, Object> paraMap) throws RemoteException,SQLException;
	/**
	 * 
	 * @param paraMap
	 * @return
	 * @throws RemoteException,SQLException
	 * @author: bsnpc4u
	 * @date:6:56:41 PM Jul 24, 2018
	 */
	public List<LandingPagePolicyInfoDetail> getLandingPageDetailInfoPlas(
			Map<String, Object> paraMap) throws RemoteException,SQLException;
	/**
	 * 
	 * @param paraMap
	 * @return
	 * @throws RemoteException,SQLException
	 * @author: bsnpc4u
	 * @date:6:56:41 PM Jul 24, 2018
	 */
	public List<GetLandingPageClaimHistoryPlas> getLandingPageClaimHistoryPlas(
			Map<String, Object> paraMap) throws RemoteException,SQLException;
	/**
	 * 
	 * @param paraMap
	 * @return
	 * @throws RemoteException,SQLException
	 * @date:   11:23:26 AM , May 18, 2018
	 * @author: bsnpc57
	 */
	public List<Map<String, Object>> GetMagnumRecievedDayIL(
			Map<String, Object> paraMap) throws RemoteException,SQLException;
  
    /**
     * get policy info by policy number from plas
     * @param policyNo
     * @return
     * @author bsnpc37(Leo Li)
     * @date: May 18, 2018 10:56:16 AM
     */
//	List<PolicyInfo> syncPolicyDetailsByPolicyPlas(String policyNo);\
	
	/**
     * get date from FD_FORM_DOC_LINK
     * @param policyNo
     * @return
     * @author asnphjq(William)
     * @date: May 18, 2018 11:20:01 AM
     */
	List<FormDocLink>  getDocTypeFormIdLink();
	
	/**
     * getAutoFileInfoSybase
     * @param params
     * @return
     * @author asnphjq(William)
     * @date: May 18, 2018 11:20:01 AM
     */
	List<AutoFileInfo>  getAutoFileInfoSybase(Map<String, Object> params);
	
	List<AutoFileInfo> getDistinctAutoFileInfoSybase (Map<String, Object> params);
	
	/**
     * updateAutoFileFormIDSybase
     * @param updateAutoFileList
     * @return
     * @author asnphjq(William)
     * @date: May 18, 2018 11:20:01 AM
     */
	List<Map<String, Object>>  updateAutoFileFormIDSybase(String params);
	
	/**
     * getAutoFileClaimNoSybase
     * @param params
     * @return
     * @author asnphjq(William)
     * @date: May 18, 2018 11:20:01 AM
     */
	void getAutoFileClaimNoSybase(Map<String, Object> params);
	
	/**
     * getNoReqNoAutoFileSybase
     * @param params
     * @return
     * @author asnphjq(William)
     * @date: May 18, 2018 11:20:01 AM
     */
	List<AutoFileInfo> getNoReqNoAutoFileSybase(Map<String, Object> params);
	
	/**
     * updateAutoFileResultSybase
     * @param params
     * @return
     * @author asnphjq(William)
     * @date: May 18, 2018 11:20:01 AM
     */
	public List<Map<String, Object>> updateAutoFileResultSybase(List<Map<String, Object>> params);

	/**
	 * @param paraMap
	 * @return
	 * @author: asnphjq
	 * @date:2018-7-18
	 */
	public List<String> getAutoFileRequestNo(
			Map<String, Object> paraMap);
    /**
     * 
     * @param params
     * @return
     * @author bsnpc37(Leo Li)
     * @date: Jun 15, 2018 9:19:54 AM
     */
	public List<PolicyRole> getAllpolicyNoHias(Map<String, Object> params)throws RemoteException,SQLException;
	
	/**
	 * get Signature Role List from IL
	 * @param param
	 * @return
	 * @throws RemoteException,SQLException
	 * @author bsnpc37(Leo Li)
	 * @date: Jul 16, 2018 10:34:35 AM
	 */
	List<PolicyRole> getSignatureRoleListIL(PolicyInfoParameter param)throws RemoteException,SQLException;
	
	/**
	 * get Signature Role List from IL
	 * @param param
	 * @return
	 * @throws RemoteException,SQLException
	 * @author bsnpc37(Leo Li)
	 * @date: Jul 16, 2018 10:34:35 AM
	 */
	List<PolicyRole> getSignatureRoleListODS(Map<String,Object> param)throws RemoteException,SQLException;
	/**
	 * get Signature Role List from Hias
	 * @param param
	 * @return
	 * @throws RemoteException,SQLException
	 * @author bsnpc37(Leo Li)
	 * @date: Jul 16, 2018 10:35:07 AM
	 */
	List<PolicyRole> getSignatureRoleListHias(PolicyInfoParameter param)throws RemoteException,SQLException;
	
	/**
	 * get Signature Role List from Plas
	 * @param param
	 * @return
	 * @throws RemoteException,SQLException
	 * @author bsnpc37(Leo Li)
	 * @date: Jul 16, 2018 10:35:24 AM
	 */
	List<PolicyRole> getSignatureRoleListPlas(PolicyInfoParameter param)throws RemoteException,SQLException;
	/**
	 * @param params
	 * @return
	 * @author: bsnpc55
	 * @date:6:56:41 PM Jul 24, 2018
	 */
	public List<CitiBankIndicatorMultiInfo> getCitiBankIndicatorMultiIL(
			Map<String, Object> params);

	/**
	 * @param agentcodeListR
	 * @return
	 * @author: bsnpc55
	 * @date:6:56:41 PM Jul 24, 2018
	 */
	public List<MDRTIndicatorMultiInfo> getMDRTIndicatorMultiAMS(
			List<String> agentcodeListR);

	/**
	 * @param paraMap
	 * @return
	 * @author: bsnpc55
	 * @date:6:56:41 PM Jul 24, 2018
	 */
	public List<PanelDoctorInfo> getPanelDoctorIndicatorMultiIL(
			Map<String, Object> paraMap);
	//add  by bsnpc65 2019-1-26 begin 
	/**
	 * @param paraMap
	 * @return
	 * @author: bsnpc55
	 * @date:6:56:41 PM Jul 24, 2018
	 */
	public List<PanelDoctorInfo> getPanelDoctorIndicatorMultiODS(
			Map<String, Object> paraMap);
	//add  by bsnpc65 2019-1-26 end
	/**
	 * @param paraMap
	 * @return
	 * @author: bsnpc55
	 * @date:6:56:41 PM Jul 24, 2018
	 */
	public List<PanelDoctorInfo> getPanelDoctorIndicatorMultiByPolicyNoIL(
			Map<String, Object> paraMap);

	/**
	 * @param paraMap
	 * @return
	 * @author: bsnpc55
	 * @date:6:56:41 PM Jul 24, 2018
	 */
	public List<PanelDoctorInfo> getPanelDoctorIndicatorMultiByPolicyNoODS(
			Map<String, Object> paraMap);
	/**
	 * @param paramHiasmap
	 * @return
	 * @author: bsnpc55
	 * @date:6:56:41 PM Jul 24, 2018
	 */
	public List<PolicyInfo> syncPolicyDetailsByPolicyHias(
			Map<String, Object> paramHiasmap);

	/**
	 * @param paramPlasMap
	 * @return
	 * @author: bsnpc55
	 * @date:6:56:41 PM Jul 24, 2018
	 */
	public List<PolicyInfo> syncPolicyDetailsByPolicyPlas(
			Map<String, Object> paramPlasMap);


	/**
	 * @param params
	 * @return
	 * @author: bsnpc55
	 * @date:6:56:41 PM Jul 24, 2018
	 */
	public List<PolicyRoleListForSignatureReindexInfo> getPolicyRoleListForSignatureReindexIL(
			PolicyRoleListForSignatureReindexParamter params);
	//add by bsnpc65  2019-1-25 begin 
	/**
	 * @param params
	 * @return
	 * @author: bsnpc65
	 * @date:6:56:41 PM Jul 24, 2018
	 */
	public List<PolicyRoleListForSignatureReindexInfo> getPolicyRoleListForSignatureReindexODS(Map<String,Object> params);
	//add by bsnpc65  2019-1-25 end
	/**
	 * @param params
	 * @return
	 * @author: bsnpc55
	 * @date:6:56:41 PM Jul 24, 2018
	 */
	public List<PolicyRoleListForSignatureReindexInfo> getPolicyRoleListForSignatureReindexPlas(
			PolicyRoleListForSignatureReindexParamter params);

	/**
	 * @param params
	 * @return
	 * @author: bsnpc55
	 * @date:6:56:41 PM Jul 24, 2018
	 */
	public List<PolicyRoleListForSignatureReindexInfo> getPolicyRoleListForSignatureReindexHias(
			PolicyRoleListForSignatureReindexParamter params);

	
	/**
	 * 
	 * @param params
	 * @return
	 * @throws RemoteException,SQLException
	 * @date:   14:16:43 AM , June 21, 2018
	 * @author: asnphec
	 */
	public GetPolicyInfoDetailsInfo getPolicySourceInd(Map<String, String> params);
	
	public String getPolicySrcSysIndSybase(Map<String, Object> params);
	
	/**
	 * 
	 * @param params
	 * @return
	 * @throws RemoteException,SQLException
	 * @date:   14:16:43 AM , June 21, 2018
	 * @author: asnphec
	 */
	public List<ClaimForDocumentView> getClaimInfoHias(Map<String, String> String);
	
	/**
	 * 
	 * @param params
	 * @return
	 * @throws RemoteException,SQLException
	 * @date:   14:16:43 AM , June 21, 2018
	 * @author: asnphec
	 */
	public List<ClaimForDocumentView> getClaimForMIMO(Map<String, String> params);
	
	public List<ClaimForDocumentView> getClaimForPlasSybase(Map<String, String> params);
	
	public List<ClaimForDocumentView> getFollowupClaimForUpdateIL(Map<String, Object> params);
	
	public List<ClaimForDocumentView> getClaimForFollowupIL(Map<String, String> params);
	
	public List<ClaimForDocumentView> getClaimForMinorAndMajorIL(Map<String, String> params);
	
	public List<ClaimForDocumentView> getClaimForHSGIL(Map<String, String> params);
	
	public String getContractNoByPolicyIL(Map<String, String> params);
	
	public List<Map<String,String>> getContractNoFirstIL(Map<String, String> params);
	
	public List<Map<String,String>> getContractNoSecondIL(Map<String, String> params);

	
	public List<ClaimForDocumentView> getClaimForMinorAndMajorODS(Map<String, Object> params);
	public List<ClaimForDocumentView> getClaimForFollowupODS(Map<String, Object> params);
    /**
     * @param paramILmap
     * @param @return
     * @return List<PolicyInfo>
     * @date 6:48:07 PM
     * @author bsnpc55
     */
	public List<PaymentModeInfo> getPaymentModeByPolicyIL(
			Map<String, Object> paramILmap);
	
	  /**
     * @param paramILmap
     * @param @return
     * @return List<PolicyInfo>
     * @date 6:48:07 PM
     * @author bsnpc55
     */
	public List<PaymentModeInfo> getPaymentModeByPolicyODS(
			Map<String, Object> paramILmap);
    /**
     * @param paramILmap
     * @param @return
     * @return List<PolicyInfo>
     * @date 6:48:07 PM
     * @author bsnpc55
     */
	public List<PaymentModeInfo> getPaymentModeByPolicyHias(
			Map<String, Object> paramILmap);
    /**
     * @param paramILmap
     * @param @return
     * @return List<PolicyInfo>
     * @date 6:48:07 PM
     * @author bsnpc55
     */
	public List<PaymentModeInfo> getPaymentModeByPolicyPlas(
			Map<String, Object> paramILmap);
	
	/**
	 * get policy status and fsc code for report
	 * @param params
	 * @return
	 * @throws RemoteException,SQLException
	 * @author bsnpc37(Leo Li)
	 * @date: Aug 21, 2018 10:45:29 AM
	 */
	List<PolicyRole> getPolicyStatusAndFSCCodeIL (Map<String, Object> params) throws RemoteException,SQLException;
	/**
	 * get FSC channel, district name and district code by FSC code
	 * @param fscCodeList
	 * @return
	 * @throws RemoteException,SQLException
	 * @author bsnpc37(Leo Li)
	 * @date: Aug 21, 2018 4:34:46 PM
	 */
	List<DistrictInfo> getFSCChannelAndDistrictAMS(List<String> fscCodeList) throws RemoteException,SQLException;
	
	List<DistrictInfo> getFSCChannelAndDistrictBruAMS(List<String> fscCodeList) throws RemoteException,SQLException;
	/**
	 * 
	 * @param params
	 * @return void
	 * @date 4:42:19 PM
	 * @author bsnpc55
	 */
	public void logAPICallInfo(Map<String, Object> params);

	public  List<PolicyInfo> getComponentContractCodeODS(Map<String, Object> paraMap);

	public List<PolicyInfo> getComponentContractCodeIL(Map<String, Object> paraMap);

	public String getFSCCodeODS(Map<String, Object> paraMap) throws SQLException ;

	public List<PolicyRole> getAllpolicyNoODS(Map<String, Object> params);

	public List<WebAPIinternalPAndOIL> getCustomerInfoODS(Map<String, Object> param) throws SQLException;

	public void getCitiBankIndicatorODS(Map<String, Object> params);

	public void get_Tsar_Value_4_Case(Map<String, Object> params);

	public List <PolicyAndCaseinfo> get_policy_clientid_by_case(Map<String, Object> params);

	public void getClaimForHSGODS(Map<String, Object> params);

	public void getCustomerInfoByNRICODS(Map<String, Object> paras);

	public void getPolicyInfoByNRICODS(Map<String, Object> map4Ods);

	public void syncPolicyInfoODS(Map<String, Object> paramILmap);

	public void updatePriorityPremium4PolicyNo(@Param("policyNo")String policyNo, @Param("regularPremium")String string, @Param("singlePremium")String string2);
   
   	public void getFollowupClaimForUpdateODS(Map<String, Object> map4Ods);
   
   	public void getPolicyStatusAndFSCCodeODS(Map<String, Object> map4Ods);
   
    /**
     * for IL register or completed
     * @description 
     * @param updateParams
     * @author bsnpc37(Leo Li)
     * @date Feb 16, 2019 2:40:22 PM
     */
	void updateIlRequest (Map<String, String> updateParams);

	void updateLocalUWID(Map<String, Object> updateParams);

	public Map<String, String> getTsarValue4CaseByPol(Map<String, Object> params);

	public void updateTsarBypolicyNo(Map<String, Object> params);
	
	public void updateSourceOfBussiness(Map<String, Object> params);
	/**
	 * update SourceOfBussiness and MDRT in table FD_PRIORITY_POL_DATA
	 * @description 
	 * @param params
	 * @author bsnpc37(Leo Li)
	 * @date Apr 2, 2019 11:10:56 AM
	 */
	void updateSBAndMDRT(Map<String, Object> params);
}
