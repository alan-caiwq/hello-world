package com.aia.case360.uam.controller;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.aia.case360.uam.domain.RoleQueryPara;
import com.aia.case360.uam.service.UAMUserRoleService;
import com.aia.case360.web.pojo.OutputVO;
import com.aia.case360.web.webservice.AbstractController;

@RestController
public class UAMRoleController extends AbstractController {

	private static final String LOCALUAM_ROLE_CONTROLLER_GET_ROLE_INFO_BY_ROLE_ID = "UAMRoleController:getRoleInfoByRoleId";

	@Autowired
	private UAMUserRoleService uamUserRoleService;

	@Autowired
	private com.aia.case360.uam.service.UAMMenuService UAMMenuService;

	/**
	 * 
	 * @param params
	 * @param request
	 * @return
	 * @ throws RemoteException function_search_001
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/case/uam/getRoleByDetOrRoleName", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Map<String, Object>>> getRoleByDetOrRoleName(@RequestBody Map<String, Object> param,
			HttpServletRequest request)  throws RemoteException {
		
		RoleQueryPara roleQueryPara = new RoleQueryPara();
		String department = String.valueOf(param.get("department") == null ? "" : param.get("department"));
		String roleName = String.valueOf(param.get("roleName") == null ? "" : param.get("roleName"));
		String roleType = String.valueOf(param.get("roleType") == null ? "" : param.get("roleType"));
		roleQueryPara.setDepartment(department);
		roleQueryPara.setRoleName(roleName);
		roleQueryPara.setRoleType(roleType);

		List<Map<String, Object>> roles = uamUserRoleService.getRolesByRoleInfo(roleQueryPara);

		this.logEnd(request);
		OutputVO OutputVO = new OutputVO();
		OutputVO.setDatas(roles);
		return new ResponseEntity(OutputVO.toMap(), HttpStatus.OK);
	}

	/**
	 * 
	 * @param params
	 * @param request
	 * @return
	 * @ throws RemoteException function_create_003
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/case/uam/get_all_req_act", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<Object, List>> getAllRequestTypeAndAct(@RequestParam Map<String, String> params,
			HttpServletRequest request)  throws RemoteException {

		this.logStart(params, "UAMRoleController:getAllRequestTypeAndAct", request);

		Map<String, String> message = new HashMap<String, String>();

		Map<String, Object> result = new HashMap<String, Object>();

		Object req_act = uamUserRoleService.getAllRequestAndActivty(null);
		result.put("message", message);

		this.logEnd(request);

		return new ResponseEntity(req_act, HttpStatus.OK);
	}

	/**
	 * 
	 * @param params
	 * @param request
	 * @return function_create_001 - update
	 * @ throws RemoteException
	 * 
	 */

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/case/uam/addRole", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Object>> addRole(@RequestBody Map<String, Object> params,
			HttpServletRequest request) {
		this.logStart(params.toString(), "UAMRoleController:addRole", request);
		OutputVO outputVO = new OutputVO();
		try {
			m_Logger.info("addRole start");
			outputVO = uamUserRoleService.addRole(params);

			this.logEnd(request);

			return new ResponseEntity(outputVO.toMap(), HttpStatus.OK);
		} catch (Exception e) {
			 
			m_Logger.info("addRole error");
			outputVO.addErrorInfo("addRole error:" + e);
			return new ResponseEntity<Map<String, Object>>(outputVO.toMap(), HttpStatus.OK);
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/case/uam/getRoleInfoByRoleId", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getRoleInfoByRoleId(@RequestParam Map<String, String> params,
			HttpServletRequest request)  throws RemoteException {
		this.logStart(params.toString(), LOCALUAM_ROLE_CONTROLLER_GET_ROLE_INFO_BY_ROLE_ID, request);
		m_Logger.info("getRoleInfoByRoleId start");
		String roleId = params.get("roleId");
		OutputVO outputVO = new OutputVO();
		try {
			Object s = uamUserRoleService.getRoleInfoByRoleId(roleId);
			 logEnd(request);
			outputVO.setDatas(s);
			m_Logger.info("getRoleInfoByRoleId end");
			return new ResponseEntity(outputVO.toMap(), HttpStatus.OK);
		} catch (Exception e) {
			 
			m_Logger.info("getRoleInfoByRoleId error:" + e);
			outputVO.addErrorInfo("getRoleInfoByRoleId error:" + e);
			return new ResponseEntity(outputVO.toMap(), HttpStatus.OK);
		}


	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/case/uam/getAllRequestAndActivty", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getRequestType(@RequestParam Map<String, String> params, HttpServletRequest request)
			 throws RemoteException {
		this.logStart(params.toString(), LOCALUAM_ROLE_CONTROLLER_GET_ROLE_INFO_BY_ROLE_ID, request);

		Object s = uamUserRoleService.getAllRequestAndActivty(null);
		this.logEnd(request);
		OutputVO OutputVO = new OutputVO();
		OutputVO.setDatas(s);

		return new ResponseEntity(OutputVO.toMap(), HttpStatus.OK);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/case/uam/getMenuByUserId/{menuType}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getMenu(@RequestParam Map<String, String> params, HttpServletRequest request,
			@PathVariable(value = "menuType") int menuType)  throws RemoteException {
		this.logStart(params.toString(), LOCALUAM_ROLE_CONTROLLER_GET_ROLE_INFO_BY_ROLE_ID, request);

		Object s = UAMMenuService.getMenusByUserId(request.getRemoteUser(), menuType);

		this.logEnd(request);

		OutputVO OutputVO = new OutputVO();
		OutputVO.setDatas(s);

		return new ResponseEntity(OutputVO.toMap(), HttpStatus.OK);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/case/uam/getAllMenu/{menuType}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getAllMenu(@RequestParam Map<String, String> params, HttpServletRequest request,
			@PathVariable(value = "menuType") int menuType)  throws RemoteException {
		this.logStart(params.toString(), LOCALUAM_ROLE_CONTROLLER_GET_ROLE_INFO_BY_ROLE_ID, request);

		Object s = UAMMenuService.getAllMenus(menuType);

		this.logEnd(request);

		OutputVO OutputVO = new OutputVO();
		OutputVO.setDatas(s);

		return new ResponseEntity(OutputVO.toMap(), HttpStatus.OK);
	}

	@RequestMapping(value = "/case/uam/getAllRoles", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Object>> getAllRoles(@RequestParam Map<String, String> params,
			HttpServletRequest request)  throws RemoteException {
		this.logStart(params.toString(), "UAMRoleController:getAllRoles", request);

		List<Map<String, Object>> s = uamUserRoleService.getAllRoles();

		this.logEnd(request);

		OutputVO result = new OutputVO();
		result.setDatas(s);

		return new ResponseEntity<Map<String, Object>>(result.toMap(), HttpStatus.OK);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/case/uam/modifyRole", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<Object, List>> modifyRole(@RequestBody Map<String, Object> params,
			HttpServletRequest request)  throws RemoteException {
		this.logStart(params.toString(), "UAMRoleController:modifyRole", request);
		boolean result = uamUserRoleService.modifyRole(params);
		 logEnd(request);
		OutputVO outputVO = new OutputVO();
		outputVO.setDatas(result);

		return new ResponseEntity(outputVO.toMap(), HttpStatus.OK);
	}

	@RequestMapping(value = "/case/uam/get_role_by_userid", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getRoleByUserIdAndRoleType(@RequestBody Map<String, Object> params,
			HttpServletRequest request) {
		this.logStart(params.toString(), "UAMRoleController:getRoleByUserIdAndRoleType", request);
		Object role = uamUserRoleService.getRoleByUserIdAndRoleType(params);

		this.logEnd(request);
		return new ResponseEntity(role, HttpStatus.OK);
	}

	@RequestMapping(value = "/case/uam/getUserButtons", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Object>> getUserButtons() {
		OutputVO output = new OutputVO();
		try {
			m_Logger.info("getUserButtons start");
			output = UAMMenuService.getUserButtons();
			return new ResponseEntity<Map<String, Object>>(output.toMap(), HttpStatus.OK);
		} catch (Exception e) {
			 
			m_Logger.info("getUserButtons error" + e);
			output.addErrorInfo("getUserButtons error" + e);
			return new ResponseEntity<Map<String, Object>>(output.toMap(), HttpStatus.OK);
		}
	}

	/**
	 * get form category data: role configured & role not configured
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/case/uam/getFormCategory", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Object>> getFormCategory(@RequestBody Map<String, Object> request) {
		OutputVO output = new OutputVO();
		try {
			m_Logger.info("getFormCategory start");
			output = UAMMenuService.getFormCategory(request);
			return new ResponseEntity<Map<String, Object>>(output.toMap(), HttpStatus.OK);
		} catch (Exception e) {
			 
			m_Logger.info("getFormCategory error");
			output.addErrorInfo("getFormCategory error" + e);
			return new ResponseEntity<Map<String, Object>>(output.toMap(), HttpStatus.OK);
		}
	}
}
