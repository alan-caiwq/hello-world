package com.aia.case360.JalDocsInterfacesEx.util;


import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

/**
 * @author asnpw16
 * 
 *         History: YYYY/MM/DD Developer Revision PDCF
 *         ------------------------------------------------------------------------------------
 *         2009/06/22 Meteor 001 add policyNoStartWithSpace To change the
 *         template for this generated type comment go to
 *         Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class StrUtil {

	private StrUtil() {
	}

	/**
	 * Converted the string with value separated by ";" into the set
	 * 
	 * @param inStr
	 * @return
	 * @throws FwException
	 */
	public static Set strToSet(String inStr)  {
		Set outSet = new HashSet();

		String[] outArr = inStr.split(";");
		for (int i = 0; i < outArr.length; i++) {
			outSet.add(outArr[i]);
		}
		return outSet;
	}

	/**
	 * Converted the string with value separated by ";" into the Array
	 * 
	 * @param inStr
	 * @return
	 * @throws FwException
	 */
	public static String[] strToArray(String inStr)  throws RemoteException {

		if (null == inStr)
			inStr = "";

		return inStr.split(";");
	}

	/**
	 * If the input string is null, returns Empty; otherwise return the original
	 * string value
	 * 
	 * @param inStr
	 * @return
	 * @throws FwException
	 */
	public static String nullToEmpty(String inStr)  {

		if (StringUtils.isBlank(inStr)) {
			inStr = "";
		} else {
			inStr = inStr.trim();
		}
		return inStr;
	}

	/**
	 * If the input Object is null, returns Empty; otherwise return the original
	 * object value
	 * 
	 * @param inStr
	 * @return
	 * @throws FwException
	 */
	public static String nullToEmptyForObject(Object object)  {
		String str = "";
		if (object == null) {
			str = "";
		} else if(object instanceof String){
			str = ((String) object).trim();
		}
		return str;
	}

	/**
	 * If the input string is null, returns Empty; otherwise return the original
	 * <B>without trim </B> string value
	 * 
	 * @author bsnpbf0
	 * @data 20090609
	 * @param inStr
	 * @return
	 * @throws FwException
	 */
	public static String nullToEmptyWithoutTrim(String inStr)  throws RemoteException {

		if (inStr == null) {
			inStr = "";
		} 
		return inStr;
	}

	/**
	 * Convert policy to 10 digital if it is 9
	 * 
	 * @param policyNo
	 * @author bsnpbf0
	 * @date 20090609
	 * @return
	 */
	public static String policyNoStartWithSpace(String policyNo) {
		String temp;
		temp = "          " + policyNo;
		return temp.substring(temp.length() - 10);
	}

     
     /**
      * convert java.sql.Timestamp to String
      * @param time java.sql.Timestamp
      * @param strFormat ( eg: "YYYY/MM/dd HH:mm:ss.SSS"）
      * @return formatString
      */
      public static String dateToStr(java.sql.Timestamp time, String strFormat) {
         DateFormat df = new SimpleDateFormat(strFormat);
         String str = df.format(time);
         return str;
     }
}
