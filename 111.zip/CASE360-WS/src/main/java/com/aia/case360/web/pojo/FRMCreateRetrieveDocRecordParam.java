package com.aia.case360.web.pojo;

public class FRMCreateRetrieveDocRecordParam {

  private Long caseId;
  
  private String reqNum;
  
  private String polNum;
  
  private String page;
  
  private String user;
  
  private String objectId;
  
  private String formId;
  
  private String reason;
  
  private String collector;
  
  private String office;
  
  private String remark;
  
  

  /**
   * @return the caseId
   */
  public Long getCaseId() {
    return caseId;
  }

  /**
   * @return the reqNum
   */
  public String getReqNum() {
    return reqNum;
  }

  /**
   * @return the polNum
   */
  public String getPolNum() {
    return polNum;
  }

  /**
   * @return the page
   */
  public String getPage() {
    return page;
  }

  /**
   * @return the user
   */
  public String getUser() {
    return user;
  }

  /**
   * @return the objectId
   */
  public String getObjectId() {
    return objectId;
  }

  /**
   * @return the formId
   */
  public String getFormId() {
    return formId;
  }

  /**
   * @return the reason
   */
  public String getReason() {
    return reason;
  }

  /**
   * @return the collector
   */
  public String getCollector() {
    return collector;
  }

  /**
   * @return the office
   */
  public String getOffice() {
    return office;
  }

  /**
   * @param caseId the caseId to set
   */
  public void setCaseId(Long caseId) {
    this.caseId = caseId;
  }

  /**
   * @param reqNum the reqNum to set
   */
  public void setReqNum(String reqNum) {
    this.reqNum = reqNum;
  }

  /**
   * @param polNum the polNum to set
   */
  public void setPolNum(String polNum) {
    this.polNum = polNum;
  }

  /**
   * @param page the page to set
   */
  public void setPage(String page) {
    this.page = page;
  }

  /**
   * @param user the user to set
   */
  public void setUser(String user) {
    this.user = user;
  }

  /**
   * @param objectId the objectId to set
   */
  public void setObjectId(String objectId) {
    this.objectId = objectId;
  }

  /**
   * @param formId the formId to set
   */
  public void setFormId(String formId) {
    this.formId = formId;
  }

  /**
   * @param reason the reason to set
   */
  public void setReason(String reason) {
    this.reason = reason;
  }

  /**
   * @param collector the collector to set
   */
  public void setCollector(String collector) {
    this.collector = collector;
  }

  /**
   * @param office the office to set
   */
  public void setOffice(String office) {
    this.office = office;
  }

  /**
   * @return the remark
   */
  public String getRemark() {
    return remark;
  }

  /**
   * @param remark the remark to set
   */
  public void setRemark(String remark) {
    this.remark = remark;
  }

  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "FRMCreateRetrieveDocRecordParam [caseId=" + caseId + ", reqNum=" + reqNum + ", polNum="
        + polNum + ", page=" + page + ", user=" + user + ", objectId=" + objectId + ", formId="
        + formId + ", reason=" + reason + ", collector=" + collector + ", office=" + office
        + ", remark=" + remark + "]";
  }
}
