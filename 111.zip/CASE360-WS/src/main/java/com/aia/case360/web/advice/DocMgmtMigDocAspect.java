package com.aia.case360.web.advice;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.aia.case360.platform.common.JsonUtil;
import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.web.dao.DocumentsRelatedDataDao;
import com.aia.case360.web.service.DocMgmtService;
import com.aia.case360.web.service.impl.AbstractServiceImpl;
import com.aia.case360.web.vo.RenameDocFormLinkParam;
import com.aia.case360.web.vo.VoidDocLinkParam;

import net.sf.json.JSONObject;

@Component
@Aspect
public class DocMgmtMigDocAspect extends AbstractServiceImpl {
	private static final String LOCALS_ROWID = "S_ROWID";
	private static final String LOCALCOPY_TO_CLAIM = "copyToClaim";
	@Autowired
	private DocumentsRelatedDataDao documentsRelatedDataDao;
	@Autowired
	private DocMgmtService docMgmtService;

	@Pointcut("execution( * com.aia.case360.web.service.DocMgmtService.*(..))")
	public void pointCutDocMgmtService() {
		// NOSONAR
	}

	@Around("pointCutDocMgmtService()")
	public Object around(ProceedingJoinPoint jp) throws RemoteException {

		String methodName = jp.getSignature().getName();
		JSONObject params;
		String uuidStr = null;
		Object[] args = jp.getArgs();
		if (methodName.equalsIgnoreCase("reindexToExistCase") || methodName.equalsIgnoreCase("reindexToPolicy")
				|| methodName.equalsIgnoreCase("copyToExistCase") || methodName.equalsIgnoreCase("copyToPolicy")
				|| methodName.equalsIgnoreCase("reindexToClaim") || methodName.equalsIgnoreCase(LOCALCOPY_TO_CLAIM)) {
			try {
				params = (JSONObject) jp.getArgs()[0];
				uuidStr = (String) jp.getArgs()[1];
				List<Map<String, String>> reIndexFrom = JsonUtil.getRequestParamsList(params, "FROM");
				List<Map<String, String>> reIndexFromUpdated = handleUnMigratedDocLink(reIndexFrom, uuidStr,
						methodName);
				params.put("FROM", reIndexFromUpdated);
				args[0] = params;
			} catch (Exception e) {
				throw LogUtil.logException(m_Logger, methodName, e);
			}
		}

		if (methodName.equalsIgnoreCase("reindexToNewCase") || methodName.equalsIgnoreCase("copyToNewCase")) {

			try {
				params = (JSONObject) jp.getArgs()[0];
				uuidStr = (String) jp.getArgs()[1];
				List<Map<String, String>> docLinkFrom = JsonUtil.getRequestParamsList(params, "DOCLINK");
				List<Map<String, String>> docLinkFromUpdated = handleUnMigratedDocLink(docLinkFrom, uuidStr,
						methodName);
				params.put("DOCLINK", docLinkFromUpdated);
				args[0] = params;
			} catch (Exception e) {
				throw LogUtil.logException(m_Logger, methodName, e);
			}

		}

		// com.aia.case360.web.service.impl.DocMgmtServiceImpl.voidDocLinks(List<VoidDocLinkParam>
		// params, String uuid)
		this.voidDocLinks(methodName, uuidStr, jp);

		// com.aia.case360.web.service.impl.DocMgmtServiceImpl.voidDocLinks(List<VoidDocLinkParam>
		// params, String uuid)
		this.unvoidDocLinks(methodName, uuidStr, jp);
		Object proceed = null;
		try {
			proceed = jp.proceed(args);
		} catch (Throwable e) {
			throw LogUtil.logException(m_Logger, e.getMessage(), e);
		}
		return proceed;
	}

	private void voidDocLinks(String methodName,String uuidStr,ProceedingJoinPoint jp) throws RemoteException {
		if (methodName.equalsIgnoreCase("voidDocLinks")) {
			List<VoidDocLinkParam> param = (List<VoidDocLinkParam>) jp.getArgs()[0];
			for (VoidDocLinkParam voidDocLinkParam : param) {
				if("0".equals(voidDocLinkParam.getLinkID()) || "null".equalsIgnoreCase(voidDocLinkParam.getLinkID())){
					//call Common Service ,move Attributes to doc link, return S_ROWID
					String objectId = voidDocLinkParam.getObjectId();
					Long linkId = docMgmtService.convertAttributesToAttrDocLink(objectId, 1, uuidStr);
					voidDocLinkParam.setLinkID(String.valueOf(linkId));
					
				}
			}
		}
	}
	private void unvoidDocLinks(String methodName,String uuidStr,ProceedingJoinPoint jp) throws RemoteException {
		 if (methodName.equalsIgnoreCase("unvoidDocLinks")) {
	            List<VoidDocLinkParam> param = (List<VoidDocLinkParam>) jp.getArgs()[0];
	            for (VoidDocLinkParam voidDocLinkParam : param) {
	                if("0".equals(voidDocLinkParam.getLinkID()) || "null".equalsIgnoreCase(voidDocLinkParam.getLinkID())){
	                    //call Common Service ,move Attributes to doc link, return S_ROWID
	                    String objectId = voidDocLinkParam.getObjectId();
	                    Long linkId = docMgmtService.convertAttributesToAttrDocLink(objectId, 1, uuidStr);
	                    voidDocLinkParam.setLinkID(String.valueOf(linkId));
	                }
	            }
	        }
	}
	private List<Map<String, String>> handleUnMigratedDocLink(List<Map<String, String>> param, String uuidStr,
			String methodName)  throws RemoteException {
		try {

			for (Map<String, String> map : param) {
				if ("0".equals(map.get(LOCALS_ROWID)) || StringUtils.isEmpty(map.get(LOCALS_ROWID))
						|| "null".equalsIgnoreCase(map.get(LOCALS_ROWID))) {
					// call Common Service ,move Attributes to doc link, return S_ROWID
					String objectId = map.get("OBJECT_ID");
					Integer deleteFlag = 1;

					Long linkId = docMgmtService.convertAttributesToAttrDocLink(objectId, deleteFlag, uuidStr);
					// set S_ROWID
					map.put(LOCALS_ROWID, String.valueOf(linkId));
					if (methodName.equalsIgnoreCase(LOCALCOPY_TO_CLAIM) || methodName.equalsIgnoreCase("reindexToClaim")) {
					  map.put("DOC_SOURCE", "MIGRATE");
					}

				}
			}
		} catch (Exception e) {
			throw LogUtil.logException(m_Logger, methodName, e);
		}
		return param;
	}
}
