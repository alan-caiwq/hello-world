package com.aia.case360.web.pojo;

import java.math.BigDecimal;

public class DocOMSDetailsInfo {
	// objectId
	private String objectId;
	// fileName
	private String fileName;
	// fileBody
	private String fileBody;
	// documentId
	private BigDecimal documentId;
	// objectId
	private String requestID;
	// requestDateTime
	private String requestDateTime;
	// responseDateTime
	private String responseDateTime;
	private String isVoid;
	// for waterMark
	private String SYSTEM_NM;

	private String pageIndicator;

	private transient String blocking;

	public String getSYSTEM_NM() {
		return SYSTEM_NM;
	}

	public void setSYSTEM_NM(String sYSTEM_NM) {
		SYSTEM_NM = sYSTEM_NM;
	}

	public String getBlocking() {
		return blocking;
	}

	public void setBlocking(String blocking) {
		this.blocking = blocking;
	}

	public String getIsVoid() {
		return isVoid;
	}

	public void setIsVoid(String isVoid) {
		this.isVoid = isVoid;
	}

	public String getObjectId() {
		return objectId;
	}

	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileBody() {
		return fileBody;
	}

	public void setFileBody(String fileBody) {
		this.fileBody = fileBody;
	}

	public BigDecimal getDocumentId() {
		return documentId;
	}

	public void setDocumentId(BigDecimal documentId) {
		this.documentId = documentId;
	}

	public String getRequestID() {
		return requestID;
	}

	public void setRequestID(String requestID) {
		this.requestID = requestID;
	}

	public String getRequestDateTime() {
		return requestDateTime;
	}

	public void setRequestDateTime(String requestDateTime) {
		this.requestDateTime = requestDateTime;
	}

	public String getResponseDateTime() {
		return responseDateTime;
	}

	public void setResponseDateTime(String responseDateTime) {
		this.responseDateTime = responseDateTime;
	}

	public String getPageIndicator() {
		return pageIndicator;
	}

	public void setPageIndicator(String pageIndicator) {
		this.pageIndicator = pageIndicator;
	}

}
