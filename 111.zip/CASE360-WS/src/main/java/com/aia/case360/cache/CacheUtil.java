package com.aia.case360.cache;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.ejb.FinderException;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.aia.case360.common.OpCase360CustomProperties;
import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.web.common.CommonUtil;
import com.aia.case360.web.dao.UserAccountDao;
import com.aia.case360.web.dao.WorkPoolDao;
import com.aia.case360.web.pojo.ConcurrentCaseRuleVO;
import com.aia.case360.web.service.GetJobRuleService;
import com.aia.case360.web.service.SonoraConfigInfoService;

/**
 * used to cache some data which is often used
 * 20190322
 * @author bsnpbys
 *
 */
@Component
public class CacheUtil {
	
	private static final String RULE_STR_GETJOB = "getjob";

	protected static Logger m_Logger = LoggerFactory.getLogger(new CacheUtil().getClass());

	static List<ConcurrentCaseRuleVO> concurrentCaseRules = null;
	
	static Map<String, String> userDeptMap = null;
	
	static Map<String, String> userAgencyMap = null;
	
	static Map<String, List<Map<String, Object>>> userRoleAuth = null;
	
	static long lastUpdateTime = 0;
	
	private static GetJobRuleService ruleService;
	
	private static UserAccountDao userAccountDao;
	
	private static WorkPoolDao workPoolDao;
	
	@Autowired
	private GetJobRuleService ruleServiceA;
	
	@Autowired
	private UserAccountDao userAccountDaoA;
	
	@Autowired
	private WorkPoolDao workPoolDaoA;
	
	@PostConstruct
    public void beforeInit() {
		ruleService = ruleServiceA;
		userAccountDao = userAccountDaoA;
		workPoolDao = workPoolDaoA;
    }
	
	public static void clearAllCache(){
		concurrentCaseRules = null;
		userDeptMap = null;
		userAgencyMap = null;
		userRoleAuth = null;
	}
	
	/**
	 * update proerty to be changed
	 * @param ruleStr
	 */
	public static void updateAllServerProperty(String ruleStr){
		synchronized (CacheUtil.class) {
			try {
				// TODO call Fred method get server list
				List<String> serverList = OpCase360CustomProperties.getRegisterHostName();
				// update each server property
				for(String serverName : serverList){
					String serverConfig = CommonUtil.getString(OpCase360CustomProperties.getCase360CustomProperty(serverName), "");
					if(!StringUtils.isBlank(serverConfig)){
						StringBuilder newConfig = new StringBuilder();
						String[] categoryArr = serverConfig.split(";");
						if(categoryArr.length > 0){
							for(String tCateg : categoryArr){
								String[] ruleArr = tCateg.split(":");
								if(ruleArr.length == 2){
									if(ruleStr.equalsIgnoreCase(ruleArr[0])){
										addString4SB(newConfig, ruleStr + ":" + "1");
									} else {
										addString4SB(newConfig, tCateg);
									}
								} else {
									addString4SB(newConfig, tCateg);
								}
							}
						}
						if(newConfig.length() > 0){
							// update custom property
							OpCase360CustomProperties.updateCase360CustomProerty(serverName, newConfig.toString());
						}
					}
				}
			} catch (RemoteException | FinderException e) {
				//do nothing
				LogUtil.logException(m_Logger, "get custom property failed", e);
			}
		}
	}

	private static void addString4SB(StringBuilder newConfig, String tCateg) {
		if(newConfig.length() != 0){
			newConfig.append(";");
		}
		newConfig.append(tCateg);
	}
	
	/**
	 * check if session is expired
	 * @return
	 */
	public static boolean isExpired(String ruleStr){
//		synchronized (CacheUtil.class) {
			LogUtil.logInfo(m_Logger, "1");
//			long expireTime = 3000000;
			boolean result = false;
			try {
				//get server name
				String serverName = InetAddress.getLocalHost().getHostName();
//				expireTime = CommonUtil.getLongValue(sonoraConfigInfoService.querySonoraPropValue("Custom", "CacheExpireTime"), expireTime);
				String serverConfig = CommonUtil.getString(OpCase360CustomProperties.getCase360CustomProperty(serverName), "");
				if(!StringUtils.isBlank(serverConfig)){// siniodwciw010 : getjob:1;drools:1
					StringBuilder newConfig = new StringBuilder();
					String[] categoryArr = serverConfig.split(";");
					if(categoryArr.length > 0){
						for(String tCateg : categoryArr){
							String[] ruleArr = tCateg.split(":");
							if(ruleArr.length == 2){
								if("1".equalsIgnoreCase(ruleArr[1]) && ruleStr.equalsIgnoreCase(ruleArr[0])){
									addString4SB(newConfig, ruleStr + ":" + "0");
									result = true;
								} else {
									addString4SB(newConfig, tCateg);
								}
							}
						}
					}
					if(newConfig.length() > 0 && result){
						// update custom property
						OpCase360CustomProperties.updateCase360CustomProerty(serverName, newConfig.toString());
					}
				}
			} catch (RemoteException | FinderException | UnknownHostException e) {
				//do nothing
				LogUtil.logException(m_Logger, "get custom property failed", e);
				return result;
			}
//			long currentTimeMillis = System.currentTimeMillis();
//			if(currentTimeMillis - lastUpdateTime >= 3000000){
//				lastUpdateTime = currentTimeMillis;
//				return true;
//			}
			return result;
//		}
	}
	
	/**
	 * get concurrent rule if department is null, return all concurrent rules
	 * charley 20190322
	 * @param department
	 * @return
	 * @throws RemoteException
	 */
	public static List<ConcurrentCaseRuleVO> getConcurrentRule(String department) throws RemoteException{
		List<ConcurrentCaseRuleVO> result = new ArrayList<>();
//		if(isExpired(RULE_STR_GETJOB)){
//			clearAllCache();
//		}
		synchronized(CacheUtil.class) {
			if(concurrentCaseRules == null) {
				concurrentCaseRules = ruleService.queryConcurrentCaseRules(null);
			}
		}
		if(StringUtils.isBlank(department)) {
			return concurrentCaseRules;
		}
		for(ConcurrentCaseRuleVO conRule : concurrentCaseRules) {
			if(department.equalsIgnoreCase(conRule.getDepartment())) {
				result.add(conRule);
			}
		}
		return result;
	}
	
	/**
	 * get user department
	 * charley 20190322
	 * @param department
	 * @return
	 * @throws RemoteException
	 */
	public static String getUserDepartment(String userId) throws RemoteException{
//		if(isExpired(RULE_STR_GETJOB)){
//			clearAllCache();
//		}
		synchronized(CacheUtil.class) {
			long currentTimeMillis = System.currentTimeMillis();
			if(currentTimeMillis - lastUpdateTime >= 300000){
				lastUpdateTime = currentTimeMillis;
				clearAllCache();
			}
			if(userDeptMap == null || userDeptMap.isEmpty()) {
				userDeptMap = new HashMap<>();
				List<Map<String, String>> userDepartments = userAccountDao.queryUsersDepartment();
				if(!CommonUtil.isListEmpty(userDepartments)){
					for(Map<String, String> m : userDepartments){
						userDeptMap.put(m.get("UAM_USER_ID"), m.get("DEPARTMENT"));
					}
				}
			}
		}
		if(StringUtils.isBlank(userId)) {
			return "";
		}
		return userDeptMap.get(userId);
	}
	
	public static String getUserAgencyLocation(String userId) throws RemoteException{
//		if(isExpired(RULE_STR_GETJOB)){
//			clearAllCache();
//		}
		synchronized(CacheUtil.class) {
			if(userAgencyMap == null || userAgencyMap.isEmpty()) {
				userAgencyMap = new HashMap<>();
				List<Map<String, String>> userAgencyList = workPoolDao.queryUserAgencyLocation(null);
				if(!CommonUtil.isListEmpty(userAgencyList)){
					for(Map<String, String> m : userAgencyList){
						userAgencyMap.put(m.get("UAM_USER_ID"), m.get("AGENCY_LOCATION"));
					}
				}
			}
		}
		if(StringUtils.isBlank(userId)) {
			return "";
		}
		return userAgencyMap.get(userId);
	}
	
	public static List<Map<String, Object>> getUserRoleAuth(String userId) throws RemoteException{
//		if(isExpired(RULE_STR_GETJOB)){
//			clearAllCache();
//		}
		if(StringUtils.isBlank(userId)) {
			return null;
		}
		synchronized(CacheUtil.class) {
			if(userRoleAuth == null || userRoleAuth.isEmpty() || userRoleAuth.get(userId) == null || userRoleAuth.get(userId).size() == 0) {
				userRoleAuth = new HashMap<>();
				List<Map<String, Object>> userRoleAuthList = workPoolDao.queryUserRoleAuth(userId);
				userRoleAuth.put(userId, userRoleAuthList);
			}
		}
		return userRoleAuth.get(userId);
	}
	
	
}
