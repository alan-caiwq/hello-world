package com.aia.case360.uam.service.impl;

import java.io.IOException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.Control;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import javax.naming.ldap.PagedResultsControl;
import javax.naming.ldap.PagedResultsResponseControl;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.aia.case360.platform.common.Constants;
import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.security.impl.UserHelperImpl;
import com.aia.case360.uam.constants.UAMConstants;
import com.aia.case360.uam.dao.UserAccountDao;
import com.aia.case360.uam.domain.UAMAuditTrail;
import com.aia.case360.uam.domain.UAMUserEditAuditTrail;
import com.aia.case360.uam.domain.UAMUserSyncAuditTrail;
import com.aia.case360.uam.domain.UamUser;
import com.aia.case360.uam.domain.UamUserAttributesMapper;
import com.aia.case360.uam.domain.UserAuthorityVO;
import com.aia.case360.uam.service.UAMUserAccountService;
import com.aia.case360.web.common.CommonUtil;
import com.aia.case360.web.dao.CaseAuditDao;
import com.aia.case360.web.dao.UAMAuditTrailDao;
import com.aia.case360.web.pojo.CaseAuditTrailVO;
import com.aia.case360.web.pojo.OutputVO;
import com.aia.case360.web.service.impl.AbstractServiceImpl;
import com.aia.case360.web.vo.UAMCopyToParam;
import com.rometools.utils.Lists;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * 
 * @author bsnpc2s
 *
 */
@Service
public class UAMUserAccountServiceImpl extends AbstractServiceImpl implements
		UAMUserAccountService {

	private static final String LOCALQUERY_AD_USERS_ERROR = "query AD users error:";

	private static final String[] NORMALUSERROLE = { "normalUser" };

	private static final String USERID = "USERID";

	private static final String CALCOMPANY = "CALCOMPANY";

	private static final String DISPLAYNAME = "DISPLAYNAME";

	private static final String DELIVERYSTRING = "DELIVERYSTRING";

	private static final String LOWERUSERID = "userId";

	private static final String USERNULLERRMSG = "userId cannot be null";

	private static final String CURLOGINUSER = "CURLOGINUSER";

	private static final String GETUSERERRMSG = "get login userId failed";

	private static final String USERAUTH = "USERAUTH";

	private static final String UNIAUTH = "UNIAUTH";

	private static final String TSARNAME = "TSARNAME";

	private static final String RANGETO = "RANGETO";

	private static final String RANGEFROM = "RANGEFROM";

	private static final String SARGROUP = "SARGROUP";

	private static final String AUTHTYPE = "AUTHTYPE";

	private static final String DEPARTMENT = "DEPARTMENT";

	private static final String RISKTYPE = "RISKTYPE";

	private static final String REQTYPE = "REQTYPE";

	private static final String ACTIVITY = "ACTIVITY";

	private static final String ACTNAME = "ACTNAME";

	private static final String BACKTRAINER = "BACKTRAINER";

	private static final String ISTRAINEE = "ISTRAINEE";

	private static final String TRAINER = "TRAINER";

	private static final String REQ_ID = "REQ_ID";

	private static final String DESCRIPTION = "DESCRIPTION";

	private static final String AUTHTYPESTR = "(\'authType\':\'";

	private static final String DESCRIPTIONSTR = "\',\'description\':\'";

	private static final String TOSTR = "\' to \'";

	private static final String COMPANY = "COMPANY";

	private static final String TEAMID = "TEAMID";

	private static final String TEAMTYPE = "TEAMTYPE";

	private static final String TEAMNAME = "TEAMNAME";

	private static final String PARENTID = "PARENTID";

	@Autowired
	UserAccountDao userAccountDao;

	@Autowired
	com.aia.case360.web.dao.UserAccountDao userAuthorityDao;

	@Autowired
	UAMAuditTrailDao auditTrailDao;
	
	@Autowired
	private CaseAuditDao caseAuditDao;

	@Override
	public Map<String, Map<String, String>> getAllUserAccounts(
			Map<String, Object> request) throws RemoteException {
		String userId = "";
		if (request != null) {
			userId = request.get(USERID) == null ? "" : "%"
					+ request.get(USERID).toString() + "%";
		}
		List<Map<String, String>> userInfoList = userAuthorityDao
				.queryAllUserInfo(userId);
		Map<String, Map<String, String>> userAccounts = new HashMap<String, Map<String, String>>();
		if (userInfoList != null && userInfoList.size() > 0) {
			for (Map<String, String> user : userInfoList) {
				userAccounts.put(user.get(UAMConstants.LOGINID).toUpperCase(),
						user);
			}
		}
		return userAccounts;
	}

	@Override
	public List<Map<String, String>> getAllUserInfoList(JSONObject params)
			throws RemoteException {
		String userId = "";
		if (params != null) {
			userId = params.getString(USERID) == null ? "" : "%"
					+ params.getString(USERID) + "%";
		}
		List<Map<String, String>> userInfoList = userAuthorityDao
				.queryAllUserInfo(userId);

		return userInfoList;
	}

	private Map<String, Map<String, String>> getAllUsersFromAD() {
		byte[] cookie = null;
		SearchControls searchCtls = new SearchControls();

		searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE);

		searchCtls.setReturningAttributes(new String[] { "mail",
				"streetaddress", "company", "telephoneNumber",
				"sAMAccountName", "displayName", "department" });
		Map<String, Map<String, String>> usersMap = new HashMap<String, Map<String, String>>();
		List<UamUser> allUsers = new ArrayList<UamUser>();
		try {

			InitialLdapContext ctx = new InitialLdapContext();
			LdapContext ldapJNDI = null;
			InitialDirContext tmp = (InitialDirContext) ctx
					.lookup(UAMConstants.LDAP_JNDI_STR);
			ldapJNDI = new InitialLdapContext(tmp.getEnvironment(), null);

			ldapJNDI.setRequestControls(new Control[] { new PagedResultsControl(
					1000, false) });
			allUsers = this.getUamUserList(ldapJNDI, searchCtls, cookie);

			for (Object o : allUsers) {
				if (o instanceof UamUser) {
					UamUser u = (UamUser) o;

					Map<String, String> userAccount = new HashMap<String, String>();
					userAccount.put(UAMConstants.LOGINID, u.getUserId()
							.toUpperCase());
					userAccount.put(UAMConstants.DISPLAYNAME, u.getUserName());
					userAccount.put(UAMConstants.DELIVERYSTRING, u.getEmail());
					userAccount.put(UAMConstants.ACTIVESTATUS, u.getStatus());

					userAccount.put(UAMConstants.UAM_USER_ID, u.getUserId()
							.toUpperCase());
					userAccount.put(UAMConstants.UAM_USER_OFFICE_NUMBER,
							u.getPhoneNumber());
					userAccount.put(UAMConstants.UAM_USER_DEPARTMENT,
							u.getDepartment());
					userAccount.put(UAMConstants.USERCOMPANY, u.getCompany());
					userAccount.put(UAMConstants.FROMAD,
							String.valueOf(u.isFromAD()));
					userAccount.put("timeZone", "Asia/Singapore");//add default time zone 20190619
					usersMap.put(u.getUserId().toUpperCase(), userAccount);
				}
			}

		} catch (NamingException e) {
			LogUtil.logError(m_Logger, LOCALQUERY_AD_USERS_ERROR + e);
		} catch (RemoteException e) {
			LogUtil.logError(m_Logger, LOCALQUERY_AD_USERS_ERROR + e);
		} catch (IOException e) {
			LogUtil.logError(m_Logger, LOCALQUERY_AD_USERS_ERROR + e);
		}
		return usersMap;
	}

	private ArrayList<UamUser> getUamUserList(LdapContext ldapJNDI,
			SearchControls searchCtls, byte[] cookie) throws NamingException,
			IOException {
		ArrayList<UamUser> allUsers = new ArrayList<UamUser>();
		do {
			NamingEnumeration answer = ldapJNDI.search(UAMConstants.BASEDN,
					UAMConstants.SEARCH_FILTER, searchCtls);
			while (answer.hasMore()) {

				UamUserAttributesMapper temp = new UamUserAttributesMapper();

				SearchResult entry = (SearchResult) answer.next();

				allUsers.add(temp.mapFromAttributes(entry.getAttributes()));

			}
			Control[] controls = ldapJNDI.getResponseControls();
			if (controls != null) {
				for (int i = 0; i < controls.length; i++) {

					if (controls[i] instanceof PagedResultsResponseControl) {
						PagedResultsResponseControl prrc = (PagedResultsResponseControl) controls[i];
						cookie = prrc.getCookie();
					}
				}
			}
			ldapJNDI.setRequestControls(new Control[] { new PagedResultsControl(
					1000, cookie, false) });
		} while (cookie != null);
		return allUsers;
	}

	/**
	 * From AD, get user account data, their field names should be mapped to
	 * Case360 user account field names
	 * 
	 * @throws RemoteException
	 */
	@Override
	public OutputVO synchUserAccounts() throws RemoteException {
		LogUtil.logInfo(m_Logger,
				"start synchUserAccounts:" + System.currentTimeMillis());
		OutputVO outputVO = new OutputVO();
		// sync users in SONORA to uam user which is not exist by charley
		// 20180806
		userAuthorityDao.syncUserFromSonora();

		LogUtil.logInfo(m_Logger,
				"start query users from C360:" + System.currentTimeMillis());
		// get users currently in system
		final Map<String, Map<String, String>> allUsersFromC360 = getC360Users();
		LogUtil.logInfo(m_Logger,
				"end query users from C360:" + System.currentTimeMillis());
		LogUtil.logInfo(m_Logger,
				"start query users from AD:" + System.currentTimeMillis());
		// get users in AD
		final Map<String, Map<String, String>> allUsersFromAD = getAllUsersFromAD();
		LogUtil.logInfo(m_Logger,
				"end query users from AD:" + System.currentTimeMillis());
		if (allUsersFromAD.isEmpty()) {
			LogUtil.logError(m_Logger, "no AD users found");
			outputVO.addErrorInfo("no AD users found");
			return outputVO;
		}
		List<Map<String, String>> updateUserAccounts = new ArrayList<Map<String, String>>();
		// users not in AD
		List<String> notInAdUsers = new ArrayList<String>();
		Set<String> sonoraLanIds = allUsersFromC360.keySet();
		Set<String> allADUserIds = allUsersFromAD.keySet();
		List<String> inActiveUsers = new ArrayList<String>();
		for (String sonoraLanId : sonoraLanIds) {
			boolean fromAD = userActInAD(allUsersFromC360, allUsersFromAD,
					updateUserAccounts, notInAdUsers, allADUserIds,
					inActiveUsers, sonoraLanId);
		}

		if (notInAdUsers.size() > 0) {
			LogUtil.logInfo(m_Logger,
					"start add audit for user which is to be terminated:"
							+ System.currentTimeMillis());
			// 2018/06/14 add audit trail add by cuixin -Start
			updateUserStatusAuditTrail(notInAdUsers,
					Constants.USER_STATUS_TERMINATE);
			// 2018/06/14 add audit trail add by cuixin -End
			LogUtil.logInfo(m_Logger,
					"end add audit for user which is to be terminated:"
							+ System.currentTimeMillis());
			LogUtil.logInfo(
					m_Logger,
					"start do update user which is to be terminated:"
							+ System.currentTimeMillis());
			// if user is no longer in AD update user status to Terminated
			userAuthorityDao.updateUserStatus(Constants.USER_STATUS_TERMINATE,
					notInAdUsers);
			// clear case owner while user is terminated 20190619
			for(String userId : notInAdUsers){
				// add clear case owner audit trail
				// get cases which owner is the user
				List<String> caseIdList = userAuthorityDao.getCaseIdByProcessor(userId);
				// write audit trail
				for(String caseId : caseIdList){
					CaseAuditTrailVO caseAuditTrail = new CaseAuditTrailVO("user " + userId + " is terminated, clear case owner", "system", new Date(),
							caseId, "CLEAROWNER", false);
					// add audit trail
					caseAuditDao.createCaseAudit(caseAuditTrail);
				}
				// clear cases owner who is terminated
				userAuthorityDao.clearInactiveUserCaseOwner(userId);
			}
			
			LogUtil.logInfo(
					m_Logger,
					"end do update user which is to be terminated:"
							+ System.currentTimeMillis());
		}
		if (inActiveUsers != null && inActiveUsers.size() > 0) {
			LogUtil.logInfo(m_Logger,
					"start add audit for user which is to be inactive:"
							+ System.currentTimeMillis());
			// 2018/06/14 add audit trail add by cuixin -Start
			updateUserStatusAuditTrail(inActiveUsers,
					Constants.USER_STATUS_INACTIVE);
			LogUtil.logInfo(
					m_Logger,
					"end add audit for user which is to be inactive:"
							+ System.currentTimeMillis());
			LogUtil.logInfo(
					m_Logger,
					"start do update user which is to be inactive:"
							+ System.currentTimeMillis());
			// 2018/06/14 add audit trail add by cuixin -End
			userAuthorityDao.updateUserStatus(Constants.USER_STATUS_INACTIVE,
					inActiveUsers);
			// clear case owner while user is inactived 20190619
			for(String userId : inActiveUsers){
				// add clear case owner audit trail
				// get cases which owner is the user
				List<String> caseIdList = userAuthorityDao.getCaseIdByProcessor(userId);
				// write audit trail
				for(String caseId : caseIdList){
					CaseAuditTrailVO caseAuditTrail = new CaseAuditTrailVO("user " + userId + " is inactive, clear case owner", "system", new Date(),
							caseId, "CLEAROWNER", false);
					// add audit trail
					caseAuditDao.createCaseAudit(caseAuditTrail);
				}
				// clear cases owner who is terminated
				userAuthorityDao.clearInactiveUserCaseOwner(userId);
			}
			
			LogUtil.logInfo(
					m_Logger,
					"end do update user which is to be inactive:"
							+ System.currentTimeMillis());
		}
		// AD keyset
		Set<String> newUsers = allUsersFromAD.keySet();
		LogUtil.logInfo(m_Logger, "newUsers:" + newUsers);
		LogUtil.logInfo(m_Logger, "case360:" + allUsersFromC360.keySet());
		// new usersList
		newUsers.removeAll(allUsersFromC360.keySet());
		LogUtil.logInfo(m_Logger, "newUsers:" + newUsers);
		LogUtil.logInfo(m_Logger,
				"start do add new user :" + System.currentTimeMillis());
		if (newUsers.size() != 0) {
			List<Map<String, String>> newUserAccounts = new ArrayList<Map<String, String>>();
			for (String userId : newUsers) {
				Map<String, String> tNewUser = allUsersFromAD.get(userId);
				tNewUser.put(LOWERUSERID, userId);
				newUserAccounts.add(tNewUser);
			}
			newUserAccount(newUserAccounts);
		}
		LogUtil.logInfo(m_Logger,
				"end do add new user :" + System.currentTimeMillis());
		LogUtil.logInfo(m_Logger,
				"start do update user :" + System.currentTimeMillis());
		if (updateUserAccounts.size() > 0) {
			updateUAMUser(updateUserAccounts);
		}
		LogUtil.logInfo(m_Logger,
				"end do update user :" + System.currentTimeMillis());
		outputVO.setMessage("sync users from AD success");
		LogUtil.logInfo(m_Logger,
				"end synchUserAccounts:" + System.currentTimeMillis());
		return outputVO;
	}

	private void updateUAMUser(List<Map<String, String>> updateUserAccounts)
			throws RemoteException {
		int counter = 0;
		List<Map<String, String>> updateUsers = new ArrayList<Map<String, String>>();
		for (Map<String, String> updateUser : updateUserAccounts) {
			updateUsers.add(updateUser);
			counter++;
			if (counter >= 200) {
				LogUtil.logInfo(
						m_Logger,
						"start add audit do update user :"
								+ System.currentTimeMillis());
				// audit trail 2018/06/14 add by cuixin -Start
				updateUserAuditTrail(updateUsers);
				// audit trail 2018/06/14 add by cuixin -End
				LogUtil.logInfo(m_Logger, "end add audit do update user :"
						+ System.currentTimeMillis());
				counter = 0;
				userAuthorityDao.updateUAMUsers(updateUsers);
				updateUsers = new ArrayList<Map<String, String>>();
			}
		}
		if (updateUsers.size() > 0) {
			// audit trail 2018/06/14 add by cuixin -Start
			updateUserAuditTrail(updateUsers);
			// audit trail 2018/06/14 add by cuixin -End
			userAuthorityDao.updateUAMUsers(updateUsers);
		}
	}

	private boolean userActInAD(
			final Map<String, Map<String, String>> allUsersFromC360,
			final Map<String, Map<String, String>> allUsersFromAD,
			List<Map<String, String>> updateUserAccounts,
			List<String> notInAdUsers, Set<String> allADUserIds,
			List<String> inActiveUsers, String sonoraLanId) {
		// if user is not in AD, and it's from AD, then it's a user which is
		// no longer
		// in AD
		boolean fromAD = false;
		Map<String, String> tUser = allUsersFromC360.get(sonoraLanId);
		if (tUser == null) {
			return fromAD;
		}
		 fromAD = CommonUtil
				.getBooleanValue("1".equalsIgnoreCase(tUser
						.get(UAMConstants.FROMAD)), false);

		if (!allADUserIds.contains(sonoraLanId)) {
			if (fromAD) {
				notInAdUsers.add(sonoraLanId);
			}
		} else {// if user is in AD, update user info
			Map<String, String> userFromC360 = allUsersFromC360
					.get(sonoraLanId);
			Map<String, String> userFromAD = allUsersFromAD
					.get(sonoraLanId);
			String departmentC360 = CommonUtil.getString(
					userFromC360.get("UAM_USER_DEPARTMENT"), "");
			String officeC360 = CommonUtil.getString(
					userFromC360.get("UAM_USER_OFFICE_NUMBER"), "");
			String companyC360 = CommonUtil.getString(
					userFromC360.get(CALCOMPANY), "");
			String displayNMC360 = CommonUtil.getString(
					userFromC360.get(DISPLAYNAME), "");
			String emailC360 = CommonUtil.getString(
					userFromC360.get(DELIVERYSTRING), "");
			String departmentAD = CommonUtil.getString(
					userFromAD.get(UAMConstants.UAM_USER_DEPARTMENT), "");
			String officeAD = CommonUtil
					.getString(userFromAD
							.get(UAMConstants.UAM_USER_OFFICE_NUMBER), "");
			String companyAD = CommonUtil.getString(
					userFromAD.get(UAMConstants.USERCOMPANY), "");
			String displayNMAD = CommonUtil.getString(
					userFromAD.get(UAMConstants.DISPLAYNAME), "");
			String emailAD = CommonUtil.getString(
					userFromAD.get(UAMConstants.DELIVERYSTRING), "");
			if (compareADc360Data(fromAD, departmentC360, departmentAD,
					officeC360, officeAD, companyC360, companyAD,
					displayNMC360, displayNMAD, emailC360, emailAD)) {
				userFromC360.put(UAMConstants.DISPLAYNAME, displayNMAD);
				userFromC360.put(UAMConstants.DELIVERYSTRING, emailAD);
				userFromC360.put(UAMConstants.UAM_USER_OFFICE_NUMBER,
						officeAD);
				userFromC360.put(UAMConstants.UAM_USER_DEPARTMENT,
						departmentAD);
				userFromC360.put(UAMConstants.USERCOMPANY, companyAD);
				userFromC360.put(LOWERUSERID, sonoraLanId);
				userFromC360.put(UAMConstants.FROMAD, "1");
				updateUserAccounts.add(userFromC360);
			}
			// if user status is Terminated, update user status to Inactive
			if (Constants.USER_STATUS_TERMINATE.toUpperCase()
					.equalsIgnoreCase(
							userFromC360.get("ACTIVESTATUS") == null ? ""
									: userFromC360.get("ACTIVESTATUS")
											.toUpperCase())) {
				inActiveUsers.add(sonoraLanId);
			}
		}
		return fromAD;
	}

	private boolean compareADc360Data(boolean fromAD, String... params) {
		String departmentC360 = params[0];
		String departmentAD = params[1];
		String officeC360 = params[2];
		String officeAD = params[3];
		String companyC360 = params[4];
		String companyAD = params[5];
		String displayNMC360 = params[6];
		String displayNMAD = params[7];
		String emailC360 = params[8];
		String emailAD = params[9];
		return !departmentC360.equals(departmentAD)
				|| !officeC360.equals(officeAD)
				|| !companyC360.equals(companyAD) || !fromAD
				|| !displayNMC360.equals(displayNMAD)
				|| !emailC360.equals(emailAD);
	}

	private Map<String, Map<String, String>> getC360Users() {
		List<Map<String, String>> userInfoList = userAuthorityDao
				.queryC360Users();
		Map<String, Map<String, String>> userAccounts = new HashMap<String, Map<String, String>>();
		if (userInfoList != null && userInfoList.size() > 0) {
			for (Map<String, String> user : userInfoList) {
				userAccounts.put(user.get(UAMConstants.LOGINID).toUpperCase(),
						user);
			}
		}
		return userAccounts;
	}

	// get SONORAUsersTable from parameter
	private List<Map<String, String>> updateSonoraUsersTable(
			List<Map<String, String>> userAccount) {
		for (Map<String, String> user : userAccount) {
			user.put("loginID", user.get(UAMConstants.LOGINID));
			user.put(
					"displayName",
					StringUtils.isBlank(user.get(UAMConstants.DISPLAYNAME)) ? user
							.get(UAMConstants.LOGINID) : user
							.get(UAMConstants.DISPLAYNAME));
			user.put("status", "false");
			user.put("deliveryString", user.get(UAMConstants.DELIVERYSTRING));
		}
		return userAccount;
	}

	// createUserAccount for synchUserAccounts
	private void newUserAccount(List<Map<String, String>> newUsers)
			throws RemoteException {
		LogUtil.logInfo(m_Logger,
				"start do add new user audit :" + System.currentTimeMillis());
		// audit trail 2018/06/14 add by cuixin -Start
		addNewUserAuditTrail(newUsers);
		// audit trail 2018/06/14 add by cuixin -End
		LogUtil.logInfo(m_Logger,
				"end do add new user audit :" + System.currentTimeMillis());
		// create users in toolbox firstly
		updateSonoraUsersTable(newUsers);
		// create AD users in sonora users
		for (Map<String, String> tUser : newUsers) {
			userHelper.createUser(tUser);
			roleHelper.updateRoles(NORMALUSERROLE, tUser.get("loginID"));
		}
		// create AD users in UAM user
		int counter = 0;// to do insert with each 500 records
		List<Map<String, String>> newUserList = new ArrayList<Map<String, String>>();
		for (Map<String, String> newUser : newUsers) {
			newUserList.add(newUser);
			counter++;
			if (counter >= 400) {
				counter = 0;
				userAuthorityDao.insertUAMUsers(newUserList);
				newUserList = new ArrayList<Map<String, String>>();
			}
		}
		if (newUserList.size() > 0) {
			userAuthorityDao.insertUAMUsers(newUserList);
		}
	}

	private void addNewUserAuditTrail(List<Map<String, String>> newUsers)
			throws RemoteException, RemoteException {
		String userIds = "";
		int counter = 0;
		UAMUserSyncAuditTrail userSyncAuditTrail = null;
		String userId = userHelper.getCurrentUser();
		for (Map<String, String> newUser : newUsers) {
			if (StringUtils.isEmpty(newUser.get(UAMConstants.LOGINID))) {
				continue;
			}
			userIds = getActDesc2(userIds);
			userIds += newUser.get(UAMConstants.LOGINID);

			counter++;

			if (counter >= 50) {
				counter = 0;

				userSyncAuditTrail = new UAMUserSyncAuditTrail();
				userSyncAuditTrail.setUamUserId(userIds);
				userSyncAuditTrail.setCurUser(userId);
				userSyncAuditTrail.setOpFlag(1);
				auditTrailDao.syncUAMUserAuditTrail(userSyncAuditTrail);

				userIds = "";
			}
		}
		if (userIds.length() > 0) {
			// create sync audit trail
			userSyncAuditTrail = new UAMUserSyncAuditTrail();
			userSyncAuditTrail.setUamUserId(userIds);
			userSyncAuditTrail.setCurUser(userId);
			userSyncAuditTrail.setOpFlag(1);
			auditTrailDao.syncUAMUserAuditTrail(userSyncAuditTrail);
		}
	}

	private void updateUserStatusAuditTrail(List<String> users,
			String activeStatus) throws RemoteException, RemoteException {
		String userIds = "";
		int counter = 0;
		UAMUserSyncAuditTrail userSyncAuditTrail = null;
		String userId = userHelper.getCurrentUser();
		String status = "";
		for (int i = 0; i < users.size(); i++) {
			if (StringUtils.isEmpty(users.get(i))) {
				continue;
			}
			if (userIds.length() > 0) {
				userIds += ",";
				status += ",";
			}
			userIds += users.get(i);
			status += activeStatus;
			counter++;

			if (counter >= 20) {
				counter = 0;

				userSyncAuditTrail = new UAMUserSyncAuditTrail();
				userSyncAuditTrail.setActiveStatus(status);
				userSyncAuditTrail.setUamUserId(userIds);
				userSyncAuditTrail.setCurUser(userId);
				userSyncAuditTrail.setOpFlag(3);
				auditTrailDao.syncUAMUserAuditTrail(userSyncAuditTrail);

				userIds = "";
				status = "";
			}

		}
		if (userIds.length() > 0) {
			// create sync audit trail
			userSyncAuditTrail = new UAMUserSyncAuditTrail();
			userSyncAuditTrail.setActiveStatus(status);
			userSyncAuditTrail.setUamUserId(userIds);
			userSyncAuditTrail.setCurUser(userId);
			userSyncAuditTrail.setOpFlag(3);
			auditTrailDao.syncUAMUserAuditTrail(userSyncAuditTrail);
		}
	}

	private String getBlankValue(String valueName) {
		return StringUtils.isBlank(valueName) ? "" : valueName;
	}

	private void updateUserAuditTrail(List<Map<String, String>> users)
			throws RemoteException, RemoteException {

		String userIds = "";
		String displayNames = "";
		String deliveryStrings = "";
		String userCompanys = "";
		String uamUserOfficeNumbers = "";
		String uamUserDepartments = "";
		int counter = 0;
		String userId = userHelper.getCurrentUser();
		UAMUserSyncAuditTrail userSyncAuditTrail = null;
		for (Map<String, String> user : users) {
			if (user == null || StringUtils.isEmpty(user.get(LOWERUSERID))) {
				continue;
			}
			if (userIds.length() > 0) {
				userIds += ",";
				displayNames += ";";
				deliveryStrings += ";";
				userCompanys += ",";
				uamUserOfficeNumbers += ",";
				uamUserDepartments += ",";
			}
			userIds += user.get(LOWERUSERID);
			displayNames += StringUtils.isBlank(user
					.get(UAMConstants.DISPLAYNAME)) ? user
					.get(UAMConstants.LOGINID) : user
					.get(UAMConstants.DISPLAYNAME);
			deliveryStrings += getBlankValue(user
					.get(UAMConstants.DELIVERYSTRING));
			userCompanys += getBlankValue(user.get(UAMConstants.USERCOMPANY));
			uamUserOfficeNumbers += getBlankValue(user
					.get(UAMConstants.UAM_USER_OFFICE_NUMBER));
			uamUserDepartments += getBlankValue(user
					.get(UAMConstants.UAM_USER_DEPARTMENT));
			counter++;

			if (counter >= 50) {
				counter = 0;
				userSyncAuditTrail = new UAMUserSyncAuditTrail();
				userSyncAuditTrail.setUamUserDepartment(uamUserDepartments);
				userSyncAuditTrail.setUamUserOfficeNumber(uamUserOfficeNumbers);
				userSyncAuditTrail.setUserCompany(userCompanys);
				userSyncAuditTrail.setDisplayName(displayNames);
				userSyncAuditTrail.setDeliveryString(deliveryStrings);
				userSyncAuditTrail.setUamUserId(userIds);
				userSyncAuditTrail.setCurUser(userId);
				userSyncAuditTrail.setOpFlag(2);
				LogUtil.logInfo(m_Logger, "updateUserAuditTrail param:"
						+ userSyncAuditTrail.toString());
				auditTrailDao.syncUAMUserAuditTrail(userSyncAuditTrail);

				userIds = "";
				displayNames = "";
				deliveryStrings = "";
				userCompanys = "";
				uamUserOfficeNumbers = "";
				uamUserDepartments = "";
			}
		}
		if (userIds.length() > 0) {
			// create sync audit trail
			userSyncAuditTrail = new UAMUserSyncAuditTrail();
			userSyncAuditTrail.setUamUserDepartment(uamUserDepartments);
			userSyncAuditTrail.setUamUserOfficeNumber(uamUserOfficeNumbers);
			userSyncAuditTrail.setUserCompany(userCompanys);
			userSyncAuditTrail.setDisplayName(displayNames);
			userSyncAuditTrail.setDeliveryString(deliveryStrings);
			userSyncAuditTrail.setUamUserId(userIds);
			userSyncAuditTrail.setCurUser(userId);
			userSyncAuditTrail.setOpFlag(2);
			LogUtil.logInfo(m_Logger, "updateUserAuditTrail param:"
					+ userSyncAuditTrail.toString());
			auditTrailDao.syncUAMUserAuditTrail(userSyncAuditTrail);
		}
	}

	private void editUserAuditTrail(UamUser user) throws RemoteException,
			RemoteException {
		String uamUserId = user.getUserId().toUpperCase();
		String displayName = user.getUserName();
		String deliveryString = user.getEmail();
		String activeStatus = user.getStatus();
		List<String> roleIds = user.getRoleIds();
		String roleIdStr = "";
		for (int i = 0; roleIds != null && i < roleIds.size(); i++) {
			if (!StringUtils.isEmpty(roleIds.get(i))) {
				roleIdStr = getActDesc2(roleIdStr);
				roleIdStr += roleIds.get(i);
			}
		}
		String uamUserPhoneNumber = user.getPhoneNumber();
		String uamUserDepartment = user.getDepartment();
		String team = user.getTeam().replace("[", "").replace("]", "")
				.replace("\"", "");
		String calCompany = user.getCalendar();
		String curUserId = userHelper.getCurrentUser();
		String userCompany = user.getCompany() == null ? "" : user.getCompany();

		UAMUserEditAuditTrail editUserAuditTrail = new UAMUserEditAuditTrail();
		editUserAuditTrail.setActiveStatus(activeStatus);
		editUserAuditTrail.setDepartment(uamUserDepartment);
		editUserAuditTrail.setUamUserPhoneNumber(uamUserPhoneNumber);
		editUserAuditTrail.setUserCompany(userCompany);
		editUserAuditTrail.setCalCompany(calCompany);
		editUserAuditTrail.setDisplayName(displayName);
		editUserAuditTrail.setDeliveryString(deliveryString);
		editUserAuditTrail.setUamUserId(uamUserId);
		editUserAuditTrail.setCurUser(curUserId);
		editUserAuditTrail.setTeams(team);
		editUserAuditTrail.setRoleIds(roleIdStr);
		LogUtil.logInfo(m_Logger, "editUserAuditTrail param:"
				+ editUserAuditTrail.toString());
		auditTrailDao.editUAMUserAuditTrail(editUserAuditTrail);

	}

	@SuppressWarnings("unchecked")
	private void editUserAuthAuditTrail(Map<String, Object> params)
			throws RemoteException, RemoteException {

		// get user authority
		OutputVO oldAuthVO = getAuthority(params);
		if (!"0".equals(oldAuthVO.getCode())) {
			LogUtil.logError(m_Logger, oldAuthVO.getMessage());
			return;
		}
		if (params.get(USERID) == null || "".equals(params.get(USERID))) {
			LogUtil.logError(m_Logger, USERNULLERRMSG);
			return;
		}

		if (params.get(CURLOGINUSER) == null
				|| "".equals(params.get(CURLOGINUSER))) {
			LogUtil.logError(m_Logger, GETUSERERRMSG);
			return;
		}

		String userId = String.valueOf(params.get(USERID));
		String loginUserId = String.valueOf(params.get(CURLOGINUSER));
		Map<String, Object> oldAuth = (Map<String, Object>) oldAuthVO
				.getDatas();

		// check differernce and create action_desc content
		String actionDesc = "";
		// "CAPACITY"
		// "OVER_TIME_CAPACITY"
		// "TRIGGER_EMAIL"
		String actionDesc1 = getMapDiffValueMessage(oldAuth, new String[] {
				"CAPACITY", "OTCAPACITY", "TRIGGEREMAIL" }, params,
				new String[] { "CAPACITY", "OVER_TIME_CAPACITY",
						"TRIGGER_EMAIL" }, new String[] { "Capacity",
						"Over Time Capacity", "Trigger email" });

		// USERAUTH
		String actionDesc2 = "";
		List<Map<String, Object>> oldUserAuths = (List<Map<String, Object>>) oldAuth
				.get(USERAUTH);
		List<Map<String, Object>> newUserAuths = (List<Map<String, Object>>) params
				.get(USERAUTH);
		actionDesc2 = getAddAndModifyAuthMessage(oldUserAuths, newUserAuths);

		// UNIAUTH
		String actionDesc3 = "";
		List<Map<String, Object>> oldUniUserAuths = (List<Map<String, Object>>) oldAuth
				.get(UNIAUTH);
		List<Map<String, Object>> newUniUserAuths = (List<Map<String, Object>>) params
				.get(UNIAUTH);

		actionDesc3 = getAddAndModifyUniAuthMessage(oldUniUserAuths,
				newUniUserAuths);

		actionDesc = actionDesc1 + actionDesc2 + actionDesc3;

		// 2018/06/22 add audit trail add by cuixin -Start
		if (actionDesc.length() > 0) {
			actionDesc = "Edit user Authority setting: '" + userId + "':("
					+ actionDesc + ")";
			actionDesc = actionDesc.replaceAll(";,", ";").replaceAll(";\\)",
					")");
			UAMAuditTrail auditTrailParam = new UAMAuditTrail();
			auditTrailParam.setActionDesc(actionDesc);
			auditTrailParam.setCategory("USER");
			auditTrailParam.setUamComponentName(userId);
			auditTrailParam.setUamUserId(loginUserId);
			auditTrailDao.addUAMAuditTrail(auditTrailParam);
		}
		// 2018/06/22 add audit trail add by cuixin -End
	}

	private String getAddAndModifyUniAuthMessage(
			List<Map<String, Object>> oldUniUserAuths,
			List<Map<String, Object>> newUniUserAuths) {
		String actionDesc3 = "";
		if (oldUniUserAuths != null && newUniUserAuths != null
				&& newUniUserAuths.size() != 0) {
			for (int i = 0; i < newUniUserAuths.size(); i++) {
				String tsarName = String.valueOf(newUniUserAuths.get(i).get(
						TSARNAME));

				String tempDesc = getMapDiffValueMessage(
						getOldUniUserAuths(tsarName, oldUniUserAuths),
						new String[] { TSARNAME, AUTHTYPE, DEPARTMENT,
								RISKTYPE, SARGROUP, RANGEFROM, RANGETO },
						newUniUserAuths.get(i), new String[] { TSARNAME,
								AUTHTYPE, DEPARTMENT, RISKTYPE, SARGROUP,
								RANGEFROM, RANGETO }, new String[] { TSARNAME,
								AUTHTYPE, DEPARTMENT, RISKTYPE, SARGROUP,
								RANGEFROM, RANGETO });
				if (actionDesc3.length() > 0 && tempDesc.length() > 0) {
					actionDesc3 += ",";
				}
				if (tempDesc.length() > 0) {
					tempDesc = "'" + tsarName + "'(" + tempDesc + ")";
				}
				actionDesc3 += tempDesc;
			}
			if (actionDesc3.length() > 0) {
				actionDesc3 = "UNIAUTH:(" + actionDesc3 + ");";
			}
		}
		return actionDesc3;
	}

	private String getAddAndModifyAuthMessage(
			List<Map<String, Object>> oldUserAuths,
			List<Map<String, Object>> newUserAuths) {
		String actionDesc2 = "";
		if (Lists.isEmpty(oldUserAuths) || Lists.isEmpty(newUserAuths)) {
			return actionDesc2;
		}

		String reqType = "";
		String activity = "";
		String reqTypeBefore = "";
		String reqName = "";
		String actName = "";
		boolean isNewReq = false;
		boolean isFirstReq = false;
		String tempDesc2 = "";
		String department = "";
		for (int i = 0; i < newUserAuths.size(); i++) {
			reqType = String.valueOf(newUserAuths.get(i).get(REQTYPE));
			activity = String.valueOf(newUserAuths.get(i).get(ACTIVITY));

			reqName = String.valueOf(newUserAuths.get(i).get("REQNAME"));
			actName = String.valueOf(newUserAuths.get(i).get(ACTNAME));
			tempDesc2 = getMapDiffValueMessage(
					getOldUserAuths(reqType, activity, oldUserAuths),
					new String[] { TRAINER, BACKTRAINER, ACTIVITY, REQTYPE,
							ISTRAINEE }, newUserAuths.get(i),
					new String[] { TRAINER, BACKTRAINER, ACTIVITY, REQTYPE,
							ISTRAINEE }, new String[] { TRAINER, BACKTRAINER,
							ACTIVITY, REQTYPE, ISTRAINEE });

			department = String.valueOf(newUserAuths.get(i).get(DEPARTMENT));
			if ("CLM".equalsIgnoreCase(department)) {
				tempDesc2 = getCLMAction(oldUserAuths, newUserAuths, reqType,
						activity, tempDesc2, i);

			}

			if (tempDesc2.length() > 0) {
				isFirstReq = isFirstReq(reqTypeBefore);
				if (reqType.equals(reqTypeBefore)) {
					isNewReq = false;
					reqTypeBefore = reqType;
				} else {
					isNewReq = true;
				}
				actionDesc2 = getActDesc2(actionDesc2);

				tempDesc2 = getTempDesc(reqName, actName, isNewReq, isFirstReq,
						tempDesc2);

				actionDesc2 += tempDesc2;
			}
		}
		if (actionDesc2.length() > 0) {
			actionDesc2 = "'USERAUTH:(" + actionDesc2 + ");";
		}

		return actionDesc2;
	}

	private String getActDesc2(String actionDesc2) {
		if (actionDesc2.length() > 0) {
			actionDesc2 += ",";
		}
		return actionDesc2;
	}

	private boolean isFirstReq(String reqTypeBefore) {
		boolean isFirstReq;
		if (reqTypeBefore.length() == 0) {
			isFirstReq = true;
		} else {
			isFirstReq = false;
		}
		return isFirstReq;
	}

	private String getCLMAction(List<Map<String, Object>> oldUserAuths,
			List<Map<String, Object>> newUserAuths, String reqType,
			String activity, String tempDesc2, int i) {
		// AUTH
		List<Map<String, Object>> oldTASRList = (List<Map<String, Object>>) getOldUserAuths(
				reqType, activity, oldUserAuths).get("AUTH");
		List<Map<String, Object>> newTASRList = (List<Map<String, Object>>) newUserAuths
				.get(i).get("AUTH");
		/*
		 * old
		 * 
		 * REQ_ID:"CLM_Cannot_Register_Claim_Major", DESCRIPTION:"authority1",
		 * RANGETO:2, RANGEFROM:1, ACTNAME:"COM_001",
		 * AUTHTYPE:"Distribution Amount Authority"
		 * 
		 * new
		 * 
		 * REQTYPE:"CLM_Cannot_Register_Claim_Major", ACTIVITY:"COM_001",
		 * AUTHTYPE:"Distribution Amount Authority", DESCRIPTION:"authority1",
		 * RANGEFROM:1, RANGETO:2
		 */
		// deleted tasr
		String deletedTasrDesc = "";
		for (Map<String, Object> oldTASR : oldTASRList) {
			String reqIdOld = String.valueOf(oldTASR.get(REQ_ID));
			String activityNameOld = String.valueOf(oldTASR.get(ACTNAME));
			String descriptionOld = String.valueOf(oldTASR.get(DESCRIPTION));
			String authTypeOld = String.valueOf(oldTASR.get(AUTHTYPE));
			String rangeFromOld = String.valueOf(oldTASR.get(RANGEFROM));
			String rangeToOld = String.valueOf(oldTASR.get(RANGETO));
			boolean isDeleted = true;
			String[] params = new String[]{authTypeOld,rangeFromOld,rangeToOld};
			deletedTasrDesc = getDelTasrDesc(newTASRList, deletedTasrDesc,
					reqIdOld, activityNameOld, descriptionOld, isDeleted,params);

		}
		if (deletedTasrDesc.length() > 0) {
			deletedTasrDesc = "\'deleted TASR\'(" + deletedTasrDesc + ")";
		}

		// added tasr
		String addedTasrDesc = "";
		for (Map<String, Object> newTASR : newTASRList) {
			String reqIdNew = String.valueOf(newTASR.get(REQTYPE));
			String activityNameNew = String.valueOf(newTASR.get(ACTIVITY));
			String descriptionNew = String.valueOf(newTASR.get(DESCRIPTION));
			String authTypeNew = String.valueOf(newTASR.get(AUTHTYPE));
			String rangeFromNew = String.valueOf(newTASR.get(RANGEFROM));
			String rangeToNew = String.valueOf(newTASR.get(RANGETO));

			boolean isAdded = true;
			for (Map<String, Object> oldTASR : oldTASRList) {
				String reqIdOld = String.valueOf(oldTASR.get(REQ_ID));
				String activityNameOld = String.valueOf(oldTASR.get(ACTNAME));
				String descriptionOld = String
						.valueOf(oldTASR.get(DESCRIPTION));
				String authTypeOld = String.valueOf(oldTASR.get(AUTHTYPE));
				isAdded = checkDupliAct(reqIdOld, activityNameOld,
						descriptionOld, authTypeOld, reqIdNew,
						activityNameNew, descriptionNew, authTypeNew);
			}

			if (isAdded) {
				addedTasrDesc = getActDesc2(addedTasrDesc);
				addedTasrDesc += AUTHTYPESTR + authTypeNew + DESCRIPTIONSTR
						+ descriptionNew + "\',\'Authority Details\':\'"
						+ rangeFromNew + TOSTR + rangeToNew + "\')";
			}
		}
		if (addedTasrDesc.length() > 0) {
			addedTasrDesc = "\'added TASR\'(" + addedTasrDesc + ")";
		}
		String modifiedTasrDesc = "";
		for (Map<String, Object> newTASR : newTASRList) {
			String reqIdNew = String.valueOf(newTASR.get(REQTYPE));
			String activityNameNew = String.valueOf(newTASR.get(ACTIVITY));
			String descriptionNew = String.valueOf(newTASR.get(DESCRIPTION));
			String authTypeNew = String.valueOf(newTASR.get(AUTHTYPE));
			String rangeFromNew = String.valueOf(newTASR.get(RANGEFROM));
			String rangeToNew = String.valueOf(newTASR.get(RANGETO));

			boolean isModified = false;
			String reqIdOld = "";
			String activityNameOld = "";
			String descriptionOld = "";
			String authTypeOld = "";
			String rangeFromOld = "";
			String rangeToOld = "";
            String[] params = new String[]{modifiedTasrDesc,reqIdNew,activityNameNew,descriptionNew, authTypeNew,
					rangeFromNew, rangeToNew,  rangeFromOld,rangeToOld};
			modifiedTasrDesc = getModifyTasrDesc(oldTASRList, isModified);
		}
		tempDesc2 = getCLMTempDesc(tempDesc2, deletedTasrDesc, addedTasrDesc,
				modifiedTasrDesc);
		return tempDesc2;
	}

	private String getCLMTempDesc(String tempDesc2, String deletedTasrDesc,
			String addedTasrDesc, String modifiedTasrDesc) {
		if (modifiedTasrDesc.length() > 0) {
			modifiedTasrDesc = "\'modified TASR\'(" + modifiedTasrDesc + ")";
		}

		if (deletedTasrDesc.length() > 0) {
			tempDesc2 = getActDesc2(tempDesc2);
			tempDesc2 += deletedTasrDesc;
		}

		if (addedTasrDesc.length() > 0) {
			tempDesc2 = getActDesc2(tempDesc2);
			tempDesc2 += addedTasrDesc;
		}

		if (modifiedTasrDesc.length() > 0) {
			tempDesc2 = getActDesc2(tempDesc2);
			tempDesc2 += modifiedTasrDesc;
		}
		return tempDesc2;
	}

	private String getModifyTasrDesc(List<Map<String, Object>> oldTASRList,boolean isModified, 
			String... params) {
		String modifiedTasrDesc=params[0];
		String reqIdNew=params[1];
		String activityNameNew=params[2];
		String descriptionNew=params[3];
		String authTypeNew=params[4];
		String rangeFromNew=params[5];
		String rangeToNew=params[6];
		String rangeFromOld=params[7];
		String rangeToOld=params[8];
		String reqIdOld;
		String activityNameOld;
		String descriptionOld;
		String authTypeOld;
		for (Map<String, Object> oldTASR : oldTASRList) {
			reqIdOld = String.valueOf(oldTASR.get(REQ_ID));
			activityNameOld = String.valueOf(oldTASR.get(ACTNAME));
			descriptionOld = String.valueOf(oldTASR.get(DESCRIPTION));
			authTypeOld = String.valueOf(oldTASR.get(AUTHTYPE));
			rangeFromOld = String.valueOf(oldTASR.get(RANGEFROM));
			rangeToOld = String.valueOf(oldTASR.get(RANGETO));

			if (reqIdNew.equalsIgnoreCase(reqIdOld)
					&& activityNameNew.equalsIgnoreCase(activityNameOld)
					&& authTypeNew.equalsIgnoreCase(authTypeOld)
					&& descriptionNew.equalsIgnoreCase(descriptionOld)
					&& (!rangeToNew.equalsIgnoreCase(rangeFromOld) || !rangeToNew
							.equalsIgnoreCase(rangeToOld))) {
				isModified = true;
				break;
			}
		}

		if (isModified) {
			modifiedTasrDesc = getActDesc2(modifiedTasrDesc);
			modifiedTasrDesc += AUTHTYPESTR
					+ authTypeNew
					+ DESCRIPTIONSTR
					+ descriptionNew
					+ "\',\'Authority Details\':("
					+ (rangeToNew.equalsIgnoreCase(rangeFromOld) ? ""
							: "\'RangeFrom\': change from \'" + rangeFromOld
									+ TOSTR + rangeFromNew + "\'")
					+ (!rangeToNew.equalsIgnoreCase(rangeFromOld)
							&& !rangeToNew.equalsIgnoreCase(rangeToOld) ? ","
							: "")
					+ (!rangeToNew.equalsIgnoreCase(rangeToOld) ? "\'RangeTo\': change from \'"
							+ rangeToOld + TOSTR + rangeToNew + "\'"
							: "") + "))";
		}
		return modifiedTasrDesc;
	}

	private String getDelTasrDesc(List<Map<String, Object>> newTASRList,
			String deletedTasrDesc, String reqIdOld, String activityNameOld,
			String descriptionOld,  boolean isDeleted,String...  params) {
		    String authTypeOld=params[0];
		    String rangeFromOld=params[1];
		    String rangeToOld=params[2];
		for (Map<String, Object> newTASR : newTASRList) {
			String reqIdNew = String.valueOf(newTASR.get(REQTYPE));
			String activityNameNew = String.valueOf(newTASR.get(ACTIVITY));
			String descriptionNew = String.valueOf(newTASR.get(DESCRIPTION));
			String authTypeNew = String.valueOf(newTASR.get(AUTHTYPE));
			isDeleted = checkDupliAct(reqIdOld, activityNameOld,
					descriptionOld, authTypeOld,  reqIdNew,
					activityNameNew, descriptionNew, authTypeNew);
			if (!isDeleted)
				break;
		}

		if (isDeleted) {
			deletedTasrDesc = getActDesc2(deletedTasrDesc);
			deletedTasrDesc += AUTHTYPESTR + authTypeOld + DESCRIPTIONSTR
					+ descriptionOld + "\',\'Authority Details\':\'"
					+ rangeFromOld + TOSTR + rangeToOld + "\')";
		}
		return deletedTasrDesc;
	}

	private boolean checkDupliAct(String reqIdOld, String activityNameOld,
			String descriptionOld, String authTypeOld,
			String reqIdNew,String... params ) {
		String activityNameNew=params[0];
		String descriptionNew=params[1];
		String authTypeNew=params[2];
		if (reqIdNew.equalsIgnoreCase(reqIdOld)
				&& activityNameNew.equalsIgnoreCase(activityNameOld)
				&& authTypeNew.equalsIgnoreCase(authTypeOld)
				&& descriptionNew.equalsIgnoreCase(descriptionOld)) {
			return false;
		}
		return true;
	}

	private String getTempDesc(String reqName, String actName,
			boolean isNewReq, boolean isFirstReq, String tempDesc2) {
		if (isNewReq) {
			if (isFirstReq) {
				tempDesc2 = "'" + reqName + "'" + "('" + actName + "'("
						+ tempDesc2 + ")";
			} else {
				tempDesc2 = ");'" + reqName + "'" + "('" + actName + "'("
						+ tempDesc2 + ")";
			}
		} else {
			tempDesc2 = "," + "'" + actName + "'(" + tempDesc2 + ")";
		}
		return tempDesc2;
	}

	private Map<String, Object> getOldUserAuths(String reqType,
			String activity, List<Map<String, Object>> oldUserAuths) {
		Map<String, Object> result = new HashMap<String, Object>();
		if (oldUserAuths != null && oldUserAuths.size() > 0) {
			for (Map<String, Object> map : oldUserAuths) {
				if (reqType.equals(map.get(REQTYPE))
						&& activity.equals(map.get(ACTIVITY))) {
					result = map;
					break;
				}
			}
		}

		return result;
	}

	private Map<String, Object> getOldUniUserAuths(String tsrName,
			List<Map<String, Object>> oldUniUserAuths) {
		Map<String, Object> result = new HashMap<String, Object>();
		if (oldUniUserAuths != null && oldUniUserAuths.size() > 0) {
			for (Map<String, Object> map : oldUniUserAuths) {
				if (tsrName.equals(map.get(TSARNAME))) {
					result = map;
					break;
				}
			}
		}

		return result;
	}

	private String getMapDiffValueMessage(Map<String, Object> oldMap,
			String[] oldKey, Map<String, Object> newMap, String[] newKey,
			String[] alias) {

		if (newMap == null || newMap.isEmpty() || newKey == null
				|| newKey.length == 0) {
			return "";
		}

		if (oldMap == null || oldMap.isEmpty()) {
			return getNreAct(newMap, newKey, alias);
		}

		String oldValue = "";
		String newValue = "";
		String actionDesc = "";
		String aliaName = "";
		for (int i = 0; i < newKey.length; i++) {
			actionDesc = getActDesc(oldMap, oldKey, newMap, newKey, alias,
					actionDesc, i);
		}

		return actionDesc;
	}

	private String getNreAct(Map<String, Object> newMap, String[] newKey,
			String[] alias) {
		String newValue = "";
		String actionDesc = "";
		String aliaName = "";
		for (int i = 0; i < newKey.length; i++) {
			newValue = newMap.get(newKey[i]) == null ? "" : String
					.valueOf(newMap.get(newKey[i]));
			actionDesc = getActDesc2(actionDesc);
			aliaName = alias != null && alias.length > i
					&& !StringUtils.isEmpty(alias[i]) ? alias[i]
					: newKey[i];
			actionDesc += "'" + aliaName + ":'" + newValue + "';";
		}
		return "(new)" + actionDesc;
	}

	private String getActDesc(Map<String, Object> oldMap, String[] oldKey,
			Map<String, Object> newMap, String[] newKey, String[] alias,
			String actionDesc, int i) {
		String oldValue;
		String newValue;
		String aliaName;
		oldValue = oldMap.get(oldKey[i]) == null ? "" : String
				.valueOf(oldMap.get(oldKey[i]));
		newValue = newMap.get(newKey[i]) == null ? "" : String
				.valueOf(newMap.get(newKey[i]));
		if (!newValue.equalsIgnoreCase(oldValue)) {
			actionDesc = getActDesc2(actionDesc);
			aliaName = alias != null && alias.length > i
					&& !StringUtils.isEmpty(alias[i]) ? alias[i]
					: newKey[i];
			actionDesc += "'" + aliaName + "' change from '" + oldValue
					+ "' to '" + newValue + "';";
		}
		return actionDesc;
	}

	@Override
	public boolean updateUser(JSONObject userParamas) throws RemoteException {
		new HashMap<String, List<String>>();

		JSONObject baseuser = userParamas.getJSONObject("USERACCOUNT");

		String userId = baseuser.getString("USER_ID");
		String team = baseuser.getString("TEAM") == null ? "" : baseuser
				.getString("TEAM");
		String phoneNumber = baseuser.getString("PHONENUMBER");
		String userName = baseuser.getString(DISPLAYNAME);
		String email = baseuser.getString(DELIVERYSTRING);
		String userStatus = baseuser.getString("STATUS");
		String calendar = baseuser.getString(CALCOMPANY);
		String company = baseuser.getString(COMPANY);
		String orgCompany = baseuser.getString("ORG_COMPANY");
		String orgDepartment = baseuser.getString("ORG_DEPARTMENT");
		JSONArray userRoles = userParamas.getJSONArray("USERROLES");  
		
		List<String> roleIds = new ArrayList<String>();
		for (int i = 0; i < userRoles.size(); i++) {
			if (userRoles.get(i) == null) {
				continue;
			}
			if (!roleIds.contains(userRoles.getString(i))) {
				roleIds.add(userRoles.getString(i));
			}
		}
		// add department
		String department = baseuser.getString(DEPARTMENT) == null ? ""
				: baseuser.getString(DEPARTMENT);
		//if user department or company changed, clear user configured columns
		processUserColumnConfig(company, orgCompany, department, orgDepartment, userId);
		UamUser uamuser = new UamUser();
		uamuser.setUserId(userId);
		uamuser.setUserName(userName);
		uamuser.setPhoneNumber(phoneNumber);
		uamuser.setEmail(email);
		uamuser.setStatus(userStatus);
		uamuser.setTeam(team);
		uamuser.setRoleIds(roleIds);
		uamuser.setDepartment(department);
		uamuser.setCalendar(calendar);
		uamuser.setCompany(company);
		// 2018/06/21 add audit trail add by cuixin -Start
		editUserAuditTrail(uamuser);
		// 2018/06/21 add audit trail add by cuixin -End

		userAuthorityDao.updateUser(uamuser);// change to use mybatis by charley 20180611
		// delete user roles
		userAuthorityDao.deleteUserRoles(userId);
		// insert user roles
		if (roleIds != null && roleIds.size() > 0) {
			userAuthorityDao.insertUserRoles(roleIds, userId);
		}
		// delete user teams
		userAuthorityDao.deleteUserTeams(userId);
		// insert user teams
		final String[] teams = team.replace("[", "").replace("]", "")
				.replace("\"", "").split(",");
		if (teams != null && teams.length > 0 && !StringUtils.isEmpty(teams[0])) {
			userAuthorityDao.insertUserTeams(teams, userId);
		}
		// add logic: when user's status is updated to inActive or Terminate,
		// update cases' owner to null for which owner is this user and case is
		// not refer&counter sign by charley 2018/6/5
		if (!"Active".equalsIgnoreCase(userStatus)) {
			List<String> caseIdList = userAuthorityDao.getCaseIdByProcessor(userId);
			// write audit trail
			for(String caseId : caseIdList){
				CaseAuditTrailVO caseAuditTrail = new CaseAuditTrailVO("user " + userId + " is inactive, clear case owner", "system", new Date(),
						caseId, "CLEAROWNER", false);
				// add audit trail
				caseAuditDao.createCaseAudit(caseAuditTrail);
			}
			userAuthorityDao.clearInactiveUserCaseOwner(userId);
		}
		if (!"SONORA".equalsIgnoreCase(userId)) {
			// add logic to update  user admin auth, when user has user account management auth,
			// then give the user admin auth, else remove it by charley 20180925
			userAuthorityDao.updateUserAdminAuth(userId);
		}
		return true;
	}

	private void processUserColumnConfig(String company, String orgCompany,
			String department, String orgDepartment, String userId) {
		if(!CommonUtil.getString(company, "").equalsIgnoreCase(CommonUtil.getString(orgCompany, "")) || !CommonUtil.getString(department, "").equalsIgnoreCase(CommonUtil.getString(orgDepartment, ""))){
			try {
				userAuthorityDao.clearUserColumnConfigure(userId);
			} catch (RemoteException e) {
				LogUtil.logError(m_Logger, "clear user column configuration failed:", e);
			}
		}
		
	}

	@Override
	public OutputVO getAuthority(Map<String, Object> params)
			throws RemoteException {
		OutputVO outputVO = new OutputVO();
		LogUtil.logInfo(m_Logger, "service getAuthority start");
		String userId = params.get(USERID) == null ? "" : params.get(USERID)
				.toString();
		LogUtil.logInfo(m_Logger, "userId:" + userId);
		if (StringUtils.isBlank(userId)) {
			LogUtil.logInfo(m_Logger, "user id is null");
			outputVO.addErrorInfo("user id cannot be null");
			return outputVO;
		}
		// get user skill set info : Capacity, OT Capacity, TRIGGER_EMAIL
		Map<String, Object> userAuthMap = new ConcurrentHashMap<String, Object>();
		List<Map<String, Object>> userSkillList = userAuthorityDao
				.queryUserSkillSet(userId);
		if (userSkillList != null && userSkillList.size() > 1) {
			LogUtil.logInfo(m_Logger,
					"user has more than 1 skill set, cannot be edit");
			outputVO.addErrorInfo("user has more than 1 skill set, cannot be edit");
			return outputVO;
		} else if (userSkillList != null && userSkillList.size() == 1) {
			userAuthMap = userSkillList.get(0);
		}
		// get user request type, activity
		List<Map<String, Object>> userTrainRoleReqActInfoList = userAuthorityDao
				.queryUserTrainRoleReqActInfo(userId);
		// get user Authority
		List<Map<String, Object>> userTSARRecords = userAuthorityDao
				.queryUserTSARRecords(userId);
		// construct result
		if (userTrainRoleReqActInfoList != null
				&& userTrainRoleReqActInfoList.size() > 0) {
			for (Map<String, Object> roleReqActInfo : userTrainRoleReqActInfoList) {
				addRoleReqActInfo(userTSARRecords, roleReqActInfo);
			}
		}
		userAuthMap.put(USERAUTH, userTrainRoleReqActInfoList);
		// query UNI TSAR authority
		List<Map<String, Object>> userUNITSARRecords = userAuthorityDao
				.queryUserUNITSARRecords(userId, Constants.DEPARTMENT_UNI);
		userAuthMap.put(UNIAUTH, userUNITSARRecords);
		// return
		outputVO.setDatas(userAuthMap);
		return outputVO;
	}

	private void addRoleReqActInfo(List<Map<String, Object>> userTSARRecords,
			Map<String, Object> roleReqActInfo) {
		String reqType;
		String actName;
		reqType = roleReqActInfo.get(REQTYPE) == null ? ""
				: roleReqActInfo.get(REQTYPE).toString();
		actName = roleReqActInfo.get(ACTIVITY) == null ? ""
				: roleReqActInfo.get(ACTIVITY).toString();
		List<Map<String, Object>> userTSARAuthList = new ArrayList<Map<String, Object>>();
		if (!StringUtils.isBlank(reqType)
				&& !StringUtils.isBlank(actName)
				&& userTSARRecords != null
				&& userTSARRecords.size() > 0) {
			addTasrRecord(userTSARRecords, reqType, actName,
					userTSARAuthList);
		}
		roleReqActInfo.put("AUTH", userTSARAuthList);
	}

	private void addTasrRecord(List<Map<String, Object>> userTSARRecords,
			String reqType, String actName,
			List<Map<String, Object>> userTSARAuthList) {
		String reqTypeT;
		String actNameT;
		for (Map<String, Object> userTsarRecord : userTSARRecords) {
			reqTypeT = userTsarRecord.get(REQ_ID) == null ? ""
					: userTsarRecord.get(REQ_ID).toString();
			actNameT = userTsarRecord.get(ACTNAME) == null ? ""
					: userTsarRecord.get(ACTNAME).toString();
			if (reqType.equalsIgnoreCase(reqTypeT)
					&& actName.equalsIgnoreCase(actNameT)
					&& !userTSARAuthList.contains(userTsarRecord)) {
				userTSARAuthList.add(userTsarRecord);
			}
		}
	}

	@Override
	public List<UserAuthorityVO> getAuthorityById(String userId)
			throws RemoteException {
		return userAuthorityDao.queryAuthorityByUserId(userId);
	}

	@Override
	public List<Map<String, Object>> getUserInfoInFirestNodeByReq(String req) {
		return userAccountDao.getUserInfoInFirestNodeByReq(req);
	}

	@Override
	public String getCurrentUserDepartment() throws RemoteException {

		String userId = userHelper.getCurrentUser();

		return getUserDepartment(userId);
	}

	@Override
	public Map<String, Object> getTraineeByUserAct(Map<String, String> param)
			throws RemoteException {
		String userId = userHelper.getCurrentUser();
		param.put(LOWERUSERID, userId);
		List<Map<String, Object>> rs = userAccountDao.getTrainee(param);
		Map<String, Object> traineeInfo = rs.get(0);
		String isTrainee = String.valueOf(traineeInfo.get("IS_TRAINEE"));
		if ("N".equalsIgnoreCase(isTrainee)) {
			throw new RemoteException("not Trainee");
		}
		return traineeInfo;
	}

	// added by bsnpc1g
	@Override
	public List<Map<String, String>> getCurrentUserCompany()
			throws RemoteException {

		String userId = userHelper.getCurrentUser();
		String currentUserCompany = userAccountDao.getCompanyByUserId(userId);
		List<Map<String, String>> companyList = new ArrayList<Map<String, String>>();
		if (currentUserCompany.contains("Brunei")
				|| currentUserCompany.toUpperCase().contains("BRU")) {// add
																		// logic
																		// to
																		// capture
																		// BRU
																		// by
																		// charley
																		// 20181011
			HashMap<String, String> company = new HashMap<String, String>();
			company.put(COMPANY, "BRU");
			companyList.add(company);
		} else {
			HashMap<String, String> company1 = new HashMap<String, String>();
			company1.put(COMPANY, "All");
			companyList.add(company1);
			HashMap<String, String> company2 = new HashMap<String, String>();
			company2.put(COMPANY, "SGP");
			companyList.add(company2);
			HashMap<String, String> company3 = new HashMap<String, String>();
			company3.put(COMPANY, "BRU");
			companyList.add(company3);
		}
		return companyList;

	}

	@Override
	public List<Map<String, String>> getUserTeam() throws RemoteException {
		List<Map<String, String>> teamList = userAuthorityDao.getAllTeamList();
		LogUtil.logInfo(m_Logger, "teamList:" + teamList);
		return teamList;
	}

	// added end

	@Override
	public List<Map<String, String>> getUserTeamAndRole(String userId)
			throws RemoteException {

		return userAccountDao.getUserTeamAndRole(userId);
	}

	/**
	 * query users which can be chosen as leader by charley
	 */
	@Override
	public OutputVO getLeaderUsers(Map<String, Object> request)
			throws RemoteException {
		OutputVO outputVO = new OutputVO();
		String userName = request.get("USERNAME") == null ? "" : request.get(
				"USERNAME").toString();
		List<Map<String, String>> leaderUsers = userAuthorityDao
				.queryLeaderUsers("%" + userName + "%", "%" + userName + "%");
		LogUtil.logInfo(m_Logger, "leaderUsers:" + leaderUsers);
		outputVO.setDatas(leaderUsers);
		return outputVO;
	}

	@Override
	public List<Map<String, String>> getUserList(JSONObject params)
			throws RemoteException {
		new OutputVO();

		String teamId = params.getString("teamId");
		String userId = params.getString(LOWERUSERID);
		String userName = params.getString("userName");
		LogUtil.logInfo(m_Logger, "getUserList start:" + "teamId : " + teamId
				+ ";userId : " + userId + ";userName : " + userName);

		Map<String, String> param = new HashMap<String, String>();
		param.put("teamId", teamId);
		param.put(LOWERUSERID, userId);
		param.put("userName", userName);
		List<Map<String, String>> result = userAuthorityDao
				.queryUserList(param);
		LogUtil.logInfo(m_Logger,
				"getUserList end, result:" + result.toString());
		return result;
	}

	/**
	 * get user's department
	 */
	@Override
	public String getUserCompany(String userId) throws RemoteException {
		// get user's team or sub team or department directly
		List<Map<String, Object>> userTeamComponents = userAuthorityDao
				.queryUserDepartment(userId);
		if (userTeamComponents.isEmpty()) {
			return null;
		}
		String teamId = userTeamComponents.get(0).get(TEAMID) == null ? ""
				: userTeamComponents.get(0).get(TEAMID).toString();
		if (userTeamComponents.isEmpty() || StringUtils.isBlank(teamId)) {
			return null;
		}
		// get component tree datas
		List<Map<String, Object>> teamComponents = userAuthorityDao
				.queryAllComponent();
		if (teamComponents.isEmpty()) {
			return null;
		}
		// iterator user's team's parent team, until find department
		String department = getCompany(teamId, teamComponents);
		// return department
		return department;
	}

	private String getCompany(String teamId,
			List<Map<String, Object>> teamComponents) {
		Map<String, Object> curTeamMap = null;
		String tTeamId;
		for (Map<String, Object> m : teamComponents) {
			tTeamId = m.get(TEAMID) == null ? "" : m.get(TEAMID).toString();
			if (teamId.equalsIgnoreCase(tTeamId)) {
				curTeamMap = m;
				break;
			}
		}
		if (curTeamMap == null) {
			return null;
		}
		String teamType = curTeamMap.get(TEAMTYPE) == null ? "" : curTeamMap
				.get(TEAMTYPE).toString();
		if (COMPANY.equalsIgnoreCase(teamType)) {
			return curTeamMap.get(TEAMNAME) == null ? "" : curTeamMap.get(
					TEAMNAME).toString();
		}
		String parentId = curTeamMap.get(PARENTID) == null ? "" : curTeamMap
				.get(PARENTID).toString();
		if (StringUtils.isBlank(parentId) || "null".equalsIgnoreCase(parentId)) {
			return null;
		}
		return getCompany(parentId, teamComponents);
	}

	/**
	 * get user's department
	 */
	@Override
	public String getUserDepartment(String userId) throws RemoteException {
		LogUtil.logInfo(m_Logger, "service getUserDepartment start");
		// to get user department from uam user table first, if not found, get department by team
		String department = userAuthorityDao.getUamUserDepartment(userId);
		if(!StringUtils.isBlank(department)){
			LogUtil.logInfo(m_Logger, "service getUserDepartment end");
			return department;
		}
		// get user's team or sub team or department directly
		List<Map<String, Object>> userTeamComponents = userAuthorityDao
				.queryUserDepartment(userId);
		if (userTeamComponents.isEmpty()) {
			return null;
		}
		String teamId = userTeamComponents.get(0).get(TEAMID) == null ? ""
				: userTeamComponents.get(0).get(TEAMID).toString();
		if (userTeamComponents.isEmpty() || StringUtils.isBlank(teamId)) {
			return null;
		}
		// get component tree datas
		List<Map<String, Object>> teamComponents = userAuthorityDao
				.queryAllComponent();
		if (teamComponents.isEmpty()) {
			return null;
		}
		// iterator user's team's parent team, until find department
		department = getDepartment(teamId, teamComponents);
		// return department
		return department;
	}

	private String getDepartment(String teamId,
			List<Map<String, Object>> teamComponents) {
		Map<String, Object> curTeamMap = null;
		String tTeamId;
		for (Map<String, Object> m : teamComponents) {
			tTeamId = m.get(TEAMID) == null ? "" : m.get(TEAMID).toString();
			if (teamId.equalsIgnoreCase(tTeamId)) {
				curTeamMap = m;
				break;
			}
		}
		if (curTeamMap == null) {
			return null;
		}
		String teamType = curTeamMap.get(TEAMTYPE) == null ? "" : curTeamMap
				.get(TEAMTYPE).toString();
		if (DEPARTMENT.equalsIgnoreCase(teamType)) {
			return curTeamMap.get(TEAMNAME) == null ? "" : curTeamMap.get(
					TEAMNAME).toString();
		}
		String parentId = curTeamMap.get(PARENTID) == null ? "" : curTeamMap
				.get(PARENTID).toString();
		if (StringUtils.isBlank(parentId) || "null".equalsIgnoreCase(parentId)) {
			return null;
		}
		return getDepartment(parentId, teamComponents);
	}

	/**
	 * update user's authority delete first, insert second
	 */
	@SuppressWarnings("unchecked")
	@Transactional("txManager")
	@Override
	public OutputVO updateUserAuth(Map<String, Object> params)
			throws RemoteException {
		LogUtil.logInfo(m_Logger, "service updateUserAuth start. params:"
				+ params);
		OutputVO outputVO = new OutputVO();
		// get user id & user skill set info
		String userId = params.get(USERID) == null ? "" : params.get(USERID)
				.toString();
		if (StringUtils.isBlank(userId)) {
			LogUtil.logInfo(m_Logger, USERNULLERRMSG);
			outputVO.addErrorInfo(USERNULLERRMSG);
			return outputVO;
		}
		// get current user id
		String currentUserId = params.get(CURLOGINUSER) == null ? "" : params
				.get(CURLOGINUSER).toString();
		if (StringUtils.isBlank(currentUserId)) {
			LogUtil.logInfo(m_Logger, GETUSERERRMSG);
			outputVO.addErrorInfo(GETUSERERRMSG);
			return outputVO;
		}

		// 2018/06/21 add audit trail add by cuixin -Start
		editUserAuthAuditTrail(params);
		// 2018/06/21 add audit trail add by cuixin -End

		// delete user skill set info
		userAuthorityDao.deleteUserSkillSet(currentUserId, userId);
		// delete user train info
		userAuthorityDao.deleteUserTrainInfo(currentUserId, userId);
		// insert user skill set info
		userAuthorityDao.insertUserSkillSet(params);
		// insert user train info & prepare user TSAR info
		List<Map<String, Object>> userTrainInfoList = (List<Map<String, Object>>) params
				.get(USERAUTH);
		if (userTrainInfoList != null && userTrainInfoList.size() > 0) {
			List<Map<String, Object>> threeHundredUserTrainList = new ArrayList<Map<String, Object>>();
			for (Map<String, Object> mUserTrain : userTrainInfoList) {
				mUserTrain.put(USERID, userId);
				threeHundredUserTrainList.add(mUserTrain);
				if (threeHundredUserTrainList.size() > 300) {
					userAuthorityDao
							.insertUserTrainInfo(threeHundredUserTrainList);
					threeHundredUserTrainList = new ArrayList<Map<String, Object>>();
				}
			}
			if (threeHundredUserTrainList.size() > 0) {
				userAuthorityDao.insertUserTrainInfo(threeHundredUserTrainList);
			}
		}
		processUNITSARConfuguration(params, userId, currentUserId);
		return outputVO;
	}

	private void processUNITSARConfuguration(Map<String, Object> params,
			String userId, String currentUserId) throws RemoteException {
		// delete user TSAR info
		userAuthorityDao.deleteUserTSARInfo(userId);
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> userUNITSARList = (List<Map<String, Object>>) params
				.get(UNIAUTH);
		if (userUNITSARList != null && userUNITSARList.size() > 0) {
			List<Map<String, Object>> tHundreadUserUNITSARList = new ArrayList<Map<String, Object>>();
			for (Map<String, Object> uniM : userUNITSARList) {
				uniM.put("UAM_USER_ID", userId);
				uniM.put("CREATE_BY", currentUserId);
				uniM.put("UPDATE_BY", currentUserId);
				tHundreadUserUNITSARList.add(uniM);
				if (tHundreadUserUNITSARList.size() > 200) {
					userAuthorityDao.insertUserTSARInfo(tHundreadUserUNITSARList);
					tHundreadUserUNITSARList = new ArrayList<Map<String, Object>>();
				}
			}
			if (tHundreadUserUNITSARList.size() > 0) {
				userAuthorityDao.insertUserTSARInfo(tHundreadUserUNITSARList);
			}
		}

	}

	@Override
	public String findUserNameById(String userId) throws RemoteException {
		return userAuthorityDao.findUserNameById(userId);
	}

	@Override
	public OutputVO getCLMAuthDropDownList() throws RemoteException {
		OutputVO outputVO = new OutputVO();
		LogUtil.logInfo(m_Logger, "service getCLMAuthDropDownList start");
		// get CLM authority drop down list
		List<Map<String, Object>> queryCLMAuthDropDownData = userAuthorityDao
				.queryCLMAuthDropDownData();
		if (queryCLMAuthDropDownData != null
				&& queryCLMAuthDropDownData.size() > 0) {
			for (Map<String, Object> tempAuth : queryCLMAuthDropDownData) {
				String valueStr = tempAuth.get("VALUE_LIST") == null ? ""
						: tempAuth.get("VALUE_LIST").toString();
				List<Map<String, Object>> valueList = new ArrayList<Map<String, Object>>();
				if (!StringUtils.isBlank(valueStr)) {
					String[] values = valueStr.split(";");
					for (String tempValue : values) {
						Map<String, Object> tMap = new ConcurrentHashMap<String, Object>();
						tMap.put("SUBAUTH", tempValue);
						valueList.add(tMap);
					}
				}
				tempAuth.put("SUBAUTHLIST", valueList);
			}
		}
		// put dropdown list data to outputVO
		outputVO.setDatas(queryCLMAuthDropDownData);
		LogUtil.logInfo(m_Logger, "service getCLMAuthDropDownList end");
		return outputVO;
	}

	@Override
	public void copyTo(UAMCopyToParam param, String uuid)
			throws RemoteException {

		String message = "FunctionName: " + uuid + " copyTo" + " param:"
				+ param;
		LogUtil.logInfo(m_Logger, message + " is Entering");

		try {
			param.setCurrentUser(userHelper.getCurrentUser());
			userAuthorityDao.copyTo(param.getSrcUser(), param.getTargetUser(),
					param.getCheckFlag(), param.getCurrentUser());
		} catch (RemoteException e) {
			if (e.getCause() != null) {
				throw new RemoteException(e.getCause().getMessage());
			} else {
				throw e;
			}
		}

		LogUtil.logInfo(m_Logger, message + " is Leaving");
	}

	@Override
	public Boolean isUserRoleExist(String userId, String uuid)
			throws RemoteException {
		String message = "FunctionName: " + uuid + " isUserRoleExist"
				+ " userId:" + userId;
		LogUtil.logInfo(m_Logger, message + " is Entering");

		Boolean result = userAuthorityDao.isUserRoleExist(userId);

		LogUtil.logInfo(m_Logger, message + " is Leaving");

		return result;
	}

	/**
	 * check if user is available
	 */
	@Override
	public boolean isUserAvaliable(String userId) {
		try {
			List<Map<String, Object>> activeUserList = userAuthorityDao
					.checkUserAvaliable(userId);
			if (activeUserList != null && activeUserList.size() > 0) {
				return true;
			}
		} catch (RemoteException e) {
			LogUtil.logException(m_Logger, "check user status error", e);
		}

		return false;
	}

	@Override
	public String isLeader(String userId) {
		try {
			List<Map<String, Object>> leaders = userAuthorityDao
					.getLeaders(userId);
			if (leaders != null && leaders.size() > 0) {
				return "1";
			}
		} catch (RemoteException e) {
			LogUtil.logException(m_Logger, "isLeader error", e);
		}
		return "0";
	}
}
