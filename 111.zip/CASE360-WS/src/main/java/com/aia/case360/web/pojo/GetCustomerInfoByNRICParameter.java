package com.aia.case360.web.pojo;

import java.io.Serializable;

public class GetCustomerInfoByNRICParameter implements Serializable {
	private String customerNRIC;
	private String source;

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getCustomerNRIC() {
		return customerNRIC;
	}

	public void setCustomerNRIC(String customerNRIC) {
		this.customerNRIC = customerNRIC;
	}

}
