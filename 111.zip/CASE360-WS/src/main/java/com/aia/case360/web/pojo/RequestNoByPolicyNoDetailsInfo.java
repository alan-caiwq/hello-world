package com.aia.case360.web.pojo;

public class RequestNoByPolicyNoDetailsInfo {
	// requestNo
	private String requestNo;
	// caseStatus
	private String caseStatus;
	// subStatus
	private String subStatus;
	// requestTypeCode
	private String requestTypeCode;

	public String getRequestNo() {
		return requestNo;
	}

	public void setRequestNo(String requestNo) {
		this.requestNo = requestNo;
	}

	public String getCaseStatus() {
		return caseStatus;
	}

	public void setCaseStatus(String caseStatus) {
		this.caseStatus = caseStatus;
	}

	public String getSubStatus() {
		return subStatus;
	}

	public void setSubStatus(String subStatus) {
		this.subStatus = subStatus;
	}

	public String getRequestTypeCode() {
		return requestTypeCode;
	}

	public void setRequestTypeCode(String requestTypeCode) {
		this.requestTypeCode = requestTypeCode;
	}

}
