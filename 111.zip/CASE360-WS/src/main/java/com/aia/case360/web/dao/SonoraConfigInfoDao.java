package com.aia.case360.web.dao;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.aia.case360.web.pojo.CaseAndPolInfo;
import com.aia.case360.web.pojo.SonoraConfigInfo;

@Repository
public interface SonoraConfigInfoDao {
	
	public List<SonoraConfigInfo> querySonoraConfig()  throws RemoteException;

	public List<String> querySonoraPropValue(Map<String, String> params)  throws RemoteException;

	public List<CaseAndPolInfo> queryPolicyInfoByReqNum(Map<String, String> params)  throws RemoteException;

	public List<CaseAndPolInfo> queryBatchFile(Map<String, String> params)  throws RemoteException;

	public String getEncryptValue(String fieldValue)  throws RemoteException;
	
	public void doDecrementCounterSybase(Map<String, Object> params)  throws RemoteException;
	public List<String> queryFSCCodeByPolicyNo(Map<String, String> params)  throws RemoteException;
	
	public String getLocation(String buildCode)  throws RemoteException;
	
	public void updateFSCCodeByPolicyNo(@Param("FSC_CODE") String fcode,@Param("TSAR") String tsar,
			@Param("COMPANYNO") String cno,@Param("POL_NUM") String pol,
			@Param("AGENCY_LOCATION") String locat)  throws RemoteException;
	
	public String findUWParentCaseAsignByCaseid(String caseId)  throws RemoteException;
}
