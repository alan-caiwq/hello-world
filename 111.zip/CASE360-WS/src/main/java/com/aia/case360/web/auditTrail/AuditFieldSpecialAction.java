package com.aia.case360.web.auditTrail;

/**
 * 
 * @author bsnpbjd
 *
 */
public class AuditFieldSpecialAction {

	private String fieldName;
	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getCreationACTION_DESC() {
		return creationACTION_DESC;
	}

	public void setCreationACTION_DESC(String creationACTION_DESC) {
		this.creationACTION_DESC = creationACTION_DESC;
	}

	public String getUpdateACTION_DESC() {
		return updateACTION_DESC;
	}

	public void setUpdateACTION_DESC(String updateACTION_DESC) {
		this.updateACTION_DESC = updateACTION_DESC;
	}

	private String creationACTION_DESC;
	private String updateACTION_DESC;

	public AuditFieldSpecialAction(String fieldName, String creationACTION_DESC, String updateACTION_DESC) {
		 this.fieldName = fieldName;
		 this.creationACTION_DESC = creationACTION_DESC;
		 this.updateACTION_DESC = updateACTION_DESC;
	}

	

}
