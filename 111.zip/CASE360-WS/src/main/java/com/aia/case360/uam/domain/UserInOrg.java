package com.aia.case360.uam.domain;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public class UserInOrg {
	public enum fieldNames {
		UAM_COMPONENT_ID, UAM_USER_POSITION, LOGINID, DISPLAYNAME, UAM_USER_DEPARTMENT, DELIVERYSTRING, USERCOMPANY,
		UAM_USER_OFFICE_NUMBER, UAM_USER_PHONE_NUMBER, ACTIVESTATUS, UAM_USER_TEAM
	};

	private BigDecimal componentId;
	private String userPosition;
	private String loginId;
	private String displayName;
	private String department;
	private String email;
	private String company;
	private String officeNumber;
	private String phoneNumber;
	private String activityStatus;
	private String userTeam;

	public BigDecimal getComponentId() {
		return componentId;
	}

	public String getUserPosition() {
		return userPosition;
	}

	public String getLoginId() {
		return loginId;
	}

	public String getDisplayName() {
		return displayName;
	}

	public String getDepartment() {
		return department;
	}

	public String getEmail() {
		return email;
	}

	public String getCompany() {
		return company;
	}

	public String getOfficeNumber() {
		return officeNumber;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public String getActivityStatus() {
		return activityStatus;
	}

	public String getUserTeam() {
		return userTeam;
	}

	public void setComponentId(BigDecimal componentId) {
		this.componentId = componentId;
	}

	public void setUserPosition(String userPosition) {
		this.userPosition = userPosition;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public void setOfficeNumber(String officeNumber) {
		this.officeNumber = officeNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public void setActivityStatus(String activityStatus) {
		this.activityStatus = activityStatus;
	}

	public void setUserTeam(String userTeam) {
		this.userTeam = userTeam;
	}

	public Map<String, Object> toMapper() {
		Map<String, Object> result = new HashMap<String, Object>();
		result.put(UserInOrg.fieldNames.ACTIVESTATUS.name(), this.activityStatus);
		result.put(UserInOrg.fieldNames.DELIVERYSTRING.name(), this.email);
		result.put(UserInOrg.fieldNames.DISPLAYNAME.name(), this.displayName);
		result.put(UserInOrg.fieldNames.LOGINID.name(), this.loginId);
		result.put(UserInOrg.fieldNames.UAM_COMPONENT_ID.name(), this.componentId);
		result.put(UserInOrg.fieldNames.USERCOMPANY.name(), this.company);
		result.put(UserInOrg.fieldNames.UAM_USER_DEPARTMENT.name(), this.department);
		result.put(UserInOrg.fieldNames.UAM_USER_OFFICE_NUMBER.name(), this.officeNumber);
		result.put(UserInOrg.fieldNames.UAM_USER_PHONE_NUMBER.name(), this.phoneNumber);
		result.put(UserInOrg.fieldNames.UAM_USER_POSITION.name(), this.userPosition);
		result.put(UserInOrg.fieldNames.UAM_USER_TEAM.name(), this.userTeam);
		return result;
	}
}
