package com.aia.case360.uam.domain;

import java.util.Set;

public class RoleMenuVo extends BaseRoleInfo {

	private String roleId;

	private String roleName;

	private String department;

	private String roleType;

	private String enable;

	private String remark;

	private Set<String> menuIds;

	public String getRoleId() {
		return roleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getRoleType() {
		return roleType;
	}

	public void setRoleType(String roleType) {
		this.roleType = roleType;
	}

	public String getEnable() {
		return enable;
	}

	public void setEnable(String enable) {
		this.enable = enable;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public Set<String> getMenuIds() {
		return menuIds;
	}

	public void setMenuIds(Set<String> menuIds) {
		this.menuIds = menuIds;
	}

}
