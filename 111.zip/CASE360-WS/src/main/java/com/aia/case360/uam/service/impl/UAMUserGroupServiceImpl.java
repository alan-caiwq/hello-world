package com.aia.case360.uam.service.impl;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;

import com.aia.case360.platform.common.PropertyUtil;
import com.aia.case360.platform.dao.TableIdBean;
import com.aia.case360.uam.service.UAMUserGroupService;
import com.aia.case360.web.exception.CustomException;
import com.aia.case360.web.service.impl.AbstractServiceImpl;

public class UAMUserGroupServiceImpl extends AbstractServiceImpl implements UAMUserGroupService {

	/**
	 * Field name
	 */
	private static final String UAM_ROLE_NAME = "UAM_ROLE_NAME";
	private static final String UAM_DEP_NAME = "UAM_DEP_NAME";

	private static final String CURRENTPAGE = "CURRENTPAGE";
	private static final String TOTALPAGE = "TOTALPAGE";

	/**
	 * Table Id
	 */
	/**
	 * Query name
	 */
	private static final String QUERY_GET_UAM_ROLE_LIST = "QUERY_GET_UAM_ROLE_LIST";

	@Override
	public List<Map<String, Object>> searchUserGroup(Map<String, String> params) throws RemoteException {
		// Map:department roleName currentPage totalPage
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(UAM_DEP_NAME, params.get(UAM_DEP_NAME));
		queryParams.put(UAM_ROLE_NAME, params.get(UAM_ROLE_NAME));
		queryParams.put(CURRENTPAGE, params.get(CURRENTPAGE));
		queryParams.put(TOTALPAGE, params.get(TOTALPAGE));

		List<Map<String, Object>> queryResult = queryHelper.doQuery(queryParams,
				PropertyUtil.getScriptAndQueryProperty(QUERY_GET_UAM_ROLE_LIST));
		int resultSize = queryResult.size();
		if (resultSize == 0) {
			throw new CustomException("get role list failure(Wrong Row Id is specified.)", HttpStatus.BAD_REQUEST);
		}
		return queryResult;

	}

}
