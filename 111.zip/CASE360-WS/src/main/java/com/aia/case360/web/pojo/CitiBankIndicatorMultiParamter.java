/**
 * 
 */
package com.aia.case360.web.pojo;

/**
 * @author bsnpc55
 *
 */
public class CitiBankIndicatorMultiParamter {
	private String policyNo;
	private String companyNo;

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getCompanyNo() {
		return companyNo;
	}

	public void setCompanyNo(String companyNo) {
		this.companyNo = companyNo;
	}

}
