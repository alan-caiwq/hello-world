/**
 * -------------------------------------------------
 * Copyright (c) 2017-2019 AIA . All Rights Reserved.  
 *-------------------------------------------------
 * Project Name: Pulse
 * @author: 
 * @version: 1.0
 * Description: 
 * Revised Records:
 */
package com.aia.case360.web.dao;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.aia.case360.uam.domain.Menu;

/**
 * @author bsnpbdu
 *
 */

@Repository
public interface MenuDao {
	public List<Menu> findAllMenus(int menuType);

	public List<Menu> findMenuByUserId(Map<String, Object> queryParam);

	public List<Map<String, Object>> queryUserButtons(@Param("userId") String userId) throws RemoteException;

	public List<Map<String, Object>> querySONORAButtons() throws RemoteException;

	public List<Map<String, Object>> queryRoleFormCategory(@Param("roleId") Integer roleId) throws RemoteException;;

	public List<Map<String, Object>> queryAllFormCategory() throws RemoteException;

	public Integer insertRoleFormCategory(List<Map<String, Object>> formCategorys) throws RemoteException;

	public Integer deleteRoleFormCategory(@Param("roleId") Integer roleId);

	public List<Map<String, Object>> queryUserAutoAssignButtonStatus(@Param("userId") String userId) throws RemoteException;
}
