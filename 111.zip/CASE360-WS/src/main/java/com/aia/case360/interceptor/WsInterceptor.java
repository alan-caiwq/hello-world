package com.aia.case360.interceptor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import ucar.ma2.ArrayDouble.D3.IF;

import com.aia.case360.cache.CacheUtil;
import com.aia.case360.platform.common.Constants;
import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.web.exception.CustomException;
import com.aia.case360.web.service.InterceptorServicec;
import com.aia.case360.web.service.impl.AbstractServiceImpl;

public class WsInterceptor extends AbstractServiceImpl implements HandlerInterceptor {

	@Autowired
	private InterceptorServicec interceptorService;

	// store user which is already logined
	private Map<String, Long> loginedUser = new ConcurrentHashMap<String, Long>();

	/**
	 * called after postHandle
	 */
	@Override
	public void afterCompletion(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, Exception arg3)
			throws CustomException {
		return;
	}

	/**
	 * called after controller run over
	 */
	@Override
	public void postHandle(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, ModelAndView arg3)
			throws CustomException {
		return;
	}

	/**
	 * do user validation
	 */
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object arg2) throws CustomException {
		try {
			String authType = request.getAuthType();
			String loginUser = request.getRemoteUser();
			if("Basic".equalsIgnoreCase(authType)){
				if(!interceptorService.validateUrlAuth(loginUser)){
					response.sendError(401, "user has no auth to access the url");
					return false;
				}
			}
			if (!StringUtils.isBlank(loginUser)) {
				SimpleDateFormat dateTimeFormat = Constants.getDateTimeFormat();
				Long currLoginTime = Long.parseLong(dateTimeFormat.format(new Date()));
				LogUtil.logInfo(m_Logger,  loginUser);
				boolean needValidation = true;
				if (loginedUser.get(loginUser) != null) {
					Long lastLoginTime = loginedUser.get(loginUser);
					if (currLoginTime - lastLoginTime <= Constants.USER_ACTIVE_MAX_TIME) {
						needValidation = false;
					}
				}
				if (needValidation && !interceptorService.validateUserStatus(loginUser)) {
					// avoid more query
					response.sendError(401, "user is not active or on leave");
					return false;
				}
				loginedUser.put(loginUser, currLoginTime);
			}
			LogUtil.logInfo(m_Logger,  "validate request body start");
            if(!request.getRequestURI().toUpperCase().contains("IMPORTDOC") 
            		&& !request.getRequestURI().toUpperCase().contains("FORUPLOADFILE") 
            		&& !request.getRequestURI().toUpperCase().contains("404") 
            		&& !request.getRequestURI().toUpperCase().contains("500") 
            		&& !checkBodyString(request)){
            	LogUtil.logInfo(m_Logger,  "validate request body failed");
            	response.sendError(9999, "request body illegal!");
            	return false;
            }
            LogUtil.logInfo(m_Logger,  "validate request body end");
		} catch (Exception e) {
			LogUtil.logException(m_Logger, "WsInterceptor error:", e);
			return false;
		}
		return true;
	}
	
	public boolean checkBodyString(HttpServletRequest request) throws IOException {
		LogUtil.logInfo(m_Logger, "checkBodyString once:" + request.getRequestURI());
		//add logic to avoid <script> injection by charley 20190624
		RepeatedlyReadRequestWrapper requestWrapper = new RepeatedlyReadRequestWrapper(request);
        StringBuilder sb = new StringBuilder();
        InputStream inputStream = null;
        BufferedReader reader = null;
        try {
            inputStream = requestWrapper.getInputStream();
            reader = new BufferedReader(
                    new InputStreamReader(inputStream, Charset.forName("UTF-8")));

            char[] bodyCharBuffer = new char[1024];
            int len = 0;
            while ((len = reader.read(bodyCharBuffer)) != -1) {
                sb.append(new String(bodyCharBuffer, 0, len));
            }
            String body = sb.toString().toLowerCase();
            if(body.matches("[\\s\\S]*< *script *>[\\s\\S]*") || body.matches("[\\s\\S]*< *script +[\\s\\S]*>[\\s\\S]*")){
            	return false;
            }
        } catch (IOException e) {
        	LogUtil.logException(m_Logger, "checkBodyString error:", e);
           	return false;
        } finally {
        	if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                	LogUtil.logException(m_Logger, "close reader error:", e);
                }
            }
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                	LogUtil.logException(m_Logger, "close inputStream error:", e);
                }
            }
        }
        return true;
    }

}
