package com.aia.case360.drools.model;

import java.util.HashMap;
import java.util.Map;

public class RuleEntity {
	private String S_ROWID;
	private String DEPARTMENT;
	private String RULE_ID;
	private String RULE_DESTINATION;
	private String RULE_CASE;
	private String RULE_STEP;
	private String COMMENTS;
	private String ACTION;
	private Map<String, String> map = new HashMap<String, String>();

	public String getRULE_ID() {
		return RULE_ID;
	}

	public void setRULE_ID(String tRULE_NAME) {
		if (tRULE_NAME != null) {
			tRULE_NAME = tRULE_NAME.toUpperCase();
		} else {
			tRULE_NAME = "";
		}
		RULE_ID = tRULE_NAME.replaceAll("\"", "");
		map.put("RULE_ID", (tRULE_NAME.replaceAll("\"", "")));
	}

	public String getRULE_DESTINATION() {
		return RULE_DESTINATION;
	}

	public void setRULE_DESTINATION(String tDESTINATION) {
		if (tDESTINATION != null) {
			tDESTINATION = tDESTINATION.toUpperCase();
			RULE_DESTINATION = tDESTINATION.replaceAll("\"", "");
			map.put("RULE_DESTINATION", (tDESTINATION.replaceAll("\"", "")));
		} else {
			map.put("RULE_DESTINATION", null);
		}

	}

	public String getRULE_CASE() {
		return RULE_CASE;
	}

	public void setRULE_CASE(String tCASE_CONDITION) {
		if (tCASE_CONDITION != null) {
			tCASE_CONDITION = tCASE_CONDITION.toUpperCase();
		}
		RULE_CASE = tCASE_CONDITION;
		map.put("RULE_CASE", tCASE_CONDITION);
	}

	public String getRULE_STEP() {
		return RULE_STEP;
	}

	public void setRULE_STEP(String tRULE_STEP) {
		if (tRULE_STEP != null) {
			tRULE_STEP = tRULE_STEP.toUpperCase();
		}
		RULE_STEP = tRULE_STEP;
		map.put("RULE_STEP", tRULE_STEP);
	}

	public String getDEPARTMENT() {
		return DEPARTMENT;
	}

	public void setDEPARTMENT(String dept) {
		 DEPARTMENT = dept;
		map.put("dept", dept);
	}

	public String getS_ROWID() {
		return S_ROWID;
	}

	public void setS_ROWID(String s_ROWID) {
		S_ROWID = s_ROWID;
	}

	public Map<String, String> toMap() {

		return map;
	}

	public String getCOMMENTS() {
		return COMMENTS;
	}

	public void setCOMMENTS(String cOMMENTS) {
		COMMENTS = cOMMENTS;
	}

	public String getACTION() {
		return ACTION;
	}

	public void setACTION(String aCTION) {
		if (aCTION != null) {
			aCTION = aCTION.toUpperCase();
			ACTION = aCTION.replaceAll("\"", "");
			map.put("ACTION", (aCTION.replaceAll("\"", "")));
		} else {
			map.put("ACTION", null);
		}

	}

	public String toTxt() {
		StringBuilder sContent = new StringBuilder();
		sContent.append("rule \"" + getRULE_ID().replaceAll("\"", "") + "\"\n");
		sContent.append("	dialect \"mvel\"" + "\n");
		sContent.append("	when" + "\n");
		sContent.append("		RuleCase(" + getRULE_CASE() + ")" + "\n");
		sContent.append("		RuleStep(" + getRULE_STEP() + ")" + "\n");
		sContent.append("	then" + "\n");
		sContent.append("		RuleResult result = new RuleResult();result.setDestination(\""
				+ getRULE_DESTINATION().replaceAll("\"", "") + "\");");
		sContent.append("result.setRulename(\"" + getRULE_ID().replaceAll("\"", "") + "\");");
		if (null != getACTION() && !"".equals(getACTION())) {
			sContent.append("result.setExtraAct(\"" + getACTION().replaceAll("\"", "") + "\");");
		}
		sContent.append("insert(result)" + "\n");
		sContent.append("end" + "\n\n");

		return sContent.toString();
	}

}
