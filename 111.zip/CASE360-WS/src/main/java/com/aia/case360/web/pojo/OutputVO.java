package com.aia.case360.web.pojo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * VO for web service output
 * 
 * @author bsnpbys
 * @date 2017/8/24
 */
public class OutputVO {
	
	public static final String SUCCESS_CODE = "0";
	
	public static final String FAIL_CODE = "1";

	public OutputVO() {

	}
	@Deprecated
	public OutputVO(String code, String message) {
		this.code = code;
		this.message = message;
	}

	// 0: success 1: fail . default 0
	private String code = SUCCESS_CODE;

	// if success, empty. else error message. default ""
	private String message = "";
	
	private String errMessage;

	// input parameters.
	private Map<String, Object> inputParameters = new HashMap<String, Object>();

	private Object datas;
	// in all there are how many records
	private Integer dataCount;
	// page number
	private Integer pageIndex;
	// how many records shown in one page
	private Integer pageNum;

	public Integer getDataCount() {
		return dataCount;
	}

	public void setDataCount(Integer dataCount) {
		this.dataCount = dataCount;
	}

	public Integer getPageIndex() {
		return pageIndex;
	}

	public void setPageIndex(Integer pageIndex) {
		this.pageIndex = pageIndex;
	}

	public Integer getPageNum() {
		return pageNum;
	}

	public void setPageNum(Integer pageNum) {
		this.pageNum = pageNum;
	}

	// turn VO to map
	public Map<String, Object> toMap() {
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("RESPONSE_CD", code);
		result.put("RESPONSE_DESC", message);
		result.put("RESPONSE_DESC_ERR", errMessage);
		if (datas != null) {
			result.put("DATA", datas);
		} else {
			result.put("DATA", inputParameters);
		}
		result.put("pageNum", pageNum);
		result.put("pageIndex", pageIndex);
		result.put("dataCount", dataCount);
		return result;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Map<String, Object> getInputParameters() {
		return inputParameters;
	}

	public void setInputParameters(Map<String, Object> inputParameters) {
		if (inputParameters == null) {
			this.inputParameters = new HashMap<String, Object>();
		} else {
			this.inputParameters.putAll(inputParameters);
			;
		}
	}

	public void addInputParameters(Map<String, String> inputParameters) {

		if (inputParameters != null) {
			Set<String> keySet = inputParameters.keySet();
			Iterator<String> iterator = keySet.iterator();
			while (iterator.hasNext()) {
				String next = iterator.next();
				this.inputParameters.put(next, inputParameters.get(next));
			}
		}

	}

	public void addErrorInfo(String message) {
		setCode("1");
		setMessage(message);
	}

	public Object getDatas() {
		return datas;
	}

	public void setDatas(Object datas) {
		this.datas = datas;
	}

	public String getErrMessage() {
		return errMessage;
	}

	public void setErrMessage(String errMessage) {
		this.errMessage = errMessage;
	}
	
	/**
	 * message for UI to show
	 * errMessage is detail error info
	 * code is code: 0 success 1 fail
	 * @param message
	 * @param errMessage
	 * @param code
	 */
	public void addInfo(String message, String errMessage, String code){
		this.code = code;
		this.message = message;
		this.errMessage = errMessage;
	}
	@Override
	public String toString() {
		return "OutputVO [code=" + code + ", message=" + message + ", errMessage=" + errMessage + ", inputParameters="
				+ inputParameters + ", datas=" + datas + ", dataCount=" + dataCount + ", pageIndex=" + pageIndex
				+ ", pageNum=" + pageNum + "]";
	}
}