package com.aia.case360.web.pojo;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

public class JAXBXmlCreator {
	
	private JAXBXmlCreator() {
		
	}

	public static void prepareXMLForCOSLetters(COSLetters cosLetters, String fileNameWithPath) throws JAXBException {
		File file = new File(fileNameWithPath);
		JAXBContext jaxbContext = JAXBContext.newInstance(COSLetters.class);
		Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

		jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

		jaxbMarshaller.marshal(cosLetters, file);
	}
}
