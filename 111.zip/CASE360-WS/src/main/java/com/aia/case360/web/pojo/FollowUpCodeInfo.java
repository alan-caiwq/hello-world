package com.aia.case360.web.pojo;

public class FollowUpCodeInfo {

	private String policyNo;
	
	private String companyCode;
	
	private String followUpCode;
	
	private String contractNo;
	
	private String PTD;
	
	private String followUpCodeStatus;

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getFollowUpCode() {
		return followUpCode;
	}

	public void setFollowUpCode(String followUpCode) {
		this.followUpCode = followUpCode;
	}

	public String getContractNo() {
		return contractNo;
	}

	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	public String getPTD() {
		return PTD;
	}

	public void setPTD(String pTD) {
		PTD = pTD;
	}

	public String getFollowUpCodeStatus() {
		return followUpCodeStatus;
	}

	public void setFollowUpCodeStatus(String followUpCodeStatus) {
		this.followUpCodeStatus = followUpCodeStatus;
	}
	
	
	
}
