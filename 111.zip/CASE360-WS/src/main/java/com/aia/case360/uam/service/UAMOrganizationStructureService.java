package com.aia.case360.uam.service;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import com.aia.case360.web.pojo.OutputVO;

public interface UAMOrganizationStructureService {
	public OutputVO getUserList(Map<String, Object> request)  throws RemoteException;
	 
	public OutputVO getAllUserList(Map<String, Object> request)  throws RemoteException;
	public String addComponent(Map<String, Object> params)  throws RemoteException;

	public String updateComponent(Map<String, Object> params)  throws RemoteException;

	public boolean deleteComponent(String componentId)  throws RemoteException;

	public OutputVO organizationlist(String parentId)  throws RemoteException;

	public List<Map<String, Object>> findAllLeader();

	public OutputVO getTeamSetting(Map<String, Object> request)  throws RemoteException;

	public OutputVO updateTeamSetting(Map<String, Object> request)  throws RemoteException;

	public OutputVO getTeamMember(Map<String, Object> request)  throws RemoteException;
}
