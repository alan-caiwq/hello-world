package com.aia.case360.platform.security.impl;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.FinderException;
import javax.ejb.RemoveException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.common.PropertyUtil;
import com.aia.case360.platform.formdata.DataTableHelper;
import com.aia.case360.platform.query.QueryHelper;
import com.aia.case360.platform.security.UserHelper;
import com.aia.case360.web.service.impl.AbstractHelperImpl;
import com.eistream.sonora.fields.FmsRow;
import com.eistream.sonora.fields.FmsRowConflict;
import com.eistream.sonora.fields.FmsRowNative;
import com.eistream.sonora.security.RolesElement;
import com.eistream.sonora.users.Persona;
import com.eistream.sonora.users.UserElement;
import com.eistream.sonora.users.UserStatus;
import com.eistream.sonora.util.StringUtil;

@Component
public class UserHelperImpl extends AbstractHelperImpl implements UserHelper {

	private static final String WORK_CALENDAR_NAME = "workCalendarName";
	public final static String USER_ACTIVIE_STATUS = "Active";
	public final static String USER_INACTIVIE_STATUS = "Inactive";
	public final static String USER_TERMINATED_STATUS = "Terminated";
	
	private static final String ISLEAVSTR = " is Leaving";
	private static final String ISENTERSTR = " is Entering";
	private static final String LOGINIDSTR = "loginID:";
	private static final String NLOGINIDSTR = "loginID";
	private static final String DISPLAYNMSTR = "displayName";
	private static final String ALLOWAPPSTR = "allowApplets";
	private static final String BUSFACTSTR = "busyFactor";
	private static final String DEFQUERYSTR = "defaultQueries";
	private static final String LOWERGROUPSTR = "group";
	private static final String HOMEPAGESTR = "homePage";
	private static final String LICENGROUPSTR = "licenseGroupID";
	private static final String MANAGERIDSTR = "managerID";
	private static final String PREFERLOCSTR = "preferredLocale";
	private static final String STATUSMSGSTR = "statusMessage";
	private static final String TIMEZONESTR = "timeZone";
	private static final String DELIVERYSTR = "deliveryString";
	private static final String LOWERSTATUSSTR = "status";
	private static final String FIRSTNMSTR = "firstName";
	private static final String LASTNMSTR = "lastName";
	private static final String LOWERCOMTSTR = "comments";
	private static final String USERVARSTR = "userVariables";
	private static final String LOWERPERSSTR = "persona";
	private static final String CURRENTUSERSTR = "CURRENT_USER";
	private static final String TEAMNAMESTR = "TEAM_NAME";
	private static final String TABLEIDUSERTEAM = "TABLEID_USER_TEAM";
	private static final String LOGINIDUSER = "LOGINID_USER";
	private static final String QUSERTMBYLOGINIDSTR = "QUERY_USERTEAMBYLOGINID";
	private static final String SROWIDSTR = "S_ROWID";
	private static final String TEAMNMSTR = "TEAM_NM";
	private static final String DEPARTMENTSTR = "DEPARTMENT";
	private static final String TBIDTMSTR = "TABLEID_TEAM";
	private static final String TBIDTMROLESTR = "TABLEID_TEAM_ROLE";
	private static final String QUGROUPROLESSTR = "QUERY_USER_GROUP_ROLES_BY_TEAMNM";
	private static final String QUGROUPSTR = "QUERY_USER_GROUP_BY_USER";
	
	@Autowired
	private QueryHelper queryHelper;

	@Autowired
	private DataTableHelper dtHelper;

	private Map<String, String> dataTableIds;

	@SuppressWarnings("unchecked")
	@Override
	public List<UserElement> getUserList(String searchType, String searchText) throws RemoteException {
		String message = String.format("FunctionName: getUserList, searchType:%s", searchType);
		LogUtil.logInfo(m_Logger, message + ISENTERSTR);

		try {
			List<UserElement> resultList = getUserEJB().getUserList(searchType, searchText,
					new String[] { USER_ACTIVIE_STATUS }, null);
			LogUtil.logInfo(m_Logger, message + ISLEAVSTR);
			return resultList;
		} catch (RemoteException e) {
			String mes = "searchType:" + searchType + "searchText:" + searchText;
			throw LogUtil.logException(m_Logger,mes, e);
		}
	}

	@Override
	public boolean userExists(String loginID) throws RemoteException {

		String message = String.format("FunctionName: userExists, loginID:%s", loginID);
		LogUtil.logInfo(m_Logger, message + ISENTERSTR);

		try {
			boolean flag = getUserEJB().userExists(loginID);
			LogUtil.logInfo(m_Logger, message + ISLEAVSTR);
			return flag;
		} catch (RemoteException e) {
			 
			throw LogUtil.logException(m_Logger, LOGINIDSTR + loginID , e);
		}
	}

	@Override
	public boolean removeUser(String loginID) throws RemoteException {

		String message = String.format("FunctionName: removeUser, loginID:%s", loginID);
		LogUtil.logInfo(m_Logger, message + ISENTERSTR);
		try {

			getUserEJB().removeUser(loginID);
			LogUtil.logInfo(m_Logger, message + ISLEAVSTR);
			return true;
		} catch (RemoteException e) {
			throw LogUtil.logException(m_Logger, LOGINIDSTR + loginID , e);
		}

	}

	@Override
	public String getCurrentUser() throws RemoteException {

		String message = "FunctionName: getCurrentUser";
		LogUtil.logInfo(m_Logger, message + ISENTERSTR);
		try {
			String loginID = getUserEJB().getCurrentUser();
			LogUtil.logInfo(m_Logger, message + " is Leaving . current_user  " + loginID);

			return loginID.toUpperCase();
		} catch (RemoteException e) {
			throw LogUtil.logException(m_Logger, message , e);
		}
	}

	@Override
	public boolean createUser(Map<String, String> params) throws RemoteException {
		String message = String.format("FunctionName: createUser ,loginID:%s,displayName:%s", params.get(NLOGINIDSTR), params.get(DISPLAYNMSTR));
		LogUtil.logInfo(m_Logger, message + ISENTERSTR);
		LogUtil.logInfo(m_Logger, params.toString());
		UserElement userElement =  getUserElement(params);
		try {
			getUserEJB().createUser(userElement);
			LogUtil.logInfo(m_Logger, message + ISLEAVSTR);
		} catch (Exception e) {
			throw LogUtil.logException(m_Logger, LOGINIDSTR + params.get(NLOGINIDSTR) + "Exception:", e);
			 
		}
		return true;
	}

	private UserElement getUserElement(Map<String, String> params) throws RemoteException {
		String message = "FunctionName:getUserElement";
		LogUtil.logInfo(m_Logger, message + ISENTERSTR);

		UserElement ue = new UserElement();
		ue.setLoginID(params.get(NLOGINIDSTR).toUpperCase());

		String allowApplets = params.get(ALLOWAPPSTR);
		String busyFactor = params.get(BUSFACTSTR);
		String defaultQueries = params.get(DEFQUERYSTR);
		String group = params.get(LOWERGROUPSTR);
		String homePage = params.get(HOMEPAGESTR);
		String licenseGroupID = params.get(LICENGROUPSTR);
		String managerID = params.get(MANAGERIDSTR);
		String preferredLocale = params.get(PREFERLOCSTR);
		String statusMessage = params.get(STATUSMSGSTR);
		String workCalendarName = params.get(WORK_CALENDAR_NAME);
		String timeZone = params.get(TIMEZONESTR);
		String deliveryString = params.get(DELIVERYSTR);
		String status = params.get(LOWERSTATUSSTR);
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		try {
			UserElement user = getUserEJB().getUserElement("SONORA");
			Persona persona = user.getPersona();

			ue.setFirstName(params.get(FIRSTNMSTR));
			ue.setLastName(params.get(LASTNMSTR));
			ue.setDisplayName(params.get(DISPLAYNMSTR));
			ue.setComments(params.get(LOWERCOMTSTR));
			ue.setPersona(persona);
			ue.setStatusUpdated(timestamp);
			ue.setUserVariables(user.getUserVariables());
			LogUtil.logInfo(m_Logger, status);
			if (status == "true") {
				ue.setStatus(UserStatus.ACTIVE);
			} else {
				ue.setStatus(UserStatus.INACTIVE);
			}
			if (!StringUtil.isBlank(deliveryString)) {
				ue.setDeliveryFlag(1);
				ue.setDeliveryString(deliveryString);
			}

			if (StringUtil.isBlank(allowApplets)) {// remove ! by charley 20180614
				ue.setAllowApplets(user.getAllowApplets());
			} else {
				ue.setAllowApplets(Integer.parseInt(allowApplets));
			}

			if (StringUtil.isBlank(busyFactor)) {
				ue.setBusyFactor(user.getBusyFactor());
			} else {
				ue.setBusyFactor(Short.parseShort(busyFactor));
			}

			
			ue.setDefaultQueries(valueIsNull(user.getDefaultQueries(),defaultQueries));
			ue.setGroup(valueIsNull(user.getGroup(),group));
			ue.setHomePage(valueIsNull(user.getHomePage(),homePage));
			ue.setLicenseGroupID(valueIsNull(user.getLicenseGroupID(),licenseGroupID));
			ue.setManagerID(valueIsNull(user.getManagerID(),managerID));
			ue.setPreferredLocale(valueIsNull(user.getPreferredLocale(),preferredLocale));
			ue.setStatusMessage(valueIsNull(user.getStatusMessage(),statusMessage));
			ue.setTimeZone(valueIsNull(user.getTimeZone(),timeZone));
			ue.setWorkCalendarName(valueIsNull(user.getWorkCalendarName(),workCalendarName));
			
			LogUtil.logInfo(m_Logger, message + ISLEAVSTR);
		} catch (Exception e) {
			throw LogUtil.logException(m_Logger, message , e);
		}

		return ue;
	}

	private String valueIsNull(String value1,String value2){

        if (StringUtil.isBlank(value1)) {
             return value1;
         } else {
             return value2;
         }
	  }
	@Override
	public boolean updateUser(Map<String, String> params) throws RemoteException {
		
		String message = String.format("FunctionName: updateUser,loginID:%s", params.get(NLOGINIDSTR));
		LogUtil.logInfo(m_Logger, message + ISENTERSTR);
		LogUtil.logInfo(m_Logger, params.toString());
		UserElement userElement =  getUserElement(params);
		try {
			getUserEJB().setUserElement(userElement);
			LogUtil.logInfo(m_Logger, message + ISLEAVSTR);
		} catch (Exception e) {
			throw LogUtil.logException(m_Logger, LOGINIDSTR + params.get(NLOGINIDSTR) + "Exception:", e);
			 
		}
		return true;
	}

	@Override
	public List<Map<String, String>> searchUser(String searchType, String searchText) throws RemoteException {
		String message = String.format("FunctionName: userSearch, searchType:%s", searchType);
		LogUtil.logInfo(m_Logger, message + ISENTERSTR);

		List<UserElement> queryList =  getUserList(searchType, searchText);
		List<Map<String, String>> resultList = new ArrayList<Map<String, String>>();
		for (UserElement u : queryList) {
			Map<String, String> map = new HashMap<String, String>();
			map.put(NLOGINIDSTR, u.getLoginID());
			map.put(FIRSTNMSTR, u.getFirstName());
			map.put(LOWERCOMTSTR, u.getComments());
			map.put("deliveryFlag", u.getDeliveryFlag() + "");
			map.put(DELIVERYSTR, u.getDeliveryString());
			map.put(DISPLAYNMSTR, u.getDisplayName());
			map.put(BUSFACTSTR, u.getBusyFactor() + "");
			map.put(LOWERGROUPSTR, u.getGroup());
			map.put(LICENGROUPSTR, u.getLicenseGroupID());
			map.put(LASTNMSTR, u.getLastName());
			map.put(MANAGERIDSTR, u.getManagerID());
			map.put(PREFERLOCSTR, u.getPreferredLocale());
			map.put(LOWERSTATUSSTR, u.getStatus().toString());
			map.put(TIMEZONESTR, u.getTimeZone());
			map.put(ALLOWAPPSTR, u.getAllowApplets() + "");
			map.put(DEFQUERYSTR, u.getDefaultQueries());
			map.put(HOMEPAGESTR, u.getHomePage());
			map.put(STATUSMSGSTR, u.getStatusMessage());
			map.put(WORK_CALENDAR_NAME, u.getWorkCalendarName());

			if (u.getStatusUpdated() == null) {
				map.put(USERVARSTR, null);
			} else {
				map.put("statusUpdated", u.getStatusUpdated().toString());
			}

			if (u.getUserVariables() == null) {
				map.put(USERVARSTR, null);
			} else {
				map.put(USERVARSTR, u.getUserVariables().toString());
			}

			if (u.getPersona() == null) {
				map.put(LOWERPERSSTR, null);
			} else {
				map.put(LOWERPERSSTR, u.getPersona().toString());
			}
			resultList.add(map);
		}
		LogUtil.logInfo(m_Logger, message + ISLEAVSTR);
		return resultList;

	}

	@Override
	public Map<String, Object> getUserElement(String loginID) throws RemoteException {
		String message = String.format("FunctionName: getUserElement,loginID:%s", loginID);
		LogUtil.logInfo(m_Logger, message + ISENTERSTR);
		Map<String, Object> resultMap = new HashMap<String, Object>();
		try {
			UserElement u = getUserEJB().getUserElement(loginID);
			resultMap.put(NLOGINIDSTR, u.getLoginID());
			resultMap.put(FIRSTNMSTR, u.getFirstName());
			resultMap.put(LOWERCOMTSTR, u.getComments());
			resultMap.put("deliveryFlag", u.getDeliveryFlag() + "");
			resultMap.put(DELIVERYSTR, u.getDeliveryString());
			resultMap.put(DISPLAYNMSTR, u.getDisplayName());
			resultMap.put(BUSFACTSTR, u.getBusyFactor() + "");
			resultMap.put(LOWERGROUPSTR, u.getGroup());
			resultMap.put(LICENGROUPSTR, u.getLicenseGroupID());
			resultMap.put(LASTNMSTR, u.getLastName());
			resultMap.put(MANAGERIDSTR, u.getManagerID());
			resultMap.put(PREFERLOCSTR, u.getPreferredLocale());
			resultMap.put(LOWERSTATUSSTR, u.getStatus().toString());
			resultMap.put(TIMEZONESTR, u.getTimeZone());
			resultMap.put(ALLOWAPPSTR, u.getAllowApplets() + "");
			resultMap.put(DEFQUERYSTR, u.getDefaultQueries());
			resultMap.put(HOMEPAGESTR, u.getHomePage());
			resultMap.put(STATUSMSGSTR, u.getStatusMessage());
			resultMap.put(WORK_CALENDAR_NAME, u.getWorkCalendarName());

			if (u.getStatusUpdated() == null) {
				resultMap.put(USERVARSTR, null);
			} else {
				resultMap.put("statusUpdated", u.getStatusUpdated().toString());
			}

			if (u.getUserVariables() == null) {
				resultMap.put(USERVARSTR, null);
			} else {
				resultMap.put(USERVARSTR, u.getUserVariables().toString());
			}

			if (u.getPersona() == null) {
				resultMap.put(LOWERPERSSTR, null);
			} else {
				resultMap.put(LOWERPERSSTR, u.getPersona().toString());
			}
		} catch (FinderException e) {
			throw LogUtil.logException(m_Logger, LOGINIDSTR + loginID , e);
		}
		return resultMap;
	}

	@Override
	public boolean createUserTeam(Map<String, String> params) throws RemoteException {
		String message = String.format("FunctionName: createUserTeam, params:%s", params.toString());
		LogUtil.logInfo(m_Logger, message + ISENTERSTR);
		LogUtil.logInfo(m_Logger, PropertyUtil.getCommonProperty(CURRENTUSERSTR));
		LogUtil.logInfo(m_Logger, PropertyUtil.getCommonProperty(TEAMNAMESTR));
		try {
			FmsRowNative frn = getFmsEJB().getNewRow(
					new BigDecimal( dataTableIds.get(PropertyUtil.getTableIDProperty(TABLEIDUSERTEAM))));
			FmsRow fmsRow = (FmsRow) frn.clone();
			fmsRow.setValue(PropertyUtil.getCommonProperty(CURRENTUSERSTR), params.get(NLOGINIDSTR));
			fmsRow.setValue(PropertyUtil.getCommonProperty(TEAMNAMESTR), params.get("teamName"));
			getFmsEJB().saveChanges(fmsRow, (FmsRowNative) fmsRow, true);
		} catch (Exception e) {
			 
			throw LogUtil.logException(m_Logger, message , e);
		}
		LogUtil.logInfo(m_Logger, message + ISLEAVSTR);
		return true;
	}

	@Override
	public boolean updateUserTeam(Map<String, String> params) throws RemoteException {
		String message = String.format("FunctionName: updateUserTeam, params:%s", params.toString());
		LogUtil.logInfo(m_Logger, message + ISENTERSTR);

		Map<String, String> reqMap = new HashMap<String, String>();
		reqMap.put(LOGINIDUSER, params.get(NLOGINIDSTR));

		try {
			ArrayList<Map<String, Object>> resultList = queryHelper.doQuery(reqMap,
					PropertyUtil.getScriptAndQueryProperty(QUSERTMBYLOGINIDSTR));
			if ( resultList.isEmpty()) {
				 createUserTeam(params);
			}
			for (Map<String, Object> l : resultList) {
				for (Map.Entry<String, Object> entry : l.entrySet()) {
					if (entry.getKey().equals(LOGINIDUSER)
							&& entry.getValue().toString().equals(params.get(NLOGINIDSTR))) {

						String rowId = l.get(SROWIDSTR).toString();

						FmsRowNative frn2 = getFmsEJB().fetch(
								new BigDecimal(
										 dataTableIds.get(PropertyUtil.getTableIDProperty(TABLEIDUSERTEAM))),
								new BigDecimal(rowId));
						FmsRow originalRo = (FmsRow) frn2.clone();
						FmsRowNative newRow = (FmsRowNative) frn2.clone();
						newRow.setValue(LOGINIDUSER, params.get(NLOGINIDSTR));
						newRow.setValue(TEAMNAMESTR, params.get("teamName"));
						FmsRowConflict frc = getFmsEJB().saveChanges(originalRo, newRow, false);
						LogUtil.logInfo(m_Logger, frc.conflictCount + " conflicted");
					}
				}
			}
			LogUtil.logInfo(m_Logger, message + ISLEAVSTR);
			return true;
		} catch (Exception e) {
			 
			throw LogUtil.logException(m_Logger, message , e);
		}
	}

	@Override
	public boolean deleteUserTeam(Map<String, String> params) throws RemoteException {
		String message = String.format("FunctionName: deleteUserTeam, params:%s", params.toString());
		LogUtil.logInfo(m_Logger, message + ISENTERSTR);

		Map<String, String> reqMap = new HashMap<String, String>();
		reqMap.put(LOGINIDUSER, params.get(NLOGINIDSTR));

		try {
			ArrayList<Map<String, Object>> resultList = queryHelper.doQuery(reqMap,
					PropertyUtil.getScriptAndQueryProperty(QUSERTMBYLOGINIDSTR));
			for (Map<String, Object> l : resultList) {
				for (Map.Entry<String, Object> entry : l.entrySet()) {
					if (entry.getKey().equals(LOGINIDUSER)
							&& entry.getValue().toString().equals(params.get(NLOGINIDSTR))) {

						String rowId = l.get(SROWIDSTR).toString();

						getFmsEJB().remove(
								new BigDecimal(
										 dataTableIds.get(PropertyUtil.getTableIDProperty(TABLEIDUSERTEAM))),
								new BigDecimal(rowId));
					}
				}
			}
			LogUtil.logInfo(m_Logger, message + ISLEAVSTR);
			return true;
		} catch (Exception e) {
			 
			throw LogUtil.logException(m_Logger, message , e);
		}
	}

	@Override
	public String getUserTeam(String userName) throws RemoteException {
		String message = String.format("FunctionName: getUserTeam, userName:%s", userName);
		LogUtil.logInfo(m_Logger, message + ISENTERSTR);

		Map<String, String> reqMap = new HashMap<String, String>();
		reqMap.put(LOGINIDUSER, userName);
		String teamName = "";
		try {
			ArrayList<Map<String, Object>> resultList = queryHelper.doQuery(reqMap,
					PropertyUtil.getScriptAndQueryProperty(QUSERTMBYLOGINIDSTR));
			if (resultList != null && resultList.size() > 0) {
				teamName = resultList.get(0).get(TEAMNAMESTR).toString();
			}
			LogUtil.logInfo(m_Logger, message + ISLEAVSTR);
			return teamName;
		} catch (Exception e) {
			 
			throw LogUtil.logException(m_Logger, message , e);
		}
	}

	@Override
	public boolean createUserGroup(Map<String, String> params, List<String> roles) throws RemoteException {
		String message = String.format("FunctionName: createUserGroup, params:%s", params.toString());
		LogUtil.logInfo(m_Logger, message + ISENTERSTR);
		try {
			Map<String, String> insertParams = new HashMap<String, String>();
			insertParams.put(TEAMNMSTR, params.get(TEAMNMSTR));
			insertParams.put(DEPARTMENTSTR, params.get(DEPARTMENTSTR));

			dtHelper.createTableRow(
					new BigDecimal( dataTableIds.get(PropertyUtil.getTableIDProperty(TBIDTMSTR))),
					insertParams);

			for (String role : roles) {
				Map<String, String> map = new HashMap<String, String>();
				map.put(TEAMNMSTR, params.get(TEAMNMSTR));
				map.put("ROLE", role);

				dtHelper.createTableRow(
						new BigDecimal( dataTableIds.get(PropertyUtil.getTableIDProperty(TBIDTMROLESTR))),
						map);
			}
		} catch (Exception e) {
			 
			throw LogUtil.logException(m_Logger, message , e);
		}
		LogUtil.logInfo(m_Logger, message + ISLEAVSTR);
		return true;
	}

	@Override
	public boolean updateUserGroup(Map<String, String> params, List<String> roles) throws RemoteException {
		String message = String.format("FunctionName: updateUserGroup, params:%s", params.toString());
		LogUtil.logInfo(m_Logger, message + ISENTERSTR);

		try {
			Map<String, String> queryParams = new HashMap<String, String>();
			queryParams.put(TEAMNMSTR, params.get(TEAMNMSTR));
			queryParams.put(DEPARTMENTSTR, params.get("OLD_DEPARTMENT"));
			Map<String, String> updateParams = new HashMap<String, String>();
			updateParams.put(TEAMNMSTR, params.get(TEAMNMSTR));
			updateParams.put(DEPARTMENTSTR, params.get(DEPARTMENTSTR));
			dtHelper.updateTableRow(
					new BigDecimal( dataTableIds.get(PropertyUtil.getTableIDProperty(TBIDTMSTR))),
					PropertyUtil.getScriptAndQueryProperty("QUERY_USER_GROUP_BY_TEAMNM"), queryParams, updateParams);

			ArrayList<Map<String, Object>> userGroupRoles = queryHelper.doQuery(params,
					PropertyUtil.getScriptAndQueryProperty(QUGROUPROLESSTR));
			String tableIdTeamRole =  dataTableIds.get(PropertyUtil.getTableIDProperty(TBIDTMROLESTR));
			for (Map<String, Object> l : userGroupRoles) {
				String rowId = l.get(SROWIDSTR).toString();
				getFmsEJB().remove(new BigDecimal(tableIdTeamRole), new BigDecimal(rowId));
			}

			for (String role : roles) {
				Map<String, String> map = new HashMap<String, String>();
				map.put(TEAMNMSTR, params.get(TEAMNMSTR));
				map.put("ROLE", role);
				dtHelper.createTableRow(
						new BigDecimal( dataTableIds.get(PropertyUtil.getTableIDProperty(TBIDTMROLESTR))),
						map);
			}

			// at the same time change roles of user that belong this groupNM
			Map<String, String> paramsin = new HashMap<String, String>();
			paramsin.put(TEAMNMSTR, params.get(TEAMNMSTR));
			LogUtil.logInfo(m_Logger, "paramsin = " + paramsin.toString());
			ArrayList<Map<String, Object>> usersGroup = queryHelper.doQuery(paramsin,
					PropertyUtil.getScriptAndQueryProperty("QUERY_GET_USERLIST_BY_GROUPNM"));
			LogUtil.logInfo(m_Logger, "usersGroup = " + usersGroup.toString());

			boolean updateuserResult = false;
			for (Map<String, Object> u : usersGroup) {
				LogUtil.logInfo(m_Logger, "u = " + u.toString());
				if (u.get(CURRENTUSERSTR) != null && !u.get(CURRENTUSERSTR).equals("")) {
					String current_user = (String) u.get(CURRENTUSERSTR);
					Map<String, String> paramCurrentuser = new HashMap<String, String>();
					paramCurrentuser.put(CURRENTUSERSTR, current_user);
					LogUtil.logInfo(m_Logger, "paramCurrentuser = " + paramCurrentuser.toString());
					ArrayList<Map<String, Object>> userGroupList = queryHelper.doQuery(paramCurrentuser,
							PropertyUtil.getScriptAndQueryProperty(QUGROUPSTR));

					LogUtil.logInfo(m_Logger, "userGroupList = " + userGroupList.toString());

					List<Map<String, String>> teamGrouplist = new ArrayList<Map<String, String>>();
					List<String> userGroups = new ArrayList<String>();
					for (Map<String, Object> g : userGroupList) {
						String team_name = g.get(TEAMNMSTR).toString();
						userGroups.add(team_name);
						Map<String, String> teamGroup = new HashMap<String, String>();
						teamGroup.put(TEAMNMSTR, team_name);
						teamGrouplist.add(teamGroup);
					}

					Map<String, String> paramsOfuser = new HashMap<String, String>();
					paramsOfuser.put(CURRENTUSERSTR, current_user);
					paramsOfuser.put("ROLE_GROUPS", teamGrouplist.toString());
					LogUtil.logInfo(m_Logger, "paramsofuser = " + paramsOfuser.toString());
					LogUtil.logInfo(m_Logger, "userGroups = " + userGroups.toString());

					updateuserResult = updateUserGroupByUser(paramsOfuser, userGroups);
					LogUtil.logInfo(m_Logger, "updateuserResult = " + updateuserResult);
				}
			}

			LogUtil.logInfo(m_Logger, message + ISLEAVSTR);
			return true;
		} catch (Exception e) {
			 
			throw LogUtil.logException(m_Logger, message , e);
		}
	}

	@Override
	public boolean deleteUserGroup(Map<String, String> params) throws RemoteException {
		String message = String.format("FunctionName: deleteUserGroup, params:%s", params.toString());
		LogUtil.logInfo(m_Logger, message + ISENTERSTR);

		try {
			ArrayList<Map<String, Object>> userGroups = queryHelper.doQuery(params,
					PropertyUtil.getScriptAndQueryProperty("QUERY_USER_GROUP_BY_TEAMNM"));
			ArrayList<Map<String, Object>> userGroupRoles = queryHelper.doQuery(params,
					PropertyUtil.getScriptAndQueryProperty(QUGROUPROLESSTR));
			String tableIdTeamRole =  dataTableIds.get(PropertyUtil.getTableIDProperty(TBIDTMROLESTR));
			for (Map<String, Object> l : userGroupRoles) {
				String rowId = l.get(SROWIDSTR).toString();

				getFmsEJB().remove(new BigDecimal(tableIdTeamRole), new BigDecimal(rowId));
			}

			tableIdTeamRole =  dataTableIds.get(PropertyUtil.getTableIDProperty(TBIDTMSTR));
			for (Map<String, Object> l : userGroups) {
				String rowId = l.get(SROWIDSTR).toString();

				getFmsEJB().remove(new BigDecimal(tableIdTeamRole), new BigDecimal(rowId));
			}

			// delete user TEAM_NM when delete userGroup
			Map<String, String> deleteparams = new HashMap<String, String>();
			String teamName = params.get(TEAMNMSTR);
			deleteparams.put(TEAMNMSTR, teamName);
			LogUtil.logInfo(m_Logger, "deleteparams = " + deleteparams.toString());
			ArrayList<Map<String, Object>> userList = queryHelper.doQuery(deleteparams,
					PropertyUtil.getScriptAndQueryProperty("QUERY_GET_USERLIST_BY_GROUPNM"));
			LogUtil.logInfo(m_Logger, "userList = " + userList.toString());

			for (Map<String, Object> u : userList) {
				LogUtil.logInfo(m_Logger, "u = " + u.toString());
				deleteUserGroupAssist(userGroupRoles, teamName, u);
			}

			LogUtil.logInfo(m_Logger, message + ISLEAVSTR);
			return true;
		} catch (Exception e) {
			 
			throw LogUtil.logException(m_Logger, message , e);
		}
	}

  private void deleteUserGroupAssist(ArrayList<Map<String, Object>> userGroupRoles,
      String teamName, Map<String, Object> u) throws RemoteException, RemoveException,
      FinderException {
    if (u.get(CURRENTUSERSTR) != null && !u.get(CURRENTUSERSTR).equals("")) {
    	String loginId = (String) u.get(CURRENTUSERSTR);
    	Map<String, String> paramCurrentuser = new HashMap<String, String>();
    	paramCurrentuser.put(CURRENTUSERSTR, loginId);
    	// delete group of the user (FD_TEAM_USER_RELATION)
    	ArrayList<Map<String, Object>> userGroupRoles2 = queryHelper.doQuery(paramCurrentuser,
    			PropertyUtil.getScriptAndQueryProperty(QUGROUPSTR));
    	String tableIdTeamRole2 =  dataTableIds
    			.get(PropertyUtil.getTableIDProperty(TABLEIDUSERTEAM));
    	for (Map<String, Object> l : userGroupRoles2) {
    		String rowId = l.get(SROWIDSTR).toString();
    		String teamNameofuser = l.get(TEAMNMSTR).toString();
    		LogUtil.logInfo(m_Logger, "S_ROWID = " + rowId);
    		if (teamNameofuser != null && teamName.equals(teamNameofuser)) {
    			getFmsEJB().remove(new BigDecimal(tableIdTeamRole2), new BigDecimal(rowId));
    		}
    	}
    	// delete role of the user (getUserRolesByLoginId)
    	ArrayList<Map<String, Object>> userRoles = queryHelper.doQuery(paramCurrentuser,
    			PropertyUtil.getScriptAndQueryProperty("QUERY_USER_ROLES_BY_USER"));
    	LogUtil.logInfo(m_Logger, "groupRoles = " + userGroupRoles.toString());
    	LogUtil.logInfo(m_Logger, "userRoles = " + userRoles.toString());
    	this.removeRole(userGroupRoles2, userRoles, loginId);
    }
  }

  private void removeRole(ArrayList<Map<String, Object>> userGroupRoles,ArrayList<Map<String, Object>> userRoles,
		  String loginId) throws RemoteException {
	  for (Map<String, Object> l : userRoles) {
  		String rolename = l.get("ROLE").toString();
  		for (Map<String, Object> r : userGroupRoles) {
  			if (rolename.equals(r.get("ROLE"))) {
  				LogUtil.logInfo(m_Logger, "Delete rolename = " + rolename);
  				getRoleEJB().removeRole(rolename, loginId);
  			}
  		}
  	}
}
	@Override
	public boolean updateUserGroupByUser(Map<String, String> params, List<String> userGroups) throws RemoteException {
		String message = String.format("FunctionName: updateUserGroupByUser, params:%s, userGroups:%s", params.toString(), userGroups.toString());
		LogUtil.logInfo(m_Logger, message + ISENTERSTR);

		try {
			ArrayList<Map<String, Object>> userGroupRoles = queryHelper.doQuery(params,
					PropertyUtil.getScriptAndQueryProperty(QUGROUPSTR));
			String tableIdTeamRole =  dataTableIds.get(PropertyUtil.getTableIDProperty(TABLEIDUSERTEAM));
			LogUtil.logInfo(m_Logger, "tableIdTeamRole = " + tableIdTeamRole);
			for (Map<String, Object> l : userGroupRoles) {
				String rowId = l.get(SROWIDSTR).toString();
				getFmsEJB().remove(new BigDecimal(tableIdTeamRole), new BigDecimal(rowId));
			}

			String loginId = params.get(CURRENTUSERSTR);
			ArrayList<Map<String, Object>> userRoles = queryHelper.doQuery(params,
					PropertyUtil.getScriptAndQueryProperty("QUERY_USER_ROLES_BY_USER"));
			for (Map<String, Object> l : userRoles) {
				String role = l.get("ROLE").toString();
				getRoleEJB().removeRole(role, loginId);
			}

			List<String> roles = new ArrayList<String>();
			LogUtil.logInfo(m_Logger, "userGroups = " + userGroups.toString());
			for (String userGroup : userGroups) {
				Map<String, String> map = new HashMap<String, String>();
				map.put(TEAMNMSTR, userGroup);
				map.put(CURRENTUSERSTR, loginId);
				LogUtil.logInfo(m_Logger, "map = " + map.toString());
				dtHelper.createTableRow(
						new BigDecimal( dataTableIds.get(PropertyUtil.getTableIDProperty(TABLEIDUSERTEAM))),
						map);
				LogUtil.logInfo(m_Logger, "createTableRow is success!");
				ArrayList<Map<String, Object>> groupRoles = queryHelper.doQuery(map,
						PropertyUtil.getScriptAndQueryProperty(QUGROUPROLESSTR));
				LogUtil.logInfo(m_Logger, "groupRoles = " + groupRoles.toString());
				for (Map<String, Object> l : groupRoles) {
					String role = l.get("ROLE").toString();
					LogUtil.logInfo(m_Logger, "role = " + role);
					if (!roles.contains(role)) {
						roles.add(role);

						RolesElement element = new RolesElement();
						element.setRole(role);
						element.setLoginID(loginId);

						getRoleEJB().createRole(element);
						LogUtil.logInfo(m_Logger, "createRole = " + element.toString());
					}
				}
			}

			LogUtil.logInfo(m_Logger, message + ISLEAVSTR);
			return true;
		} catch (Exception e) {
			 
			throw LogUtil.logException(m_Logger, message , e);
		}
	}

	@Override
	public List<Map<String, Object>> getUserGroups(String loginID) throws RemoteException {
		Map<String, String> params = new HashMap<String, String>();
		params.put(CURRENTUSERSTR, loginID);
		ArrayList<Map<String, Object>> userGroupRoles = queryHelper.doQuery(params,
				PropertyUtil.getScriptAndQueryProperty(QUGROUPSTR));

		return userGroupRoles;
	}
}
