package com.aia.case360.uam.domain;

import java.util.ArrayList;
import java.util.List;

public class Menu {

	public enum MenuTypeEnum {
		MENU(0), BUTTON(1), FORMCATEGORY(2);
		private int menuType;

		MenuTypeEnum(int menuType) {
			this.menuType = menuType;
		}

		public int getMenuType() {
			return menuType;
		}

		public static MenuTypeEnum getByValue(int value) {
			for (MenuTypeEnum code : values()) {
				if (code.getMenuType() == value) {
					return code;
				}
			}
			return null;
		}
	};

	private int menuType = 0;

	private String menuId = "";

	private String menuNm;

	private String menuLink;

	private String parentMenuId = "00";

	private Boolean isPublic;

	private List<Menu> items = new ArrayList<Menu>();

	public List<Menu> getItems() {
		return items;
	}

	public void setItems(List<Menu> items) {
		this.items = items;
	}

	public String getMenuId() {
		return menuId;
	}

	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}

	public String getMenuNm() {
		return menuNm;
	}

	public void setMenuNm(String menuNm) {
		this.menuNm = menuNm;
	}

	public String getMenuLink() {
		return menuLink;
	}

	public void setMenuLink(String menuLink) {
		this.menuLink = menuLink;
	}

	public String getParentMenuId() {
		return parentMenuId;
	}

	public void setParentMenuId(String parentMenuId) {
		this.parentMenuId = parentMenuId;
	}

	public Boolean getIsPublic() {
		return isPublic;
	}

	public void setIsPublic(Boolean isPublic) {
		this.isPublic = isPublic;
	}

	public int getMenuType() {
		return menuType;
	}

	public void setMenuType(int menuType) {
		this.menuType = menuType;
	}

}
