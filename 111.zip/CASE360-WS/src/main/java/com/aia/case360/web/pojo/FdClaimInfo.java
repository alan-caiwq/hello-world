package com.aia.case360.web.pojo;

import java.util.Date;

public class FdClaimInfo {
	private String sRowId;
	private String claimNo;
	private String childClaimNo;
	private String claimDecision;
	private String claimStatus;
	private String polNum;
	private String insuredId;
	private String insuredName;
	private String linkCaseId;
	private String source;
	private String preDecision;
	private String preDecisionStatus;
	private String claimNoCategory;
	private String isIL;
	private String isHSG;
	private String isDeleted;
	private String claimType;
	private String createdBy;
	private Date createdTimestamp;
	private String lastUpdatedBy;
	private Date lastUpdatedTimestamp;
	private String insuredNric;

	public String getInsuredNric() {
		return insuredNric;
	}

	public void setInsuredNric(String insuredNric) {
		this.insuredNric = insuredNric;
	}

	public String getsRowId() {
		return sRowId;
	}

	public void setsRowId(String sRowId) {
		this.sRowId = sRowId;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public String getChildClaimNo() {
		return childClaimNo;
	}

	public void setChildClaimNo(String childClaimNo) {
		this.childClaimNo = childClaimNo;
	}

	public String getClaimDecision() {
		return claimDecision;
	}

	public void setClaimDecision(String claimDecision) {
		this.claimDecision = claimDecision;
	}

	public String getClaimStatus() {
		return claimStatus;
	}

	public void setClaimStatus(String claimStatus) {
		this.claimStatus = claimStatus;
	}

	public String getPolNum() {
		return polNum;
	}

	public void setPolNum(String polNum) {
		this.polNum = polNum;
	}

	public String getInsuredId() {
		return insuredId;
	}

	public void setInsuredId(String insuredId) {
		this.insuredId = insuredId;
	}

	public String getInsuredName() {
		return insuredName;
	}

	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}

	public String getLinkCaseId() {
		return linkCaseId;
	}

	public void setLinkCaseId(String linkCaseId) {
		this.linkCaseId = linkCaseId;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getPreDecision() {
		return preDecision;
	}

	public void setPreDecision(String preDecision) {
		this.preDecision = preDecision;
	}

	public String getPreDecisionStatus() {
		return preDecisionStatus;
	}

	public void setPreDecisionStatus(String preDecisionStatus) {
		this.preDecisionStatus = preDecisionStatus;
	}

	public String getClaimNoCategory() {
		return claimNoCategory;
	}

	public void setClaimNoCategory(String claimNoCategory) {
		this.claimNoCategory = claimNoCategory;
	}

	public String getIsIL() {
		return isIL;
	}

	public void setIsIL(String isIL) {
		this.isIL = isIL;
	}

	public String getIsHSG() {
		return isHSG;
	}

	public void setIsHSG(String isHSG) {
		this.isHSG = isHSG;
	}

	public String getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(String isDeleted) {
		this.isDeleted = isDeleted;
	}

	public String getClaimType() {
		return claimType;
	}

	public void setClaimType(String claimType) {
		this.claimType = claimType;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Date lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

}
