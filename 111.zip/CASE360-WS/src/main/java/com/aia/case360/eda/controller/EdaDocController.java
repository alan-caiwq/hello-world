package com.aia.case360.eda.controller;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.aia.case360.eda.service.EdaDocService;
import com.aia.case360.web.webservice.AbstractController;

@RestController
@Scope("prototype")
public class EdaDocController extends AbstractController {

	@Autowired
	private EdaDocService edaDocService;

	/**
	 * return specified page for document in JPEG format must use get method since
	 * img src doesn't support post
	 * 
	 * @param request
	 * @param objectId
	 * @param objectName
	 * @return
	 */
	@RequestMapping(value = "/case/edadoc", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, String>> getEx360Image(@RequestBody Map<String, Object> params,
			HttpServletRequest request)  throws RemoteException {

		if (m_Logger.isDebugEnabled()) {
			m_Logger.info(params.toString(), "EDAConnector", request);
		}
		Map<String, String> result = new HashMap<String, String>();
		String objectId = params.get("objectId") == null ? null : String.valueOf(params.get("objectId"));

		String objectName = params.get("objectName") == null ? null : String.valueOf(params.get("objectName"));

		try {

			result = edaDocService.getEx360Image(objectId, objectName);

			return new ResponseEntity<Map<String, String>>(result, HttpStatus.OK);
		} catch (Exception e) {

			return new ResponseEntity<Map<String, String>>(result, HttpStatus.OK);
		}
	}

}
