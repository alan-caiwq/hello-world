package com.aia.case360.web.dao;

import java.rmi.RemoteException;
import java.util.Map;

import org.springframework.stereotype.Repository;

@Repository
public interface UniProcessDao {

	// added by bsnpc1g on 2018/05/29: to get the case pending reason by linkcaseid
	// and pending reason
	public int getActivePendingCount(Map<String, String> params)  throws RemoteException;

	// added by bsnpc1g on18/05/29: to update the data_value of available step
	// 'IS_PEND'
	public void updatePendAvaStep(Map<String, String> params);
}
