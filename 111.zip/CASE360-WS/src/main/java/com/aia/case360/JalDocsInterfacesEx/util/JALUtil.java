package com.aia.case360.JalDocsInterfacesEx.util;

import java.rmi.RemoteException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.common.PropertyUtil;
import com.eistream.jal.JalClient;
import com.eistream.jal.JalClientListItem;
import com.eistream.jal.JalConst;
import com.eistream.jal.JalException;
import com.eistream.jal.JalMaster;

@Service
public class JALUtil {
	private static final String FAILED = " failed...";

	private static final String LOGON_DOMAIN = " logon domain ";

	private Logger m_Logger = LoggerFactory.getLogger("JALUtil");

	private JalClient jalClient = null;
	private JalMaster jMaster = null;

	private boolean proxyLogin = new Boolean(PropertyUtil.getCommonProperty("IS_PROXY_LOGIN").trim());
	private String gUser = PropertyUtil.getCommonProperty("G_USER");
	private String gPassword = PropertyUtil.getCommonProperty("G_PASSWORD");
	private String gDomain = PropertyUtil.getCommonProperty("G_DOMAIN");
	private String proxyUserId = PropertyUtil.getCommonProperty("PROXY_USER_ID");
	private String encryptKey = PropertyUtil.getCommonProperty("ENCRYPT_KEY");

	private String gPasswordAes = sg.aia.webservice.utility.aesencryption.AESDecrypt.decryptPassword(gPassword,
			encryptKey);

	public JalClient initJalClient() throws RemoteException {
		if (jalClient == null) {
			getJalMaster();
			if (!proxyLogin) {
				passwordLogon();
			} else {
				proxyLogon();
			}
		}
		return jalClient;
	}


	private JalMaster getJalMaster() {
		if (jMaster == null) {
			try {
				jMaster = new JalMaster();
				jMaster.allowMultipleVMs(true);
			} catch (Exception e) {
				LogUtil.logException(m_Logger, gUser + LOGON_DOMAIN + gDomain + FAILED, e);
			}
			
		}
		return jMaster;
	}

	public void createJalClient() throws RemoteException {

		try {

			jalClient = jMaster.createClient(gUser, "", gDomain,
					JalConst.JAL_CREATECLIENT_APPLY_FUNCTIONAL_SECURITY + JalConst.JAL_CREATECLIENT_FORCE_RELOGON);
			LogUtil.logInfo(m_Logger,gUser + LOGON_DOMAIN + gDomain + " successfully...");
			LogUtil.logInfo(m_Logger,"JAL Client created...");
		} catch (Exception e) {
			LogUtil.logException(m_Logger, gUser + LOGON_DOMAIN + gDomain + FAILED, e);
			jalClientDestroy();
			 
		}

	}

	public void proxyLogon() throws RemoteException  {

		try {
			jalClient = jMaster.createClient(proxyUserId, gPasswordAes, gDomain, gUser,
					JalConst.JAL_CREATECLIENT_FORCE_RELOGON + JalConst.JAL_CREATECLIENT_PROXIED_LOGON);
			jalClient.getClientList().clear(JalConst.JAL_DEFAULT); // DM
			LogUtil.logInfo(m_Logger,gUser + " logon domain successfully...");
		} catch (JalException e) {
			jalClientDestroy();
			throw LogUtil.logException(m_Logger, gUser + LOGON_DOMAIN + gDomain + FAILED, e);
		} catch (RemoteException e) {
			 
			throw LogUtil.logException(m_Logger, gUser + LOGON_DOMAIN + gDomain + FAILED, e);
		} catch (Exception e) {
			throw LogUtil.logException(m_Logger, gUser + LOGON_DOMAIN + gDomain + FAILED, e);
		}
	}

	public void passwordLogon() throws RemoteException  {

		try {
			jalClient = jMaster.createClient(gUser, gPasswordAes, gDomain, JalConst.JAL_CREATECLIENT_FORCE_RELOGON);//
			jalClient.getClientList().clear(JalConst.JAL_DEFAULT); // DM
			LogUtil.logInfo(m_Logger,gUser + " logon domain successfully...");
		} catch (JalException e) {
			LogUtil.logException(m_Logger, gUser + LOGON_DOMAIN + gDomain + FAILED, e);
			 
			jalClientDestroy();
			throw LogUtil.logException(m_Logger, gUser + LOGON_DOMAIN + gDomain + FAILED, e);
		} catch (Exception e) {
			 
			throw LogUtil.logException(m_Logger, gUser + LOGON_DOMAIN + gDomain + FAILED, e);
		}
	}

	public void jalClientDestroy() throws RemoteException {

		try {
			JalMaster.clearAllJalCaches();
			if (jalClient != null) {

				while (jalClient.getClientList().getCount(JalConst.JAL_OBJ_TYPE_ALL) > 0) {
					JalClientListItem item = jalClient.getClientList().getItem(1, JalConst.JAL_OBJ_TYPE_ALL);
					if (item.getOpenedItem() != null) {
						item.getOpenedItem().destroy(JalConst.JAL_WORKITEM_DESTROY_ABORT_CHANGES);
					}
					jalClient.getClientList().remove(item);
				}

				jalClient.destroy(JalConst.JAL_CLIENT_DESTROY_ABORT_CHANGES);
				jalClient = null;
				LogUtil.logInfo(m_Logger,"JAL Client destroyed...");
			}
		} catch (Exception e) {
			 
			throw LogUtil.logException(m_Logger, gUser + " JAL Client destroy error...", e);
		}

	}
}
