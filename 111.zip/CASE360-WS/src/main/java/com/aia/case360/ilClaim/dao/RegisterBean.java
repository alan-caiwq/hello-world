package com.aia.case360.ilClaim.dao;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

/**
 * 
 * @author bsnpc0y UER Register in IL sync to CASE360
 */

public class RegisterBean {


	private JdbcTemplate jdbcTemplate = ILDataSource.getILjdbcTemplate();

	public List<Map<String, String>> getClaimNo(String landId, String policyNo, String createDate) throws SQLException {

		StringBuilder str = new StringBuilder();

		str.append("Select distinct CHDRNUM,ZACLMMT, ZACLMCD from ZPMDPF where 1=1  ");

		// policyNo
		if (null != policyNo && policyNo.length() > 0) {
			str.append(" and CHDRNUM='");
			str.append(policyNo + "'");
		}
		// land id
		if (null != landId && landId.length() > 0) {
			str.append(" and lanid='");
			str.append(landId + "'");
		}
		// createDate
		if (null != createDate && createDate.length() > 0) {
			str.append(" and createDate='");
			str.append(createDate + "'");
		}

		List<Map<String, String>> result = jdbcTemplate.query(str.toString(), new RowMapper<Map<String, String>>() {

			@Override
			public Map<String, String> mapRow(ResultSet rs, int index) throws SQLException {
				Map<String, String> map = new HashMap<String, String>();
				ResultSetMetaData meta = rs.getMetaData();
				int count = meta.getColumnCount();
				for (int i = 1; i <= count; i++) {
					map.put(meta.getColumnName(i), rs.getString(i) == null ? "" : rs.getString(i));
				}
				return map;
			}
		});

		return result;

	}

}
