package com.aia.case360.web.pojo;

public class ReportSummaryInfo {

	private String sRowid;

	private String countAll;

	private String createdTimeStamp;

	private String createdUser;

	private String deleteFlag;

	private String fileNm;

	private String fileUpdateTimeStamp;

	private String lastUpdateTimeStamp;

	private String lastUpdateUser;

	private String remarks;

	private String emailSend;

	private String emailTimeStamp;

	private String status;

	private String interfaceReportId;

	private String isCompleted;

	public String getsRowid() {
		return sRowid;
	}

	public void setsRowid(String sRowid) {
		this.sRowid = sRowid;
	}

	public String getCountAll() {
		return countAll;
	}

	public void setCountAll(String countAll) {
		this.countAll = countAll;
	}

	public String getCreatedTimeStamp() {
		return createdTimeStamp;
	}

	public void setCreatedTimeStamp(String createdTimeStamp) {
		this.createdTimeStamp = createdTimeStamp;
	}

	public String getCreatedUser() {
		return createdUser;
	}

	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	public String getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	public String getFileNm() {
		return fileNm;
	}

	public void setFileNm(String fileNm) {
		this.fileNm = fileNm;
	}

	public String getFileUpdateTimeStamp() {
		return fileUpdateTimeStamp;
	}

	public void setFileUpdateTimeStamp(String fileUpdateTimeStamp) {
		this.fileUpdateTimeStamp = fileUpdateTimeStamp;
	}

	public String getLastUpdateTimeStamp() {
		return lastUpdateTimeStamp;
	}

	public void setLastUpdateTimeStamp(String lastUpdateTimeStamp) {
		this.lastUpdateTimeStamp = lastUpdateTimeStamp;
	}

	public String getLastUpdateUser() {
		return lastUpdateUser;
	}

	public void setLastUpdateUser(String lastUpdateUser) {
		this.lastUpdateUser = lastUpdateUser;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getEmailSend() {
		return emailSend;
	}

	public void setEmailSend(String emailSend) {
		this.emailSend = emailSend;
	}

	public String getEmailTimeStamp() {
		return emailTimeStamp;
	}

	public void setEmailTimeStamp(String emailTimeStamp) {
		this.emailTimeStamp = emailTimeStamp;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getInterfaceReportId() {
		return interfaceReportId;
	}

	public void setInterfaceReportId(String interfaceReportId) {
		this.interfaceReportId = interfaceReportId;
	}

	public String getIsCompleted() {
		return isCompleted;
	}

	public void setIsCompleted(String isCompleted) {
		this.isCompleted = isCompleted;
	}

}
