package com.aia.case360.web.pojo;

public class PolNum {

	private String company;
	
	private String polNumValue;

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getPolNum() {
		return polNumValue;
	}

	public void setPolNum(String polNum) {
		this.polNumValue = polNum;
	}

	@Override
	public String toString() {
		return "PolNum [company=" + company + ", polNum=" + polNumValue + "]";
	}
}
