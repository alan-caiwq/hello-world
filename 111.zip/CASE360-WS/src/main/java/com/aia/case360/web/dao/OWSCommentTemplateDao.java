package com.aia.case360.web.dao;

import java.rmi.RemoteException;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.aia.case360.web.vo.OWSCommentTemplate;

public interface OWSCommentTemplateDao {

	public OWSCommentTemplate insertUpdateCommentTemplate(OWSCommentTemplate commentTemplate)  throws RemoteException;

	public void batchUpdateCommentTemplateOrder(@Param("tmpIds") String tmpIds, @Param("tmpSorts") String tmpSorts, @Param("currentUser") String currentUser)  throws RemoteException;

	public void batchDeleteCommentTemplate(@Param("tmpIds") String tmpIds, @Param("currentUser") String currentUser)  throws RemoteException;

	public List<OWSCommentTemplate> searchTemplate(OWSCommentTemplate commentTemplate)  throws RemoteException;

	public OWSCommentTemplate searchTemplateByID(Long rowID)  throws RemoteException;

}
