package com.aia.case360.web.common;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

import org.apache.http.client.methods.HttpEntityEnclosingRequestBase;
import org.apache.http.client.methods.HttpUriRequest;
import org.drools.core.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.ResponseErrorHandler;
import org.springframework.web.client.RestTemplate;

import com.aia.case360.platform.common.LogUtil;
import com.eistream.sonora.util.Base64;

import net.sf.json.JSONObject;

public class CallWsUtil {
	private CallWsUtil() {
		
	}
	private static Logger m_Logger = LoggerFactory.getLogger(CallWsUtil.class.getClass());
	private static class HttpEntityEnclosingRequest extends HttpEntityEnclosingRequestBase {

		private String methodName = "DELETE";

		public HttpEntityEnclosingRequest(final URI uri, String methodName) {
			super();
			setURI(uri);
			this.methodName = methodName;
		}

		@Override
		public String getMethod() {
			return methodName;
		}
	}

	public static ResponseEntity<JSONObject> doPost(String urlStr, String user, String psw, JSONObject request)
			throws MalformedURLException, URISyntaxException {
		URL url = new URL(urlStr);
		RestTemplate rest = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.add("Accept", "application/json");
		headers.add("Content-Type", "application/json; charset=UTF-8");

		String jsonPost = request.toString();
		if (!StringUtils.isEmpty(user)) {
			char[] token = Base64.encode((user + ":" + psw).getBytes());
			headers.add("Authorization", "Basic " + new String(token));
		}
		HttpEntity<String> entity = new HttpEntity<String>(jsonPost, headers);
		rest.setErrorHandler(new ResponseErrorHandler() {

			@Override
			public boolean hasError(ClientHttpResponse response) throws IOException {
				int status = response.getStatusCode().ordinal();
				if (status >= 200 && status < 400) {
					return false;
				}
				return true;
			}

			@Override
			public void handleError(ClientHttpResponse response) throws IOException {
                LogUtil.logInfo(m_Logger,response.getStatusText());
			}
		});
		// update by paul,support https ignore validation
		if (!urlStr.contains("https")) {
			rest.setRequestFactory(new HttpComponentsClientHttpRequestFactory() {
				@Override
				protected HttpUriRequest createHttpUriRequest(HttpMethod httpMethod, URI uri) {
					return new HttpEntityEnclosingRequest(uri, HttpMethod.POST.name());
				}
			});
		} else {
			rest.setRequestFactory(new HttpsClientRequestFactory());
		}
		ResponseEntity<JSONObject> res = rest.postForEntity(url.toURI(), entity, JSONObject.class);
		LogUtil.logInfo(m_Logger,"Executing request POST " + url+ ":parms: "+entity.toString());
		LogUtil.logInfo(m_Logger,res.toString());
		return res;
	}

	public static ResponseEntity<String> doGet(String urlStr, String user, String psw, String request)
			throws MalformedURLException, URISyntaxException {
		URL url = new URL(urlStr);
		RestTemplate rest = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.add("Accept", "application/json");
		headers.add("Content-Type", "application/json; charset=UTF-8");

		String jsonPost = request;
		if (!StringUtils.isEmpty(user)) {
			char[] token = Base64.encode((user + ":" + psw).getBytes());
			headers.add("Authorization", "Basic " + new String(token));
		}
		HttpEntity<String> entity = new HttpEntity<String>(jsonPost, headers);
		rest.setErrorHandler(new ResponseErrorHandler() {

			@Override
			public boolean hasError(ClientHttpResponse response) throws IOException {
				int status = response.getStatusCode().ordinal();
				if (status >= 200 && status < 400) {
					return false;
				}
				return true;
			}

			@Override
			public void handleError(ClientHttpResponse response) throws IOException {
                LogUtil.logInfo(m_Logger,response.getStatusText());
			}
		});
		// update by paul,support https ignore validation
		if (!urlStr.contains("https")) {
			rest.setRequestFactory(new HttpComponentsClientHttpRequestFactory() {
				@Override
				protected HttpUriRequest createHttpUriRequest(HttpMethod httpMethod, URI uri) {
					return new HttpEntityEnclosingRequest(uri, HttpMethod.GET.name());
				}
			});
		} else {
			rest.setRequestFactory(new HttpsClientRequestFactory());
		}
		ResponseEntity<String> res = rest.exchange(url.toURI(), HttpMethod.GET, entity, String.class);
		return res;
	}
}
