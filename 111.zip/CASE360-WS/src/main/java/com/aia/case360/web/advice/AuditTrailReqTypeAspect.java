package com.aia.case360.web.advice;

import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import com.aia.case360.web.service.impl.AbstractServiceImpl;

@Component
@Aspect
public class AuditTrailReqTypeAspect extends AbstractServiceImpl {

}
