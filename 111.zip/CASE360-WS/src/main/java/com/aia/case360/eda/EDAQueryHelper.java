package com.aia.case360.eda;

import java.util.Map;
import java.util.Map.Entry;

import com.eistream.sonora.fields.FieldPropertiesTO;

public class EDAQueryHelper {

	private EDAQueryHelper() {
	}

	public static FieldPropertiesTO[] getQueryParamList(Map<String, String> queryParams) {
		// Get the list of contents
		FieldPropertiesTO[] queryFields = null;
		if (queryParams != null) {
			queryFields = new FieldPropertiesTO[queryParams.size()];

			int fieldsNum = 0;
			for (Entry<String, String> param : queryParams.entrySet()) {
				queryFields[fieldsNum++] = createFieldPropertyTO(param.getKey(), param.getValue());
			}
		}

		return queryFields;
	}

	/**
	 * Create a new String field property
	 * 
	 * @return
	 */
	public static FieldPropertiesTO createFieldPropertyTO(String key, String value) {
		FieldPropertiesTO prop = new FieldPropertiesTO();
		prop.setPropertyName(key);
		prop.setStringValue(value);
		prop.setDataType(4);
		return prop;
	}

}
