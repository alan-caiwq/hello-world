package com.aia.case360.web.dao;

import java.rmi.RemoteException;
import java.util.List;

import org.springframework.stereotype.Repository;

@Repository
public interface PendingReasonDao {

	public boolean deletedPendingReason(String deleteData)  throws RemoteException;

	public List<String> searchPengReason(String deleteData)  throws RemoteException;

	public boolean updatePengReason(String reason)  throws RemoteException;

}
