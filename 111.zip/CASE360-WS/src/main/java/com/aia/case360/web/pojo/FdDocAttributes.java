package com.aia.case360.web.pojo;

import java.util.Date;

public class FdDocAttributes {

	private String agency;
	private String agentName;
	private String assignReasonCd;
	private String assignUserId;
	private String autoFiling;
	private String batchNo;
	private String clmCategory;
	private String cohUserId;
	private String companyNo;
	private String currentUserId;
	private String formDesc;
	private String formId;
	private String inpogressMig;
	private String inpogressUserId;
	private String isClmForm;
	private String isMajorClaim;
	private String isMedCase;
	private String isPosForm;
	private String isPosIlpForm;
	private String isUniForm;
	private String itemStatus;
	private String jobStatus;
	private String kivReason;
	private String kivReasonCd;
	private String kivUserId;
	private String lastProcUserId;
	private String linkIndicator;
	private String lob;
	private String lobaStatus;
	private String lobadSyncRetried;
	private String lobadSynced;
	private String name;
	private String nric;
	private String objectClass;
	private String objectId;
	private String objectName;
	private String objectServer;
	private int objectType;
	private String orgCompanyNo;
	private String orgPolicyNo;
	private String orgRequestNo;
	private String orgRequestType;
	private String orginalUserId;
	private String policyNo;
	private String policyType;
	private String posRequestCategory;
	private String processType;
	private String queueId;
	private String referFromUserId;
	private String referReasonCd;
	private String referToMr;
	private String referToUserId;
	private String referUserList;
	private String relatedPolicyNo;
	private String requestNo;
	private String requestType;
	private String rouError;
	private String rouErrorRetryCount;
	private String sourceSystemCode;
	private String statusIndicator;
	private String taadd;
	private String taci;
	private String tci;
	private String tsa;
	private String uniPlanNm;
	private String uniPlanType;
	private String wfNonWf;
	private String wfStatus;
	private String wfrCrUserId;
	private String wfrUpdUserId;
	private String workitemFormId;
	private String boxNo;
	private Date kivExpirationDt;
	private Date lastPendDt;
	private Date lastProcDt;
	private Date latestDocRecDt;
	private Date lobadLastSyncDt;
	private Date processDueDt;
	private Date reqReceivedDt;
	private Date scanDt;
	private Date wfrCrDt;
	private Date wfrUpdDt;
	private Date receivedDt;
	private int isDeleted;
	private String pageIndicator;

	public String getAgency() {
		return agency;
	}

	public void setAgency(String agency) {
		this.agency = agency;
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public String getAssignReasonCd() {
		return assignReasonCd;
	}

	public void setAssignReasonCd(String assignReasonCd) {
		this.assignReasonCd = assignReasonCd;
	}

	public String getAssignUserId() {
		return assignUserId;
	}

	public void setAssignUserId(String assignUserId) {
		this.assignUserId = assignUserId;
	}

	public String getAutoFiling() {
		return autoFiling;
	}

	public void setAutoFiling(String autoFiling) {
		this.autoFiling = autoFiling;
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public String getClmCategory() {
		return clmCategory;
	}

	public void setClmCategory(String clmCategory) {
		this.clmCategory = clmCategory;
	}

	public String getCohUserId() {
		return cohUserId;
	}

	public void setCohUserId(String cohUserId) {
		this.cohUserId = cohUserId;
	}

	public String getCompanyNo() {
		return companyNo;
	}

	public void setCompanyNo(String companyNo) {
		this.companyNo = companyNo;
	}

	public String getCurrentUserId() {
		return currentUserId;
	}

	public void setCurrentUserId(String currentUserId) {
		this.currentUserId = currentUserId;
	}

	public String getFormDesc() {
		return formDesc;
	}

	public void setFormDesc(String formDesc) {
		this.formDesc = formDesc;
	}

	public String getFormId() {
		return formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}

	public String getInpogressMig() {
		return inpogressMig;
	}

	public void setInpogressMig(String inpogressMig) {
		this.inpogressMig = inpogressMig;
	}

	public String getInpogressUserId() {
		return inpogressUserId;
	}

	public void setInpogressUserId(String inpogressUserId) {
		this.inpogressUserId = inpogressUserId;
	}

	public String getIsClmForm() {
		return isClmForm;
	}

	public void setIsClmForm(String isClmForm) {
		this.isClmForm = isClmForm;
	}

	public String getIsMajorClaim() {
		return isMajorClaim;
	}

	public void setIsMajorClaim(String isMajorClaim) {
		this.isMajorClaim = isMajorClaim;
	}

	public String getIsMedCase() {
		return isMedCase;
	}

	public void setIsMedCase(String isMedCase) {
		this.isMedCase = isMedCase;
	}

	public String getIsPosForm() {
		return isPosForm;
	}

	public void setIsPosForm(String isPosForm) {
		this.isPosForm = isPosForm;
	}

	public String getIsPosIlpForm() {
		return isPosIlpForm;
	}

	public void setIsPosIlpForm(String isPosIlpForm) {
		this.isPosIlpForm = isPosIlpForm;
	}

	public String getIsUniForm() {
		return isUniForm;
	}

	public void setIsUniForm(String isUniForm) {
		this.isUniForm = isUniForm;
	}

	public String getItemStatus() {
		return itemStatus;
	}

	public void setItemStatus(String itemStatus) {
		this.itemStatus = itemStatus;
	}

	public String getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}

	public String getKivReason() {
		return kivReason;
	}

	public void setKivReason(String kivReason) {
		this.kivReason = kivReason;
	}

	public String getKivReasonCd() {
		return kivReasonCd;
	}

	public void setKivReasonCd(String kivReasonCd) {
		this.kivReasonCd = kivReasonCd;
	}

	public String getKivUserId() {
		return kivUserId;
	}

	public void setKivUserId(String kivUserId) {
		this.kivUserId = kivUserId;
	}

	public String getLastProcUserId() {
		return lastProcUserId;
	}

	public void setLastProcUserId(String lastProcUserId) {
		this.lastProcUserId = lastProcUserId;
	}

	public String getLinkIndicator() {
		return linkIndicator;
	}

	public void setLinkIndicator(String linkIndicator) {
		this.linkIndicator = linkIndicator;
	}

	public String getLob() {
		return lob;
	}

	public void setLob(String lob) {
		this.lob = lob;
	}

	public String getLobaStatus() {
		return lobaStatus;
	}

	public void setLobaStatus(String lobaStatus) {
		this.lobaStatus = lobaStatus;
	}

	public String getLobadSyncRetried() {
		return lobadSyncRetried;
	}

	public void setLobadSyncRetried(String lobadSyncRetried) {
		this.lobadSyncRetried = lobadSyncRetried;
	}

	public String getLobadSynced() {
		return lobadSynced;
	}

	public void setLobadSynced(String lobadSynced) {
		this.lobadSynced = lobadSynced;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNric() {
		return nric;
	}

	public void setNric(String nric) {
		this.nric = nric;
	}

	public String getObjectClass() {
		return objectClass;
	}

	public void setObjectClass(String objectClass) {
		this.objectClass = objectClass;
	}

	public String getObjectId() {
		return objectId;
	}

	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}

	public String getObjectName() {
		return objectName;
	}

	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}

	public String getObjectServer() {
		return objectServer;
	}

	public void setObjectServer(String objectServer) {
		this.objectServer = objectServer;
	}

	public int getObjectType() {
		return objectType;
	}

	public void setObjectType(int objectType) {
		this.objectType = objectType;
	}

	public String getOrgCompanyNo() {
		return orgCompanyNo;
	}

	public void setOrgCompanyNo(String orgCompanyNo) {
		this.orgCompanyNo = orgCompanyNo;
	}

	public String getOrgPolicyNo() {
		return orgPolicyNo;
	}

	public void setOrgPolicyNo(String orgPolicyNo) {
		this.orgPolicyNo = orgPolicyNo;
	}

	public String getOrgRequestNo() {
		return orgRequestNo;
	}

	public void setOrgRequestNo(String orgRequestNo) {
		this.orgRequestNo = orgRequestNo;
	}

	public String getOrgRequestType() {
		return orgRequestType;
	}

	public void setOrgRequestType(String orgRequestType) {
		this.orgRequestType = orgRequestType;
	}

	public String getOrginalUserId() {
		return orginalUserId;
	}

	public void setOrginalUserId(String orginalUserId) {
		this.orginalUserId = orginalUserId;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getPolicyType() {
		return policyType;
	}

	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}

	public String getPosRequestCategory() {
		return posRequestCategory;
	}

	public void setPosRequestCategory(String posRequestCategory) {
		this.posRequestCategory = posRequestCategory;
	}

	public String getProcessType() {
		return processType;
	}

	public void setProcessType(String processType) {
		this.processType = processType;
	}

	public String getQueueId() {
		return queueId;
	}

	public void setQueueId(String queueId) {
		this.queueId = queueId;
	}

	public String getReferFromUserId() {
		return referFromUserId;
	}

	public void setReferFromUserId(String referFromUserId) {
		this.referFromUserId = referFromUserId;
	}

	public String getReferReasonCd() {
		return referReasonCd;
	}

	public void setReferReasonCd(String referReasonCd) {
		this.referReasonCd = referReasonCd;
	}

	public String getReferToMr() {
		return referToMr;
	}

	public void setReferToMr(String referToMr) {
		this.referToMr = referToMr;
	}

	public String getReferToUserId() {
		return referToUserId;
	}

	public void setReferToUserId(String referToUserId) {
		this.referToUserId = referToUserId;
	}

	public String getReferUserList() {
		return referUserList;
	}

	public void setReferUserList(String referUserList) {
		this.referUserList = referUserList;
	}

	public String getRelatedPolicyNo() {
		return relatedPolicyNo;
	}

	public void setRelatedPolicyNo(String relatedPolicyNo) {
		this.relatedPolicyNo = relatedPolicyNo;
	}

	public String getRequestNo() {
		return requestNo;
	}

	public void setRequestNo(String requestNo) {
		this.requestNo = requestNo;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getRouError() {
		return rouError;
	}

	public void setRouError(String rouError) {
		this.rouError = rouError;
	}

	public String getRouErrorRetryCount() {
		return rouErrorRetryCount;
	}

	public void setRouErrorRetryCount(String rouErrorRetryCount) {
		this.rouErrorRetryCount = rouErrorRetryCount;
	}

	public String getSourceSystemCode() {
		return sourceSystemCode;
	}

	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}

	public String getStatusIndicator() {
		return statusIndicator;
	}

	public void setStatusIndicator(String statusIndicator) {
		this.statusIndicator = statusIndicator;
	}

	public String getTaadd() {
		return taadd;
	}

	public void setTaadd(String taadd) {
		this.taadd = taadd;
	}

	public String getTaci() {
		return taci;
	}

	public void setTaci(String taci) {
		this.taci = taci;
	}

	public String getTci() {
		return tci;
	}

	public void setTci(String tci) {
		this.tci = tci;
	}

	public String getTsa() {
		return tsa;
	}

	public void setTsa(String tsa) {
		this.tsa = tsa;
	}

	public String getUniPlanNm() {
		return uniPlanNm;
	}

	public void setUniPlanNm(String uniPlanNm) {
		this.uniPlanNm = uniPlanNm;
	}

	public String getUniPlanType() {
		return uniPlanType;
	}

	public void setUniPlanType(String uniPlanType) {
		this.uniPlanType = uniPlanType;
	}

	public String getWfNonWf() {
		return wfNonWf;
	}

	public void setWfNonWf(String wfNonWf) {
		this.wfNonWf = wfNonWf;
	}

	public String getWfStatus() {
		return wfStatus;
	}

	public void setWfStatus(String wfStatus) {
		this.wfStatus = wfStatus;
	}

	public String getWfrCrUserId() {
		return wfrCrUserId;
	}

	public void setWfrCrUserId(String wfrCrUserId) {
		this.wfrCrUserId = wfrCrUserId;
	}

	public String getWfrUpdUserId() {
		return wfrUpdUserId;
	}

	public void setWfrUpdUserId(String wfrUpdUserId) {
		this.wfrUpdUserId = wfrUpdUserId;
	}

	public String getWorkitemFormId() {
		return workitemFormId;
	}

	public void setWorkitemFormId(String workitemFormId) {
		this.workitemFormId = workitemFormId;
	}

	public String getBoxNo() {
		return boxNo;
	}

	public void setBoxNo(String boxNo) {
		this.boxNo = boxNo;
	}

	public Date getKivExpirationDt() {
		return kivExpirationDt;
	}

	public void setKivExpirationDt(Date kivExpirationDt) {
		this.kivExpirationDt = kivExpirationDt;
	}

	public Date getLastPendDt() {
		return lastPendDt;
	}

	public void setLastPendDt(Date lastPendDt) {
		this.lastPendDt = lastPendDt;
	}

	public Date getLastProcDt() {
		return lastProcDt;
	}

	public void setLastProcDt(Date lastProcDt) {
		this.lastProcDt = lastProcDt;
	}

	public Date getLatestDocRecDt() {
		return latestDocRecDt;
	}

	public void setLatestDocRecDt(Date latestDocRecDt) {
		this.latestDocRecDt = latestDocRecDt;
	}

	public Date getLobadLastSyncDt() {
		return lobadLastSyncDt;
	}

	public void setLobadLastSyncDt(Date lobadLastSyncDt) {
		this.lobadLastSyncDt = lobadLastSyncDt;
	}

	public Date getProcessDueDt() {
		return processDueDt;
	}

	public void setProcessDueDt(Date processDueDt) {
		this.processDueDt = processDueDt;
	}

	public Date getReqReceivedDt() {
		return reqReceivedDt;
	}

	public void setReqReceivedDt(Date reqReceivedDt) {
		this.reqReceivedDt = reqReceivedDt;
	}

	public Date getScanDt() {
		return scanDt;
	}

	public void setScanDt(Date scanDt) {
		this.scanDt = scanDt;
	}

	public Date getWfrCrDt() {
		return wfrCrDt;
	}

	public void setWfrCrDt(Date wfrCrDt) {
		this.wfrCrDt = wfrCrDt;
	}

	public Date getWfrUpdDt() {
		return wfrUpdDt;
	}

	public void setWfrUpdDt(Date wfrUpdDt) {
		this.wfrUpdDt = wfrUpdDt;
	}

	public Date getReceivedDt() {
		return receivedDt;
	}

	public void setReceivedDt(Date receivedDt) {
		this.receivedDt = receivedDt;
	}

	public int getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(int isDeleted) {
		this.isDeleted = isDeleted;
	}

	public String getPageIndicator() {
		return pageIndicator;
	}

	public void setPageIndicator(String pageIndicator) {
		this.pageIndicator = pageIndicator;
	}

}
