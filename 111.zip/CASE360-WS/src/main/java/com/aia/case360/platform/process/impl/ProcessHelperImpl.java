package com.aia.case360.platform.process.impl;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.ejb.FinderException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.aia.case360.platform.common.DateUtil;
import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.process.ProcessHelper;
import com.aia.case360.web.service.impl.AbstractHelperImpl;
import com.eistream.sonora.exceptions.SonoraApplicationException;
import com.eistream.sonora.exceptions.SonoraException;
import com.eistream.sonora.fields.FieldDataType;
import com.eistream.sonora.fields.FmsColumnDefinition;
import com.eistream.sonora.fields.FmsFieldDefinition;
import com.eistream.sonora.fields.FmsRow;
import com.eistream.sonora.workflow.Envelope;
import com.eistream.sonora.workflow.workflows.WFElement;
import com.eistream.sonora.workflow.worksteps.WSElement;

@Component
public class ProcessHelperImpl extends AbstractHelperImpl implements ProcessHelper {

	@Override
	public WFElement getProcessDefinition(String workFlowName) throws RemoteException {

		LogUtil.logInfo(m_Logger,workFlowName);
		ArrayList alwfs = getWfsSEJB().getElementList(workFlowName);
		WFElement result = null;

		for (int ii = 0; ii < alwfs.size(); ii++) {

			WFElement wfe = (WFElement) alwfs.get(ii);
			if (wfe.m_IsPublished) {
				return wfe;
			} else {
				if (result == null || wfe.m_WorkFlowVersion > result.m_WorkFlowVersion) {
					result = wfe;
				}
			}
		}
		return result;
	}

	private List<FmsColumnDefinition> getTableDefinition(BigDecimal tableId) throws RemoteException {
		try {
			return getFmsSchemaSessionEJB().getColumns(tableId);
		} catch (FinderException e) {

			 
			throw new RemoteException("", e);
		}
	}

	@Override
	public List<String> getTableColumnName(String processName) throws RemoteException {
		List<String> result = new ArrayList<String>();
		WFElement wfe = getProcessDefinition(processName);
		if (wfe != null) {
			BigDecimal tableId = getProcessDefinition(processName).m_FMSTableID;
			List<FmsColumnDefinition> columns =  getTableDefinition(tableId);

			if (columns != null) {
				for (FmsColumnDefinition col : columns) {
					result.add(col.getFieldName());
				}
			}
		}
		return result;
	}

	@Override
	public String createWorkitem(String workFlowName, Map<String, Object> cfParams, String startWorkStep)
			throws RemoteException {
		LogUtil.logInfo(m_Logger,workFlowName + "  " + cfParams.toString());
		cfParams.put("CREATE_TIMESTAMP", DateUtil.getCurrentTime());
		if (null == workFlowName || "".equals(workFlowName)) {
			throw new RemoteException("");
		}

		WFElement wfe = getProcessDefinition(workFlowName);
		String key = "";
		if (wfe != null) {
			String envID = getWfEJB().createEnvelope(wfe.m_WorkFlowID, wfe.m_WorkFlowVersion, null, startWorkStep,
					false);
			LogUtil.logInfo(m_Logger,envID);
			FmsRow fields = getWfEJB().getFields(wfe.m_WorkFlowID, envID);
			Envelope fields2 = getWfEJB().getEnvelope(wfe.m_WorkFlowID, envID, true);
			for (Entry<String, Object> name : cfParams.entrySet()) {
				if (fields.getField(name.getKey()) != null) {
					setWorkItemFldValue(cfParams, wfe, envID, fields, name.getKey());
				}
			}
			String workItemId = "";
			try {
				workItemId = fields2.getWorkItemId().toString();
			} catch (SonoraApplicationException e) {
				 
				throw new RemoteException(e.getMessage());
			}
			key = "2." + wfe.m_WorkFlowID + "." + workItemId + "." + envID;
			// ... same for any other field.
			getWfEJB().setWorkItemFields(wfe.m_WorkFlowID, envID, fields);

			getWfEJB().routeEnvelope(wfe.m_WorkFlowID, envID, envID);

		}
		return key;
	}

	/**
	 * Modified by Henry, do not set '' value to Integer
	 * 
	 * @date 2017/05/16
	 * @param cfParams
	 * @param wfe
	 * @param envID
	 * @param fields
	 * @param name
	 * @throws NumberFormatException
	 * @throws RemoteException
	 */
	private void setWorkItemFldValue(Map<String, Object> cfParams, WFElement wfe, String envID, FmsRow fields,
			String name) throws NumberFormatException, RemoteException {
		try {
			if (getFieldType(name).equalsIgnoreCase("Decimal")) {
				fields.setValue(name, new BigDecimal(cfParams.get(name).toString()));

			} else if (getFieldType(name).equalsIgnoreCase("Integer")) {
				if (cfParams.get(name).toString().equals("")) {
					return;
				}
				fields.setValue(name, new Integer(cfParams.get(name).toString()));

			} else if (getFieldType(name).equalsIgnoreCase("Boolean")) {
				fields.setValue(name, new Boolean(cfParams.get(name).toString()));

			} else if (getFieldType(name).equalsIgnoreCase("Timestamp")) {
				fields.setValue(name, DateUtil.getTimestamp(cfParams.get(name).toString()));

			} else {
				fields.setValue(name, cfParams.get(name).toString());
			}
		} catch (SonoraException e) {
			LogUtil.logError(m_Logger, e.getMessage() + " fieldName:" + name + " wfId:" + wfe.m_WorkFlowID + " envID:" + envID);
			 
		}
	}

	private String getFieldType(String filedName) throws RemoteException {
		FmsFieldDefinition fmsFile;
		String fieldDataType = null;
		try {
			fmsFile = getFmsSchemaSessionEJB().getField(filedName);
			FieldDataType fdType = fmsFile.getDataType();
			fieldDataType = fdType.toString();
		} catch (FinderException e) {
			 
			throw LogUtil.logException(m_Logger,filedName, e);
		}
		return fieldDataType;
	}

	@Override
	public List<Map<String, String>> getDispatchButtons(String workstep, int flowId) throws RemoteException {

		List<Map<String, String>> dispatchBtnNames = new ArrayList<Map<String, String>>();
		int version = 0;
		try {
			ArrayList<WFElement> alwfs = getWfsSEJB().getElementList(flowId);
			int maxVersion = 0;
			for (WFElement elem : alwfs) {

				if (elem.m_IsPublished) {
					version = elem.getVersionNumber();
					break;
				} else if (maxVersion < elem.getVersionNumber()){
					
						maxVersion = elem.getVersionNumber();
					
				}
			}
			if (version == 0) {
				version = maxVersion;
			}
			List<WSElement> wsElements = getWssSEJB().getElementList(flowId, version);
			WSElement actElement = null;
			for (WSElement element : wsElements) {
				if (element.m_WorkStepName.equalsIgnoreCase(workstep)) {
					actElement = element;
					break;
				}

			}
			if (actElement != null) {
				dispatchBtnNames = getDispatchButton(actElement.activityOpts);
			}

		} catch (RemoteException e) {

			 
			throw LogUtil.logException(m_Logger, workstep, e);
		} catch (FinderException e) {
			 
			throw LogUtil.logException(m_Logger, workstep, e);
		} catch (ParserConfigurationException e) {
			 
			throw LogUtil.logException(m_Logger, workstep, e);
		} catch (SAXException e) {
			 
			throw LogUtil.logException(m_Logger, workstep, e);
		} catch (IOException e) {
			 
			throw LogUtil.logException(m_Logger, workstep, e);
		}

		return dispatchBtnNames;
	}

	private List<Map<String, String>> getDispatchButton(String optString)
			throws SAXException, IOException, ParserConfigurationException {

		List<Map<String, String>> result = new ArrayList<Map<String, String>>();
		if (optString != null) {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.parse(new InputSource(new ByteArrayInputStream(optString.getBytes())));
			NodeList nodeList = doc.getElementsByTagName("Dispatch");
			if (nodeList != null) {
				for (int i = 0; i < nodeList.getLength(); i++) {
					Node node = nodeList.item(i);
					NamedNodeMap attrs = node.getAttributes();
					getDispatchButtonAssist(result, attrs);
				}
			}
		}
		return result;

	}

  private void getDispatchButtonAssist(List<Map<String, String>> result, NamedNodeMap attrs) {
    if (attrs != null) {
    	Map<String, String> map = new HashMap<String, String>();
    	String name = "";
    	String displayname = "";
    	for (int j = 0; j < attrs.getLength(); j++) {

    		Node nattr = attrs.item(j);
    		if (nattr.getNodeName().equalsIgnoreCase("name")) {

    			name = nattr.getNodeValue();
    		}
    		if (nattr.getNodeName().equalsIgnoreCase("Display")) {

    			displayname = nattr.getNodeValue();
    		}

    	}
    	if (name.length() > 0 && displayname.length() > 0) {
    		map.put(name, displayname);
    		result.add(map);
    	}
    }
  }

	@Override
	public Map<String, String> closeWorkItems(String rkey) throws RemoteException {
		RepositoryKey key = RepositoryKey.getInstance(rkey);
		try {
			getWfEJB().removeFromWorkflow(key.getWorkflowId(), key.getWorkItemId().toString(),
					key.getEnvelopeId().toString());
		} catch (RemoteException e) {
			 
			throw new RemoteException(e.getMessage());
		}
		return null;
	}

}
