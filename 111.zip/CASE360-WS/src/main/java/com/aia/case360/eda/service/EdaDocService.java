package com.aia.case360.eda.service;

import java.rmi.RemoteException;
import java.util.Map;

import javax.ejb.CreateException;
import javax.naming.NamingException;

public interface EdaDocService {

	/**
	 * get Ex360 Image via eda connector
	 * 
	 * @throws RemoteException
	 */

	public Map<String, String> getEx360Image(String objectId, String objectName)
			throws NamingException, RemoteException, CreateException;

}