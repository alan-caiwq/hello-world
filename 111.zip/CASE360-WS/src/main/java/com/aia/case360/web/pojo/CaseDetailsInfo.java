package com.aia.case360.web.pojo;

import java.util.List;
import java.util.Map;

public class CaseDetailsInfo {
	// callingSystem
	private String callingSystem;
	// companyNo
	private String companyNo;
	// companyNo+policyNo
	private List<Map<String, String>> companyNoPolicyNoPairList;
	// caseStatus
	private List<String> caseStatus;

	private String caseStatusString;

	// requestType
	private String requestType;

	private String requestTypeStr;
	// processName
	private String processName;
	// requestNo
	private String requestNo;
	// requestDate
	private String requestDate;

	// requestStatus
	private String requestStatus;
	// reason
	private String reason;
	// subStatus
	private String subStatus;
	// assignee
	private String assignee;
	// createDate
	private String createDate;
	// updateDate
	private String updateDate;
	// createBy
	private String createBy;
	// lastupdateBy
	private String lastupdateBy;
	// policyNo
	private List<String> policyNo;

	private String policyNoStr;
	// claimNo
	private String claimNo;
	// actionSignal
	private String actionSignal;

	private String casefolderid;

	private String rootCaseId;

	private List<PendingComment> pendingComment;

	private String  lob;

	private String sourceSystem;
	
	public String getPolicyNoStr() {
		return policyNoStr;
	}

	public void setPolicyNoStr(String policyNoStr) {
		this.policyNoStr = policyNoStr;
	}

	public String getRequestTypeStr() {
		return requestTypeStr;
	}

	public void setRequestTypeStr(String requestTypeStr) {
		this.requestTypeStr = requestTypeStr;
	}

	public String getCallingSystem() {
		return callingSystem;
	}

	public void setCallingSystem(String callingSystem) {
		this.callingSystem = callingSystem;
	}

	public String getCompanyNo() {
		return companyNo;
	}

	public void setCompanyNo(String companyNo) {
		this.companyNo = companyNo;
	}

	public List<Map<String, String>> getCompanyNoPolicyNoPairList() {
		return companyNoPolicyNoPairList;
	}

	public void setCompanyNoPolicyNoPairList(List<Map<String, String>> companyNoPolicyNoPairList) {
		this.companyNoPolicyNoPairList = companyNoPolicyNoPairList;

	}

	public List<String> getCaseStatus() {
		return caseStatus;
	}

	public void setCaseStatus(List<String> caseStatus) {
		this.caseStatus = caseStatus;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getProcessName() {
		return processName;
	}

	public void setProcessName(String processName) {
		this.processName = processName;
	}

	public String getRequestNo() {
		return requestNo;
	}

	public void setRequestNo(String requestNo) {
		this.requestNo = requestNo;
	}

	public String getRequestDate() {
		return requestDate;
	}

	public void setRequestDate(String requestDate) {
		this.requestDate = requestDate;
	}

	public String getRequestStatus() {
		return requestStatus;
	}

	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getSubStatus() {
		return subStatus;
	}

	public void setSubStatus(String subStatus) {
		this.subStatus = subStatus;
	}

	public String getAssignee() {
		return assignee;
	}

	public void setAssignee(String assignee) {
		this.assignee = assignee;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}

	public String getLastupdateBy() {
		return lastupdateBy;
	}

	public void setLastupdateBy(String lastupdateBy) {
		this.lastupdateBy = lastupdateBy;
	}

	public List<String> getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(List<String> policyNo) {
		this.policyNo = policyNo;
	}

	public String getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(String claimNo) {
		this.claimNo = claimNo;
	}

	public String getActionSignal() {
		return actionSignal;
	}

	public void setActionSignal(String actionSignal) {
		this.actionSignal = actionSignal;
	}

	public String getCasefolderid() {
		return casefolderid;
	}

	public void setCasefolderid(String casefolderid) {
		this.casefolderid = casefolderid;
	}

	public String getCaseStatusString() {
		return caseStatusString;
	}

	public void setCaseStatusString(String caseStatusString) {
		this.caseStatusString = caseStatusString;
	}

	public List<PendingComment> getPendingComment() {
		return pendingComment;
	}

	public void setPendingComment(List<PendingComment> pendingComment) {
		this.pendingComment = pendingComment;
	}

	public String getRootCaseId() {
		return rootCaseId;
	}

	public void setRootCaseId(String rootCaseId) {
		this.rootCaseId = rootCaseId;
	}

	public String getLob() {
		return lob;
	}

  public void setLob(String lob) {
    this.lob = lob;
  }

  public String getSourceSystem() {
    return sourceSystem;
  }

  public void setSourceSystem(String sourceSystem) {
    this.sourceSystem = sourceSystem;
  }
	

}
