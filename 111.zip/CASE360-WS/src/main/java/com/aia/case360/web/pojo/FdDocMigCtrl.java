package com.aia.case360.web.pojo;

import java.math.BigDecimal;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

public class FdDocMigCtrl {

	private BigDecimal sRowId;
	private Integer migStatus;
	private String objectId;
	private String objectName;
	private String policyNo;

	@DateTimeFormat(pattern = "yyyy-MM-ddHH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-ddHH:mm:ss", timezone = "GMT+8")
	private Date policyDate;
	private String policySource;
	private String plicyStatus;

	@DateTimeFormat(pattern = "yyyy-MM-ddHH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-ddHH:mm:ss", timezone = "GMT+8")
	private Date migDate;
	private String DocSource;
	private String seq;
	private String companyNo;
	private String processType;
	private String formId;
	private String cObjectId;
	private String batchNo;

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public BigDecimal getsRowId() {
		return sRowId;
	}

	public void setsRowId(BigDecimal sRowId) {
		this.sRowId = sRowId;
	}

	public Integer getMigStatus() {
		return migStatus;
	}

	public void setMigStatus(Integer migStatus) {
		this.migStatus = migStatus;
	}

	public String getObjectId() {
		return objectId;
	}

	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}

	public String getObjectName() {
		return objectName;
	}

	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getPolicySource() {
		return policySource;
	}

	public void setPolicySource(String policySource) {
		this.policySource = policySource;
	}

	public String getPlicyStatus() {
		return plicyStatus;
	}

	public void setPlicyStatus(String plicyStatus) {
		this.plicyStatus = plicyStatus;
	}

	public Date getPolicyDate() {
		return policyDate;
	}

	public void setPolicyDate(Date policyDate) {
		this.policyDate = policyDate;
	}

	public Date getMigDate() {
		return migDate;
	}

	public void setMigDate(Date migDate) {
		this.migDate = migDate;
	}

	public String getDocSource() {
		return DocSource;
	}

	public void setDocSource(String docSource) {
		DocSource = docSource;
	}

	public String getSeq() {
		return seq;
	}

	public void setSeq(String seq) {
		this.seq = seq;
	}

	public String getCompanyNo() {
		return companyNo;
	}

	public void setCompanyNo(String companyNo) {
		this.companyNo = companyNo;
	}

	public String getProcessType() {
		return processType;
	}

	public void setProcessType(String processType) {
		this.processType = processType;
	}

	public String getFormId() {
		return formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}

	public String getcObjectId() {
		return cObjectId;
	}

	public void setcObjectId(String cObjectId) {
		this.cObjectId = cObjectId;
	}

}
