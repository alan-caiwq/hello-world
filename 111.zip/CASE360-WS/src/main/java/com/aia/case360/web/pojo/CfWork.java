package com.aia.case360.web.pojo;

public class CfWork {

	private String requestNum;
	private String caseStatus;
	private String linkRequestNum;

	public String getLinkRequestNum() {
		return linkRequestNum;
	}

	public void setLinkRequestNum(String linkRequestNum) {
		this.linkRequestNum = linkRequestNum;
	}

	public String getRequestNum() {
		return requestNum;
	}

	public void setRequestNum(String requestNum) {
		this.requestNum = requestNum;
	}

	public String getCaseStatus() {
		return caseStatus;
	}

	public void setCaseStatus(String caseStatus) {
		this.caseStatus = caseStatus;
	}

}
