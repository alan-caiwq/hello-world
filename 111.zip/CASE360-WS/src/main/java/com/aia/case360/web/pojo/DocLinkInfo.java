package com.aia.case360.web.pojo;

public class DocLinkInfo {
  
  private String orgRequestNo;
  
  private String objectId;

  /**
   * @return the orgRequestNum
   */
  public String getOrgRequestNo() {
    return orgRequestNo;
  }

  /**
   * @param orgRequestNum the orgRequestNum to set
   */
  public void setOrgRequestNo(String orgRequestNo) {
    this.orgRequestNo = orgRequestNo;
  }

  /**
   * @return the objectId
   */
  public String getObjectId() {
    return objectId;
  }

  /**
   * @param objectId the objectId to set
   */
  public void setObjectId(String objectId) {
    this.objectId = objectId;
  }

  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "DocLinkInfo [orgRequestNo=" + orgRequestNo + ", objectId=" + objectId + "]";
  }
  
  

}
