package com.aia.case360.platform.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Component;

@Component
public class FsDocumentBean {

	private static final String DOCUMENTID = "DOCUMENTID";
	private static final String PAGEINDICATORS = "PAGEINDICATORS";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public Map<String, String> getVoidDocuments() throws SQLException {

		String sql = "select DOCUMENTID,PAGEINDICATORS from FS_DOCUMENT where PAGEINDICATORS like '%V%'";

		Map<String, String> result = (Map<String, String>) jdbcTemplate.query(sql, new ResultSetExtractor<Object>() {
			public Object extractData(ResultSet resultObj) throws SQLException, DataAccessException {
				Map<String, String> tempResult = new HashMap<String, String>();
				while (resultObj.next()) {
					tempResult.put(resultObj.getString(DOCUMENTID), resultObj.getString(PAGEINDICATORS));
				}
				return tempResult;
			}
		});
		return result;
	}

}
