package com.aia.case360.platform.casefolder.impl;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.FinderException;

import org.springframework.stereotype.Component;

import com.aia.case360.platform.casefolder.CasefolderSearchHelper;
import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.web.service.impl.AbstractHelperImpl;
import com.eistream.sonora.fields.FmsColumnDefinition;
import com.eistream.sonora.query.Query;
import com.eistream.sonora.query.QueryForm;

@Component
public class CasefolderSearchHelperImpl extends AbstractHelperImpl implements CasefolderSearchHelper {

	@Override
	public List<String> getFormDefinition(String queryName) throws RemoteException {
        String message="Fuction : getFormDefinition ";    
		List<String> columns = new ArrayList<String>();
		try {

			if (getQryEJB() == null || getFmsSchemaSessionEJB() == null) {
				RemoteException e = new RemoteException("EJB is null!");
				throw e;
			}
			Query query = getQryEJB().getElementByName(queryName);
			QueryForm qf = query.getForm();
			qf.getFmsTableDefinitionID();

			List<FmsColumnDefinition> columndefs = getFmsSchemaSessionEJB().getColumns(qf.getFmsTableDefinitionID());

			for (FmsColumnDefinition col : columndefs) {
				columns.add(col.getFieldName());
			}
			return columns;

		} catch (RemoteException e) {
			 
			e = new RemoteException(queryName, e);
			throw e;
		} catch (FinderException e1) {
			LogUtil.logException(m_Logger, message, e1);
			RemoteException e = new RemoteException(queryName, e1);
			throw e;
		}
	}

}
