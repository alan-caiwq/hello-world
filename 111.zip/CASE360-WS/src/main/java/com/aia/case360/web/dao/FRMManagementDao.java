package com.aia.case360.web.dao;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

@Repository
public interface FRMManagementDao {

	//For box management
	public int isBoxExist(Map<String,String> params)  throws RemoteException;
	
	public int isBoxBatchExist(Map<String,String> params)  throws RemoteException;
	
	public void addBoxNo(Map<String,String> params)  throws RemoteException;
	
	public int updateBoxNo(Map<String,String> params)  throws RemoteException;
	
	public int updateBoxBatchNo(Map<String,String> params)  throws RemoteException;
	
	public void addBoxHistory(Map<String,String> params)  throws RemoteException;
	
	//For Investigation
	public List<Map<String, Object>> searchInvestigation(Map<String, String> params)  throws RemoteException;
	
	public int updateInvestigation(Map<String,String> params)  throws RemoteException;
	
	public List<Map<String, Object>> searchInvestAuditTrail(Map<String,String> params)  throws RemoteException;
	
	public void addInvestAuditTrail(Map<String,String> params)  throws RemoteException;
	
	//For Scanned Document Enquiry
	public List<Map<String, Object>> searchScannedDoc(Map<String, String> params)  throws RemoteException;
	
	//For Request Mangement
	public List<Map<String, Object>> searchSubmittedRequest(Map<String, String> params)  throws RemoteException;
	
	//For search Borrow History
	public List<Map<String, Object>> searchBorrowHistory(Map<String, String> params)  throws RemoteException;
	
	//For Warehouse
	public List<Map<String, Object>> getWarehouseList()  throws RemoteException;
	
}
