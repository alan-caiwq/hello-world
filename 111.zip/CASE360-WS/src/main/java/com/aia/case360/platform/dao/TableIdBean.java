package com.aia.case360.platform.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Component;

@Component
public class TableIdBean {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	private Map<String, String> tableIds;

	private Map<String, String> templateIds;

	Map<String, String> tableIdsMap = new HashMap<String, String>();
	Map<String, String> templateIdsMap = new HashMap<String, String>();

	private void loadTableIds()  {

		if (tableIds == null) {

			String sql = "select TABLEID,PARENTID,SQLTABLENAME,REPOSITORYID from SONORATABLES where REPOSITORYID >0 ";

			jdbcTemplate.query(sql, new ResultSetExtractor() {
				public Object extractData(ResultSet resultObj) throws SQLException, DataAccessException {

					while (resultObj.next()) {

						tableIdsMap.put(resultObj.getString("SQLTABLENAME"), resultObj.getString("TABLEID"));
						if (resultObj.getString("PARENTID") != null) {
							templateIdsMap.put(resultObj.getString("SQLTABLENAME"), resultObj.getString("PARENTID"));
						}

					}
					return "";
				}
			});

			tableIds = Collections.unmodifiableMap(tableIdsMap);
			templateIds = Collections.unmodifiableMap(templateIdsMap);
		}

	}

	public Map<String, String> getTableIds()  {
		loadTableIds();
		return tableIds;
	}

	public Map<String, String> getTemplateIds()  {
		loadTableIds();
		return templateIds;
	}

}
