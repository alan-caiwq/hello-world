package com.aia.case360.web.pojo;

public class FRMCaseCheckRetrieveDocResult {

  private String createUser;
  
  private String caseId;
  
  private String reqNum;
  
  private String conflictPage;

  /**
   * @return the createUser
   */
  public String getCreateUser() {
    return createUser;
  }

  /**
   * @return the caseId
   */
  public String getCaseId() {
    return caseId;
  }

  /**
   * @return the reqNum
   */
  public String getReqNum() {
    return reqNum;
  }

  /**
   * @return the conflictPage
   */
  public String getConflictPage() {
    return conflictPage;
  }

  /**
   * @param createUser the createUser to set
   */
  public void setCreateUser(String createUser) {
    this.createUser = createUser;
  }

  /**
   * @param caseId the caseId to set
   */
  public void setCaseId(String caseId) {
    this.caseId = caseId;
  }

  /**
   * @param reqNum the reqNum to set
   */
  public void setReqNum(String reqNum) {
    this.reqNum = reqNum;
  }

  /**
   * @param conflictPage the conflictPage to set
   */
  public void setConflictPage(String conflictPage) {
    this.conflictPage = conflictPage;
  }

  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "FRMCaseCheckRetrieveDocResult [createUser=" + createUser + ", caseId=" + caseId
        + ", reqNum=" + reqNum + ", conflictPage=" + conflictPage + "]";
  }
}
