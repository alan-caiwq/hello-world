package com.aia.case360.eda;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import javax.imageio.stream.MemoryCacheImageInputStream;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.graphics.image.LosslessFactory;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aia.case360.platform.common.LogUtil;
import com.itextpdf.text.pdf.PdfReader;

/**
 * @author bsnpbjy
 *
 *         ImageUtil: Utility class that responsible for image conversion from
 *         TIF to PDF
 *
 *         History: YYYY/MM/DD Developer Revision PDCF
 *         ------------------------------------------------------------------------------------
 *         2018/08/14 FengLi 001 Initial version
 */

public class ImageUtil {

	private ImageUtil() {
	}

	private static Logger m_Logger = LoggerFactory.getLogger("ImageUtil");

	private static PDRectangle getPageSize(String paperSize) {
		if ("A4".equalsIgnoreCase(paperSize)) {
			return PDRectangle.A4;
		}

		return PDRectangle.A4;
	}

	/**
	 * 002: new method to check if page is required to be included
	 * 
	 * @param pageNo
	 * @param pageToInclude
	 * @return
	 */
	private static boolean isPageRequired(int pageNo, int pageToInclude) {
		if (pageToInclude == -1) {
			return true;
		} else {
			return (pageNo == pageToInclude);
		}
	}

	public static Map<String, Object> convertImageoPDF(byte[] byteImage, String paperSize, Map<String, Object> indexMap)
			throws IOException {
		try {
			convertImageoPDF(byteImage, paperSize, -1, indexMap);

		} catch (Exception e) {
			LogUtil.logError(m_Logger, e.toString());
		}
		return indexMap;
	}

	/**
	 * Method to convert a TIFF to PDF directly.
	 * 
	 * @throws IOException
	 */
	public static Map<String, Object> convertImageoPDF(byte[] byteImage, String paperSize, int pageNumber,
			Map<String, Object> indexMap)  throws IOException {
		long iStart = System.currentTimeMillis();
		LogUtil.logInfo(m_Logger,"ImageUtil: convertImageoPDF start ========== " + iStart);
		indexMap.put("ConvertedFlag", false);
		List<BufferedImage> bImageList = null;
		String imageFormat = (String) indexMap.get("imageType");
		int numPdfPages;
		long pdfSize;

		bImageList = getAllBufferedImages(byteImage, pageNumber, imageFormat);

		PDDocument pdDoc = null;
		PDPage page = null;
		PDImageXObject pdImage = null;
		PDPageContentStream contentStream = null;
		PDRectangle pdRectangle = null;
		ByteArrayOutputStream baos = new ByteArrayOutputStream();

		try {
			pdDoc = new PDDocument();
			pdRectangle = getPageSize(paperSize);

			for (int i = 0; i < bImageList.size(); i++) {
				try {
					page = new PDPage(pdRectangle);
					pdDoc.addPage(page);
					pdImage = LosslessFactory.createFromImage(pdDoc, bImageList.get(i));
					contentStream = new PDPageContentStream(pdDoc, page);
					contentStream.drawImage(pdImage, 1, 1, pdRectangle.getWidth(), pdRectangle.getHeight());
				} finally {
					if (contentStream != null) {
						contentStream.close();
					}
				}
			}
			pdDoc.save(baos);
			pdDoc.close();
			byte[] content = baos.toByteArray();

			PdfReader r = new PdfReader(content);
			numPdfPages = r.getNumberOfPages();
			pdfSize = r.getFileLength();

			indexMap.put("TIF_PAGES", bImageList.size());
			indexMap.put("PDF_PAGES", numPdfPages);
			indexMap.put("PDF_SIZE", pdfSize);
			indexMap.put("convertDateTime", new Date());
			indexMap.put("pdfByte", content);

			indexMap.put("convertTifToPdfDateTime", new Date());

			long iEnd = System.currentTimeMillis();
			LogUtil.logInfo(m_Logger,"ImageUtil: convertImageoPDF end ========== " + iEnd);
			LogUtil.logInfo(m_Logger,"ImageUtil: convertImageoPDF spend time ========== " + (iEnd - iStart));
			indexMap.put("CONVERT_FIEL_SPENDTIME", (iEnd - iStart));
			indexMap.put("ConvertedFlag", true);
		} catch (Exception e) {
			LogUtil.logError(m_Logger, e.toString());
			return indexMap;
		} finally {
			try {
				if (pdDoc != null) {
					pdDoc.close();
				}

			} catch (IOException e) {
				LogUtil.logError(m_Logger, e.toString());
			}
		}

		return indexMap;
	}

	private static List<BufferedImage> getAllBufferedImages(byte[] byteImage, int pageToInclude, String imageFormat) {
		long startTime = System.currentTimeMillis();
		List<BufferedImage> buffImgList = new ArrayList<BufferedImage>();
		LogUtil.logInfo(m_Logger,"Start to getAllBufferedImages()");
		if (null == byteImage || 0 == byteImage.length) {
			LogUtil.logError(m_Logger, "the argument 'byteImage' must not be null or empty");
			return buffImgList;
		}

		Iterator<ImageReader> iterator = ImageIO.getImageReadersByFormatName(imageFormat);

		if (iterator == null || !iterator.hasNext()) {
			LogUtil.logError(m_Logger, "Image file format not supported by ImageIO");
			return buffImgList;
		}

		ImageReader reader = null;
		try {
			ByteArrayInputStream bais = new ByteArrayInputStream(byteImage);
			ImageInputStream imageInputstream = new MemoryCacheImageInputStream(bais);

			if (imageInputstream.length() == 0) {
				LogUtil.logError(m_Logger, "Unable to get ImageInputStream");

			} else {

				reader = iterator.next();
				reader.setInput(imageInputstream);

				int pageCount = reader.getNumImages(true);
				LogUtil.logInfo(m_Logger,"Image has " + pageCount + " pages");

				checkIfPageRequired(pageToInclude, buffImgList, reader, pageCount);
			}
		} catch (NullPointerException e) {
			LogUtil.logError(m_Logger, e.getMessage());
		} catch (IOException e) {
			LogUtil.logError(m_Logger, e.getMessage());
		}
		String log = String.format("End to getAllBufferedImages. Time taken: %s ms",
				(System.currentTimeMillis() - startTime));
		LogUtil.logInfo(m_Logger,log);
		return buffImgList;
	}

	private static void checkIfPageRequired(int pageToInclude, List<BufferedImage> buffImgList, ImageReader reader,
			int pageCount) throws IOException {
		BufferedImage bufImg = null;
		for (int i = 0; i < pageCount; i++) {
			// 002: if page is required, add into list
			if (isPageRequired(i, pageToInclude)) {
				bufImg = reader.read(i);
				buffImgList.add(bufImg);

				if (pageToInclude > -1) {
					break;
				}
			}
		}
	}

}
