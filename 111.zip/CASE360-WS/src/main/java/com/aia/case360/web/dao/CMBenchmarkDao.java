package com.aia.case360.web.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.aia.case360.web.pojo.CMAddBenchmarkParam;
import com.aia.case360.web.pojo.CMEditBenchmarkParam;
import com.aia.case360.web.pojo.CMGetBenchmarkParam;
import com.aia.case360.web.vo.CMGetBenchmarksVo;

public interface CMBenchmarkDao {

  List<CMGetBenchmarksVo> getBenchmarks(CMGetBenchmarkParam param) throws SQLException;

  CMGetBenchmarksVo getBenchmarkById(@Param("sRowid")Long benchmarkId, @Param("cmType")Integer cmType) throws SQLException;

  Long addBenchmark(CMAddBenchmarkParam param) throws SQLException;

  Long editBenchmark(CMEditBenchmarkParam param) throws SQLException;

  void batchUpdateBenchmarkStatus(@Param("user")String user, @Param("ids")String ids, @Param("status")Integer status, @Param("cmType")Integer cmType) throws SQLException;

  Boolean checkBenchmarkNameExist(@Param("benchmarkName")String benchmarkName, @Param("cmType")Integer cmType) throws SQLException;

  Boolean checkBenchmarkNameExistWithOtherId(@Param("name")String benchmarkName, @Param("id")Long sRowid, @Param("cmType")Integer cmType) throws SQLException;

}
