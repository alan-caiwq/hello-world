package com.aia.case360.uam.domain;

public class UAMRoleAuditTrail {

	private Integer roleType;
	private Long roleId;
	private String reqIds;
	private String actIds;
	private String menuIds;

	private String roleName;
	private String department;
	private int enable;
	private String remark;
	private String loginUser;

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "UAMRoleAuditTrail [roleType=" + roleType + ", roleId=" + roleId + ", reqIds=" + reqIds + ", actIds="
				+ actIds + ", menuIds=" + menuIds + ", roleName=" + roleName + ", department=" + department
				+ ", enable=" + enable + ", remark=" + remark + ", loginUser=" + loginUser + "]";
	}

	/**
	 * @return the roleType
	 */
	public Integer getRoleType() {
		return roleType;
	}

	/**
	 * @return the roleId
	 */
	public Long getRoleId() {
		return roleId;
	}

	/**
	 * @return the reqIds
	 */
	public String getReqIds() {
		return reqIds;
	}

	/**
	 * @return the actIds
	 */
	public String getActIds() {
		return actIds;
	}

	/**
	 * @return the menuIds
	 */
	public String getMenuIds() {
		return menuIds;
	}

	/**
	 * @return the roleName
	 */
	public String getRoleName() {
		return roleName;
	}

	/**
	 * @return the department
	 */
	public String getDepartment() {
		return department;
	}

	/**
	 * @return the enable
	 */
	public int getEnable() {
		return enable;
	}

	/**
	 * @return the remark
	 */
	public String getRemark() {
		return remark;
	}

	/**
	 * @return the loginUser
	 */
	public String getLoginUser() {
		return loginUser;
	}

	/**
	 * @param roleType the roleType to set
	 */
	public void setRoleType(Integer roleType) {
		this.roleType = roleType;
	}

	/**
	 * @param roleId the roleId to set
	 */
	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	/**
	 * @param reqIds the reqIds to set
	 */
	public void setReqIds(String reqIds) {
		this.reqIds = reqIds;
	}

	/**
	 * @param actIds the actIds to set
	 */
	public void setActIds(String actIds) {
		this.actIds = actIds;
	}

	/**
	 * @param menuIds the menuIds to set
	 */
	public void setMenuIds(String menuIds) {
		this.menuIds = menuIds;
	}

	/**
	 * @param roleName the roleName to set
	 */
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	/**
	 * @param department the department to set
	 */
	public void setDepartment(String department) {
		this.department = department;
	}

	/**
	 * @param enable the enable to set
	 */
	public void setEnable(int enable) {
		this.enable = enable;
	}

	/**
	 * @param remark the remark to set
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}

	/**
	 * @param loginUser the loginUser to set
	 */
	public void setLoginUser(String loginUser) {
		this.loginUser = loginUser;
	}
}
