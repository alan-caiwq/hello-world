package com.aia.case360.platform.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Component;

@Component
public class FieldBean {



	@Autowired
	private JdbcTemplate jdbcTemplate;

	@SuppressWarnings({ "unchecked", "unused" })
	private Map<String, String> loadFields() throws SQLException {
		String sql = "select FIELDNAME,PARENTNAME,DATATYPE from SONORAFIELDS where PARENTNAME is not null";

		Map<String, String> query = (Map<String, String>) jdbcTemplate.query(sql, new ResultSetExtractor<Object>() {
			public Object extractData(ResultSet resultObj) throws SQLException, DataAccessException {
				Map<String, String> result = new HashMap<String, String>();
				while (resultObj.next()) {
					result.put(resultObj.getString("FIELDNAME"), resultObj.getString("PARENTNAME"));

				}
				return result;
			}
		});
		return query;

	}


}
