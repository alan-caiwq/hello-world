package com.aia.case360.web.pojo;

import java.io.Serializable;

public class GetCustomerInfoParameter implements Serializable {
	// policyNo
	private String policyNo;
	// companyCode
	private String companyCode;

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

}
