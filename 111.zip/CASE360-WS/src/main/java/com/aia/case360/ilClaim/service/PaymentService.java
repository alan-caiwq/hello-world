package com.aia.case360.ilClaim.service;

import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public interface PaymentService {

	public List<Map<String, String>> getPaymentApproval(String paymentIds, Map<String, String> params)  throws SQLException;

	public List<Map<String, String>> getPaymentAuthorization(String paymentIds, Map<String, String> params)
			 throws SQLException;

}
