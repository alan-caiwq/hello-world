package com.aia.case360.platform.common;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import com.eistream.sonora.exceptions.SonoraException;
import com.eistream.sonora.grammar.QueryProperties;
import com.eistream.sonora.system.SystemSessionEJB;

public class ScriptUtil {
	
	private ScriptUtil() {}

	public static final Map<String, Object> doScript(String scriptName, HashMap<String, String> params, Locale lc,
			SystemSessionEJB systemEjb) throws RemoteException {

		String[] prpNames = null;
		Map<String, Object> retMap = new HashMap<String, Object>();
		try {

			Object scriptResponse = systemEjb.doScript(scriptName, params, lc);
			if (scriptResponse == null)
				return null;
			if (scriptResponse instanceof QueryProperties) {
				QueryProperties qp = (QueryProperties) scriptResponse;

				prpNames = qp.getNames();
				for (int j = 0; j < prpNames.length; j++) {

					retMap.put(prpNames[j], qp.get(prpNames[j]));

				}
			} else {
				retMap.put("StrBack", scriptResponse.toString());
			}
		} catch (RemoteException e) {
			 
			throw e;

		} catch (SonoraException e) {

			 
			throw new RemoteException(e.getMessage());
		}
		return retMap;
	}

}
