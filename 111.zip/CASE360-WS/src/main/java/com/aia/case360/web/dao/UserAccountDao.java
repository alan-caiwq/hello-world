/**
 * -------------------------------------------------
 * Copyright (c) 2017-2019 AIA . All Rights Reserved.  
 *-------------------------------------------------
 * Project Name: Pulse
 * @author: 
 * @version: 1.0
 * Description: 
 * Revised Records:
 */
package com.aia.case360.web.dao;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.aia.case360.uam.domain.UamUser;
import com.aia.case360.uam.domain.UserAuthorityVO;

/**
 * @author bsnpbdu
 *
 */

@Repository
public interface UserAccountDao {

	public List<UamUser> findAllUsers();

	public List<UamUser> findUserByUserId(String userId);

	public void insertNewAccount(UamUser userAccountFromAD);

	public List<UserAuthorityVO> queryAuthorityByUserId(String userId);

	public List<Map<String, String>> queryLeaderUsers(@Param("userId") String userId, @Param("userName") String userName) throws RemoteException;

	public List<Map<String, String>> queryTeamLeaders(@Param("componentId") Integer componentId) throws RemoteException;

	public List<Map<String, String>> queryAllUsers(@Param("componentId") Integer componentId) throws RemoteException;

	public List<Map<String, String>> queryUserList(Map<String, String> params) throws RemoteException;

	public Integer insertComponentLeader(List<Map<String, Object>> list) throws RemoteException;

	public Integer deleteComponentLeader(@Param("componentId") Integer componentId) throws RemoteException;

	public List<Map<String, Object>> queryUserDepartment(@Param("userId") String userId) throws RemoteException;

	public List<Map<String, Object>> queryAllComponent() throws RemoteException;

	public List<Map<String, Object>> queryUserSkillSet(@Param("userId") String userId) throws RemoteException;

	public List<Map<String, Object>> queryUserTrainRoleReqActInfo(@Param("userId") String userId) throws RemoteException;

	public List<Map<String, Object>> queryUserTSARRecords(@Param("userId") String userId) throws RemoteException;

	public Integer deleteUserSkillSet(@Param("loginId") String loginId, @Param("userId") String userId) throws RemoteException;

	public Integer deleteUserTrainInfo(@Param("loginId") String loginId, @Param("userId") String userId) throws RemoteException;

	public Integer deleteUserTSARInfo(@Param("userId") String userId) throws RemoteException;

	public Integer insertUserSkillSet(Map<String, Object> params) throws RemoteException;

	public Integer insertUserTrainInfo(List<Map<String, Object>> params) throws RemoteException;

	public Integer insertUserTSARInfo(List<Map<String, Object>> params) throws RemoteException;

//	public Integer insertUserUNITSARInfo(List<Map<String, Object>> params) throws RemoteException;

	public List<Map<String, Object>> queryUserUNITSARRecords(@Param("userId") String userId ,@Param("department") String department) throws RemoteException;

	public List<Map<String, Object>> queryDefaultUNITSARRecords(@Param("userId") String userId) throws RemoteException;

	public List<Map<String, Object>> queryTSARName(@Param("sarGroup") String sarGroup, @Param("riskType") String riskType, @Param("prdType") String prdType,
			@Param("payFrenquency") String payFrenquency) throws RemoteException;

	public String findUserNameById(@Param("userId") String userId) throws RemoteException;

	public List<Map<String, Object>> queryCLMAuthDropDownData() throws RemoteException;

	public List<Map<String, Object>> queryTeamSetting(@Param("teamId") int teamId, @Param("userId") String userId) throws RemoteException;

	public Integer deleteTeamSetting(@Param("teamId") int teamId) throws RemoteException;

	public Integer insertTeamSetting(List<Map<String, Object>> list) throws RemoteException;

	public Integer clearInactiveUserCaseOwner(@Param("userId") String userId) throws RemoteException;

	public void copyTo(@Param("srcUser") String srcUser, @Param("targetUser") String targetUser,
			@Param("checkFlag") int checkFlag, @Param("currentUser") String currentUser) throws RemoteException;

	public Boolean isUserRoleExist(@Param("userId") String userId) throws RemoteException;

	public Integer updateUser(UamUser uamuser) throws RemoteException;

	public Integer deleteUserRoles(@Param("userId") String userId) throws RemoteException;

	public Integer insertUserRoles(@Param("roleIds") List<String> roleIds, @Param("userId") String userId)
			throws RemoteException;

	public Integer deleteUserTeams(@Param("userId") String userId) throws RemoteException;

	public Integer insertUserTeams(@Param("teams") String[] teams, @Param("userId") String userId) throws RemoteException;

	public List<Map<String, String>> queryAllUserInfo(@Param("userId") String userId) throws RemoteException;

	public Integer updateUserStatus(@Param("status") String status, @Param("userIds") List<String> userIds)
			throws RemoteException;

	public Integer insertUAMUsers(@Param("users") List<Map<String, String>> users) throws RemoteException;

	public Integer updateUAMUsers(@Param("users") List<Map<String, String>> users) throws RemoteException;

	public List<Map<String, String>> getAllTeamList();

	public Integer syncUserFromSonora() throws RemoteException;

	public List<Map<String, Object>> checkUserAvaliable(@Param("userId") String userId) throws RemoteException;

	public List<Map<String, Object>> queryTeamMember(@Param("loginUser") String loginUser) throws RemoteException;

	public List<Map<String, Object>> getLeaders(@Param("userId") String userId) throws RemoteException;

	public List<Map<String, String>> queryC360Users();

	public List<Map<String, Object>> queryRoleByRoleName(@Param("role") String role);

	/**
	 * bsnpc0y add 20180920
	 * 
	 * @param userId
	 * @return
	 */
	public List<Map<String, Object>> getDepartmentByUserId(@Param("userId") String userId);

	/**
	 * bsnpc0y add 20180920
	 * 
	 * @param componentId
	 * @return
	 */
	public List<Map<String, Object>> getTeamListByComponentId(@Param("componentId") String componentId);

	// added by bsnpc1g on 21/09/2018 MyBatis
	public String getCompCDByUserId(String userId);
	// added end

	public void updateUserAdminAuth(@Param("userId") String userId) throws RemoteException;

	public List<Map<String, Object>> getMenuCodeMap() throws RemoteException;

	public List<Map<String, String>> findReqActCodeMapList(@Param("list") List<String> queryParamList) throws RemoteException;

	public String getUserNames(List<String> userList);

	public Integer clearUserColumnConfigure(@Param("userId") String userId) throws RemoteException;

	public String getUamUserDepartment(@Param("userId") String userId) throws RemoteException;

	public void updateTeamAmountAuthority(@Param("teamId") int teamId, @Param("list")List<Map<String, Object>> amountAuthMapList) throws RemoteException;
	
	public void updateTeamAgencyLocation(@Param("teamId") int teamId, @Param("agencyLocation")String agencyLocation) throws RemoteException;

	public String queryTeamAgencyLocation(@Param("teamId") int teamId) throws RemoteException;

	public List<Map<String, Object>> queryTeamAmountAuthority(@Param("teamId") int teamId) throws RemoteException;
	
//	public Integer updateUserInfo(@Param("userName") String userName, @Param("email") String email, @Param("status") String status, @Param("userId") String userId) throws RemoteException;
	
	public List<Map<String, String>> queryUsersDepartment() throws RemoteException;
	
	public List<String> getCaseIdByProcessor(@Param("userId") String userId) throws RemoteException;
}
