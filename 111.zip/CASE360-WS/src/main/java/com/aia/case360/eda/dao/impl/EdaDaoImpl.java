package com.aia.case360.eda.dao.impl;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.aia.case360.eda.dao.EdaDao;
import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.common.PropertyUtil;
import com.aia.case360.platform.dao.TableIdBean;
import com.eistream.sonora.webservices.WsSessionEJB;

/**
 * 
 * @author bsnpbjy
 *
 */
@Repository
public class EdaDaoImpl implements EdaDao {

	private static final String LOCALDOCUMENTID = "DOCUMENTID";
	private static final String LOCALPAGEINDICATOR = "PageIndicator";
	private static final String LOCALOBJECTID = "OBJECT_ID";
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private JdbcTemplate locatorJdbcTemplate;	
	@Autowired
	private TableIdBean dataTableIds;

	private final String e360SelectAttr = PropertyUtil.getCommonProperty("E360_SELECT_SQL_ATTRIBUTES");
	private final String c360SelectAttr = PropertyUtil.getCommonProperty("C360_SELECT_SQL_ATTRIBUTES");
	private final String c360InsertAttr = PropertyUtil.getCommonProperty("C360_INSERT_SQL_ATTRIBUTES");
	private final String c360UpdateAttributesAll = PropertyUtil.getCommonProperty("C360_UPDATE_SQL_ATTRIBUTES_ALL");
	private final String c360UpdateFilestore = PropertyUtil.getCommonProperty("C360_UPDATE_SQL_FS_DOCUMENTS");
	private final String c360UpdateMigCtrl = PropertyUtil.getCommonProperty("C360_UPDATE_SQL_FD_DOC_MIG_CTRL");
	private final String c360InsertEdaReport = PropertyUtil.getCommonProperty("C360_INSERT_SQL_EDA_REPORT");
	private final String c360SelectFilestore = PropertyUtil.getCommonProperty("C360_SELECT_SQL_FS_DOCUMENTS");
	private final String c360UpdateAttributes = PropertyUtil.getCommonProperty("C360_UPDATE_SQL_ATTRIBUTES");
	private final String c360UpdateAttr = PropertyUtil.getCommonProperty("C360_UPDATE_SQL_ATTR");
	private final String c360UpdateDoclink = PropertyUtil.getCommonProperty("C360_UPDATE_SQL_DOCLINK");
	private final String c360UpdateXFilestore = PropertyUtil.getCommonProperty("C360_UPDATE_SQL_FS_DOCUMENTS_X");
	private final String c360SelectMigDemand = PropertyUtil.getCommonProperty("C360_SELECT_SQL_MIG_DEMAND");
	private final String c360InsertMigDemand = PropertyUtil.getCommonProperty("C360_INSERT_SQL_MIG_DEMAND");
	private final String c360UpdateMigDemand = PropertyUtil.getCommonProperty("C360_UPDATE_SQL_MIG_DEMAND");
				
	private Logger m_Logger = LoggerFactory.getLogger(getClass());

	@Override
	public boolean insertDocAttr(Map<String, Object> docAttr) {
		boolean iRet = false;
		try {
			StringBuilder sql = new StringBuilder(c360InsertAttr);
			Object args[] = new Object[] { docAttr.get("Agency"), docAttr.get("AgentName"),
					docAttr.get("AssignReasonCode"), docAttr.get("AssignUserId"), docAttr.get("AutoFiling"),
					docAttr.get("BatchNo"), docAttr.get("BoxNo"), docAttr.get("CLMCategory"), docAttr.get("COHUserId"),
					docAttr.get("CompanyNo"), docAttr.get("CurrentUserId"), docAttr.get("FormDesc"),
					docAttr.get("FormId"), docAttr.get("Inprogress"), // need confim if from INPROGRESS_MIG
					docAttr.get("InprogressUserId"), docAttr.get("IsCLMForm"), docAttr.get("IsMajorClaim"),
					docAttr.get("IsMedCase"), docAttr.get("IsPOSForm"), docAttr.get("IsPOSILPForm"),
					docAttr.get("IsUNIForm"), docAttr.get("ItemStatus"), docAttr.get("JobStatus"),
					docAttr.get("KIVExpirationDate"), docAttr.get("KIVReason"), docAttr.get("KIVReasonCode"),
					docAttr.get("KIVUserId"), docAttr.get("LastPendDate"), docAttr.get("LastProcDate"),
					docAttr.get("LastProcUserId"), docAttr.get("LatestDocRecDate"), docAttr.get("LinkIndicator"),
					docAttr.get("LOB"), docAttr.get("LOBAStatus"), docAttr.get("LOBADLastSyncDate"),
					docAttr.get("LOBADSyncRetried"), docAttr.get("LOBADSynced"), docAttr.get("Name"),
					docAttr.get("NRIC"), docAttr.get("OBJECT_CLASS"), docAttr.get(LOCALOBJECTID),
					docAttr.get("OBJECT_NAME"), docAttr.get("OBJECT_SERVER"), docAttr.get("OBJECT_TYPE"),
					docAttr.get("OrgCompanyNo"), docAttr.get("OrgPolicyNo"), docAttr.get("OrgRequestNo"),
					docAttr.get("OrgRequestType"), docAttr.get("OriginalUserId"), docAttr.get("PolicyNo"),
					docAttr.get("PolicyType"), docAttr.get("POSRequestCategory"), docAttr.get("ProcessDueDate"),
					docAttr.get("ProcessType"), docAttr.get("QueueId"), docAttr.get("ReceivedDate"),
					docAttr.get("ReferFromUserId"), docAttr.get("ReferReasonCode"), docAttr.get("ReferToMR"),
					docAttr.get("ReferToUserId"), docAttr.get("ReferUserList"), docAttr.get("RelatedPolicyNo"),
					docAttr.get("ReqReceivedDate"), docAttr.get("RequestNo"), docAttr.get("RequestType"),
					docAttr.get("RouError"), docAttr.get("RouErrorRetryCount"), docAttr.get("ScanDate"),
					docAttr.get("SourceSystemCode"), docAttr.get("StatusIndicator"), docAttr.get("TAADD"),
					docAttr.get("TACI"), docAttr.get("TCI"), docAttr.get("TSA"), docAttr.get("UNIPlanName"),
					docAttr.get("UNIPlanType"), docAttr.get("WFNonWF"), docAttr.get("WFStatus"),
					docAttr.get("WFRCrDate"), docAttr.get("WFRCrUserId"), docAttr.get("WFRUpdDate"),
					docAttr.get("WFRUpdUserId"), docAttr.get("WorkitemFormId"), docAttr.get("IS_DELETED"),
					docAttr.get(LOCALPAGEINDICATOR) };
			// need confirm IS_DELETED
			LogUtil.logInfo(m_Logger,String.format("EdaDaoImpl: insertDocAttr sql=======%s====%s", docAttr.get(LOCALOBJECTID),
					sql.toString()));
			int count = jdbcTemplate.update(sql.toString(), args);

			if (count > 0) {
				iRet = true;
			} 
		} catch (Exception e) {
			LogUtil.logException(m_Logger, docAttr.toString(), e);
		}

		return iRet;
	}

	@Override
	public boolean updateDocFileStore(Map<String, Object> docFs) {
		boolean iRet = false;
		try {
			StringBuilder sql = new StringBuilder(c360UpdateFilestore);
			Object args[] = new Object[] { docFs.get("FILENAME"), docFs.get("IS_DELETED"), docFs.get(LOCALOBJECTID),
					docFs.get("IS_SYS_VOID"), docFs.get("IS_VOID"), docFs.get("LAST_UPDATED_BY"),
					docFs.get(LOCALPAGEINDICATOR), docFs.get("FILE_EXTENSION"), docFs.get("IS_MIGRATED"),
					docFs.get("IS_MOVED"), docFs.get("SUBMIT_CHANNEL"), docFs.get(LOCALDOCUMENTID) };
			LogUtil.logInfo(m_Logger,String.format("EdaDaoImpl: updateDocFileStore sql===%s====%s", docFs.get(LOCALOBJECTID),
					sql.toString()));
			int count = jdbcTemplate.update(sql.toString(), args);

			if (count > 0) {
				iRet = true;
			} 

		} catch (Exception e) {
			LogUtil.logException(m_Logger, docFs.toString(), e);
		}

		return iRet;

	}

	@Override
	public boolean updateDocMigCtrl(String objectName, String objectId) {
		boolean iRet = false;
		try {
			StringBuilder sql = new StringBuilder(c360UpdateMigCtrl);
			LogUtil.logInfo(m_Logger,"EdaDaoImpl: updateDocMigCtrl sql=======" + sql.toString());
			int count = jdbcTemplate.update(sql.toString(), new Object[] { objectName, objectId });

			if (count > 0) {
				iRet = true;
			} 

		} catch (Exception e) {
			LogUtil.logException(m_Logger,objectId+"_"+objectName, e);
		}

		return iRet;
	}

	@Override
	public boolean selectC360DocAttr(String objectId) {
		boolean iRet = false;

		try {
			StringBuilder sql = new StringBuilder(c360SelectAttr);
			LogUtil.logInfo(m_Logger,"EdaDaoImpl: selectC360DocAttr sql=======" + sql.toString());
			int count = jdbcTemplate.queryForObject(sql.toString(), new Object[] { objectId }, Integer.class);

			if (count > 0) {
				iRet = true;
			} 

		} catch (Exception e) {
			LogUtil.logException(m_Logger,objectId, e);
		}

		return iRet;
	}

	@Override
	public Map<String, Object> selectE360DocAttr(String objectId) {

		Map<String, Object> retMap = null;

		try {
			StringBuilder sql = new StringBuilder(e360SelectAttr);
			LogUtil.logInfo(m_Logger,"EdaDaoImpl: selectE360DocAttr sql=======" + sql.toString());

			retMap = locatorJdbcTemplate.queryForMap(sql.toString(), new Object[] { objectId });

		} catch (Exception e) {
			LogUtil.logException(m_Logger,objectId, e);
		}

		return retMap;

	}

	@Override
	public BigDecimal saveToFileStore(WsSessionEJB wsEJB, String fileName, byte[] fileByte, String objectId)
			throws RemoteException {
		BigDecimal docId = new BigDecimal(0);
		// check if there is data in filestore
		Map<String, Object> retMap = selectC360FileStore(objectId);

		try {			
				if (retMap == null || retMap.isEmpty()) {
				//change for prod
			 	
				BigDecimal tempId = new BigDecimal(this.dataTableIds.getTemplateIds()
							.get(PropertyUtil.getTableIDProperty("TABLEID_UPLOADDOCUMENT")));
				docId = wsEJB.createFileStore(tempId);	 	
		} else {
			docId = retMap.get(LOCALDOCUMENTID) == null ? new BigDecimal(0) : (BigDecimal) retMap.get(LOCALDOCUMENTID);
		}

		wsEJB.putFile(docId, fileByte, fileName);
	 		
		}catch (RemoteException eq) {
			m_Logger.error(eq.toString());
		}catch (Exception e) {
			m_Logger.error(e.toString());
		}	
		LogUtil.logInfo(m_Logger,"EdaDaoImpl: saveToFileStore docId ======" + docId);

		return docId;
	}

	@Override
	public boolean insertEdaReport(Map<String, Object> reportInfo) {
		boolean iRet = false;
		try {
			StringBuilder sql = new StringBuilder(c360InsertEdaReport);
			Object args[] = new Object[] { reportInfo.get(LOCALOBJECTID), reportInfo.get("TIF_SIZE"),
					reportInfo.get("PDF_SIZE"), reportInfo.get("TIF_PAGES"), reportInfo.get("PDF_PAGES"),
					reportInfo.get("FILE_EXT"), reportInfo.get("GET_FIEL_SPENDTIME"),
					reportInfo.get("CONVERT_FIEL_SPENDTIME"), reportInfo.get("SAVE_FIELSTORE_SPENDTIME") };
			// need confirm IS_DELETED
			LogUtil.logInfo(m_Logger,String.format("EdaDaoImpl: insertEdaReport sql=======%s====%s", reportInfo.get(LOCALOBJECTID),
					sql.toString()));
			int count = jdbcTemplate.update(sql.toString(), args);

			if (count > 0) {
				iRet = true;
			} 
		} catch (Exception e) {
			LogUtil.logException(m_Logger,reportInfo.toString(), e);
		}

		return iRet;
	}

	public Map<String, Object> selectC360FileStore(String objectId) {

		Map<String, Object> retMap = null;

		try {
			StringBuilder sql = new StringBuilder(c360SelectFilestore);
			LogUtil.logInfo(m_Logger,"EdaDaoImpl: selectC360FileStore sql=======" + sql.toString());
			retMap = jdbcTemplate.queryForMap(sql.toString(), new Object[] { objectId });

		} catch (Exception e) {
			LogUtil.logException(m_Logger,objectId, e);  
		}

		return retMap;
	}

	@Override
	public boolean updateDocAttributes(String objectName, String objectId) {
		boolean iRet = false;
		try {
			StringBuilder sql = new StringBuilder(c360UpdateAttributes);
			LogUtil.logInfo(m_Logger,"EdaDaoImpl: updateDocAttributes sql=======" + sql.toString());
			int count = jdbcTemplate.update(sql.toString(), new Object[] { objectName, objectId });

			if (count > 0) {
				iRet = true;
			} 

		} catch (Exception e) {
			LogUtil.logException(m_Logger,objectId, e);  
		}

		return iRet;
	}

	@Override
	public boolean updateDocAttr(String objectName, String objectId) {
		boolean iRet = false;
		try {
			StringBuilder sql = new StringBuilder(c360UpdateAttr);
			LogUtil.logInfo(m_Logger,"EdaDaoImpl: updateDocAttr sql=======" + sql.toString());
			int count = jdbcTemplate.update(sql.toString(), new Object[] { objectName, objectId });

			if (count > 0) {
				iRet = true;
			} 

		} catch (Exception e) {
			LogUtil.logException(m_Logger,objectId, e);  
		}

		return iRet;
	}

	@Override
	public boolean updateDocLink(String objectId) {
		boolean iRet = false;
		try {
			StringBuilder sql = new StringBuilder(c360UpdateDoclink);
			LogUtil.logInfo(m_Logger,"EdaDaoImpl: updateDocLink sql=======" + sql.toString());
			int count = jdbcTemplate.update(sql.toString(), new Object[] { objectId });

			if (count > 0) {
				iRet = true;
			} 

		} catch (Exception e) {
			LogUtil.logException(m_Logger,objectId, e);  
		}

		return iRet;
	}

	@Override
	public boolean updateXFileStore(String objectId) {

		boolean iRet = false;
		try {
			StringBuilder sql = new StringBuilder(c360UpdateXFilestore);
			LogUtil.logInfo(m_Logger,"EdaDaoImpl: updateXFileStore sql=======" + sql.toString());
			int count = jdbcTemplate.update(sql.toString(), new Object[] { objectId });

			if (count > 0) {
				iRet = true;
			} 

		} catch (Exception e) {
			LogUtil.logException(m_Logger,objectId, e);  
		}

		return iRet;

	}

	@Override
	public boolean updateDocAttributesAll(Map<String, Object> docAttr) {

		boolean iRet = false;
		try {
			LogUtil.logInfo(m_Logger,"EdaDaoImpl: updateDocAttributes sql=======" + c360UpdateAttributes);
			Object args[] = new Object[] { docAttr.get(LOCALPAGEINDICATOR), docAttr.get("ReceivedDate"),
					docAttr.get("PolicyNo"), docAttr.get("BatchNo"), docAttr.get("BoxNo"), docAttr.get("FormId"),
					docAttr.get("OBJECT_NAME"), docAttr.get("CompanyNo"), docAttr.get("ProcessType"),
					docAttr.get("RequestNo"), docAttr.get(LOCALOBJECTID) };

			int count = jdbcTemplate.update(c360UpdateAttributesAll, args);

			if (count > 0) {
				iRet = true;
			} 

		} catch (Exception e) {
			LogUtil.logException(m_Logger,docAttr.toString(), e);  
			
		}

		return iRet;
	}

	@Override
	public boolean insertMigDemand(String objectId, String objectName) {
		boolean iRet =  false;
		try{
			int count = jdbcTemplate.update(c360InsertMigDemand, new Object[]{objectId,objectName});
			if(count>0){
				iRet = true;
			}else{
				iRet = false;
			}
		}catch(Exception e){
			LogUtil.logException(m_Logger, "insertMigDemand failed", e);
			iRet = false;
		}

		return iRet;
	}

	@Override
	public boolean selectMigDemand(String objectId) {
		boolean iRet =  false;
		
		try{
			int count = jdbcTemplate.queryForObject(c360SelectMigDemand, new Object[]{objectId}, Integer.class);

			if(count>0){
				iRet = true;
			}else{
				iRet = false;
			}
			
		}catch(Exception e){
			LogUtil.logException(m_Logger, "selectMigDemand failed", e);
			iRet = false;
		}
		
		return iRet;
	}

	@Override
	public boolean updateMigDemand(String objectId) {
		boolean iRet =  false;
		try{
			int count = jdbcTemplate.update(c360UpdateMigDemand, new Object[]{objectId});

			if(count>0){
				iRet = true;
			}else{
				iRet = false;
			}
			
		}catch(Exception e){
			LogUtil.logException(m_Logger, "updateMigDemand failed", e);
			iRet = false;
		}
	
		return iRet;
	}

}
