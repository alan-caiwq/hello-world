package com.aia.case360.ilClaim.dao;

import org.springframework.jdbc.core.JdbcTemplate;

/**
 * 
 * @author bsnpc0y IL integration DataSource
 */
public class ILDataSource {

	private static JdbcTemplate iLjdbcTemplate;
	private ILDataSource() {}

	public static JdbcTemplate getILjdbcTemplate() {
		return iLjdbcTemplate;
	}

}
