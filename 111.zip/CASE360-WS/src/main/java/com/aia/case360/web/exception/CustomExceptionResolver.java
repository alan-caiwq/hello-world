package com.aia.case360.web.exception;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.core.Ordered;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;

import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.web.service.impl.AbstractServiceImpl;

public class CustomExceptionResolver extends AbstractServiceImpl implements HandlerExceptionResolver,Ordered {
	
	private int order = Ordered.HIGHEST_PRECEDENCE;
	
	@Override
	public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, Object handler,
			Exception ex) {
		LogUtil.logInfo(m_Logger,"CustomExceptionResolver.resolveException() start");
		LogUtil.logInfo(m_Logger,"resolveException:" + ex.getMessage());
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("error");
		LogUtil.logInfo(m_Logger,"CustomExceptionResolver.resolveException() start");
		return modelAndView;
	}

	@Override
	public int getOrder() {
		return order;
	}
	
	public void setOrder(int order) {
		this.order = order;
	}
}
