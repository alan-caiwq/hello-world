package com.aia.case360.web.auditTrail;

import java.rmi.RemoteException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.aia.case360.platform.common.LogUtil;
import com.aia.case360.platform.security.UserHelper;
import com.aia.case360.web.dao.ReqtypeDao;
import com.aia.case360.web.pojo.FdReqTypeAuditTrail;

/**
 * 
 * @author bsnpbjd category- update, create.
 *
 */
@Component
public class RequesetTypeAuditTrailEngine extends AuditTrailEngine {

	@Autowired
	private ReqtypeDao reqtypeDao;
	@Autowired
	public UserHelper userHelper;

	@Override
	void saveAudit(Boolean isNew, String action, AuditTrail n) throws RemoteException {

		if (action != null && !"null".equals(action)) {

			FdReqTypeAuditTrail newRecord = new FdReqTypeAuditTrail();
			String currentUser = userHelper.getCurrentUser();
			newRecord.setCreated_by(currentUser);
			newRecord.setAction_desc(action);
			newRecord.setCategory(isNew ? "CREATE" : "UPDATE");
			newRecord.setCreated_timestamp((java.util.Date) new Date());
			newRecord.setReq_type(tableKeyString);
			reqtypeDao.addAuditTrail(newRecord);

			LogUtil.logInfo(m_Logger,tableKeyString + "saveAudit:" + action);
		}
	}
}
