package com.aia.case360.web.auditTrail.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * 
 * @author bsnpbjd
 * @version only the class annotated as AuditEntity will capture the Audit
 *          trail. otherwise, the field will be ignored.
 */
@Documented
@Retention(value = java.lang.annotation.RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface AuditEntity {
	// the entity name shows in audit trail.
	// 1. related entity.exmaple:[Activity:ACT1]Activity Name set to ACT1
	// 2. entity Created.exmaple:[Activity:ACT1]Activity Name set to ACT1
	String entityName();

	// not in user currently.
	String tableName();

	// not in user currently.
	String formDataName();
}
