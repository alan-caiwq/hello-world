package com.aia.case360.web.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.aia.case360.web.pojo.FdUniBuddyCheck;

@Repository
public interface UniBuddyCheckAdminDao {

	List<FdUniBuddyCheck> findBuddyCheckList(FdUniBuddyCheck buddyCheck);
	
	FdUniBuddyCheck findBuddyCheck(String sRowId);
	
	void addBuddyCheck(FdUniBuddyCheck buddyCheck);
	
	void updateBuddyCheck(FdUniBuddyCheck buddyCheck);
	
	void deleteBuddyCheck(FdUniBuddyCheck buddyCheck);
	
}