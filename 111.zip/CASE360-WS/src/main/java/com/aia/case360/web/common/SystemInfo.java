package com.aia.case360.web.common;

public class SystemInfo {

	private static boolean ilOnline_status = true;
	private SystemInfo() {
		
	}
	public static boolean isIlOnline_status() {
		return ilOnline_status;
	}

	public static void setIlOnline_status(boolean ilOnline_status) {
		SystemInfo.ilOnline_status = ilOnline_status;
	}

}
