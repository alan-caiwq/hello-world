package com.aia.case360.JalDocsInterfacesEx.vo;

public class ObjectNameDefVo {

	private String objectNameDef;

	private String conversion;

	private String length;

	/**
	 * @return Returns the conversion.
	 */
	public String getConversion() {
		return conversion;
	}

	/**
	 * @param conversion The conversion to set.
	 */
	public void setConversion(String conversion) {
		 this.conversion = conversion;
	}

	/**
	 * @return Returns the objNameDef.
	 */
	public String getObjectNameDef() {
		return objectNameDef;
	}

	/**
	 * @param objectNameDef The objectNameDef to set.
	 */
	public void setObjectNameDef(String objectNameDef) {
		this.objectNameDef = objectNameDef;
	}

	/**
	 * 
	 * @return
	 */
	public String getLength() {
		return length;
	}

	/**
	 * 
	 * @param length
	 */
	public void setLength(String length) {
		this.length = length;
	}
}
